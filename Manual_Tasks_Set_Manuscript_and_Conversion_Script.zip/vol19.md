---
title: "AI自律型サイバー防御システム 構築マニュアル 前編"
subtitle: "第19部　LLMに渡す情報を最小にする"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」前編の第19部です。第18部までで、Wazuh のアラートを AI（Ollama の qwen3:8b）で分析し、結果を SQLite に残せるようになりました。ここでは、**SQLite に何が残るか**と、**LLM に何を渡しているか**を確かめ、余計な情報を渡さないように直します。

1. SQLite のカラムと保存の処理を確かめる
2. LLM に送るイベントの項目を、決めた6項目だけにする
3. イベントのカテゴリを、決めた固定の値に置き換える
4. LLM に送るイベントの要約から、秘密の情報・メールアドレス・IPアドレスを伏せ字にする

元の Wazuh のイベントと SQLite の保存の仕様は変えません。

## 本書の表記

- コマンドやプログラムは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 実行先は **ai-defense-manager VM 230（root）** です。

# 第1章　保存と入力の点検

## 1.1　SQLiteのカラム

```bash
cd /opt/ai-defense-manager && runuser -u ai-defense -- ./venv/bin/python - <<'PY'
import sqlite3

db = "/opt/ai-defense-manager/data/ai-defense.db"
conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True)

for table in (
    "analysis_runs",
    "analysis_evidence",
    "action_proposals",
    "action_approvals",
    "audit_logs",
):
    print(f"\n[{table}]")
    for row in conn.execute(f"PRAGMA table_info({table})"):
        print(f"  {row[1]} ({row[2]})")

conn.close()
PY
```

Wazuh の `full_log`、任意の `data`、ユーザー名、コマンド、パスワードを保存するカラムはありません。中身を確かめる必要があるのは、AI が作った `summary`・`reasoning` と、Wazuh から来た `event_summary` です。

## 1.2　保存・取得・データモデル・分析のコード

```bash
sed -n '1,300p' /opt/ai-defense-manager/app/services/analysis_history.py
```

SQL はすべてプレースホルダーを使っていて、SQL インジェクションの対策はできています。

```bash
sed -n '1,320p' /opt/ai-defense-manager/app/services/wazuh_relay.py
```

`full_log`、任意の `data`、コマンド、パスワードは参照していません。ただし、`rule.description`（要約の元）と `decoder.name`／`location`（カテゴリの元）は外から来た文字列なので、思わぬ情報がまじる可能性は残ります。

```bash
cat /opt/ai-defense-manager/app/schemas/security_event.py
```

```bash
sed -n '1,360p' /opt/ai-defense-manager/app/services/ai_analysis.py
```

AI の分析のサービスには、次のよい点があります。

- イベントの説明やコンテキストを「信頼できないデータ」として扱うよう指示している
- JSON Schema で出力の形を決めている
- 証拠のイベントIDが入力に含まれるかを検証している
- 内部のIPの遮断を禁止し、遮断の提案には複数の証拠・グローバルIP・TTL 900秒まで・人の承認を求めている

一方、`request.model_dump(mode="json")` をそのまま LLM に渡しているため、分析に必要のない `agent_name`、`agent_id`、`rule_description`、IPアドレスなども送られています。

```bash
cat /opt/ai-defense-manager/app/schemas/analysis.py
```

| 項目 | 今のLLMへの送信 | SQLiteへの保存 |
|---|---|---|
| `event_id` | ○ | ○ |
| `source` | ○ | ○ |
| `observed_at` | ○ | ○ |
| `severity` | ○ | ○ |
| `rule_id` | ○ | ○ |
| `rule_description` | ○ | × |
| `source_ip`・`destination_ip` | ○ | × |
| `agent_id`・`agent_name` | ○ | × |
| `event_category` | ○ | × |
| `event_summary` | ○ | ○ |

# 第2章　LLMに送る項目を6つにする

## 2.1　バックアップ

```bash
cp -a /opt/ai-defense-manager/app/services/ai_analysis.py /root/ai-analysis-backup-20261121.py && sha256sum /opt/ai-defense-manager/app/services/ai_analysis.py /root/ai-analysis-backup-20261121.py
```

2つの SHA-256 が一致すれば、バックアップは正しく取れています。

## 2.2　送る項目を決める

LLM に送るのは、次の6項目と分析の言語だけにします。`agent_name`、`agent_id`、IPアドレス、`rule_description`、任意の `analysis_context` は送りません。

- `event_id`
- `observed_at`
- `severity`
- `rule_id`
- `event_category`
- `event_summary`

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
from pathlib import Path

path = Path("app/services/ai_analysis.py")
source = path.read_text(encoding="utf-8")

old = '''                "content": json.dumps(
                    request.model_dump(mode="json"),
                    ensure_ascii=False,
                ),'''

new = '''                "content": json.dumps(
                    {
                        "requested_language": request.requested_language,
                        "events": [
                            {
                                "event_id": str(event.event_id),
                                "observed_at": event.observed_at.isoformat(),
                                "severity": event.severity,
                                "rule_id": event.rule_id,
                                "event_category": event.event_category,
                                "event_summary": event.event_summary,
                            }
                            for event in request.events
                        ],
                    },
                    ensure_ascii=False,
                ),'''

if source.count(old) != 1:
    raise SystemExit("PATCH_ABORTED: expected source block not found exactly once")

path.write_text(source.replace(old, new), encoding="utf-8")
print("LLM_INPUT_ALLOWLIST_PATCH: OK")
PY
```

```bash
cd /opt/ai-defense-manager && ./venv/bin/python -m py_compile app/services/ai_analysis.py && echo "PY_COMPILE_OK"
```

## 2.3　コードの上での確認

ソースコードを解析し、送る項目が6つだけで、除いた項目の名前が出てこないことを確かめます。

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
import ast
import json
from pathlib import Path

source = Path("app/services/ai_analysis.py").read_text(encoding="utf-8")
tree = ast.parse(source)

expected = {
    "event_id",
    "observed_at",
    "severity",
    "rule_id",
    "event_category",
    "event_summary",
}

found = set()
for node in ast.walk(tree):
    if isinstance(node, ast.Dict):
        for key in node.keys:
            if isinstance(key, ast.Constant) and isinstance(key.value, str):
                if key.value in expected:
                    found.add(key.value)

assert found == expected, f"Unexpected allowlist: {found}"
assert "request.model_dump(mode=\"json\")" not in source
assert '"analysis_context"' not in source
assert '"agent_name"' not in source
assert '"agent_id"' not in source
assert '"source_ip"' not in source
assert '"destination_ip"' not in source
assert '"rule_description"' not in source

print("LLM_EVENT_FIELDS:", ", ".join(sorted(found)))
print("EXCLUDED_FIELDS_CHECK: OK")
print("LLM_PAYLOAD_ALLOWLIST_TEST: OK")
PY
```

## 2.4　実行して確かめる（モック）

既存のテストはありません。

```bash
cd /opt/ai-defense-manager && find . -maxdepth 3 -type f \( -name 'test_*.py' -o -name '*_test.py' \) -not -path './venv/*' -print | sort
```

```bash
cd /opt/ai-defense-manager && sed -n '1,260p' app/schemas/analysis_proposal.py && sed -n '1,220p' app/schemas/security_event.py
```

HTTP のクライアントを一時的に偽物（モック）に差し替え、実際に送られる内容を取り出して調べます。テスト用のイベントには、わざと除外する項目（`PRIVATE_...` やIPアドレス）を入れておき、それが送信の内容に入っていないことを確かめます。Ollama への通信、DB への書き込み、サービスの再起動は起きません。

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
import asyncio
import json
from datetime import datetime, timezone
from uuid import uuid4

import httpx

from app.schemas.analysis import AIAnalysisRequest
from app.schemas.security_event import SecurityEvent
from app.services import ai_analysis


event_id = uuid4()

request = AIAnalysisRequest(
    events=[
        SecurityEvent(
            event_id=event_id,
            source="wazuh",
            observed_at=datetime.now(timezone.utc),
            severity="high",
            rule_id="5710",
            rule_description="PRIVATE_RULE_DESCRIPTION",
            source_ip="203.0.113.10",
            destination_ip="198.51.100.20",
            agent_id="PRIVATE_AGENT_ID",
            agent_name="PRIVATE_AGENT_NAME",
            event_category="authentication",
            event_summary="Repeated authentication failures",
        )
    ],
    analysis_context="PRIVATE_ANALYSIS_CONTEXT",
    requested_language="ja",
)

captured = {}


class MockResponse:
    def raise_for_status(self):
        pass

    def json(self):
        return {
            "message": {
                "content": json.dumps({
                    "summary": "認証失敗イベントを検出",
                    "severity": "high",
                    "confidence": 0.9,
                    "evidence_event_ids": [str(event_id)],
                    "recommended_action": "human_review",
                    "target_ip": None,
                    "ttl_seconds": None,
                    "requires_human_approval": True,
                    "reasoning": "確認が必要です",
                })
            }
        }


class MockAsyncClient:
    def __init__(self, *args, **kwargs):
        pass

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        pass

    async def post(self, url, json):
        captured["url"] = url
        captured["payload"] = json
        return MockResponse()


async def main():
    original_client = ai_analysis.httpx.AsyncClient
    ai_analysis.httpx.AsyncClient = MockAsyncClient
    try:
        proposal = await ai_analysis.analyze_events(request)
    finally:
        ai_analysis.httpx.AsyncClient = original_client

    payload = captured["payload"]
    user_content = next(
        message["content"]
        for message in payload["messages"]
        if message["role"] == "user"
    )
    sent = json.loads(user_content)

    expected_fields = {
        "event_id",
        "observed_at",
        "severity",
        "rule_id",
        "event_category",
        "event_summary",
    }

    assert set(sent) == {"requested_language", "events"}
    assert set(sent["events"][0]) == expected_fields
    assert sent["events"][0]["event_id"] == str(event_id)
    assert sent["requested_language"] == "ja"

    serialized = json.dumps(sent, ensure_ascii=False)
    for secret in (
        "PRIVATE_RULE_DESCRIPTION",
        "PRIVATE_AGENT_ID",
        "PRIVATE_AGENT_NAME",
        "PRIVATE_ANALYSIS_CONTEXT",
        "203.0.113.10",
        "198.51.100.20",
    ):
        assert secret not in serialized, f"Excluded value leaked: {secret}"

    assert proposal.evidence_event_ids == [event_id]

    print("MOCK_HTTP_CALL: OK")
    print("SENT_EVENT_FIELDS:", ", ".join(sorted(sent["events"][0])))
    print("SENSITIVE_FIELD_EXCLUSION: OK")
    print("PROPOSAL_VALIDATION: OK")
    print("LLM_PAYLOAD_RUNTIME_TEST: OK")


asyncio.run(main())
PY
```

## 2.5　差分の確認と反映

```bash
diff -u /root/ai-analysis-backup-20261121.py /opt/ai-defense-manager/app/services/ai_analysis.py
```

変わっているのは、LLM に送る内容の部分だけです。サービスを再起動して反映します（API が少し止まります）。

```bash
systemctl restart ai-defense-manager.service && systemctl is-active ai-defense-manager.service
```

```bash
curl -sS -i http://127.0.0.1:8000/health
```

実際に Wazuh のイベントを取り、変更後の送り方で分析します。分析の結果は SQLite に記録されますが、ファイアウォールの変更や IP の遮断はしません。

```bash
curl -sS -i -X POST http://127.0.0.1:8000/api/v1/wazuh/analyze -H 'Content-Type: application/json' -d '{}'
```

構築時は `HTTP 200` で、Proxmox VE の認証成功のイベント7件を分析し、`severity: info`、`confidence: 0.9`、`recommended_action: no_action` が返りました。

```bash
cd /opt/ai-defense-manager && runuser -u ai-defense -- ./venv/bin/python - <<'PY'
import sqlite3

path = "/opt/ai-defense-manager/data/ai-defense.db"
db = sqlite3.connect(f"file:{path}?mode=ro", uri=True)

for table in (
    "analysis_runs",
    "analysis_evidence",
    "action_proposals",
    "action_approvals",
    "audit_logs",
):
    count = db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
    print(f"{table}: {count}")

latest = db.execute("""
    SELECT severity, recommended_action, evidence_count, status
    FROM analysis_runs
    ORDER BY created_at DESC
    LIMIT 1
""").fetchone()

print("LATEST_ANALYSIS:", latest)
db.close()
PY
```

構築時は `analysis_runs` が3件になり、最新の記録は `('info', 'no_action', 7, 'completed')` でした。

# 第3章　カテゴリと要約の中身を守る

## 3.1　どこに情報がまじるか

```bash
sed -n '1,320p' /opt/ai-defense-manager/app/services/wazuh_relay.py
```

- `description` → `event_summary`：最大512文字。そのまま LLM に送られる
- `decoder` か `location` → `event_category`：最大64文字。そのまま LLM に送られる。`location` はログの取り元なので、ファイルのパスやホストの情報が入ることがある

方針は次のとおりです。

1. `event_category` は、決めた固定のカテゴリに置き換える
2. `event_summary` は、API キー・トークン・パスワード・メールアドレス・IPアドレスなどを見つけて伏せ字にする
3. 伏せ字にした後も、長さの上限を守る
4. 元の Wazuh のイベントと SQLite の保存の処理は変えない

## 3.2　使えるライブラリ

```bash
cd /opt/ai-defense-manager && ls -la
```

```bash
cd /opt/ai-defense-manager && find tests -maxdepth 3 -type f -printf '%p\n' | sort && echo '--- REQUIREMENTS LOCK ---' && cat requirements.lock
```

依存関係は `requirements.lock` で管理しています。秘密の情報を見つける専用のライブラリはないので、Python の標準の `re` と `ipaddress` で作ります。

IPアドレスやメールアドレスを消してしまうと攻撃元の特定に必要な情報まで失うため、消さずに次の伏せ字に置き換えます。

| 情報 | 置き換え |
|---|---|
| API キー・Bearer トークン・パスワード | `[REDACTED_SECRET]` |
| メールアドレス | `[REDACTED_EMAIL]` |
| IPアドレス（内部・外部とも） | `[REDACTED_IP]` |
| 文字列でない入力など | `[REDACTED_EVENT]` |

## 3.3　実際のカテゴリを調べる

直近24時間の50件のカテゴリを数えます。

```bash
cd /opt/ai-defense-manager && runuser -u ai-defense -- ./venv/bin/python - <<'PY'
import asyncio
from collections import Counter
from app.services.wazuh_relay import fetch_wazuh_events

async def main():
    events = await fetch_wazuh_events(limit=50, since_minutes=1440)
    categories = Counter(event.event_category for event in events)
    print("EVENT_COUNT:", len(events))
    print("CATEGORY_COUNTS:")
    for category, count in sorted(categories.items()):
        print(f"{category!r}: {count}")

asyncio.run(main())
PY
```

構築時は5種類でした。これを次のように置き換えます。

| 今のカテゴリ | 件数 | LLMに送る値 |
|---|---:|---|
| `pvedaemon` | 34 | `virtualization_management` |
| `pam` | 11 | `authentication` |
| `sshd` | 2 | `remote_access` |
| `useradd` | 2 | `account_management` |
| `open-userdel` | 1 | `account_management` |
| それ以外 | — | `other` |

## 3.4　バックアップ

```bash
cd /opt/ai-defense-manager && cp -a app/services/wazuh_relay.py /root/wazuh-relay-backup-20261121.py && cp -a app/services/ai_analysis.py /root/ai-analysis-backup-privacy-20261121.py && sha256sum app/services/wazuh_relay.py /root/wazuh-relay-backup-20261121.py app/services/ai_analysis.py /root/ai-analysis-backup-privacy-20261121.py
```

4つの SHA-256 が2つずつ一致することを確かめます。

```bash
cd /opt/ai-defense-manager && sed -n '1,240p' app/services/wazuh_relay.py
```

```bash
cd /opt/ai-defense-manager && sed -n '1,280p' app/services/ai_analysis.py
```

## 3.5　カテゴリの固定

`wazuh_relay.py` で置き換えるので、LLM に送るときだけでなく、これから保存するイベントのカテゴリも固定の値になります。

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
from pathlib import Path

path = Path("app/services/wazuh_relay.py")
text = path.read_text(encoding="utf-8")

old = '''    category = (decoder or location or "wazuh")[:64]
    summary = (description or "Wazuh security alert")[:512]
'''

new = '''    raw_category = (decoder or location or "").strip().lower()
    category_map = {
        "pvedaemon": "virtualization_management",
        "pam": "authentication",
        "sshd": "remote_access",
        "useradd": "account_management",
        "open-userdel": "account_management",
    }
    category = category_map.get(raw_category, "other")
    summary = (description or "Wazuh security alert")[:512]
'''

if old not in text:
    raise SystemExit("PATCH_ABORTED: expected source block not found")

path.write_text(text.replace(old, new, 1), encoding="utf-8")
print("WAZUH_CATEGORY_ALLOWLIST_PATCH: OK")
PY
```

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
from datetime import datetime, timezone
from app.services.wazuh_relay import _convert_alert

cases = {
    "pvedaemon": "virtualization_management",
    "pam": "authentication",
    "sshd": "remote_access",
    "useradd": "account_management",
    "open-userdel": "account_management",
    "unknown-sensitive-hostname": "other",
}

for decoder, expected in cases.items():
    alert = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "rule.level": 5,
        "rule.id": "100001",
        "rule.description": "Test security event",
        "decoder.name": decoder,
    }
    event = _convert_alert(alert)
    assert event.event_category == expected, (
        decoder, event.event_category, expected
    )
    print(f"{decoder}: {event.event_category} OK")

print("PYTHON_COMPILE_AND_CATEGORY_TEST: OK")
PY
```

知らないデコーダーの名前も `other` になり、ホスト名などの任意の文字列がカテゴリに入らなくなります。

## 3.6　要約の伏せ字

`ai_analysis.py` に `_sanitize_event_summary()` を足し、LLM に送る直前の `event_summary` に使います。これは決まった形の情報を見つけるもので、知らない形の秘密の情報やユーザー名まで見つけられるわけではありません。完全な匿名化ではない点に注意してください。

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
from pathlib import Path

path = Path("app/services/ai_analysis.py")
text = path.read_text(encoding="utf-8")

if "def _sanitize_event_summary(" in text:
    raise SystemExit("PATCH_ABORTED: sanitizer already exists")

marker = "\n\nclass AIAnalysisError(Exception):\n    pass\n"

helper = r'''

def _sanitize_event_summary(value: str) -> str:
    """Redact common secrets and personal identifiers before LLM submission."""
    import ipaddress
    import re

    if not isinstance(value, str):
        return "[REDACTED_EVENT]"

    # Remove control characters that can interfere with prompt boundaries.
    value = "".join(
        char if char.isprintable() or char in "\t " else " "
        for char in value
    )

    # Authorization credentials.
    value = re.sub(
        r"(?i)\bBearer\s+[A-Za-z0-9._~+/=-]+",
        "Bearer [REDACTED_SECRET]",
        value,
    )

    # Common secret assignments.
    value = re.sub(
        r"""(?i)\b(?:password|passwd|pwd|secret|api[_-]?key|access[_-]?token|refresh[_-]?token)\b\s*[:=]\s*["']?[^\s,;"'<>]+""",
        "[REDACTED_SECRET]",
        value,
    )

    # Recognizable provider key formats.
    value = re.sub(r"\bAKIA[0-9A-Z]{16}\b", "[REDACTED_SECRET]", value)
    value = re.sub(
        r"\bgh[pousr]_[A-Za-z0-9]{20,}\b",
        "[REDACTED_SECRET]",
        value,
    )
    value = re.sub(r"\bsk-[A-Za-z0-9_-]{20,}\b", "[REDACTED_SECRET]", value)

    # Email addresses.
    value = re.sub(
        r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b",
        "[REDACTED_EMAIL]",
        value,
    )

    # Replace valid IPv4/IPv6 literals, leaving surrounding punctuation intact.
    candidates = re.compile(
        r"(?<![A-Za-z0-9_])(?:"
        r"(?:\d{1,3}\.){3}\d{1,3}"
        r"|"
        r"[0-9A-Fa-f:]{2,}"
        r")(?![A-Za-z0-9_])"
    )

    def redact_ip(match):
        candidate = match.group(0)
        try:
            ipaddress.ip_address(candidate)
        except ValueError:
            return candidate
        return "[REDACTED_IP]"

    value = candidates.sub(redact_ip, value)

    return value[:512] if value.strip() else "[REDACTED_EVENT]"
'''

if marker not in text:
    raise SystemExit("PATCH_ABORTED: insertion point not found")

text = text.replace(marker, helper + marker, 1)

old = '"event_summary": event.event_summary,'
new = '"event_summary": _sanitize_event_summary(event.event_summary),'

if old not in text:
    raise SystemExit("PATCH_ABORTED: event_summary payload field not found")

text = text.replace(old, new, 1)
path.write_text(text, encoding="utf-8")
print("LLM_SUMMARY_SANITIZER_PATCH: OK")
PY
```

貼り付けで端末の表示が崩れることがあるので、ファイルの中身を確かめます。

```bash
cd /opt/ai-defense-manager && sed -n '1,180p' app/services/ai_analysis.py
```

## 3.7　伏せ字のテスト

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
from app.services.ai_analysis import _sanitize_event_summary

cases = [
    ("Bearer abc.def-123", "Bearer [REDACTED_SECRET]"),
    ("password=hunter2", "[REDACTED_SECRET]"),
    ('password="my secret phrase"', "[REDACTED_SECRET]"),
    ("api_key: sk-abcdefghijklmnopqrstuvwxyz123456", "[REDACTED_SECRET]"),
    ("AWS AKIA1234567890ABCDEF", "[REDACTED_SECRET]"),
    ("GitHub ghp_abcdefghijklmnopqrstuvwxyz123456", "[REDACTED_SECRET]"),
    ("user admin@example.com login", "[REDACTED_EMAIL]"),
    ("connection from 203.0.113.10", "[REDACTED_IP]"),
    ("connection from 2001:db8::1", "[REDACTED_IP]"),
]

for source, expected in cases:
    result = _sanitize_event_summary(source)
    assert expected in result, (source, result, expected)
    print("REDACTION_TEST: OK")

normal = "SSH authentication failed for invalid user"
assert _sanitize_event_summary(normal) == normal
print("NORMAL_EVENT_PRESERVATION: OK")

assert _sanitize_event_summary(None) == "[REDACTED_EVENT]"
print("INVALID_INPUT_FAILSAFE: OK")

print("SANITIZER_TESTS: ALL PASSED")
PY
```

```bash
cd /opt/ai-defense-manager && ./venv/bin/python -m py_compile app/services/wazuh_relay.py app/services/ai_analysis.py && echo "PYTHON_COMPILE: OK"
```

## 3.8　送信の内容のテスト（モック）

```bash
cd /opt/ai-defense-manager && sed -n '1,240p' app/schemas/analysis.py && sed -n '1,240p' app/schemas/security_event.py && sed -n '1,260p' app/schemas/analysis_proposal.py
```

実際の `analyze_events()` を通し、Ollama に渡す JSON に秘密の情報が残っていないことを確かめます。Ollama への通信も SQLite への書き込みもしません。

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
import asyncio
import json
from datetime import datetime, timezone
from uuid import uuid4
from unittest.mock import patch

from app.schemas.analysis import AIAnalysisRequest
from app.schemas.security_event import SecurityEvent
from app.services.ai_analysis import analyze_events


event_id = uuid4()

event = SecurityEvent(
    event_id=event_id,
    source="wazuh",
    observed_at=datetime.now(timezone.utc),
    severity="high",
    rule_id="5710",
    rule_description="PRIVATE_RULE_DESCRIPTION",
    source_ip="203.0.113.10",
    destination_ip="198.51.100.20",
    agent_id="PRIVATE_AGENT_ID",
    agent_name="PRIVATE_AGENT_NAME",
    event_category="remote_access",
    event_summary=(
        "SSH login failed password=hunter2 "
        "user@example.com from 203.0.113.10"
    ),
)

request = AIAnalysisRequest(
    events=[event],
    analysis_context="PRIVATE_ANALYSIS_CONTEXT",
    requested_language="ja",
)

captured = {}

class FakeResponse:
    def raise_for_status(self):
        pass

    def json(self):
        return {
            "message": {
                "content": json.dumps({
                    "summary": "SSH authentication failure",
                    "severity": "high",
                    "confidence": 0.9,
                    "evidence_event_ids": [str(event_id)],
                    "recommended_action": "monitor",
                    "target_ip": None,
                    "ttl_seconds": None,
                    "requires_human_approval": True,
                    "reasoning": "Authentication failure detected",
                })
            }
        }


class FakeClient:
    def __init__(self, *args, **kwargs):
        pass

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        pass

    async def post(self, url, json):
        captured["url"] = url
        captured["payload"] = json
        return FakeResponse()


async def main():
    with patch("app.services.ai_analysis.httpx.AsyncClient", FakeClient):
        proposal = await analyze_events(request)

    assert proposal.recommended_action.value == "monitor"

    user_content = captured["payload"]["messages"][1]["content"]
    sent = json.loads(user_content)
    sent_event = sent["events"][0]

    expected_fields = {
        "event_id",
        "observed_at",
        "severity",
        "rule_id",
        "event_category",
        "event_summary",
    }
    assert set(sent_event) == expected_fields

    summary = sent_event["event_summary"]
    assert "[REDACTED_SECRET]" in summary
    assert "[REDACTED_EMAIL]" in summary
    assert "[REDACTED_IP]" in summary

    serialized = json.dumps(sent, ensure_ascii=False)
    forbidden = [
        "PRIVATE_RULE_DESCRIPTION",
        "PRIVATE_AGENT_ID",
        "PRIVATE_AGENT_NAME",
        "PRIVATE_ANALYSIS_CONTEXT",
        "203.0.113.10",
        "198.51.100.20",
        "hunter2",
        "user@example.com",
    ]
    for value in forbidden:
        assert value not in serialized, f"Sensitive value leaked: {value}"

    print("MOCK_HTTP_CALL: OK")
    print("LLM_EVENT_FIELDS: ", ", ".join(sorted(sent_event)))
    print("SECRET_REDACTION: OK")
    print("PRIVATE_FIELD_EXCLUSION: OK")
    print("PROPOSAL_VALIDATION: OK")
    print("LLM_PAYLOAD_RUNTIME_TEST: OK")


asyncio.run(main())
PY
```

## 3.9　引用符で囲んだ値を最後まで伏せる

3.6 の正規表現では、`password="my secret phrase"` のように引用符で囲んだ値が、空白の手前までしか伏せ字になりません。値が `"..."` や `'...'` のときは、引用符の中を丸ごと伏せるように、その1行だけを書き換えます。

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
from pathlib import Path

path = Path("app/services/ai_analysis.py")
lines = path.read_text(encoding="utf-8").splitlines()

matches = [
    i for i, line in enumerate(lines)
    if "refresh[_-]?token" in line and line.strip().startswith('r"""')
]

if len(matches) != 1:
    raise SystemExit(f"PATCH_ABORTED: expected one regex line, found {len(matches)}")

lines[matches[0]] = (
    r'''        r"""(?i)\b(?:password|passwd|pwd|secret|api[_-]?key|access[_-]?token|refresh[_-]?token)\b\s*[:=]\s*(?:"[^"]*"|'[^']*'|[^\s,;<>]+)""",'''
)

path.write_text("\n".join(lines) + "\n", encoding="utf-8")
print("QUOTED_SECRET_REDACTION_PATCH: OK")
PY
```

結果がまるごと `[REDACTED_SECRET]` になることを確かめます。

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
from app.services.ai_analysis import _sanitize_event_summary

cases = {
    'password="my secret phrase"': "[REDACTED_SECRET]",
    "password='another secret phrase'": "[REDACTED_SECRET]",
    "api_key=abc123": "[REDACTED_SECRET]",
    "password=hunter2": "[REDACTED_SECRET]",
}

for source, expected in cases.items():
    result = _sanitize_event_summary(source)
    assert result == expected, (
        f"FAIL source={source!r}, result={result!r}, expected={expected!r}"
    )
    print("EXACT_REDACTION: OK")

print("QUOTED_SECRET_TEST: ALL PASSED")
PY
```

## 3.10　差分の確認と反映

```bash
cd /opt/ai-defense-manager && diff -u /root/wazuh-relay-backup-20261121.py app/services/wazuh_relay.py; diff -u /root/ai-analysis-backup-privacy-20261121.py app/services/ai_analysis.py
```

`wazuh_relay.py` はカテゴリの置き換えだけ、`ai_analysis.py` は伏せ字の関数の追加と `event_summary` の加工だけが変わっていることを確かめます。伏せ字は LLM に送るときだけに使い、SQLite に保存する `event_summary` はこれまでどおりです（次の部で扱います）。

```bash
cd /opt/ai-defense-manager && ./venv/bin/python -m py_compile app/services/wazuh_relay.py app/services/ai_analysis.py && echo "FINAL_COMPILE: OK"
```

```bash
systemctl restart ai-defense-manager.service && systemctl is-active ai-defense-manager.service
```

```bash
curl -sS -i http://127.0.0.1:8000/health
```

```bash
curl -sS http://127.0.0.1:8000/api/v1/wazuh/events?limit=5\&since_minutes=60
```

構築時は5件すべての `event_category` が `virtualization_management` になっていました。この API はイベントを取って返すもので、`agent_id` や `agent_name` も含まれますが、LLM には送りません。

# おわりに

第19部で、LLM に渡す情報を次のように絞りました。

| 対策 | 内容 |
|---|---|
| 送る項目 | 6項目と分析の言語だけ |
| カテゴリ | 固定の値（知らないものは `other`） |
| 要約 | 秘密の情報・メールアドレス・IPアドレスを伏せ字にしてから送る |

次の部では、AI の分析が失敗する問題を直し、SQLite に保存する要約にも伏せ字を使います。
