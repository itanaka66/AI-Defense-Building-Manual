---
title: "AI自律型サイバー防御システム 構築マニュアル 中編"
subtitle: "第30部　Collectorが同じ理由で止まらないようにする"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」中編の第30部です。第28部・第29部で、Collector は試験用の隠しディレクトリ（`.acl-inheritance-test.bkv8vd`）に入れずに止まっていたことを突き止め、読み取り位置を直して動かし直しました。ただし、このディレクトリは残っているため、次にファイルが切り替わったときにまた止まるおそれがあります。

ここでは、ディレクトリを消したり Collector の権限を広げたりするのではなく、**前のファイルを探すときに、名前が `.` で始まるディレクトリ（隠しディレクトリ）を探さない**ように、Collector のコードを2行だけ直します。

- 本物のアラートの置き場（`2026/Nov` など）は、これまでどおり探す
- ふつうのディレクトリに入れないときのエラーは、これまでどおり止まる（握りつぶさない）
- シンボリックリンクをたどらない作りは変えない

最後に、ログの切り替え（ローテーション）のときの処理と、状態ファイル・重複の扱いをコードで確かめます。

## 本書の表記

- コマンドやプログラムは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 実行先は、各手順の「実行先」に示します。
  - **VM 220**：security-core（root）
  - **postgresql**：LXC 109（192.168.0.151）。OS のユーザー `postgres`

# 第1章　隠しディレクトリの正体

> **実行先：VM 220**

```bash
find /var/ossec/logs/alerts/.acl-inheritance-test.bkv8vd -maxdepth 5 -printf '%y %M %u:%g %s bytes %TY-%Tm-%Td %TH:%TM:%TS %p\n'
```

2026年11月18日に作られ、すべて `root:root`、中は `2027/Jan/test.json`（0バイト）だけでした。前編 第6部で ACL の継承を試したときに作ったものです。作ったスクリプトが残っていないかを探します。

```bash
grep -R -n -F --exclude='*.pyc' --exclude='*.log' '.acl-inheritance-test' /root /usr/local /etc 2>/dev/null | head -n 40
```

0件でした。ACL を見ます。

```bash
getfacl -p /var/ossec/logs/alerts /var/ossec/logs/alerts/.acl-inheritance-test.bkv8vd /var/ossec/logs/alerts/.acl-inheritance-test.bkv8vd/2027 /var/ossec/logs/alerts/.acl-inheritance-test.bkv8vd/2027/Jan /var/ossec/logs/alerts/.acl-inheritance-test.bkv8vd/2027/Jan/test.json
```

いちばん上のディレクトリだけ、次の状態でした（要点）。

```text
user:wazuh-collector:r-x
mask::---
effective:---
```

ACL の項目はあるものの、マスクが `---` のため、実際には入れません。

# 第2章　探す処理を直す

## 2.1　今のコード

```bash
sed -n '300,365p' /usr/local/lib/wazuh-collector/collector.py
```

`find_inode_file()` は、次の部分で、隠しディレクトリも含めてすべてのディレクトリを探す対象に入れていました。

```text
if entry.is_dir(follow_symlinks=False):
    pending.append(Path(entry.path))
    continue
```

`alerts` の直下と、本物の置き場の形を確かめます。

```bash
find /var/ossec/logs/alerts -mindepth 1 -maxdepth 1 -type d -printf '%f\n'
```

```bash
find /var/ossec/logs/alerts/2026 -type d -printf '%P\n' | head -50
```

直下のディレクトリは `2026` と `.acl-inheritance-test.bkv8vd` の2つで、本物は `2026/Nov` でした。隠しディレクトリを除いても、本物は探せます。

```bash
stat -c '%A %U:%G %s bytes %y %n' /usr/local/lib/wazuh-collector/collector.py && python3 -m py_compile /usr/local/lib/wazuh-collector/collector.py
```

```bash
sed -n '365,455p' /usr/local/lib/wazuh-collector/collector.py
```

`open_initial_file()` は、前のファイルが見つからなければ起動を止めます。この安全策は変えません。変えるのは次の形です。

```text
if entry.is_dir(follow_symlinks=False):
    if entry.name.startswith("."):
        continue
    pending.append(Path(entry.path))
    continue
```

## 2.2　バックアップ

動いている Collector には触れずに、ファイルのバックアップを取ります。

```bash
cp -a /usr/local/lib/wazuh-collector/collector.py /usr/local/lib/wazuh-collector/collector.py.pre-hidden-dir-fix-20261121 && sha256sum /usr/local/lib/wazuh-collector/collector.py /usr/local/lib/wazuh-collector/collector.py.pre-hidden-dir-fix-20261121
```

2つの SHA-256 が同じであることを確かめます。

## 2.3　直す

直す場所がちょうど1か所あるときだけ書き換えます。

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/usr/local/lib/wazuh-collector/collector.py")
source = path.read_text()

old = '''                if entry.is_dir(follow_symlinks=False):
                    pending.append(Path(entry.path))
                    continue
'''

new = '''                if entry.is_dir(follow_symlinks=False):
                    if entry.name.startswith("."):
                        continue
                    pending.append(Path(entry.path))
                    continue
'''

count = source.count(old)
if count != 1:
    raise SystemExit(f"安全確認失敗: 対象コードが {count} 件。変更していません")

path.write_text(source.replace(old, new, 1))
print("修正完了: 隠しディレクトリを探索対象から除外")
PY
```

```bash
python3 -m py_compile /usr/local/lib/wazuh-collector/collector.py && diff -u /usr/local/lib/wazuh-collector/collector.py.pre-hidden-dir-fix-20261121 /usr/local/lib/wazuh-collector/collector.py
```

差分は `if entry.name.startswith("."):` と `continue` の2行だけでした。

## 2.4　Collectorのユーザーで試す

`find_inode_file()` だけを取り出し、Collector のユーザーで、存在しない inode を探させます。隠しディレクトリに入れなくても、`None`（見つからない）を返して正常に終われば成功です。DB には接続しません。

```bash
runuser -u wazuh-collector -- python3 - <<'PY'
import ast
import os
from pathlib import Path

source_path = "/usr/local/lib/wazuh-collector/collector.py"
source = Path(source_path).read_text()
tree = ast.parse(source)

function = next(
    node for node in tree.body
    if isinstance(node, ast.FunctionDef)
    and node.name == "find_inode_file"
)

namespace = {
    "os": os,
    "Path": Path,
    "ALERT_DIR": Path("/var/ossec/logs/alerts"),
}

exec(compile(ast.Module(body=[function], type_ignores=[]), source_path, "exec"), namespace)

result = namespace["find_inode_file"](9223372036854775807)

print("RESULT:", result)
print("TEST: PASS" if result is None else "TEST: UNEXPECTED MATCH")
PY
```

`TEST: PASS` でした。

# 第3章　反映する

## 3.1　再起動

```bash
systemctl show wazuh-collector.service -p MainPID -p NRestarts -p ActiveState -p SubState
```

今のプロセス（PID 13542）は直す前のコードで動いています。再起動して読み込ませます。再起動のあいだは少しだけ収集が止まりますが、状態ファイルの位置から続けます。

```bash
systemctl restart wazuh-collector.service
```

```bash
systemctl show wazuh-collector.service -p MainPID -p NRestarts -p ActiveState -p SubState
```

構築時は PID 14203、`NRestarts=0`、`active`・`running` でした。

```bash
journalctl -u wazuh-collector.service -n 30 --no-pager
```

```bash
journalctl -u wazuh-collector.service --since "2026-11-21 11:09:00" --no-pager
```

`Resuming current alert file` があり、隠しディレクトリの `PermissionError` は出ていませんでした。

## 3.2　PostgreSQLの接続のログがない

```bash
systemctl status wazuh-collector.service --no-pager -l
```

```bash
sed -n '500,570p' /usr/local/lib/wazuh-collector/collector.py
```

Collector は、**読んでいない行が来たときに初めて** PostgreSQL につなぎます。最後まで読み終えていて、新しいアラートが来ていなければ、接続のログは出ません。

```bash
python3 - <<'PY'
import json, os
state_path = "/var/lib/wazuh-collector/state.json"
alert_path = "/var/ossec/logs/alerts/alerts.json"

with open(state_path) as f:
    state = json.load(f)

st = os.stat(alert_path)

print("STATE_INODE:", state["inode"])
print("STATE_OFFSET:", state["offset"])
print("CURRENT_INODE:", st.st_ino)
print("CURRENT_SIZE:", st.st_size)
print("INODE_MATCH:", state["inode"] == st.st_ino)
print("OFFSET_AT_EOF:", state["offset"] == st.st_size)
print("UNPROCESSED_BYTES:", max(0, st.st_size - state["offset"]) if state["inode"] == st.st_ino else "inode mismatch")
PY
```

```bash
stat -c 'ALERT_FILE_SIZE=%s MODIFIED=%y INODE=%i' /var/ossec/logs/alerts/alerts.json && journalctl -u wazuh-collector.service --since "2026-11-21 11:09:11 UTC" --no-pager
```

読み残しは0で、`alerts.json` は再起動の前から更新されていませんでした。

## 3.3　接続の確認

Collector のユーザーで、Collector と同じ接続の設定（`DB_CONFIG`）を使い、`SELECT 1` だけを実行します。接続の情報は表示しません。

```bash
runuser -u wazuh-collector -- python3 - <<'PY'
import importlib.util
from pathlib import Path

path = Path("/usr/local/lib/wazuh-collector/collector.py")
spec = importlib.util.spec_from_file_location("collector_check", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

try:
    with module.psycopg.connect(**module.DB_CONFIG) as connection:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            result = cursor.fetchone()[0]
    print("POSTGRESQL_READ_ONLY_TEST:", "PASS" if result == 1 else "FAIL")
except Exception as error:
    print("POSTGRESQL_READ_ONLY_TEST: FAIL")
    print("ERROR_TYPE:", type(error).__name__)
PY
```

`POSTGRESQL_READ_ONLY_TEST: PASS` でした。しばらくして、新しいアラートが来たあとのログを見ます。

```bash
journalctl -u wazuh-collector.service --since "2026-11-21 11:09:11 UTC" --no-pager | grep -E 'ERROR|WARNING|PostgreSQL connection established|Alert processing failed|Duplicate alert skipped'
```

```text
Nov 21 11:12:08
INFO PostgreSQL connection established
```

> **実行先：postgresql**（OS のユーザー `postgres`。すでに `postgres` で入っているので `sudo` は使いません）

```bash
psql -d security_workbench -c "SELECT COUNT(*) AS recent_events, COUNT(DISTINCT event_id) AS distinct_events, MAX(ingested_at) AS latest_ingested_at FROM incident.alert_events WHERE ingested_at >= TIMESTAMPTZ '2026-11-21 11:09:11+00';"
```

再起動のあとに3件（異なる `event_id` も3件）が保存されていました。

# 第4章　ローテーションの処理の確認

> **実行先：VM 220**

```bash
sed -n '550,735p' /usr/local/lib/wazuh-collector/collector.py
```

| 状況 | Collector の動き |
|---|---|
| ふつうの行 | PostgreSQL に保存してから位置を保存する |
| PostgreSQL につながらない・保存に失敗 | 行の頭に戻ってやり直す |
| ファイルの最後が途中の行 | 切り替わるのを待つ |
| 途中の行のまま切り替わった | その行を捨てて、新しい inode に切り替える |
| 最後まで読んで切り替わった | 新しい inode に切り替える |
| 位置の保存に失敗 | 新しいファイルに切り替えずにやり直す |

```bash
grep -n -A75 -B10 '^def save_state\|^def load_state\|^def read_alert_line' /usr/local/lib/wazuh-collector/collector.py
```

`save_state()` は、同じディレクトリの一時ファイルに `0600` で書き、`flush()` と `fsync()` をしてから `os.replace()` で置き換え、ディレクトリも `fsync()` します。処理の順番は次のとおりです。

```text
PostgreSQL INSERT
       ↓
トランザクション確定
       ↓
save_state(inode, offset)
```

```bash
grep -n -A45 -B15 'INSERT_SQL\|event_id' /usr/local/lib/wazuh-collector/collector.py | head -120
```

`event_id` は Wazuh のアラートの `alert["id"]` で、重複（SQLSTATE `23505`）だけを「すでにある」として扱います。INSERT を確定してから位置を進めるので、保存と位置の保存のあいだで止まって同じ行を読み直しても、二重には登録されません。

# おわりに

第30部で、Collector が隠しディレクトリで止まらないようにしました。

| 項目 | 結果 |
|---|---|
| 直したところ | `find_inode_file()` で、名前が `.` で始まるディレクトリを探さない（2行） |
| バックアップ | `collector.py.pre-hidden-dir-fix-20261121` |
| 試験 | Collector のユーザーで `TEST: PASS` |
| 反映 | 再起動して `NRestarts=0`、PostgreSQL への保存も確認 |
| 隠しディレクトリ | 消していない（残っていても Collector は止まらない） |

構築時は、このあと Wazuh のログの切り替えが `copytruncate` かどうかなど、ローテーションの方式の確認に進みましたが、その結果は受け取った記録の範囲にはありません（不足情報メモ 30-B）。
