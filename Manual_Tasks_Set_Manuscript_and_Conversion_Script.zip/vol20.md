---
title: "AI自律型サイバー防御システム 構築マニュアル 前編"
subtitle: "第20部　信頼度の修正と保存データの保護"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」前編の第20部です。第19部の後、実際の Wazuh のイベントで分析すると失敗する（`502`）ことがわかりました。ここでは次のことを行います。

1. 分析が失敗する原因（AI が信頼度を 0〜100 で返す）を調べて直す
2. 第19部の伏せ字の処理を共通のモジュールに移し、SQLite に保存するときにも使う
3. 保存済みの履歴・DB のファイル・サービスの設定・待ち受けのポートを点検する

## 本書の表記

- コマンドやプログラムは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 実行先は **ai-defense-manager VM 230（root）** です。

# 第1章　分析が失敗する原因

## 1.1　症状

第19部の最後に、カテゴリが置き換わったことは確かめました。続けて AI の分析を実行します。

```bash
curl -fsS http://127.0.0.1:8000/openapi.json | python3 -c 'import json,sys; d=json.load(sys.stdin); p=d["paths"]["/api/v1/wazuh/analyze"]["post"]; print(json.dumps({"summary":p.get("summary"),"requestBody":p.get("requestBody"),"responses":p.get("responses")},ensure_ascii=False,indent=2))'
```

```bash
curl -fsS http://127.0.0.1:8000/openapi.json | python3 -c 'import json,sys; d=json.load(sys.stdin); print(json.dumps(d["components"]["schemas"]["WazuhAnalysisRequest"],ensure_ascii=False,indent=2))'
```

```bash
curl -sS -X POST http://127.0.0.1:8000/api/v1/wazuh/analyze \
  -H 'Content-Type: application/json' \
  -d '{"limit":5,"since_minutes":60,"requested_language":"ja"}'
```

構築時は `{"detail":"AI analysis failed or returned an invalid response"}`（`502`）が返りました。

## 1.2　ログと接続先

```bash
journalctl -u ai-defense-manager.service --since "5 minutes ago" --no-pager -n 100
```

ログには、`/health` とイベントの取得は `200`、分析は `502` と記録されていますが、Python の例外の詳しい内容は出ません（外に詳しいことを出さない作りのため）。

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
from app.core.config import settings

for name in ("ollama_base_url", "ollama_url", "ollama_host", "ollama_model"):
    if hasattr(settings, name):
        print(f"{name}: {getattr(settings, name)}")
PY
```

接続先は `http://192.168.0.180:11434/` でした。VM 230 から Ollama に届くかを確かめます。

```bash
curl -sS --connect-timeout 5 --max-time 10 http://192.168.0.180:11434/api/tags
```

モデルの一覧が返り、`qwen3:8b` があることがわかりました。ネットワークの問題ではありません。

## 1.3　モデルとスキーマ

```bash
cd /opt/ai-defense-manager && grep -nE 'model|format|json_schema|response_format|ollama' app/services/ai_analysis.py
```

```bash
cd /opt/ai-defense-manager && sed -n '1,165p' app/services/ai_analysis.py
```

モデルの名前は `qwen3:8b` で、Ollama にあるものと一致しています。API は Ollama の `/api/chat` で、出力の形は `AIAnalysisProposal.model_json_schema()` で指定し、返事は Pydantic の `model_validate()` で検証しています。

```bash
cd /opt/ai-defense-manager && sed -n '1,240p' app/schemas/analysis_proposal.py
```

| 項目 | 制約 |
|---|---|
| `summary` | 1〜2000文字 |
| `severity` | `info`・`low`・`medium`・`high`・`critical` |
| `confidence` | 0.0〜1.0 |
| `evidence_event_ids` | 1〜100件（必須） |
| `reasoning` | 1〜4000文字 |

## 1.4　Ollamaに直接聞く

アプリの DB には書き込まず、同じスキーマで Ollama に直接たずねます。

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
import httpx, json
from app.schemas.analysis_proposal import AIAnalysisProposal

payload = {
    "model": "qwen3:8b",
    "stream": False,
    "think": False,
    "format": AIAnalysisProposal.model_json_schema(),
    "messages": [{"role": "user", "content": "Return a valid JSON proposal. Use event ID 11111111-1111-4111-8111-111111111111. Choose no_action and provide all required fields."}]
}

try:
    r = httpx.post("http://192.168.0.180:11434/api/chat", json=payload, timeout=180)
    print("HTTP_STATUS:", r.status_code)
    print("RESPONSE:", r.text[:4000])
except Exception as e:
    print("ERROR:", type(e).__name__, str(e))
PY
```

構築時は `HTTP_STATUS: 200` で JSON も返りましたが、その中が `"confidence": 100` でした。スキーマは 0.0〜1.0 なので、`100` は検証で失敗します。これが `502` の原因です。

# 第2章　信頼度の指示を足す

## 2.1　SYSTEM_PROMPTの修正

Pydantic の制約（0.0〜1.0）は変えず、AI への指示（`SYSTEM_PROMPT`）に、信頼度は小数で答えるという3行を足します。バックアップも取ります。

```bash
cd /opt/ai-defense-manager && cp -a app/services/ai_analysis.py /root/ai-analysis-backup-confidence-20261121.py && ./venv/bin/python - <<'PY'
from pathlib import Path

path = Path("app/services/ai_analysis.py")
source = path.read_text()

old = """Return exactly one JSON object matching the supplied JSON Schema.

Never recommend blocking private, local, or internal IP addresses."""

new = """Return exactly one JSON object matching the supplied JSON Schema.

The confidence field must be a decimal number between 0.0 and 1.0.
Never express confidence as a percentage from 0 to 100.
For example, use 0.85 instead of 85.

Never recommend blocking private, local, or internal IP addresses."""

if source.count(old) != 1:
    raise SystemExit("ERROR: Expected prompt section not found exactly once. No changes made.")

path.write_text(source.replace(old, new))
print("SYSTEM_PROMPT_UPDATE: OK")
PY
diff -u /root/ai-analysis-backup-confidence-20261121.py app/services/ai_analysis.py
```

差分は、指示の3行の追加だけです。

```bash
cd /opt/ai-defense-manager && ./venv/bin/python -m py_compile app/services/ai_analysis.py && echo "CONFIDENCE_PROMPT_COMPILE: OK"
```

## 2.2　修正した指示で確かめる

修正した `SYSTEM_PROMPT` を使って Ollama に聞き、返事を実際のスキーマで検証します。SQLite への保存もサービスの再起動もしません。

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
import httpx, json
from app.services.ai_analysis import SYSTEM_PROMPT
from app.schemas.analysis_proposal import AIAnalysisProposal

payload = {
    "model": "qwen3:8b",
    "stream": False,
    "think": False,
    "format": AIAnalysisProposal.model_json_schema(),
    "messages": [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": "Return a valid harmless test proposal. Use event ID 11111111-1111-4111-8111-111111111111. Choose no_action and provide all required fields."}
    ]
}

try:
    r = httpx.post("http://192.168.0.180:11434/api/chat", json=payload, timeout=180)
    print("HTTP_STATUS:", r.status_code)
    r.raise_for_status()
    content = r.json()["message"]["content"]
    print("MODEL_RESPONSE:", content)
    proposal = AIAnalysisProposal.model_validate_json(content)
    print("SCHEMA_VALIDATION: OK")
    print("CONFIDENCE:", proposal.confidence)
except Exception as e:
    print("ERROR:", type(e).__name__, str(e))
PY
```

構築時は `"confidence": 0.95` が返り、`SCHEMA_VALIDATION: OK` になりました。

## 2.3　反映

```bash
systemctl restart ai-defense-manager.service && systemctl is-active ai-defense-manager.service
```

```bash
curl -sS -i http://127.0.0.1:8000/health
```

実際の Wazuh のイベント5件で分析します。結果は SQLite に保存されます。

```bash
curl -sS -i -X POST http://127.0.0.1:8000/api/v1/wazuh/analyze \
  -H 'Content-Type: application/json' \
  -d '{"limit":5,"since_minutes":60,"requested_language":"ja"}'
```

構築時の結果は次のとおりです。認証の成功だけでは不正なアクセスと決められないため、すぐに遮断するのではなく「監視」をすすめる、安全側の判断でした。

| 項目 | 結果 |
|---|---|
| HTTP | `200 OK` |
| `severity` | `info` |
| `confidence` | `0.85` |
| `recommended_action` | `monitor` |
| `target_ip`・`ttl_seconds` | `null` |
| `requires_human_approval` | `true` |

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
import sqlite3

db = sqlite3.connect(
    "file:/opt/ai-defense-manager/data/ai-defense.db?mode=ro",
    uri=True
)

for table in (
    "analysis_runs",
    "analysis_evidence",
    "action_proposals",
    "action_approvals",
    "audit_logs",
):
    count = db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
    print(f"{table}: {count}")

db.close()
print("DATABASE_READ_ONLY_CHECK: OK")
PY
```

構築時は `analysis_runs` が4件、`analysis_evidence` が28件になりました。

# 第3章　保存する要約にも伏せ字を使う

## 3.1　今の作り

```bash
cd /opt/ai-defense-manager && grep -R -n -C 5 "event_summary" app/services app/api
```

```bash
cd /opt/ai-defense-manager && sed -n '1,65p' app/services/analysis_history.py && sed -n '150,195p' app/services/analysis_history.py && sed -n '1,100p' app/services/ai_analysis.py
```

LLM に送るときは `_sanitize_event_summary()` で伏せ字にしていますが、SQLite に保存するときは `event.event_summary` をそのまま書いています。

```bash
cd /opt/ai-defense-manager && grep -R -n "analysis_history\|ai_analysis" app --include="*.py"
```

```bash
cd /opt/ai-defense-manager && grep -n "_sanitize_event_summary" app/services/ai_analysis.py
```

`analysis_history.py` と `ai_analysis.py` は、お互いを読み込んでいません。片方からもう片方を読み込む形にはせず、伏せ字の関数を新しい `app/services/event_sanitizer.py` に移し、2か所から使います。既存の SQLite のデータは変えず、これから保存する分だけを守ります。

## 3.2　バックアップ

```bash
cd /opt/ai-defense-manager && mkdir -p /root/ai-defense-backup-privacy-sqlite-20261121 && cp -a app/services/ai_analysis.py app/services/analysis_history.py /root/ai-defense-backup-privacy-sqlite-20261121/ && sha256sum app/services/ai_analysis.py app/services/analysis_history.py
```

```bash
cd /opt/ai-defense-manager && sed -n '30,100p' app/services/ai_analysis.py
```

## 3.3　共通のモジュールに移す

関数の中身（伏せ字のきまり）は変えず、名前を `sanitize_event_summary()` にして移します。

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
from pathlib import Path

base = Path("/opt/ai-defense-manager/app/services")
ai_path = base / "ai_analysis.py"
history_path = base / "analysis_history.py"
sanitizer_path = base / "event_sanitizer.py"

ai = ai_path.read_text()
history = history_path.read_text()

start = ai.index("def _sanitize_event_summary(value: str) -> str:")
end = ai.index("\n\nclass AIAnalysisError", start)

function = ai[start:end]
function = function.replace(
    "def _sanitize_event_summary(value: str) -> str:",
    "def sanitize_event_summary(value: str) -> str:",
    1,
)
function = function.replace(
    "before LLM submission.",
    "before storage or LLM submission.",
    1,
)

assert ai.count("_sanitize_event_summary(event.event_summary)") == 1
assert history.count("                    event.event_summary,") == 1
assert not sanitizer_path.exists()

sanitizer_path.write_text(
    '"""Shared sanitization for security event summaries."""\n\n'
    + function
    + "\n"
)

ai = ai[:start] + ai[end + 2:]
ai = ai.replace(
    "from app.schemas.analysis import AIAnalysisRequest",
    "from app.services.event_sanitizer import sanitize_event_summary\n"
    "from app.schemas.analysis import AIAnalysisRequest",
    1,
)
ai = ai.replace(
    "_sanitize_event_summary(event.event_summary)",
    "sanitize_event_summary(event.event_summary)",
    1,
)

history = history.replace(
    "from uuid import uuid4",
    "from uuid import uuid4\n\n"
    "from app.services.event_sanitizer import sanitize_event_summary",
    1,
)
history = history.replace(
    "                    event.event_summary,",
    "                    sanitize_event_summary(event.event_summary),",
    1,
)

ai_path.write_text(ai)
history_path.write_text(history)

print("SANITIZER_MODULE_CREATED: OK")
print("LLM_SANITIZATION_CONNECTED: OK")
print("SQLITE_SANITIZATION_CONNECTED: OK")
PY
```

```bash
cd /opt/ai-defense-manager && ./venv/bin/python -m py_compile app/services/event_sanitizer.py app/services/ai_analysis.py app/services/analysis_history.py && echo "PRIVACY_SANITIZER_COMPILE: OK"
```

## 3.4　伏せ字のテスト

実際のデータは使わず、作ったデータで確かめます。

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
from app.services.event_sanitizer import sanitize_event_summary

tests = {
    "bearer": ("Bearer abc.def_123", "[REDACTED_SECRET]"),
    "password": ("password='my secret value'", "[REDACTED_SECRET]"),
    "api_key": ("api_key=example-secret-123", "[REDACTED_SECRET]"),
    "aws": ("AKIAIOSFODNN7EXAMPLE", "[REDACTED_SECRET]"),
    "github": ("ghp_abcdefghijklmnopqrstuvwxyz123456", "[REDACTED_SECRET]"),
    "openai": ("sk-abcdefghijklmnopqrstuvwxyz123456", "[REDACTED_SECRET]"),
    "email": ("user@example.com", "[REDACTED_EMAIL]"),
    "ipv4": ("source=203.0.113.10", "[REDACTED_IP]"),
    "ipv6": ("source=2001:db8::1", "[REDACTED_IP]"),
}

for name, (source, expected) in tests.items():
    result = sanitize_event_summary(source)
    assert expected in result, (name, result)
    assert source not in result, (name, result)
    print(f"{name}: OK -> {result}")

normal = "Multiple authentication failures detected"
assert sanitize_event_summary(normal) == normal
print("normal_text: OK")

assert sanitize_event_summary(None) == "[REDACTED_EVENT]"
print("invalid_input: OK")

control = sanitize_event_summary("event\x00summary")
assert "\x00" not in control
print("control_characters: OK")

print("SANITIZER_TESTS: ALL PASSED")
PY
```

## 3.5　差分の確認

`/opt/ai-defense-manager` は Git で管理していないので、3.2 のバックアップと比べます。

```bash
cd /opt/ai-defense-manager && diff -u /root/ai-defense-backup-privacy-sqlite-20261121/ai_analysis.py app/services/ai_analysis.py; diff -u /root/ai-defense-backup-privacy-sqlite-20261121/analysis_history.py app/services/analysis_history.py; echo "----- SHARED SANITIZER -----"; sed -n '1,120p' app/services/event_sanitizer.py
```

- `ai_analysis.py`：共通の関数を使っている
- `analysis_history.py`：SQLite に INSERT する直前に伏せ字にしている
- `event_sanitizer.py`：伏せ字のきまりは元のまま

## 3.6　一時的なDBで保存を確かめる

```bash
cd /opt/ai-defense-manager && grep -n -A 100 "^def save_analysis" app/services/analysis_history.py
```

```bash
cd /opt/ai-defense-manager && sed -n '65,120p' app/services/analysis_history.py && sed -n '209,290p' app/services/analysis_history.py
```

`save_analysis()` は、正常に終わると自動で確定（コミット）します。本番の DB で試して取り消す方法はとらず、一時的な DB を使います。

```bash
cd /opt/ai-defense-manager && sed -n '1,240p' app/schemas/analysis.py && sed -n '1,220p' app/schemas/analysis_proposal.py
```

```bash
cd /opt/ai-defense-manager && sed -n '1,220p' app/schemas/security_event.py
```

メールアドレス・パスワード・API キー・IPv4 アドレスを含むイベントを保存し、読み戻して元の値が残っていないことを確かめます。

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
import sqlite3
import tempfile
from pathlib import Path
from uuid import uuid4

from app.schemas.analysis import AIAnalysisRequest
from app.schemas.analysis_proposal import AIAnalysisProposal
from app.schemas.security_event import SecurityEvent
import app.services.analysis_history as history

original_db_path = history.DB_PATH

try:
    with tempfile.TemporaryDirectory(prefix="ai-defense-privacy-test-") as tmp:
        history.DB_PATH = Path(tmp) / "test.db"
        history.initialize_database()

        event_id = uuid4()
        request = AIAnalysisRequest(
            events=[
                SecurityEvent(
                    source="wazuh",
                    severity="low",
                    rule_id="TEST-001",
                    event_category="authentication",
                    event_summary=(
                        "Login from 203.0.113.10 "
                        "email=user@example.com "
                        "password='test secret value' "
                        "api_key=example-secret-123"
                    ),
                )
            ]
        )
        event_id = request.events[0].event_id

        proposal = AIAnalysisProposal(
            summary="Synthetic privacy test",
            severity="low",
            confidence=0.95,
            evidence_event_ids=[event_id],
            recommended_action="no_action",
            target_ip=None,
            ttl_seconds=None,
            requires_human_approval=False,
            reasoning="Test only. No action required.",
        )

        run_id = history.save_analysis(request, proposal)

        with sqlite3.connect(history.DB_PATH) as conn:
            row = conn.execute(
                "SELECT event_summary FROM analysis_evidence WHERE run_id = ?",
                (run_id,),
            ).fetchone()

        assert row is not None
        saved = row[0]

        for secret in (
            "203.0.113.10",
            "user@example.com",
            "test secret value",
            "example-secret-123",
        ):
            assert secret not in saved, f"Unmasked value found: {secret}"

        assert "[REDACTED_IP]" in saved
        assert "[REDACTED_EMAIL]" in saved
        assert saved.count("[REDACTED_SECRET]") == 2

        print("SQLITE_SAVED_SUMMARY:", saved)
        print("SQLITE_SECRET_REDACTION: OK")
        print("SQLITE_TEMP_DB_TEST: PASSED")

finally:
    history.DB_PATH = original_db_path
PY
```

## 3.7　反映

```bash
systemctl restart ai-defense-manager.service && systemctl is-active ai-defense-manager.service
```

```bash
curl -sS -i http://127.0.0.1:8000/health
```

これから保存する分析は、保存のときにも伏せ字になります。すでに保存した記録は変えません。

# 第4章　点検

## 4.1　保存済みの履歴

保存済みの `analysis_evidence.event_summary` を共通の関数にかけ、伏せ字が必要になる行を数えます。DB は読み取り専用で開き、秘密の情報そのものは表示しません。

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
import sqlite3
from collections import Counter

from app.services.analysis_history import DB_PATH
from app.services.event_sanitizer import sanitize_event_summary

db_uri = DB_PATH.resolve().as_uri() + "?mode=ro"

with sqlite3.connect(db_uri, uri=True) as conn:
    rows = conn.execute(
        "SELECT event_summary FROM analysis_evidence"
    ).fetchall()

total = len(rows)
needs_masking = 0
patterns = Counter()

for (original,) in rows:
    sanitized = sanitize_event_summary(original)

    if sanitized != original:
        needs_masking += 1
        for marker, label in (
            ("[REDACTED_SECRET]", "secret"),
            ("[REDACTED_EMAIL]", "email"),
            ("[REDACTED_IP]", "ip"),
            ("[REDACTED_EVENT]", "invalid_or_empty"),
        ):
            if marker in sanitized:
                patterns[label] += 1

print("DATABASE_READ_ONLY: YES")
print("EVIDENCE_ROWS_SCANNED:", total)
print("ROWS_REQUIRING_MASKING:", needs_masking)
print("DETECTION_COUNTS:", dict(patterns))
print("PRODUCTION_DATABASE_MODIFIED: NO")
PY
```

構築時は28件を調べ、伏せ字が必要な行は0件でした。

## 4.2　DBのファイル

```bash
stat -c '%A (%a) %U:%G %n' /opt/ai-defense-manager/data /opt/ai-defense-manager/data/ai-defense.db /opt/ai-defense-manager/data/ai-defense.db-wal /opt/ai-defense-manager/data/ai-defense.db-shm 2>&1
```

| 対象 | 持ち主 | 権限 |
|---|---|---:|
| `data` ディレクトリ | `ai-defense:ai-defense` | 750 |
| DB 本体 | `ai-defense:ai-defense` | 600 |
| WAL | `ai-defense:ai-defense` | 600 |
| SHM | `ai-defense:ai-defense` | 600 |

## 4.3　サービスの設定

```bash
systemctl show ai-defense-manager.service -p User -p Group -p NoNewPrivileges -p ProtectSystem -p ProtectHome -p PrivateTmp -p PrivateDevices -p RestrictSUIDSGID -p LockPersonality -p ReadWritePaths
```

root ではなく `ai-defense` で動き、ファイルシステムは原則として読み取り専用、書き込めるのは `data` ディレクトリだけです。

## 4.4　待ち受けのポート

```bash
ss -lntp
```

| ポート | 待ち受け | 判定 |
|---|---|---|
| 8000（FastAPI） | `127.0.0.1` | 外からは直接つなげない |
| 22（SSH） | `0.0.0.0`・`[::]` | 次の部で点検する |
| 53（DNS） | `127.0.0.53`・`127.0.0.54` | ローカルだけ |

# おわりに

第20部で、次のことを行いました。

| 項目 | 結果 |
|---|---|
| 分析の失敗（`502`） | 信頼度を 0.0〜1.0 で返すよう指示に追加して解消 |
| 伏せ字 | `event_sanitizer.py` に共通化し、LLM に送る前と SQLite に保存する前の両方で使う |
| 保存済みの履歴 | 28件を点検し、伏せ字が必要なものはなし |
| DB・サービス・ポート | 点検して問題なし |

次の部では、VM 230 の SSH を、パスワードではなく公開鍵でログインする形に切り替えます。
