---
title: "AI自律型サイバー防御システム 構築マニュアル 前編"
subtitle: "第7部　Collectorの耐障害性の仕上げ"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」前編の第7部です。第6部の最後にテスト版で確かめた「読み取り位置の検証」を本番に反映し、そのうえで、DBの重複処理、巨大な行、JSONの深さ、ファイルディスクリプタ、状態の保存の失敗など、残った異常系を一つずつ検証して仕上げます。

## 本書の表記

- コマンドやファイル内容は、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 各手順の冒頭に「実行先」を示します。DBの確認は、LXC 109の中でDB管理者（`postgres`）で行います。
- 「実行結果（例）」は構築時の実際の出力です。ハッシュ・件数・時刻・inodeなどは、お使いの環境では異なります。
- テスト用のファイルやスクリプトは `/tmp` に作ります。VMを再起動すると消えることがあります。

## 第6部終了時点の状態

| 項目 | 状態 |
|---|---|
| 本番のCollector | 再帰探索版（SHA-256 `ac297477...`） |
| テスト版 | `/tmp/wazuh-collector-step330-test.py`（読み取り位置の検証を追加、`df4a9ff6...`） |
| ACL | `alerts`・`年`・`月` のディレクトリにCollectorの `r-x` |

# 第1章　読み取り位置の検証の本番反映

## 1.1　異常終了時のファイルの解放

inodeの取り違えで起動を拒否したときに、開いたファイルが閉じられ（ファイルディスクリプタが漏れず）、既存の状態ファイルも変わらないことを確認します。

**実行先：security-core VM 220（root）**

```bash
cat > /tmp/test_step330_cleanup.py <<'PY'
import importlib.util
import os
import tempfile
from pathlib import Path
from unittest.mock import patch

spec = importlib.util.spec_from_file_location(
    "collector_test",
    "/tmp/wazuh-collector-step330-test.py",
)
collector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(collector)

with tempfile.TemporaryDirectory(prefix="step330-cleanup-") as tmp:
    root = Path(tmp)
    alert_dir = root / "alerts"
    alert_dir.mkdir()

    current = alert_dir / "alerts.json"
    impostor = alert_dir / "impostor.json"
    current.write_bytes(b'{"current":true}\n')
    impostor.write_bytes(b'{"impostor":true}\n')

    collector.ALERT_FILE = current
    collector.ALERT_DIR = alert_dir
    collector.STATE_FILE = root / "state" / "state.json"
    collector.STATE_FILE.parent.mkdir()

    sentinel = b'{"inode":123,"offset":456}\n'
    collector.STATE_FILE.write_bytes(sentinel)

    wrong_inode = impostor.stat().st_ino + 1
    before = len(os.listdir("/proc/self/fd"))

    with patch.object(
        collector,
        "find_inode_file",
        return_value=impostor,
    ):
        try:
            collector.open_initial_file((wrong_inode, 0))
        except RuntimeError:
            pass
        else:
            raise AssertionError("Expected inode mismatch rejection")

    after = len(os.listdir("/proc/self/fd"))

    assert after == before, (before, after)
    print("PASS: no file descriptor leak")

    assert collector.STATE_FILE.read_bytes() == sentinel
    print("PASS: existing state file unchanged")

print("PASS: cleanup tests completed")
PY

python3 /tmp/test_step330_cleanup.py
```

## 1.2　反映前の確認

**実行先：security-core VM 220（root）**

```bash
echo "=== PRODUCTION ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== BACKUP ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py.backup-before-recursive-rotation-20261119

echo
echo "=== TEST CANDIDATE ==="
sha256sum /tmp/wazuh-collector-step330-test.py

echo
echo "=== FILE PERMISSIONS ==="
stat -c '%n | %U:%G | %a | %s bytes' \
  /usr/local/lib/wazuh-collector/collector.py \
  /usr/local/lib/wazuh-collector/collector.py.backup-before-recursive-rotation-20261119 \
  /tmp/wazuh-collector-step330-test.py
```

| ファイル | SHA-256（構築時） |
|---|---|
| 本番 | `ac297477...` |
| バックアップ（第5部の版） | `7a816056...` |
| 候補（テスト版） | `df4a9ff6...`（19,593バイト） |

## 1.3　本番への反映

本番と候補のハッシュを確かめ、現在の本番を追加でバックアップしてから、一度に置き換えます。サービスはまだ再起動しません。

**実行先：security-core VM 220（root）**

```bash
set -euo pipefail

PROD=/usr/local/lib/wazuh-collector/collector.py
CANDIDATE=/tmp/wazuh-collector-step330-test.py
BACKUP=/usr/local/lib/wazuh-collector/collector.py.backup-before-step330-offset-20261119
TEMP=/usr/local/lib/wazuh-collector/.collector.py.step330.tmp

echo "=== PRE-INSTALL VALIDATION ==="
test "$(sha256sum "$PROD" | awk '{print $1}')" = \
  "ac2974775d46b902ee69b3e7219bf9cb550c7d8a65c38cbdf8ac89ecc67a5e96"
test "$(sha256sum "$CANDIDATE" | awk '{print $1}')" = \
  "df4a9ff6c55767851bf9c9831c1d96862e876a4f030d52aa9e394224e51d0a3e"
test ! -e "$BACKUP"
test ! -e "$TEMP"

echo "PASS: source hashes and backup path"

echo
echo "=== CREATE ADDITIONAL BACKUP ==="
cp -a "$PROD" "$BACKUP"
test "$(sha256sum "$BACKUP" | awk '{print $1}')" = \
  "ac2974775d46b902ee69b3e7219bf9cb550c7d8a65c38cbdf8ac89ecc67a5e96"
echo "PASS: additional backup created"

echo
echo "=== INSTALL CANDIDATE ATOMICALLY ==="
install -o root -g root -m 755 "$CANDIDATE" "$TEMP"
python3 -c 'from pathlib import Path; p=Path("'"$TEMP"'"); compile(p.read_text(encoding="utf-8"), str(p), "exec")'
mv -f "$TEMP" "$PROD"

echo
echo "=== POST-INSTALL VALIDATION ==="
sha256sum "$PROD" "$BACKUP"
stat -c '%n | %U:%G | %a | %s bytes' "$PROD" "$BACKUP"
python3 -c 'from pathlib import Path; p=Path("'"$PROD"'"); compile(p.read_text(encoding="utf-8"), str(p), "exec"); print("PASS: production syntax")'

echo
echo "=== SERVICE STATUS (NOT RESTARTED) ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts
```

2つのハッシュは、自分の環境の本番（反映前）と候補の値に置き換えます。

## 1.4　再起動と確認

**実行先：security-core VM 220（root）**

```bash
systemctl restart wazuh-collector

echo "=== SERVICE STATUS ==="
systemctl show wazuh-collector \
  -p ActiveState \
  -p SubState \
  -p MainPID \
  -p NRestarts \
  -p ExecMainStatus

echo
echo "=== RECENT JOURNAL ==="
journalctl -u wazuh-collector -n 30 --no-pager
```

```bash
echo "=== JOURNAL SINCE RESTART ==="
journalctl -u wazuh-collector \
  --since "2026-11-18 21:53:00" \
  --no-pager

echo
echo "=== STATE FILE METADATA ==="
stat -c '%n | %U:%G | %a | %s bytes | modified=%y' \
  /var/lib/wazuh-collector/state.json

echo
echo "=== STATE VALUES ==="
python3 - <<'PY'
import json
from pathlib import Path

p = Path("/var/lib/wazuh-collector/state.json")
s = json.loads(p.read_text())
print("inode:", s["inode"])
print("offset:", s["offset"])
PY

echo
echo "=== SERVICE STATUS ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts
```

構築時は、新しいPID `91473` で `Resuming current alert file` と表示され、保存されたinode `5409146` から再開しました。第6部8.1のとおり、DBへの接続は新しいアラートを読んだときに行われます。

# 第2章　反映後の取り込みの確認

## 2.1　DBの基準値

**実行先：LXC 109 postgresql（root）**

```bash
sudo -u postgres psql -X -d security_workbench -c "
SELECT
    COUNT(*) AS total_events,
    MAX(ingested_at) AS latest_ingested_at,
    MAX(event_timestamp) AS latest_event_timestamp
FROM incident.alert_events;
"
```

構築時は727件でした。

## 2.2　新しいアラートの取り込み

新しいアラートが来るまで待ってから、再起動後のログを確認します。

**実行先：security-core VM 220（root）**

```bash
journalctl -u wazuh-collector \
  --since "2026-11-18 21:53:13" \
  --no-pager
```

構築時は、再起動から約5分後に新しいアラートを検知して、DBに接続しました。

```text
21:58:08 INFO PostgreSQL connection established
```

**実行先：LXC 109 postgresql（root）**

```bash
sudo -u postgres psql -X -d security_workbench -c "
SELECT
    COUNT(*) AS total_events,
    MAX(ingested_at) AS latest_ingested_at,
    MAX(event_timestamp) AS latest_event_timestamp
FROM incident.alert_events;
"
```

件数が727件から730件に増え、新しいアラートが登録されていました。状態ファイルの位置も、`alerts.json` の末尾と一致していました。

# 第3章　実際のDBでの重複処理の試験

## 3.1　考え方

第4部・第6部では、モックの接続で重複処理を試験しました。ここでは、本番のCollectorのコードと実際のPostgreSQL（`wazuh_collector` の権限）を使い、外側のトランザクションの中ですべてを行って、最後に必ずロールバックします。本番のテーブルにテストのデータは残りません。

`connection.transaction()` は、すでにトランザクションの中で呼ばれるとセーブポイントになります。そのため、重複でエラーになっても、そのセーブポイントだけが戻り、同じ接続で次のイベントを処理できるはずです。

## 3.2　試験

**実行先：security-core VM 220（root）**

```bash
cat > /tmp/test_step330_20e.py <<'PY'
import importlib.util
import json
import uuid
from datetime import datetime, timezone

import psycopg


SOURCE = "/usr/local/lib/wazuh-collector/collector.py"

spec = importlib.util.spec_from_file_location(
    "collector_step330_20e",
    SOURCE,
)
collector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(collector)


class RollbackOnly(Exception):
    pass


def make_alert(event_id):
    return {
        "id": event_id,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "rule": {
            "id": 100001,
            "level": 3,
            "description": "STEP330-20E rollback-only test",
            "groups": ["step330-test"],
            "mitre": {},
        },
        "agent": {
            "id": "000",
            "name": "security-core",
        },
        "manager": {
            "name": "security-core",
        },
        "decoder": {
            "name": "json",
        },
    }


prefix = "step33020e-" + uuid.uuid4().hex

first_alert = make_alert(prefix + "-duplicate")
next_alert = make_alert(prefix + "-next")

first_event = collector.extract_event(first_alert)

if first_event is None:
    raise RuntimeError("Test fixture validation failed")

connection = psycopg.connect(**collector.DB_CONFIG)

try:
    try:
        with connection.transaction():
            # Seed one event inside the outer transaction.
            connection.execute(
                collector.INSERT_SQL,
                first_event,
            )

            print("PASS: initial test event inserted")

            # Same event_id must trigger UniqueViolation.
            collector.process_line(
                connection,
                json.dumps(first_alert).encode("utf-8"),
            )

            print("PASS: duplicate event handled")

            if (
                connection.info.transaction_status
                != psycopg.pq.TransactionStatus.INTRANS
            ):
                raise AssertionError(
                    "Transaction did not recover after duplicate"
                )

            print("PASS: transaction remains usable after duplicate")

            # A different event must succeed on the same connection.
            collector.process_line(
                connection,
                json.dumps(next_alert).encode("utf-8"),
            )

            print("PASS: next event processed on same connection")

            if (
                connection.info.transaction_status
                != psycopg.pq.TransactionStatus.INTRANS
            ):
                raise AssertionError(
                    "Transaction unexpectedly left active state"
                )

            # Force rollback of every test INSERT.
            raise RollbackOnly()

    except RollbackOnly:
        pass

    if (
        connection.info.transaction_status
        != psycopg.pq.TransactionStatus.IDLE
    ):
        raise AssertionError("Connection did not return to IDLE")

    print("PASS: outer transaction rolled back")
    print("PASS: connection returned to IDLE")
    print("PASS: no test rows committed")

finally:
    connection.close()

print("PASS: STEP330-20E")
PY

python3 /tmp/test_step330_20e.py
```

| 確認項目 | 意味 |
|---|---|
| `initial test event inserted` | 1件目を登録した |
| `duplicate event handled` | 同じIDの2件目が `UniqueViolation` として処理された |
| `transaction remains usable after duplicate` | 重複の後もトランザクションが使える |
| `next event processed on same connection` | 同じ接続で別のイベントを登録できた |
| `no test rows committed` | 最後にすべてロールバックした |

## 3.3　テストのデータが残っていないことの確認

**実行先：LXC 109 postgresql（root）**

```bash
sudo -u postgres psql -X -d security_workbench -c "
SELECT
    COUNT(*) AS total_events,
    COUNT(*) FILTER (
        WHERE event_id LIKE 'step33020e-%'
    ) AS remaining_test_events,
    MAX(ingested_at) AS latest_ingested_at
FROM incident.alert_events;
"
```

`remaining_test_events` が `0` であれば、テストのデータは1件も残っていません。

# 第4章　本番のコードを使った隔離試験

ここからは、本番の `collector.py` をPythonのモジュールとして読み込み、ファイルのパスだけを一時ディレクトリに差し替えて、実際の関数を試験します。`run()` は起動しないので、本番のサービス・ログ・状態ファイル・DBには触れません。

> 古いテスト用コピー（`/tmp/wazuh-collector-rotation-test.py` など）は、本番に反映したあとの修正を含んでいません。また、そのまま実行すると本番のパスを使って常駐ループが始まります。試験は必ず本番のコードを読み込み、パスを差し替えて行ってください。

## 4.1　起動時の再開と拒否

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import importlib.util
import tempfile
from pathlib import Path

spec = importlib.util.spec_from_file_location(
    "collector_rotation_test",
    "/usr/local/lib/wazuh-collector/collector.py",
)
collector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(collector)


def setup():
    tmp = tempfile.TemporaryDirectory(prefix="step330-22e-")
    root = Path(tmp.name)
    current = root / "alerts.json"
    current.write_bytes(b"new-file-data")

    collector.ALERT_FILE = current
    collector.ALERT_DIR = root
    collector.STATE_FILE = root / "state.json"

    return tmp, root, current


def expect_refusal(state, label):
    try:
        handle, _ = collector.open_initial_file(state)
    except RuntimeError:
        print(f"PASS: {label}")
        return
    else:
        handle.close()
        raise AssertionError(f"FAIL: {label} was accepted")


# 1. Current file resume
tmp, root, current = setup()
try:
    inode = current.stat().st_ino
    handle, active_inode = collector.open_initial_file((inode, 4))
    assert active_inode == inode
    assert handle.tell() == 4
    assert handle.read() == b"file-data"
    handle.close()
    print("PASS: current file resume")
finally:
    tmp.cleanup()


# 2. Previous rotated file resume
tmp, root, current = setup()
try:
    old_dir = root / "archive" / "2026"
    old_dir.mkdir(parents=True)
    old_file = old_dir / "alerts-old.json"
    old_file.write_bytes(b"old-file-data")

    old_inode = old_file.stat().st_ino
    handle, active_inode = collector.open_initial_file((old_inode, 4))
    assert active_inode == old_inode
    assert handle.tell() == 4
    assert handle.read() == b"file-data"
    handle.close()
    print("PASS: previous rotated file resume")
finally:
    tmp.cleanup()


# 3. Previous inode missing
tmp, root, current = setup()
try:
    expect_refusal((999999999, 0), "missing previous inode refused")
finally:
    tmp.cleanup()


# 4. Current file offset exceeds size
tmp, root, current = setup()
try:
    expect_refusal(
        (current.stat().st_ino, current.stat().st_size + 1),
        "current file oversized offset refused",
    )
finally:
    tmp.cleanup()


# 5. Previous rotated file offset exceeds size
tmp, root, current = setup()
try:
    old_dir = root / "archive"
    old_dir.mkdir()
    old_file = old_dir / "alerts-old.json"
    old_file.write_bytes(b"old-data")

    expect_refusal(
        (old_file.stat().st_ino, old_file.stat().st_size + 1),
        "rotated file oversized offset refused",
    )
finally:
    tmp.cleanup()


print("PASS: STEP330-22E ALL TESTS")
PY
```

| テスト | 結果 |
|---|---|
| 現在のファイルから保存位置で再開 | 再開する |
| サブディレクトリの旧ファイルから再開 | 再開する |
| 旧inodeが見つからない | 起動を拒否 |
| 現在のファイルで位置がファイルより大きい | 起動を拒否 |
| 旧ファイルで位置がファイルより大きい | 起動を拒否 |

## 4.2　未完了の行とローテーション

ローテーションの直前に書きかけだったJSONの行が、DBへの登録の対象にならず、新しいファイルの正常な行から読み直すことを、本番の `read_alert_line()`・`safe_open_current_alert_file()`・`save_state()` で確かめます。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import importlib.util
import json
import tempfile
from pathlib import Path

spec = importlib.util.spec_from_file_location(
    "collector_step330_23",
    "/usr/local/lib/wazuh-collector/collector.py",
)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

with tempfile.TemporaryDirectory(prefix="step330-23d-") as tmp:
    root = Path(tmp)
    archive = root / "archive"
    archive.mkdir()

    old_file = root / "alerts.json"
    new_file = root / "new-alerts.json"

    old_file.write_bytes(b'{"id":"incomplete')
    c.ALERT_FILE = old_file
    c.ALERT_DIR = root
    c.STATE_FILE = root / "state.json"

    # Open old file and detect incomplete JSON line.
    handle = old_file.open("rb")
    old_inode = handle.fileno()
    old_inode = __import__("os").fstat(old_inode).st_ino

    status, line, _ = c.read_alert_line(handle)
    assert status == "incomplete"
    assert line is None
    print("PASS: incomplete old line detected")

    # Simulate log rotation: preserve old inode and create new alerts.json.
    old_path = archive / "alerts-old.json"
    old_file.rename(old_path)

    valid_alert = (
        b'{"id":"new-event","timestamp":"2026-11-19T00:00:00+00:00",'
        b'"rule":{"id":"100001","level":5},'
        b'"agent":{"id":"000","name":"test"},'
        b'"manager":{"name":"test"},'
        b'"decoder":{"name":"test"}}\n'
    )
    old_file.write_bytes(valid_alert)

    # Follow the production incomplete-line rotation branch.
    current_stat = c.ALERT_FILE.stat()
    assert current_stat.st_ino != old_inode

    new_handle, new_stat = c.safe_open_current_alert_file()
    assert new_handle is not None
    assert new_stat.st_ino == current_stat.st_ino

    c.save_state(new_stat.st_ino, 0)

    handle.close()
    handle = new_handle

    state = json.loads(c.STATE_FILE.read_text())
    assert state == {"inode": new_stat.st_ino, "offset": 0}
    print("PASS: new inode and offset 0 saved")

    # Ensure the old incomplete fragment is never returned as an event.
    status, line, _ = c.read_alert_line(handle)
    assert status == "line"
    parsed = json.loads(line)
    assert parsed["id"] == "new-event"
    assert parsed["id"] != "incomplete"
    print("PASS: valid new-file JSON read")
    print("PASS: incomplete old fragment not processed")

    handle.close()

print("PASS: STEP330-23D ALL TESTS")
PY
```

`STATE_FILE` も一時ディレクトリに差し替えているため、本番の状態ファイルは変わりません。

# 第5章　巨大なアラート行の扱い

## 5.1　上限と分割読み込み

本番のCollectorは、1行の上限を1 MiB（`MAX_ALERT_LINE_BYTES`＝1,048,576バイト）とし、上限を超えた行は64 KiB（`READ_CHUNK_BYTES`＝65,536バイト）ずつ読み捨てます。上限ちょうどの行、上限を超える行、何回にも分けて読み捨てる行、改行のないままファイルの末尾に達する行を試します。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import importlib.util
import tempfile
from pathlib import Path

spec = importlib.util.spec_from_file_location(
    "collector_step330_24a",
    "/usr/local/lib/wazuh-collector/collector.py",
)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

MAX = c.MAX_ALERT_LINE_BYTES
CHUNK = c.READ_CHUNK_BYTES
valid = b'{"id":"after-oversized"}\n'

with tempfile.TemporaryDirectory(prefix="step330-24a-") as tmp:
    path = Path(tmp) / "alerts.json"

    # Test 1: exactly the configured maximum, including newline.
    path.write_bytes(b"x" * (MAX - 1) + b"\n")
    with path.open("rb") as handle:
        status, line, discarding = c.read_alert_line(handle)
        assert status == "line"
        assert len(line) == MAX
        assert discarding is False
        print("PASS: maximum-size line accepted")

    # Test 2: oversized line followed by a valid line.
    path.write_bytes(b"x" * MAX + b"\n" + valid)
    with path.open("rb") as handle:
        status, line, discarding = c.read_alert_line(handle)
        assert status == "oversized"
        assert line is None
        assert discarding is False

        status, line, discarding = c.read_alert_line(handle)
        assert status == "line"
        assert line == valid
        print("PASS: oversized line rejected; next valid line preserved")

    # Test 3: very large line requiring repeated chunk discards.
    huge = b"x" * (MAX + CHUNK * 3 + 17) + b"\n"
    path.write_bytes(huge + valid)

    with path.open("rb") as handle:
        status, line, discarding = c.read_alert_line(handle)
        assert status == "discarding"
        assert line is None
        assert discarding is True

        discard_calls = 0
        while True:
            status, line, discarding = c.read_alert_line(
                handle, discarding=True
            )
            discard_calls += 1

            if status == "oversized":
                break

            assert status == "discarding"
            assert line is None
            assert discarding is True

        assert discard_calls >= 3

        status, line, discarding = c.read_alert_line(handle)
        assert status == "line"
        assert line == valid
        print(
            "PASS: multi-chunk oversized line discarded; "
            "next valid line preserved"
        )

    # Test 4: oversized incomplete line ending at EOF.
    path.write_bytes(b"x" * (MAX + 1))

    with path.open("rb") as handle:
        status, line, discarding = c.read_alert_line(handle)
        assert status == "discarding"
        assert discarding is True

        status, line, discarding = c.read_alert_line(
            handle, discarding=True
        )
        assert status == "eof"
        assert line is None
        assert discarding is False
        print("PASS: oversized incomplete line reaches EOF safely")

print("PASS: STEP330-24A ALL TESTS")
PY
```

## 5.2　読み捨ての途中のローテーション

巨大な行を読み捨てている途中でファイルの末尾に達し、その間にローテーションされた場合に、新しいファイルへ切り替わり、読み捨ての状態がリセットされることを確認します。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import importlib.util
import json
import tempfile
from pathlib import Path

spec = importlib.util.spec_from_file_location(
    "collector_step330_24b",
    "/usr/local/lib/wazuh-collector/collector.py",
)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

with tempfile.TemporaryDirectory(prefix="step330-24b-") as tmp:
    root = Path(tmp)
    c.ALERT_FILE = root / "alerts.json"
    c.STATE_FILE = root / "state.json"

    old_path = c.ALERT_FILE
    archive_path = root / "alerts.json.1"
    valid = b'{"id":"after-rotation"}\n'

    # Create an oversized, incomplete old-file line.
    old_path.write_bytes(
        b"x" * (
            c.MAX_ALERT_LINE_BYTES
            + c.READ_CHUNK_BYTES * 2
            + 17
        )
    )

    old_handle = old_path.open("rb")
    old_inode = old_path.stat().st_ino

    status, line, discarding = c.read_alert_line(old_handle)
    assert status == "discarding"
    assert line is None
    assert discarding is True
    print("PASS: oversized line enters discard mode")

    # Continue discarding until the old file reaches EOF.
    while True:
        status, line, next_discarding = c.read_alert_line(
            old_handle,
            discarding=discarding,
        )
        if status == "eof":
            break
        assert status == "discarding"
        assert line is None
        assert next_discarding is True
        discarding = next_discarding

    print("PASS: old oversized line reaches EOF")

    # Rotate old file and create a new file with a valid alert.
    old_path.rename(archive_path)
    old_path.write_bytes(valid)
    new_inode = old_path.stat().st_ino
    assert new_inode != old_inode

    # Exercise the same file-switch operations as production run().
    new_handle, new_stat = c.safe_open_current_alert_file()
    assert new_handle is not None
    assert new_stat.st_ino == new_inode

    c.save_state(new_stat.st_ino, 0)

    old_handle.close()
    active_handle = new_handle
    active_inode = new_stat.st_ino
    discarding = False
    discard_start = None

    assert active_inode == new_inode
    assert discarding is False
    assert discard_start is None
    print("PASS: new inode saved and discard state reset")

    # The first line in the new file must be read normally.
    status, line, _ = c.read_alert_line(active_handle)
    assert status == "line"
    assert line == valid
    assert json.loads(line)["id"] == "after-rotation"
    print("PASS: valid new-file alert read successfully")

    state = json.loads(c.STATE_FILE.read_text())
    assert state["inode"] == new_inode
    assert state["offset"] == 0
    print("PASS: persisted state references new inode at offset 0")

    active_handle.close()

print("PASS: STEP330-24B ALL TESTS")
PY
```

## 5.3　読み捨てた後の位置の保存と再開

巨大な行を読み捨てた後の位置を保存し、再起動したときにその次の行から再開できることを確認します。`load_state()` は `(inode, offset)` の組（タプル）を返します。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import importlib.util
import json
import tempfile
from pathlib import Path

spec = importlib.util.spec_from_file_location(
    "collector_step330_24c_retry",
    "/usr/local/lib/wazuh-collector/collector.py",
)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

with tempfile.TemporaryDirectory(prefix="step330-24c-retry-") as tmp:
    root = Path(tmp)
    c.STATE_FILE = root / "state.json"
    alert_path = root / "alerts.json"

    valid = b'{"id":"after-large-line"}\n'
    oversized = (
        b"x" * (c.MAX_ALERT_LINE_BYTES + c.READ_CHUNK_BYTES * 2)
        + b"\n"
    )
    alert_path.write_bytes(oversized + valid)

    with alert_path.open("rb") as handle:
        status, line, discarding = c.read_alert_line(handle)
        assert status == "discarding"
        assert discarding is True

        while True:
            status, line, next_discarding = c.read_alert_line(
                handle,
                discarding=True,
            )
            if status == "oversized":
                break
            assert status == "discarding"
            assert next_discarding is True

        c.save_state(alert_path.stat().st_ino, handle.tell())

        state = json.loads(c.STATE_FILE.read_text())
        assert state["inode"] == alert_path.stat().st_ino
        assert state["offset"] == len(oversized)
        print("PASS: oversized-line offset persisted")

        status, line, _ = c.read_alert_line(handle)
        assert status == "line"
        assert line == valid
        print("PASS: following valid alert preserved")

    # Production load_state returns (inode, offset).
    saved_inode, saved_offset = c.load_state()
    assert saved_inode == alert_path.stat().st_ino
    assert saved_offset == len(oversized)
    print("PASS: load_state restored inode and offset")

    with alert_path.open("rb") as resumed:
        resumed.seek(saved_offset)
        status, line, _ = c.read_alert_line(resumed)
        assert status == "line"
        assert line == valid
        print("PASS: restart resumes after oversized line")

print("PASS: STEP330-24C ALL TESTS")
PY
```

この試験は、一般ユーザー（`ag`）のシェルで実行しても構いません。本番のファイルには書き込みません。

# 第6章　入力の検証の境界値

## 6.1　境界値の試験

本番の `extract_event()` が、不正な形・範囲外の値・長すぎる文字列を拒否または切り詰め、決められた項目だけを出力することを確認します。`full_log` や想定外の項目は、DBに登録する内容に入りません。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import copy
import importlib.util
from datetime import datetime

spec = importlib.util.spec_from_file_location(
    "collector_step330_25a",
    "/usr/local/lib/wazuh-collector/collector.py",
)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

baseline = {
    "id": "step330-25a-test",
    "timestamp": "2026-11-19T07:00:00+09:00",
    "rule": {
        "id": "100001",
        "level": 10,
        "description": "test alert",
        "groups": ["syslog", "authentication"],
        "mitre": {
            "id": ["T1110"],
            "tactic": ["Credential Access"],
            "technique": ["Brute Force"],
            "unexpected": "must not persist",
        },
    },
    "agent": {"id": "001", "name": "test-agent"},
    "manager": {"name": "test-manager"},
    "decoder": {"name": "test-decoder"},
    "data": {"srcip": "192.0.2.10", "srcport": 443},
    "full_log": "must never persist",
    "unexpected": {"secret": "must never persist"},
}

# 1. Valid baseline.
event = c.extract_event(copy.deepcopy(baseline))
assert event is not None
assert isinstance(event["event_timestamp"], datetime)
print("PASS: valid baseline accepted")

# 2. Invalid top-level structures.
for value in (None, [], "text", 123):
    assert c.extract_event(value) is None
print("PASS: non-object top-level input rejected")

# 3. Required nested objects.
for key in ("rule", "agent", "manager", "decoder"):
    test = copy.deepcopy(baseline)
    test[key] = []
    assert c.extract_event(test) is None
print("PASS: invalid required nested objects rejected")

# 4. Invalid required numeric fields.
for key, value in (
    ("id", True),
    ("id", -1),
    ("id", 2147483648),
    ("id", "1;DROP"),
    ("level", True),
    ("level", 17),
    ("level", -1),
):
    test = copy.deepcopy(baseline)
    test["rule"][key] = value
    assert c.extract_event(test) is None
print("PASS: invalid rule IDs and levels rejected")

# 5. Invalid timestamps.
for value in (
    None,
    "",
    "not-a-timestamp",
    "2026-11-19T07:00:00",
    "x" * 65,
):
    test = copy.deepcopy(baseline)
    test["timestamp"] = value
    assert c.extract_event(test) is None
print("PASS: invalid timestamps rejected")

# 6. Text length and control-character handling.
test = copy.deepcopy(baseline)
test["rule"]["description"] = "A" * 5000 + "\x00"
event = c.extract_event(test)
assert event is not None
assert len(event["rule_description"]) == 4096
assert "\x00" not in event["rule_description"]
print("PASS: text sanitized and limited to 4096 characters")

# 7. String-list limits.
test = copy.deepcopy(baseline)
test["rule"]["groups"] = ["G" + str(i) for i in range(100)]
event = c.extract_event(test)
assert len(event["rule_groups"]) == 64
print("PASS: rule groups limited to 64 items")

# 8. Invalid IP and port.
test = copy.deepcopy(baseline)
test["data"] = {"srcip": "999.999.999.999", "srcport": 70000}
event = c.extract_event(test)
assert event["srcip"] is None
assert event["srcport"] is None
print("PASS: invalid IP and port discarded")

# 9. Unexpected fields never enter the output.
event = c.extract_event(copy.deepcopy(baseline))
allowed = {
    "event_id", "event_timestamp", "rule_id", "rule_level",
    "rule_description", "agent_id", "agent_name", "manager_name",
    "decoder_name", "rule_groups", "srcip", "srcport", "mitre",
}
assert set(event) == allowed
assert "full_log" not in event
assert "unexpected" not in event
mitre = event["mitre"].obj
assert "unexpected" not in mitre
print("PASS: output restricted to whitelist fields")

print("PASS: STEP330-25A ALL TESTS")
PY
```

| 項目 | 上限・扱い |
|---|---|
| 説明文 | 4096文字。制御文字は除く |
| グループ | 64件 |
| 時刻 | タイムゾーンのない値や不正な値は拒否 |
| ルールID・レベル | 範囲外・真偽値・文字列の混入は拒否 |
| IPアドレス・ポート | 不正な値は空（`None`）にする |
| 出力 | 決められた13項目だけ |

## 6.2　過大な入力と異常な入れ子

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import copy
import importlib.util

spec = importlib.util.spec_from_file_location(
    "collector_step330_25b",
    "/usr/local/lib/wazuh-collector/collector.py",
)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

baseline = {
    "id": "step330-25b-test",
    "timestamp": "2026-11-19T07:00:00+09:00",
    "rule": {
        "id": 100001,
        "level": 10,
        "description": "normal",
        "groups": ["normal"],
        "mitre": {},
    },
    "agent": {"id": "001", "name": "agent"},
    "manager": {"name": "manager"},
    "decoder": {"name": "decoder"},
    "data": {},
}

# 1. Oversized description is bounded.
test = copy.deepcopy(baseline)
test["rule"]["description"] = "A" * 900_000
event = c.extract_event(test)
assert event is not None
assert len(event["rule_description"]) == 4096
print("PASS: oversized description bounded")

# 2. Large group list is bounded.
test = copy.deepcopy(baseline)
test["rule"]["groups"] = ["G" + str(i) for i in range(100_000)]
event = c.extract_event(test)
assert len(event["rule_groups"]) == 64
print("PASS: large group list bounded to 64 items")

# 3. Oversized MITRE arrays are bounded by key.
test = copy.deepcopy(baseline)
test["rule"]["mitre"] = {
    "id": ["I"] * 1000,
    "tactic": ["T"] * 1000,
    "technique": ["X"] * 1000,
}
event = c.extract_event(test)
mitre = event["mitre"].obj
assert len(mitre["id"]) == 32
assert len(mitre["tactic"]) == 16
assert len(mitre["technique"]) == 32
print("PASS: MITRE arrays bounded by key")

# 4. Unexpected deeply nested data is ignored.
test = copy.deepcopy(baseline)
test["unexpected"] = {
    "level1": {
        "level2": {
            "level3": ["secret"] * 1000
        }
    }
}
test["data"] = {
    "srcip": {"nested": "192.0.2.1"},
    "srcport": ["443"],
    "unexpected": {"secret": "value"},
}
event = c.extract_event(test)
assert event is not None
assert event["srcip"] is None
assert event["srcport"] is None
assert set(event) == {
    "event_id", "event_timestamp", "rule_id", "rule_level",
    "rule_description", "agent_id", "agent_name", "manager_name",
    "decoder_name", "rule_groups", "srcip", "srcport", "mitre",
}
print("PASS: nested unexpected structures ignored")

# 5. Wrong types in optional fields do not crash extraction.
test = copy.deepcopy(baseline)
test["rule"]["description"] = {"text": "unexpected"}
test["rule"]["groups"] = {"not": "a list"}
test["rule"]["mitre"] = ["not", "a", "dict"]
test["data"] = "not a dictionary"
event = c.extract_event(test)
assert event is not None
assert event["rule_description"] is None
assert event["rule_groups"] == []
assert event["srcip"] is None
assert event["srcport"] is None
assert event["mitre"].obj == {}
print("PASS: malformed optional fields safely discarded")

# 6. Non-string MITRE entries are discarded.
test = copy.deepcopy(baseline)
test["rule"]["mitre"] = {
    "id": [None, 123, "T1110"],
    "tactic": {"unexpected": "object"},
    "technique": ["Valid", False],
}
event = c.extract_event(test)
mitre = event["mitre"].obj
assert mitre["id"] == ["T1110"]
assert "tactic" not in mitre
assert mitre["technique"] == ["Valid"]
print("PASS: malformed MITRE entries filtered")

print("PASS: STEP330-25B ALL TESTS")
PY
```

構築時は6項目すべて合格しました。MITREの配列は、`id` が32件、`tactic` が16件、`technique` が32件までに制限されます。本番のコードの変更や再起動は不要でした。

# 第7章　DBの障害と読み取り位置

## 7.1　run() の処理の順序

本番の `run()` は、1行を読む前に行の先頭の位置（`line_start`）を覚えておき、失敗したときはその位置に戻ります。構築時にコードを読んで確かめた動作は次のとおりです。

| 処理 | 動作 |
|---|---|
| PostgreSQLへの接続の失敗 | 行の先頭に戻し、5秒後に再接続 |
| 登録・処理の失敗 | 行の先頭に戻し、接続を捨てる |
| 状態の保存の失敗 | 行の先頭に戻して、もう一度処理 |
| 重複したイベント | SQLSTATE `23505` として処理済みにする |
| 上限を超えた行 | 状態を保存してから読み飛ばす |
| ローテーションの検知 | 新しいinodeに切り替える |
| 終了時 | ファイルとDBの接続を閉じる |

## 7.2　DBのエラーの分離

モックの接続を使い、DBの障害は呼び出し元に伝わり、重複だけが処理済みになり、壊れたJSONや不正なアラートはDBに届かないことを確認します。

**実行先：security-core VM 220（root）**

```bash
cat > /tmp/test_step330_26b.py <<'PY'
import copy
import importlib.util
from unittest.mock import MagicMock

spec = importlib.util.spec_from_file_location(
    "collector_step330_26b",
    "/usr/local/lib/wazuh-collector/collector.py",
)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

alert = {
    "id": "step330-26b-test",
    "timestamp": "2026-11-19T07:00:00+09:00",
    "rule": {
        "id": 100001,
        "level": 10,
        "description": "test",
        "groups": [],
        "mitre": {},
    },
    "agent": {"id": "001", "name": "agent"},
    "manager": {"name": "manager"},
    "decoder": {"name": "decoder"},
    "data": {},
}

import json
line = (json.dumps(alert) + "\n").encode()

# 1. DB failure must propagate to run() caller.
connection = MagicMock()
connection.transaction.side_effect = RuntimeError("simulated DB failure")

try:
    c.process_line(connection, line)
except RuntimeError as error:
    assert str(error) == "simulated DB failure"
else:
    raise AssertionError("DB failure was swallowed")

print("PASS: DB failure propagates")

# 2. Duplicate event is handled without propagating.
connection = MagicMock()
duplicate = c.psycopg.errors.UniqueViolation("duplicate")
duplicate.sqlstate = "23505"
connection.transaction.side_effect = duplicate

c.process_line(connection, line)
print("PASS: duplicate event handled")

# 3. Non-duplicate database errors must propagate.
connection = MagicMock()
other_error = c.psycopg.errors.InsufficientPrivilege("permission denied")
connection.transaction.side_effect = other_error

try:
    c.process_line(connection, line)
except c.psycopg.errors.InsufficientPrivilege:
    pass
else:
    raise AssertionError("Non-duplicate DB error was swallowed")

print("PASS: non-duplicate DB error propagates")

# 4. Invalid JSON must not reach the database.
connection = MagicMock()
c.process_line(connection, b'{"broken":')
connection.execute.assert_not_called()
print("PASS: invalid JSON does not reach DB")

# 5. Invalid alert must not reach the database.
connection = MagicMock()
c.process_line(connection, b'{"id":"invalid"}\n')
connection.execute.assert_not_called()
print("PASS: invalid alert does not reach DB")

print("PASS: STEP330-26B ALL TESTS")
PY

python3 /tmp/test_step330_26b.py
```

## 7.3　行の先頭への巻き戻し

失敗した行の先頭に戻ると、もう一度同じイベントを読み、成功した後は次のイベントを読めることを確認します。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import tempfile
from pathlib import Path

first = b'{"id":"first"}\n'
second = b'{"id":"second"}\n'

with tempfile.TemporaryDirectory(prefix="step330-26c-") as tmp:
    path = Path(tmp) / "alerts.json"
    path.write_bytes(first + second)

    with path.open("rb") as handle:
        line_start = handle.tell()
        line = handle.readline()

        assert line == first

        # Simulate the run() exception path.
        handle.seek(line_start)
        assert handle.tell() == 0

        # Retry must read the exact same event.
        retry = handle.readline()
        assert retry == first

        # After successful processing, the next event is readable.
        next_line = handle.readline()
        assert next_line == second

        print("PASS: failed event rewound to line_start")
        print("PASS: retry reads identical event")
        print("PASS: subsequent event remains readable")

print("PASS: STEP330-26C ALL TESTS")
PY
```

# 第8章　状態ファイルの異常

## 8.1　状態の読み込みの異常

壊れたJSON、型の違い、範囲外の数値、読み込みの権限のエラーは、すべて起動の拒否（`collector state is invalid`）になり、状態ファイルがないときだけ、最初から読む扱い（`None`）になることを確認します。

**実行先：security-core VM 220（root）**

```bash
cat > /tmp/test_step330_27b.py <<'PY'
import importlib.util
import json
import tempfile
from pathlib import Path
from unittest.mock import patch

spec = importlib.util.spec_from_file_location(
    "collector_step330_27b",
    "/usr/local/lib/wazuh-collector/collector.py",
)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

with tempfile.TemporaryDirectory(prefix="step330-27b-") as tmp:
    state_path = Path(tmp) / "state.json"
    c.STATE_FILE = state_path

    # 1. Valid state.
    state_path.write_text(
        json.dumps({"inode": 12345, "offset": 67890}),
        encoding="utf-8",
    )
    assert c.load_state() == (12345, 67890)
    print("PASS: valid state loaded")

    # 2. Missing state.
    state_path.unlink()
    assert c.load_state() is None
    print("PASS: missing state returns None")

    # 3. Corrupt JSON.
    invalid_documents = [
        "{broken json",
        "[]",
        '"text"',
        "null",
        '{"inode": true, "offset": 10}',
        '{"inode": 123, "offset": false}',
        '{"inode": 0, "offset": 10}',
        '{"inode": 123, "offset": -1}',
        '{"inode": 9223372036854775808, "offset": 10}',
        '{"inode": 123, "offset": 9223372036854775808}',
        '{"inode": "123;DROP", "offset": 10}',
        '{"inode": 123}',
    ]

    for document in invalid_documents:
        state_path.write_text(document, encoding="utf-8")
        try:
            c.load_state()
        except RuntimeError as error:
            assert str(error) == "collector state is invalid"
        else:
            raise AssertionError(
                f"Invalid state accepted: {document!r}"
            )

    print("PASS: malformed and out-of-range states rejected")

    # 4. Simulated permission failure.
    state_path.write_text(
        json.dumps({"inode": 12345, "offset": 67890}),
        encoding="utf-8",
    )
    original_open = Path.open

    def controlled_open(self, *args, **kwargs):
        if self == state_path:
            raise PermissionError("simulated permission failure")
        return original_open(self, *args, **kwargs)

    with patch.object(Path, "open", controlled_open):
        try:
            c.load_state()
        except RuntimeError as error:
            assert str(error) == "collector state is invalid"
        else:
            raise AssertionError("Permission failure was accepted")

    print("PASS: permission failure rejected safely")

print("PASS: STEP330-27B ALL TESTS")
PY

python3 /tmp/test_step330_27b.py
```

## 8.2　inodeと位置の復元の異常

**実行先：security-core VM 220（root）**

```bash
cat > /tmp/test_step330_27c.py <<'PY'
import importlib.util
import json
import tempfile
from pathlib import Path
from unittest.mock import patch

spec = importlib.util.spec_from_file_location(
    "collector_step330_27c",
    "/usr/local/lib/wazuh-collector/collector.py",
)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

with tempfile.TemporaryDirectory(prefix="step330-27c-") as tmp:
    root = Path(tmp)
    current = root / "alerts.json"
    state = root / "state.json"

    current.write_bytes(b'{"id":"one"}\n{"id":"two"}\n')

    c.ALERT_FILE = current
    c.ALERT_DIR = root
    c.STATE_FILE = state

    inode = current.stat().st_ino
    size = current.stat().st_size

    # 1. Valid current inode and offset.
    handle, active_inode = c.open_initial_file((inode, 0))
    assert active_inode == inode
    assert handle.tell() == 0
    assert handle.readline() == b'{"id":"one"}\n'
    handle.close()
    print("PASS: valid current inode resumed")

    # 2. Missing previous inode must be refused.
    try:
        c.open_initial_file((inode + 999999, 0))
    except RuntimeError as error:
        assert "cannot be located" in str(error)
    else:
        raise AssertionError("Missing inode was accepted")
    print("PASS: missing previous inode refused")

    # 3. Current file offset beyond EOF must be refused.
    try:
        c.open_initial_file((inode, size + 1))
    except RuntimeError as error:
        assert "exceeds current" in str(error)
    else:
        raise AssertionError("Oversized current offset accepted")
    print("PASS: current offset beyond EOF refused")

    # 4. Different inode with no matching old file must be refused.
    other = root / "other.json"
    other.write_bytes(b'{"id":"other"}\n')
    other_inode = other.stat().st_ino

    try:
        c.open_initial_file((other_inode + 999999, 0))
    except RuntimeError:
        pass
    else:
        raise AssertionError("Unverified inode accepted")
    print("PASS: unverified inode refused")

    # 5. Traversal permission error must propagate.
    original_scandir = c.os.scandir

    def failing_scandir(path):
        if Path(path) == root:
            raise PermissionError("simulated traversal failure")
        return original_scandir(path)

    with patch.object(c.os, "scandir", failing_scandir):
        try:
            c.find_inode_file(999999999)
        except PermissionError:
            pass
        else:
            raise AssertionError("Traversal error was swallowed")

    print("PASS: traversal permission error propagated")

print("PASS: STEP330-27C ALL TESTS")
PY

python3 /tmp/test_step330_27c.py
```

ディレクトリを探すときの権限のエラーは握りつぶされず、起動の拒否につながります（第5部で本番が起動しなかった原因と同じ経路が、正しく止まることの確認です）。

# 第9章　状態の保存の障害とファイルディスクリプタの修正

## 9.1　保存の途中の失敗

`save_state()` は、同じディレクトリに一時ファイルを作り、権限を `600` にして書き込み、`fsync()` してから `os.replace()` で置き換え、最後にディレクトリも `fsync()` します。途中で失敗したときに、古い状態ファイルが残るかどうかを確認します。

**実行先：security-core VM 220（root）**

```bash
cat > /tmp/test_step330_28b.py <<'PY'
import importlib.util
import json
import os
import tempfile
from pathlib import Path
from unittest.mock import patch

spec = importlib.util.spec_from_file_location(
    "collector_step330_28b",
    "/usr/local/lib/wazuh-collector/collector.py",
)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

with tempfile.TemporaryDirectory(prefix="step330-28b-") as tmp:
    root = Path(tmp)
    c.STATE_FILE = root / "state.json"
    state = c.STATE_FILE

    old = {"inode": 111, "offset": 222}
    new = {"inode": 333, "offset": 444}

    # 1. Normal save and JSON integrity.
    c.save_state(new["inode"], new["offset"])
    assert json.loads(state.read_text()) == new
    print("PASS: normal save and JSON integrity")

    # 2. Temporary file permissions and no leftovers.
    assert state.stat().st_mode & 0o777 == 0o600
    assert list(root.glob(".state-*")) == []
    print("PASS: mode 600 and no temporary leftovers")

    # Prepare an existing state for failure tests.
    state.write_text(json.dumps(old), encoding="utf-8")

    # 3. File fsync failure: old state must remain.
    original_fsync = os.fsync
    calls = {"count": 0}

    def fail_first_fsync(fd):
        calls["count"] += 1
        if calls["count"] == 1:
            raise OSError("simulated file fsync failure")
        return original_fsync(fd)

    with patch.object(c.os, "fsync", fail_first_fsync):
        try:
            c.save_state(new["inode"], new["offset"])
        except OSError:
            pass
        else:
            raise AssertionError("fsync failure was not propagated")

    assert json.loads(state.read_text()) == old
    assert list(root.glob(".state-*")) == []
    print("PASS: file fsync failure preserves old state")

    # 4. os.replace failure: old state must remain.
    with patch.object(
        c.os,
        "replace",
        side_effect=OSError("simulated replace failure"),
    ):
        try:
            c.save_state(new["inode"], new["offset"])
        except OSError:
            pass
        else:
            raise AssertionError("replace failure was not propagated")

    assert json.loads(state.read_text()) == old
    assert list(root.glob(".state-*")) == []
    print("PASS: replace failure preserves old state")

    # 5. Directory fsync failure happens after replacement.
    calls = {"count": 0}

    def fail_second_fsync(fd):
        calls["count"] += 1
        if calls["count"] == 2:
            raise OSError("simulated directory fsync failure")
        return original_fsync(fd)

    with patch.object(c.os, "fsync", fail_second_fsync):
        try:
            c.save_state(new["inode"], new["offset"])
        except OSError:
            pass
        else:
            raise AssertionError("directory fsync failure was not propagated")

    # Replacement already happened; new JSON should be visible.
    assert json.loads(state.read_text()) == new
    assert list(root.glob(".state-*")) == []
    print("PASS: directory fsync failure propagated after replacement")
    print("INFO: replacement is visible; crash durability is not guaranteed")

print("PASS: STEP330-28B ALL TESTS")
PY

python3 /tmp/test_step330_28b.py
```

| 失敗した箇所 | 結果 |
|---|---|
| ファイルの `fsync()` | 古い状態が残る |
| `os.replace()` | 古い状態が残る |
| ディレクトリの `fsync()` | 新しい状態に置き換わっている（電源断のときの永続性は保証されない） |

どの場合も、一時ファイルは残りません。

## 9.2　ファイルディスクリプタの解放の確認

`mkstemp()` で開いた一時ファイルが、権限の設定（`fchmod()`）に失敗したときにも閉じられるかを確認します。

**実行先：security-core VM 220（root）**

```bash
cat > /tmp/test_step330_28c.py <<'PY'
import importlib.util
import os
import tempfile
from pathlib import Path
from unittest.mock import patch

spec = importlib.util.spec_from_file_location(
    "collector_step330_28c",
    "/usr/local/lib/wazuh-collector/collector.py",
)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

with tempfile.TemporaryDirectory(prefix="step330-28c-") as tmp:
    c.STATE_FILE = Path(tmp) / "state.json"

    original_mkstemp = tempfile.mkstemp
    captured = {}

    def capture_mkstemp(*args, **kwargs):
        fd, path = original_mkstemp(*args, **kwargs)
        captured["fd"] = fd
        captured["path"] = path
        return fd, path

    with patch.object(c.tempfile, "mkstemp", capture_mkstemp):
        with patch.object(
            c.os,
            "fchmod",
            side_effect=OSError("simulated fchmod failure"),
        ):
            try:
                c.save_state(12345, 67890)
            except OSError:
                pass
            else:
                raise AssertionError("fchmod failure was not propagated")

    # Check whether the descriptor was closed.
    try:
        os.fstat(captured["fd"])
    except OSError:
        print("PASS: descriptor closed after fchmod failure")
    else:
        os.close(captured["fd"])
        print("FAIL: descriptor leaked after fchmod failure")

    assert not Path(captured["path"]).exists()
    print("PASS: temporary file removed after fchmod failure")

print("PASS: STEP330-28C TEST COMPLETED")
PY

python3 /tmp/test_step330_28c.py
```

構築時は `FAIL: descriptor leaked after fchmod failure` と表示されました。一時ファイルは削除されますが、`fchmod()` が失敗するとファイルディスクリプタが閉じられずに残ります。次節で修正します。

## 9.3　修正の方針とバックアップ

`os.fdopen()` でファイルディスクリプタをファイルオブジェクトに渡し、その `with` の中で `fchmod()` を行うように変えます。`fchmod()` が失敗しても、`with` を抜けるときにファイルが閉じられます。

まず本番のファイルをバックアップします。

**実行先：security-core VM 220（root）**

```bash
cp -a /usr/local/lib/wazuh-collector/collector.py \
  /usr/local/lib/wazuh-collector/collector.py.backup-before-step330-28d-20261119

sha256sum \
  /usr/local/lib/wazuh-collector/collector.py \
  /usr/local/lib/wazuh-collector/collector.py.backup-before-step330-28d-20261119
```

2つのハッシュが同じ（構築時は `df4a9ff6...`）であることを確認します。

## 9.4　一時コピーでの修正の試験

本番のコードを一時コピーに書き換え、ファイルディスクリプタが漏れないことを確認します。

**実行先：security-core VM 220（root）**

```bash
cat > /tmp/test_step330_28d.py <<'PY'
import importlib.util
import os
import tempfile
from pathlib import Path
from unittest.mock import patch

source = Path("/usr/local/lib/wazuh-collector/collector.py")
patched = Path("/tmp/collector_step330_28d.py")

code = source.read_text(encoding="utf-8")

old = '''        os.fchmod(fd, 0o600)

        with os.fdopen(fd, "w", encoding="utf-8") as output:
            json.dump(
                {"inode": inode, "offset": offset},
                output,
            )
            output.flush()
            os.fsync(output.fileno())
'''

new = '''        with os.fdopen(fd, "w", encoding="utf-8") as output:
            os.fchmod(output.fileno(), 0o600)
            json.dump(
                {"inode": inode, "offset": offset},
                output,
            )
            output.flush()
            os.fsync(output.fileno())
'''

assert code.count(old) == 1, "Target code block mismatch"
patched.write_text(code.replace(old, new), encoding="utf-8")

spec = importlib.util.spec_from_file_location(
    "collector_step330_28d",
    patched,
)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

with tempfile.TemporaryDirectory(prefix="step330-28d-") as tmp:
    c.STATE_FILE = Path(tmp) / "state.json"

    before = set(os.listdir("/proc/self/fd"))

    with patch.object(
        c.os,
        "fchmod",
        side_effect=OSError("simulated fchmod failure"),
    ):
        try:
            c.save_state(12345, 67890)
        except OSError:
            pass
        else:
            raise AssertionError("fchmod failure was not propagated")

    after = set(os.listdir("/proc/self/fd"))

    assert before == after, (
        f"FD leak detected: before={before}, after={after}"
    )
    assert list(Path(tmp).glob(".state-*")) == []

    print("PASS: no FD leak after fchmod failure")
    print("PASS: temporary file removed")

    c.save_state(12345, 67890)
    assert c.STATE_FILE.stat().st_mode & 0o777 == 0o600
    print("PASS: normal save and mode 600")

print("PASS: STEP330-28D ALL TESTS")
PY

python3 /tmp/test_step330_28d.py
```

続けて、9.1の試験を修正版の一時コピーに対して実行し、これまでの動作が変わっていないことを確かめます。

```bash
sed \
  's|/usr/local/lib/wazuh-collector/collector.py|/tmp/collector_step330_28d.py|' \
  /tmp/test_step330_28b.py \
  > /tmp/test_step330_28e.py

python3 /tmp/test_step330_28e.py
```

## 9.5　反映前の確認

**実行先：security-core VM 220（root）**

```bash
echo "=== SERVICE ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts

echo
echo "=== PRODUCTION HASH ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== STATE METADATA ==="
stat -c 'owner=%U:%G mode=%a size=%s' \
  /var/lib/wazuh-collector/state.json

echo
echo "=== STATE / ALERT FILE CONSISTENCY ==="
python3 - <<'PY'
import json
from pathlib import Path

state_path = Path("/var/lib/wazuh-collector/state.json")
alert_path = Path("/var/ossec/logs/alerts/alerts.json")

state = json.loads(state_path.read_text())
st = alert_path.stat()

print("state_inode:", state["inode"])
print("file_inode:", st.st_ino)
print("state_offset:", state["offset"])
print("file_size:", st.st_size)
print("inode_match:", state["inode"] == st.st_ino)
print("offset_within_file:", 0 <= state["offset"] <= st.st_size)
PY
```

`inode_match: True` と `offset_within_file: True` を確認します。

## 9.6　本番への修正の反映

本番とバックアップのハッシュを確かめてから、該当の箇所だけを書き換え、所有者と権限を保ったまま一度に置き換えます。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import os
import tempfile
from pathlib import Path

target = Path("/usr/local/lib/wazuh-collector/collector.py")
backup = Path(
    "/usr/local/lib/wazuh-collector/"
    "collector.py.backup-before-step330-28d-20261119"
)

expected = "df4a9ff6c55767851bf9c9831c1d96862e876a4f030d52aa9e394224e51d0a3e"

import hashlib

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert sha256(target) == expected, "Production file changed unexpectedly"
assert sha256(backup) == expected, "Backup hash mismatch"

old = '''        os.fchmod(fd, 0o600)

        with os.fdopen(fd, "w", encoding="utf-8") as output:
            json.dump(
                {"inode": inode, "offset": offset},
                output,
            )
            output.flush()
            os.fsync(output.fileno())
'''

new = '''        with os.fdopen(fd, "w", encoding="utf-8") as output:
            os.fchmod(output.fileno(), 0o600)
            json.dump(
                {"inode": inode, "offset": offset},
                output,
            )
            output.flush()
            os.fsync(output.fileno())
'''

source = target.read_text(encoding="utf-8")
assert source.count(old) == 1, "Target code block mismatch"
updated = source.replace(old, new)

metadata = target.stat()
fd, temporary = tempfile.mkstemp(
    prefix=".collector-step330-28g-",
    dir=str(target.parent),
)

try:
    os.fchown(fd, metadata.st_uid, metadata.st_gid)
    os.fchmod(fd, metadata.st_mode & 0o7777)

    with os.fdopen(fd, "w", encoding="utf-8") as output:
        output.write(updated)
        output.flush()
        os.fsync(output.fileno())

    os.replace(temporary, target)

    directory_fd = os.open(target.parent, os.O_DIRECTORY)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)

except Exception:
    try:
        os.unlink(temporary)
    except FileNotFoundError:
        pass
    raise

print("PASS: production patch installed")
print("SHA256:", sha256(target))
print("OWNER:", target.stat().st_uid, target.stat().st_gid)
print("MODE:", oct(target.stat().st_mode & 0o7777))
PY

python3 -m py_compile /usr/local/lib/wazuh-collector/collector.py
```

`expected` の値は、自分の環境の本番（反映前）のハッシュに置き換えます。構築時の反映後のハッシュは `a2015974...`、所有者は `root:root`、権限は `755` でした。

## 9.7　反映後の確認

**実行先：security-core VM 220（root）**

```bash
echo "=== PRODUCTION DIFF ==="
diff -u \
  /usr/local/lib/wazuh-collector/collector.py.backup-before-step330-28d-20261119 \
  /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== SAVE_STATE ==="
sed -n '249,283p' /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== SERVICE ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts

echo
echo "=== PRODUCTION HASH ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== STATE FILE ==="
stat -c 'owner=%U:%G mode=%a size=%s' \
  /var/lib/wazuh-collector/state.json
```

差分が `save_state()` の1か所だけであることを確認します。

最後に、本番のコードを読み込んで、一時ディレクトリで修正後の動作を確かめます。

```bash
cat > /tmp/test_step330_28i.py <<'PY'
import importlib.util
import os
import tempfile
from pathlib import Path
from unittest.mock import patch

spec = importlib.util.spec_from_file_location(
    "collector_step330_28i",
    "/usr/local/lib/wazuh-collector/collector.py",
)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

with tempfile.TemporaryDirectory(prefix="step330-28i-") as tmp:
    c.STATE_FILE = Path(tmp) / "state.json"

    c.save_state(12345, 67890)
    assert c.STATE_FILE.stat().st_mode & 0o777 == 0o600
    print("PASS: production save_state normal operation")

    before = set(os.listdir("/proc/self/fd"))

    with patch.object(
        c.os,
        "fchmod",
        side_effect=OSError("simulated fchmod failure"),
    ):
        try:
            c.save_state(12346, 67891)
        except OSError:
            pass
        else:
            raise AssertionError("Expected fchmod failure")

    after = set(os.listdir("/proc/self/fd"))

    assert before == after, (before, after)
    assert list(Path(tmp).glob(".state-*")) == []
    print("PASS: production save_state FD cleanup")
    print("PASS: temporary file cleanup")

print("PASS: STEP330-28I ALL TESTS")
PY

python3 /tmp/test_step330_28i.py
```

> この時点ではサービスを再起動していません。動いているCollectorのプロセス（構築時はPID `91473`）は、再起動するまで反映前のコードで動き続けます。ファイルの修正は、次にサービスを再起動したときから使われます。

# 第10章　保存する値の検証の追加

## 10.1　読み込み側の境界の確認

`load_state()` は `safe_integer()` でinodeと位置を検証していますが、`save_state()` は受け取った値をそのままJSONにしています。まず、どの値が読み込みで拒否されるかを確かめます。

**実行先：security-core VM 220（root）**

```bash
cat > /tmp/test_step330_29b.py <<'PY'
import importlib.util
import json
import tempfile
from pathlib import Path

spec = importlib.util.spec_from_file_location(
    "collector_step330_29b",
    "/usr/local/lib/wazuh-collector/collector.py",
)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

with tempfile.TemporaryDirectory(prefix="step330-29b-") as tmp:
    c.STATE_FILE = Path(tmp) / "state.json"

    cases = [
        ("valid", 123, 456, True),
        ("inode_zero", 0, 456, False),
        ("inode_negative", -1, 456, False),
        ("inode_bool", True, 456, False),
        ("offset_negative", 123, -1, False),
        ("offset_bool", 123, False, False),
        ("inode_too_large", 2**63, 456, False),
        ("offset_too_large", 123, 2**63, False),
        ("inode_string", "123", 456, False),
        ("offset_string", 123, "456", False),
        ("inode_none", None, 456, False),
        ("offset_none", 123, None, False),
    ]

    for name, inode, offset, expected_valid in cases:
        c.save_state(inode, offset)

        try:
            loaded = c.load_state()
            actual_valid = loaded is not None
        except RuntimeError:
            loaded = None
            actual_valid = False

        print(
            name,
            "accepted" if actual_valid else "rejected",
            "loaded=", repr(loaded),
        )

        assert actual_valid == expected_valid, (
            name,
            expected_valid,
            actual_valid,
        )

    # Non-JSON-serializable object.
    try:
        c.save_state(object(), 1)
    except TypeError:
        print("PASS: non-serializable inode rejected by JSON")
    else:
        raise AssertionError("non-serializable inode unexpectedly saved")

print("PASS: STEP330-29B ALL TESTS")
PY
```

`safe_integer()` は、数字だけの文字列（`"123"` など）も整数として受け付ける仕様です。そのため、文字列の2件の期待値を「受け付ける」に直してから実行します。

```bash
sed -i \
  -e 's/("inode_string", "123", 456, False)/("inode_string", "123", 456, True)/' \
  -e 's/("offset_string", 123, "456", False)/("offset_string", 123, "456", True)/' \
  /tmp/test_step330_29b.py

python3 /tmp/test_step330_29b.py
```

読み込みのときには、0・負の数・真偽値・上限を超える値・`None` が拒否されました。

## 10.2　問題の再現

不正な値が保存されてしまうと、正常な状態ファイルが置き換わり、次に起動したときに読み込みで拒否されて、Collectorが止まります。現在の `save_state()` で確かめます。

**実行先：security-core VM 220（root）**

```bash
cat > /tmp/test_step330_29d.py <<'PY'
import importlib.util
import tempfile
from pathlib import Path

spec = importlib.util.spec_from_file_location(
    "collector_step330_29d",
    "/usr/local/lib/wazuh-collector/collector.py",
)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

with tempfile.TemporaryDirectory(prefix="step330-29d-") as tmp:
    root = Path(tmp)
    c.STATE_FILE = root / "state.json"

    c.save_state(123, 456)
    print("baseline:", c.load_state())

    for name, inode, offset in [
        ("negative_inode", -1, 456),
        ("boolean_inode", True, 456),
        ("negative_offset", 123, -1),
        ("boolean_offset", 123, True),
        ("string_inode", "123", 456),
    ]:
        try:
            c.save_state(inode, offset)
            print(name, "SAVED", "state=", c.STATE_FILE.read_text())
        except Exception as error:
            print(name, "REJECTED", type(error).__name__)

    print("temporary_files:", list(root.glob(".state-*")))

print("STEP330-29D REPRODUCTION COMPLETED")
PY

python3 /tmp/test_step330_29d.py
```

構築時は5件すべてが `SAVED`（保存された）になりました。

## 10.3　一時コピーでの修正の試験

`save_state()` の最初で、inodeは `1`〜`2^63-1` の整数、位置は `0`〜`2^63-1` の整数だけを受け付け、それ以外は一時ファイルを作る前に `ValueError` にします。保存のときは、数字の文字列も拒否します。

**実行先：security-core VM 220（root）**

```bash
cat > /tmp/test_step330_29e.py <<'PY'
import importlib.util
import tempfile
from pathlib import Path

source = Path("/usr/local/lib/wazuh-collector/collector.py")
patched = Path("/tmp/collector_step330_29e.py")

code = source.read_text(encoding="utf-8")

old = '''def save_state(inode, offset):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
'''

new = '''def save_state(inode, offset):
    if (
        isinstance(inode, bool)
        or not isinstance(inode, int)
        or not 1 <= inode <= 9223372036854775807
    ):
        raise ValueError("invalid state inode")

    if (
        isinstance(offset, bool)
        or not isinstance(offset, int)
        or not 0 <= offset <= 9223372036854775807
    ):
        raise ValueError("invalid state offset")

    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
'''

assert code.count(old) == 1
patched.write_text(code.replace(old, new), encoding="utf-8")

spec = importlib.util.spec_from_file_location(
    "collector_step330_29e",
    patched,
)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

with tempfile.TemporaryDirectory(prefix="step330-29e-") as tmp:
    root = Path(tmp)
    c.STATE_FILE = root / "state.json"

    c.save_state(123, 456)
    original = c.STATE_FILE.read_text()
    assert c.load_state() == (123, 456)
    print("PASS: valid integer state")

    invalid = [
        ("negative_inode", -1, 456),
        ("zero_inode", 0, 456),
        ("boolean_inode", True, 456),
        ("string_inode", "123", 456),
        ("none_inode", None, 456),
        ("large_inode", 2**63, 456),
        ("negative_offset", 123, -1),
        ("boolean_offset", 123, False),
        ("string_offset", 123, "456"),
        ("none_offset", 123, None),
        ("large_offset", 123, 2**63),
    ]

    for name, inode, offset in invalid:
        try:
            c.save_state(inode, offset)
        except ValueError:
            pass
        else:
            raise AssertionError(f"{name}: invalid value accepted")

        assert c.STATE_FILE.read_text() == original, (
            f"{name}: existing state changed"
        )
        assert list(root.glob(".state-*")) == [], (
            f"{name}: temporary file remains"
        )
        print("PASS:", name, "rejected; old state preserved")

    c.save_state(1, 0)
    assert c.load_state() == (1, 0)
    c.save_state(2**63 - 1, 2**63 - 1)
    assert c.load_state() == (2**63 - 1, 2**63 - 1)
    print("PASS: integer boundary values")

print("PASS: STEP330-29E ALL TESTS")
PY

python3 /tmp/test_step330_29e.py
```

続けて、同じ一時コピーで、保存の失敗の後に再試行できることを確かめます。

```bash
cat > /tmp/test_step330_29f.py <<'PY'
import importlib.util
import json
import os
import tempfile
from pathlib import Path
from unittest.mock import patch

spec = importlib.util.spec_from_file_location(
    "collector_step330_29f",
    "/tmp/collector_step330_29e.py",
)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

with tempfile.TemporaryDirectory(prefix="step330-29f-") as tmp:
    root = Path(tmp)
    c.STATE_FILE = root / "state.json"

    old = {"inode": 100, "offset": 200}
    new = {"inode": 300, "offset": 400}

    c.save_state(old["inode"], old["offset"])

    # 1. os.replace failure, followed by retry.
    with patch.object(
        c.os,
        "replace",
        side_effect=OSError("simulated replace failure"),
    ):
        try:
            c.save_state(new["inode"], new["offset"])
        except OSError:
            pass
        else:
            raise AssertionError("replace failure not propagated")

    assert json.loads(c.STATE_FILE.read_text()) == old
    assert list(root.glob(".state-*")) == []
    print("PASS: replace failure preserves old state")

    c.save_state(new["inode"], new["offset"])
    assert json.loads(c.STATE_FILE.read_text()) == new
    print("PASS: retry after replace failure")

    # 2. File fsync failure, followed by retry.
    c.save_state(old["inode"], old["offset"])
    original_fsync = os.fsync
    calls = {"count": 0}

    def fail_first_fsync(fd):
        calls["count"] += 1
        if calls["count"] == 1:
            raise OSError("simulated file fsync failure")
        return original_fsync(fd)

    with patch.object(c.os, "fsync", fail_first_fsync):
        try:
            c.save_state(new["inode"], new["offset"])
        except OSError:
            pass
        else:
            raise AssertionError("fsync failure not propagated")

    assert json.loads(c.STATE_FILE.read_text()) == old
    assert list(root.glob(".state-*")) == []
    print("PASS: fsync failure preserves old state")

    c.save_state(new["inode"], new["offset"])
    assert json.loads(c.STATE_FILE.read_text()) == new
    print("PASS: retry after fsync failure")

print("PASS: STEP330-29F ALL TESTS")
PY

python3 /tmp/test_step330_29f.py
```

## 10.4　反映前のバックアップと確認

**実行先：security-core VM 220（root）**

```bash
cp -a /usr/local/lib/wazuh-collector/collector.py \
  /usr/local/lib/wazuh-collector/collector.py.backup-before-step330-29g-20261119

echo "=== HASH ==="
sha256sum \
  /usr/local/lib/wazuh-collector/collector.py \
  /usr/local/lib/wazuh-collector/collector.py.backup-before-step330-29g-20261119

echo
echo "=== SERVICE ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts

echo
echo "=== STATE ==="
stat -c 'owner=%U:%G mode=%a size=%s' \
  /var/lib/wazuh-collector/state.json

python3 - <<'PY'
import json
from pathlib import Path

state = json.loads(
    Path("/var/lib/wazuh-collector/state.json").read_text()
)
st = Path("/var/ossec/logs/alerts/alerts.json").stat()

print("state_inode:", state["inode"])
print("file_inode:", st.st_ino)
print("state_offset:", state["offset"])
print("file_size:", st.st_size)
print("inode_match:", state["inode"] == st.st_ino)
print("offset_within_file:", 0 <= state["offset"] <= st.st_size)
PY
```

## 10.5　本番への反映

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import hashlib
import os
import tempfile
from pathlib import Path

target = Path("/usr/local/lib/wazuh-collector/collector.py")
backup = Path(
    "/usr/local/lib/wazuh-collector/"
    "collector.py.backup-before-step330-29g-20261119"
)

expected = "a20159748087c4c26df7103cc5c5314f67a41b5cf56a98c2afea98ce4724bcb3"

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert sha256(target) == expected, "Production file changed"
assert sha256(backup) == expected, "Backup mismatch"

old = '''def save_state(inode, offset):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
'''

new = '''def save_state(inode, offset):
    if (
        isinstance(inode, bool)
        or not isinstance(inode, int)
        or not 1 <= inode <= 9223372036854775807
    ):
        raise ValueError("invalid state inode")

    if (
        isinstance(offset, bool)
        or not isinstance(offset, int)
        or not 0 <= offset <= 9223372036854775807
    ):
        raise ValueError("invalid state offset")

    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
'''

source = target.read_text(encoding="utf-8")
assert source.count(old) == 1, "Target block mismatch"

updated = source.replace(old, new)
metadata = target.stat()

fd, temporary = tempfile.mkstemp(
    prefix=".collector-step330-29h-",
    dir=str(target.parent),
)

try:
    os.fchown(fd, metadata.st_uid, metadata.st_gid)
    os.fchmod(fd, metadata.st_mode & 0o7777)

    with os.fdopen(fd, "w", encoding="utf-8") as output:
        output.write(updated)
        output.flush()
        os.fsync(output.fileno())

    os.replace(temporary, target)

    directory_fd = os.open(target.parent, os.O_DIRECTORY)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)

except Exception:
    try:
        os.unlink(temporary)
    except FileNotFoundError:
        pass
    raise

print("PASS: production patch installed")
print("SHA256:", sha256(target))
print("OWNER:", target.stat().st_uid, target.stat().st_gid)
print("MODE:", oct(target.stat().st_mode & 0o7777))
PY

python3 -m py_compile /usr/local/lib/wazuh-collector/collector.py
```

構築時の反映後のハッシュは `faf2c203...` でした。ここでもサービスは再起動していません。

## 10.6　本番のコードでの動作確認

**実行先：security-core VM 220（root）**

```bash
cat > /tmp/test_step330_29i.py <<'PY'
import importlib.util
import json
import tempfile
from pathlib import Path

spec = importlib.util.spec_from_file_location(
    "collector_step330_29i",
    "/usr/local/lib/wazuh-collector/collector.py",
)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

with tempfile.TemporaryDirectory(prefix="step330-29i-") as tmp:
    root = Path(tmp)
    c.STATE_FILE = root / "state.json"

    # Valid state
    c.save_state(100, 200)
    assert json.loads(c.STATE_FILE.read_text()) == {
        "inode": 100,
        "offset": 200,
    }
    assert (c.STATE_FILE.stat().st_mode & 0o777) == 0o600
    print("PASS: valid state saved with mode 600")

    # Invalid inode and offset values
    invalid_cases = [
        (0, 0),
        (-1, 0),
        (True, 0),
        ("100", 0),
        (None, 0),
        (9223372036854775808, 0),
        (100, -1),
        (100, True),
        (100, "200"),
        (100, None),
        (100, 9223372036854775808),
    ]

    for inode, offset in invalid_cases:
        before = c.STATE_FILE.read_bytes()
        try:
            c.save_state(inode, offset)
        except ValueError:
            pass
        else:
            raise AssertionError(
                f"Invalid state accepted: {inode!r}, {offset!r}"
            )

        assert c.STATE_FILE.read_bytes() == before

    assert json.loads(c.STATE_FILE.read_text()) == {
        "inode": 100,
        "offset": 200,
    }
    assert list(root.iterdir()) == [c.STATE_FILE]
    print("PASS: invalid values rejected; old state preserved; no temp files")

    # Boundary values
    c.save_state(1, 0)
    assert json.loads(c.STATE_FILE.read_text()) == {
        "inode": 1,
        "offset": 0,
    }

    c.save_state(9223372036854775807, 9223372036854775807)
    assert json.loads(c.STATE_FILE.read_text()) == {
        "inode": 9223372036854775807,
        "offset": 9223372036854775807,
    }
    print("PASS: minimum and maximum boundaries")

print("PASS: STEP330-29I ALL TESTS")
PY

python3 /tmp/test_step330_29i.py
```

# 第11章　修正の有効化（再起動）

## 11.1　差分と稼働状態の確認

**実行先：security-core VM 220（root）**

```bash
echo "=== PRODUCTION DIFF ==="
diff -u \
  /usr/local/lib/wazuh-collector/collector.py.backup-before-step330-29g-20261119 \
  /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== SYNTAX ==="
python3 -m py_compile /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== PRODUCTION HASH ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== SERVICE ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts -p ExecMainStatus

echo
echo "=== STATE INTEGRITY ==="
python3 - <<'PY'
import json
from pathlib import Path

state_path = Path("/var/lib/wazuh-collector/state.json")
alerts_path = Path("/var/ossec/logs/alerts/alerts.json")

state = json.loads(state_path.read_text())
st = alerts_path.stat()

print("state_owner:", state_path.stat().st_uid, state_path.stat().st_gid)
print("state_mode:", oct(state_path.stat().st_mode & 0o777))
print("state_inode:", state["inode"])
print("file_inode:", st.st_ino)
print("state_offset:", state["offset"])
print("file_size:", st.st_size)
print("inode_match:", state["inode"] == st.st_ino)
print("offset_within_file:", 0 <= state["offset"] <= st.st_size)
PY
```

差分が `save_state()` の入力の検証（14行）だけであることを確かめます。第9章・第10章の修正はディスク上のファイルにだけ入っていて、動いているプロセス（構築時はPID `91473`）は古いコードのままです。

## 11.2　再起動

再起動の直前に、サービスの状態、状態ファイルの位置と `alerts.json` が一致していること、本番のハッシュ（構築時は `faf2c203...`）を記録しておきます（11.1の出力を使えます）。

**実行先：security-core VM 220（root）**

```bash
systemctl restart wazuh-collector
```

## 11.3　再起動後の確認

**実行先：security-core VM 220（root）**

```bash
echo "=== SERVICE ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts -p ExecMainStatus

echo
echo "=== RECENT LOGS ==="
journalctl -u wazuh-collector -n 20 --no-pager

echo
echo "=== PRODUCTION CODE HASH ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== STATE AND ALERT FILE ==="
python3 - <<'PY'
import json
from pathlib import Path

state_path = Path("/var/lib/wazuh-collector/state.json")
alerts_path = Path("/var/ossec/logs/alerts/alerts.json")

state = json.loads(state_path.read_text())
st = alerts_path.stat()

print("state:", state)
print("file_inode:", st.st_ino)
print("file_size:", st.st_size)
print("inode_match:", state["inode"] == st.st_ino)
print("offset_within_file:", 0 <= state["offset"] <= st.st_size)
print("state_owner:", state_path.stat().st_uid, state_path.stat().st_gid)
print("state_mode:", oct(state_path.stat().st_mode & 0o777))
PY
```

構築時は新しいPID `92423` で起動し、`Wazuh alert collector starting` と表示され、再起動前と同じinode・位置から再開しました。

```bash
echo "=== SERVICE ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts

echo
echo "=== LOGS SINCE RESTART ==="
journalctl -u wazuh-collector --since "2026-11-18 23:04:00" --no-pager

echo
echo "=== DATABASE CONNECTION MESSAGES ==="
journalctl -u wazuh-collector --since "2026-11-18 23:04:00" --no-pager \
  | grep -E 'PostgreSQL connection established|ERROR|WARNING|Duplicate alert|Invalid JSON|Alert rejected' \
  || true
```

`--since` の時刻は、再起動した時刻に合わせます。新しいアラートを読んだ後に `PostgreSQL connection established` が表示されれば、DBに接続できています。

## 11.4　取り込みと読み取り位置の追従

**実行先：LXC 109 postgresql（root）**

```bash
sudo -u postgres psql -d security_workbench -c "
SELECT
    COUNT(*) AS total_events,
    MAX(ingested_at) AS latest_ingested_at
FROM incident.alert_events;
"
```

構築時は735件から755件に増えていました。

**実行先：security-core VM 220（root）**

```bash
echo "=== SERVICE ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts -p ExecMainStatus

echo
echo "=== STATE AND ALERT FILE ==="
python3 - <<'PY'
import json
from pathlib import Path

state_path = Path("/var/lib/wazuh-collector/state.json")
alerts_path = Path("/var/ossec/logs/alerts/alerts.json")

state = json.loads(state_path.read_text())
st = alerts_path.stat()

print("state:", state)
print("file_inode:", st.st_ino)
print("file_size:", st.st_size)
print("inode_match:", state["inode"] == st.st_ino)
print("offset_within_file:", 0 <= state["offset"] <= st.st_size)
print("state_at_eof:", state["offset"] == st.st_size)
print("state_owner:", state_path.stat().st_uid, state_path.stat().st_gid)
print("state_mode:", oct(state_path.stat().st_mode & 0o777))
PY

echo
echo "=== POST-RESTART WARNINGS / ERRORS ==="
journalctl -u wazuh-collector --since "2026-11-18 23:04:00" --no-pager \
  | grep -Ei 'error|warning|traceback|failed|duplicate|invalid json|alert rejected' \
  || true

echo
echo "=== ACTIVE PROCESS ==="
ps -o pid,uid,gid,etimes,stat,cmd -p "$(systemctl show -p MainPID --value wazuh-collector)"
```

| 確認項目 | 構築時の結果 |
|---|---|
| プロセス | PID `92423`（UID 996 / GID 987） |
| 状態 | `active` / `running`、再起動の回数 `0` |
| 読み取り位置 | ファイルの末尾（2,762,833バイト）と一致 |
| 状態ファイルの権限 | `600` |
| 再起動後のエラー・警告 | なし |

# 第12章　重複の再処理と状態の保存の失敗

## 12.1　設計の確認

構築時にコードを読んで確かめた、登録とローテーションの設計は次のとおりです。

| 項目 | 内容 |
|---|---|
| イベントID | Wazuhのアラートの `id`（128文字まで）。IDのないイベントは拒否 |
| 登録 | 通常の `INSERT`（`ON CONFLICT` は使わない） |
| 状態の保存 | DBへの登録が成功した後 |
| 重複 | SQLSTATE `23505` だけを処理済みにする |
| ローテーション | 新しいファイルのinodeと位置 `0` を先に保存してから切り替える |

DBに登録した後で状態の保存に失敗すると、同じ行をもう一度処理します。そのとき、同じIDのイベントは重複として扱われ、二重に登録されません。

## 12.2　重複の再処理

疑似のDB接続を使い、1回目は登録、同じイベントの再処理は重複として処理済み、次の別のイベントは登録されることを確認します。

**実行先：security-core VM 220（root）**

```bash
cat > /tmp/test_step330_31d.py <<'PY'
import importlib.util
from contextlib import contextmanager

import psycopg

spec = importlib.util.spec_from_file_location(
    "collector_step330_31d",
    "/usr/local/lib/wazuh-collector/collector.py",
)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)


class FakeConnection:
    def __init__(self):
        self.ids = set()
        self.calls = 0

    @contextmanager
    def transaction(self):
        yield

    def execute(self, sql, event):
        self.calls += 1
        event_id = event["event_id"]

        if event_id in self.ids:
            raise psycopg.errors.UniqueViolation(
                "duplicate event_id"
            )

        self.ids.add(event_id)


connection = FakeConnection()

event = {
    "event_id": "step330-31d-test-event",
}

# Mock extraction to isolate process_line's DB behavior.
original_extract = c.extract_event
c.extract_event = lambda alert: event

try:
    # First delivery.
    c.process_line(connection, b'{"id":"step330-31d-test-event"}')
    assert connection.ids == {event["event_id"]}
    assert connection.calls == 1
    print("PASS: first insert")

    # Retry after simulated state-save failure.
    c.process_line(connection, b'{"id":"step330-31d-test-event"}')
    assert connection.ids == {event["event_id"]}
    assert connection.calls == 2
    print("PASS: duplicate retry handled")

    # A subsequent different event must still be accepted.
    next_event = {"event_id": "step330-31d-next-event"}
    c.extract_event = lambda alert: next_event

    c.process_line(connection, b'{"id":"step330-31d-next-event"}')
    assert connection.ids == {
        "step330-31d-test-event",
        "step330-31d-next-event",
    }
    assert connection.calls == 3
    print("PASS: subsequent event accepted")

finally:
    c.extract_event = original_extract

print("PASS: STEP330-31D ALL TESTS")
PY

python3 /tmp/test_step330_31d.py
```

## 12.3　状態の保存の失敗と再試行の組み合わせ

DBへの登録が成功した後に状態の保存が失敗し、行の先頭に戻って同じイベントを処理し直す流れを、一時ディレクトリで再現します。

**実行先：security-core VM 220（root）**

```bash
cat > /tmp/test_step330_31e.py <<'PY'
import importlib.util
import io
import json
import os
import tempfile
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch

import psycopg

spec = importlib.util.spec_from_file_location(
    "collector_step330_31e",
    "/usr/local/lib/wazuh-collector/collector.py",
)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)


class FakeConnection:
    def __init__(self):
        self.ids = set()
        self.insert_count = 0

    @contextmanager
    def transaction(self):
        yield

    def execute(self, sql, event):
        event_id = event["event_id"]

        if event_id in self.ids:
            raise psycopg.errors.UniqueViolation(
                "duplicate event_id"
            )

        self.ids.add(event_id)
        self.insert_count += 1


with tempfile.TemporaryDirectory(
    prefix="step330-31e-"
) as temp_dir:

    # 本番stateファイルには触れず、一時領域を使用する。
    c.STATE_FILE = Path(temp_dir) / "state.json"

    connection = FakeConnection()
    event = {"event_id": "step330-31e-test-event"}

    original_extract = c.extract_event
    c.extract_event = lambda alert: event

    line = b'{"id":"step330-31e-test-event"}\n'
    stream = io.BytesIO(line)

    try:
        # 初期stateを作成。
        c.save_state(12345, 0)
        assert c.load_state() == (12345, 0)
        print("PASS: initial state")

        # 初回DB登録。
        c.process_line(connection, line)
        assert connection.insert_count == 1
        assert len(connection.ids) == 1
        print("PASS: first DB insert")

        # 最初のfsyncを意図的に失敗させる。
        real_fsync = os.fsync
        fsync_calls = {"count": 0}

        def fail_first_fsync(fd):
            fsync_calls["count"] += 1
            if fsync_calls["count"] == 1:
                raise OSError("simulated fsync failure")
            return real_fsync(fd)

        try:
            with patch.object(c.os, "fsync", fail_first_fsync):
                c.save_state(12345, len(line))
            raise AssertionError("expected fsync failure")
        except OSError:
            pass

        # 旧stateが維持されていること。
        assert c.load_state() == (12345, 0)
        print("PASS: failed state save preserves old state")

        # Collectorと同様に読み取り位置を先頭へ戻す。
        stream.seek(0)
        assert stream.tell() == 0
        print("PASS: input position rewound")

        # 同じイベントを再処理。重複としてスキップされる。
        retry_line = stream.readline()
        c.process_line(connection, retry_line)

        assert connection.insert_count == 1
        assert len(connection.ids) == 1
        print("PASS: duplicate retry skipped")

        # 再試行時のstate保存は成功する。
        c.save_state(12345, stream.tell())

        saved = c.load_state()
        assert saved == (12345, len(line))
        print("PASS: state saved after retry")

        # 一時ファイルが残っていないこと。
        leftovers = list(Path(temp_dir).glob(".state-*"))
        assert leftovers == []
        print("PASS: no temporary state files")

    finally:
        c.extract_event = original_extract

print("PASS: STEP330-31E ALL TESTS")
PY

python3 /tmp/test_step330_31e.py
```

| 確認項目 | 結果 |
|---|---|
| 状態の保存の失敗 | 古い状態が残る |
| 行の先頭への巻き戻し | 同じイベントを読み直す |
| 再処理 | 重複として扱われ、登録は1件のまま |
| 再試行での保存 | 成功し、一時ファイルも残らない |

# 第13章　ローテーション時の保存の失敗と最終確認

## 13.1　本番の稼働状態（読み取りだけ）

**実行先：security-core VM 220（root）**

```bash
echo "=== SERVICE STATUS ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts

echo
echo "=== PRODUCTION CODE HASH ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== STATE AND ALERT FILE ==="
python3 - <<'PY'
import json
import os
from pathlib import Path

state_path = Path("/var/lib/wazuh-collector/state.json")
alert_path = Path("/var/ossec/logs/alerts/alerts.json")

state = json.loads(state_path.read_text())
state_stat = state_path.stat()
alert_stat = alert_path.stat()

print("state_owner_uid:", state_stat.st_uid)
print("state_owner_gid:", state_stat.st_gid)
print("state_mode:", oct(state_stat.st_mode & 0o777))
print("state_inode:", state["inode"])
print("state_offset:", state["offset"])
print("alert_inode:", alert_stat.st_ino)
print("alert_size:", alert_stat.st_size)
print("inode_match:", state["inode"] == alert_stat.st_ino)
print("offset_within_file:", 0 <= state["offset"] <= alert_stat.st_size)
print("state_at_eof:", state["offset"] == alert_stat.st_size)
PY
```

構築時は、PID `92423`、再起動の回数 `0`、`inode_match`・`offset_within_file`・`state_at_eof` がすべて `True` でした。

## 13.2　ローテーションの処理の確認

**実行先：security-core VM 220（root）**

```bash
echo "=== ROTATION FUNCTIONS ==="
grep -n -A45 -B5 -E 'def safe_open_current_alert_file|def open_initial_file|def save_state' \
  /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== ROTATION CALL SITES ==="
grep -n -A55 -B15 -E 'safe_open_current_alert_file|Switched to new alerts.json inode|State save failed during rotation' \
  /usr/local/lib/wazuh-collector/collector.py
```

ローテーションの処理は、ファイルの末尾に達したときと、未完了の行を読んでいる途中の2か所にあります。どちらも、新しいファイルの状態の保存が成功するまで古いファイルを開いたままにし、保存に失敗したときは新しいファイルを閉じて、次の確認のときにやり直します。

## 13.3　ファイルの末尾でのローテーションと保存の失敗

**実行先：security-core VM 220（root）**

```bash
cat > /tmp/test_step330_33a.py <<'PY'
import importlib.util
import tempfile
from pathlib import Path

spec = importlib.util.spec_from_file_location(
    "collector_step330_33a",
    "/usr/local/lib/wazuh-collector/collector.py",
)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

with tempfile.TemporaryDirectory(prefix="step330-33a-") as tmp:
    root = Path(tmp)
    c.ALERT_FILE = root / "alerts.json"
    c.STATE_FILE = root / "state.json"

    old_path = c.ALERT_FILE
    rotated_path = root / "alerts.json.1"

    old_path.write_bytes(b'{"id":"old-event"}\n')
    old_handle = old_path.open("rb")
    old_inode = old_handle.fileno()
    import os
    old_inode = os.fstat(old_inode).st_ino
    old_offset = old_handle.seek(0, 2)

    c.save_state(old_inode, old_offset)
    assert c.load_state() == (old_inode, old_offset)
    print("PASS: initial old-file state")

    # Simulate rename and creation of a new alerts.json.
    old_path.rename(rotated_path)
    old_path.write_bytes(b'{"id":"new-event"}\n')

    new_inode = old_path.stat().st_ino
    assert new_inode != old_inode
    print("PASS: new inode created")

    original_save_state = c.save_state
    attempts = {"count": 0}

    def fail_once(inode, offset):
        attempts["count"] += 1
        if attempts["count"] == 1:
            raise OSError("simulated state save failure")
        return original_save_state(inode, offset)

    c.save_state = fail_once
    active_handle = old_handle
    active_inode = old_inode

    try:
        # First rotation attempt: state save fails.
        new_handle, new_stat = c.safe_open_current_alert_file()
        assert new_handle is not None
        assert new_stat.st_ino == new_inode

        try:
            c.save_state(new_stat.st_ino, 0)
        except OSError:
            new_handle.close()

        assert not active_handle.closed
        assert active_inode == old_inode
        assert c.load_state() == (old_inode, old_offset)
        print("PASS: failed save preserves old handle and state")

        # Second attempt: state save succeeds.
        new_handle, new_stat = c.safe_open_current_alert_file()
        assert new_handle is not None
        assert new_stat.st_ino == new_inode

        c.save_state(new_stat.st_ino, 0)

        active_handle.close()
        active_handle = new_handle
        active_inode = new_stat.st_ino

        assert active_inode == new_inode
        assert c.load_state() == (new_inode, 0)
        print("PASS: retry switches to new inode")

        # Verify new file can be read from offset zero.
        line = active_handle.readline()
        assert line == b'{"id":"new-event"}\n'
        print("PASS: new file starts at offset zero")

        assert attempts["count"] == 2
        print("PASS: exactly one failed save and one successful retry")

    finally:
        c.save_state = original_save_state
        if not active_handle.closed:
            active_handle.close()

print("PASS: STEP330-33A ALL TESTS")
PY

python3 /tmp/test_step330_33a.py
```

## 13.4　未完了の行の途中でのローテーションと保存の失敗

**実行先：security-core VM 220（root）**

```bash
cat > /tmp/test_step330_33b.py <<'PY'
import importlib.util
import os
import tempfile
from pathlib import Path

spec = importlib.util.spec_from_file_location(
    "collector_step330_33b",
    "/usr/local/lib/wazuh-collector/collector.py",
)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

with tempfile.TemporaryDirectory(prefix="step330-33b-") as tmp:
    root = Path(tmp)
    c.ALERT_FILE = root / "alerts.json"
    c.STATE_FILE = root / "state.json"

    old_path = c.ALERT_FILE
    rotated_path = root / "alerts.json.1"

    # Old file contains an incomplete JSON line.
    old_path.write_bytes(b'{"id":"incomplete-old')
    old_handle = old_path.open("rb")
    old_inode = os.fstat(old_handle.fileno()).st_ino

    c.save_state(old_inode, 0)

    status, line, discarding = c.read_alert_line(old_handle)
    assert status == "incomplete"
    assert line is None
    assert not discarding
    line_start = 0
    print("PASS: incomplete line detected")

    # Simulate rotation and creation of a complete new event.
    old_path.rename(rotated_path)
    old_path.write_bytes(b'{"id":"new-event"}\n')
    new_inode = old_path.stat().st_ino

    assert new_inode != old_inode
    print("PASS: rotation detected")

    original_save_state = c.save_state
    attempts = {"count": 0}

    def fail_once(inode, offset):
        attempts["count"] += 1
        if attempts["count"] == 1:
            raise OSError("simulated state save failure")
        return original_save_state(inode, offset)

    c.save_state = fail_once
    active_handle = old_handle
    active_inode = old_inode

    try:
        # First attempt: state save fails.
        new_handle, new_stat = c.safe_open_current_alert_file()
        assert new_handle is not None
        assert new_stat.st_ino == new_inode

        try:
            c.save_state(new_stat.st_ino, 0)
        except OSError:
            new_handle.close()
            active_handle.seek(line_start)

        assert not active_handle.closed
        assert active_handle.tell() == line_start
        assert active_inode == old_inode
        assert c.load_state() == (old_inode, 0)
        print("PASS: failure preserves old handle and rewinds")

        # Second attempt: state save succeeds.
        new_handle, new_stat = c.safe_open_current_alert_file()
        assert new_handle is not None
        assert new_stat.st_ino == new_inode

        c.save_state(new_stat.st_ino, 0)

        active_handle.close()
        active_handle = new_handle
        active_inode = new_stat.st_ino

        assert active_inode == new_inode
        assert c.load_state() == (new_inode, 0)
        print("PASS: retry switches to new inode")

        # New file begins with a complete event.
        status, line, discarding = c.read_alert_line(active_handle)
        assert status == "line"
        assert line == b'{"id":"new-event"}\n'
        assert not discarding
        print("PASS: new event read from beginning")

        assert attempts["count"] == 2
        print("PASS: one failed save followed by successful retry")

    finally:
        c.save_state = original_save_state
        if not active_handle.closed:
            active_handle.close()

print("PASS: STEP330-33B ALL TESTS")
PY

python3 /tmp/test_step330_33b.py
```

どちらの場合も、保存に1回失敗しても古いファイルと状態が保たれ、2回目で新しいファイルに切り替わって、新しいファイルの最初の行から正しく読めました。本番のコードの変更は不要でした。

# 第7部のまとめ

## 本番のCollectorの変更の履歴（第7部）

| 段階 | SHA-256 | 内容 | 有効化 |
|---|---|---|---|
| 第6部の最後 | `ac297477...` | 旧ファイルの再帰探索 | ― |
| 1.3 | `df4a9ff6...` | 読み取り位置の検証 | 1.4の再起動 |
| 9.6 | `a2015974...` | 状態の保存のファイルディスクリプタの修正 | 11.2の再起動 |
| 10.5 | `faf2c203...` | 保存する値の検証 | 11.2の再起動 |

## バックアップ

| ファイル | 中身 |
|---|---|
| `collector.py.backup-before-step330-offset-20261119` | `ac297477...` |
| `collector.py.backup-before-step330-28d-20261119` | `df4a9ff6...` |
| `collector.py.backup-before-step330-29g-20261119` | `a2015974...` |

## 検証した異常系

| 分類 | 内容 | 章 |
|---|---|---|
| DB | 重複とセーブポイント（実際のDB、ロールバックのみ） | 第3章 |
| 起動 | 再開・旧inodeの欠落・位置の超過 | 第4章 |
| 読み込み | 未完了の行、1 MiBを超える行、読み捨て中のローテーション | 第4章・第5章 |
| 入力 | 境界値、過大な入力、異常な入れ子、型の違い | 第6章 |
| DBの障害 | 障害の伝達、重複だけの処理済み、行の先頭への巻き戻し | 第7章・第12章 |
| 状態ファイル | 壊れた内容・権限のエラー・探索のエラー | 第8章 |
| 状態の保存 | `fsync`・置き換えの失敗、ファイルディスクリプタ、不正な値 | 第9章・第10章 |
| ローテーション | 保存の失敗と再試行（末尾・未完了の行） | 第13章 |

## 第7部終了時点の状態

| 項目 | 状態 |
|---|---|
| Collector | `active` / `running`（PID `92423`、再起動の回数 `0`） |
| 本番のコード | `faf2c203...` |
| 読み取り位置 | `alerts.json` の末尾と一致 |
| DB | 755件（構築時）、テストのデータの残りなし |

## 未対応の課題

| 課題 | 内容 |
|---|---|
| 圧縮後の旧ファイルからの再開 | Collectorが止まっている間に、読み途中だった旧ファイル（`alerts/年/月/ossec-alerts-DD.json`）が圧縮（`.json.gz`）されると、保存したinodeのファイルが見つからないため、Collectorは起動を拒否します（安全側に止まる設計です）。この場合の復旧手順は、構築時には作っていません。 |

> Collectorを長く止めたままにしないでください。日付が変わってローテーションと圧縮が行われる前に再起動すれば、この状態にはなりません。
