---
title: "AI自律型サイバー防御システム 構築マニュアル 前編"
subtitle: "第22部　Relayと接続情報の点検"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」前編の第22部です。第14部〜第21部で作った Wazuh → Relay → AI Defense Manager のつながりを、設定は変えずに**読み取りだけで**点検します。

| 点検の対象 | 場所 |
|---|---|
| VM 230 から Relay への接続（接続情報・TLS） | VM 230 |
| Relay のサービス・プログラム・待ち受け・秘密の情報 | VM 220 |
| Indexer の読み取り専用ユーザー（認証・検索の権限・返る項目） | VM 220 |

## 本書の表記

- コマンドやプログラムは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 実行先は、各手順の「実行先」に示します。
  - **VM 230**：ai-defense-manager（root）
  - **VM 220**：security-core（root）
- パスワードやトークンの中身は表示しません。パスワードを使うプログラムは、ファイルから読み込んで使うだけで、画面には出しません。

# 第1章　VM 230の側

## 1.1　Wazuhのサービスの有無

> **実行先：VM 230**

```bash
systemctl list-units --type=service --all --no-pager | grep -Ei 'wazuh|filebeat|ossec'
```

構築時は何も出ませんでした。VM 230 は Wazuh のエージェントではなく、Relay の `/v1/alerts` を HTTPS で呼んでアラートを受け取る作りです。

## 1.2　Relayを呼ぶコードと設定

```bash
cd /opt/ai-defense-manager && sed -n '1,260p' app/services/wazuh_relay.py
```

```bash
cd /opt/ai-defense-manager && grep -n -B 3 -A 5 -E 'wazuh_relay_(base_url|ca_file|token_file|timeout_seconds)' app/core/config.py
```

確かめられたことは次のとおりです。

- CA 証明書で TLS を検証している
- Bearer トークンはファイルから読み、コードやログには出さない
- リダイレクトをたどらない。タイムアウトがある（1〜60秒）
- 取る件数は最大100件、期間は最大24時間
- `full_log` や任意の `data` は取り込まない

## 1.3　接続情報の権限

```bash
stat -c '%A %a %U:%G %n' /etc/ai-defense-manager /etc/ai-defense-manager/credentials /etc/ai-defense-manager/credentials/relay-ca.crt /etc/ai-defense-manager/credentials/relay-api.token
```

| 対象 | 権限 |
|---|---|
| `/etc/ai-defense-manager` | `755 root:root` |
| `credentials/` | `750 root:ai-defense` |
| `relay-ca.crt` | `640 root:ai-defense` |
| `relay-api.token` | `640 root:ai-defense` |

## 1.4　TLSの点検

トークンは送らず、証明書だけを確かめます。

```bash
openssl x509 -in /etc/ai-defense-manager/credentials/relay-ca.crt -noout -subject -issuer -dates -fingerprint -sha256
```

構築時は、`AI-Defense-Relay-Internal-CA` の自己署名の CA 証明書で、有効期間は 2026年11月20日〜2036年11月17日でした。

```bash
openssl s_client -connect 192.168.0.220:8765 -CAfile /etc/ai-defense-manager/credentials/relay-ca.crt -verify_return_error -brief </dev/null
```

TLS 1.3 で接続でき、`Verification: OK` でした。アプリは IP アドレスで接続するので、証明書の SAN に IP アドレスが入っているかも確かめます。

```bash
openssl s_client -connect 192.168.0.220:8765 -CAfile /etc/ai-defense-manager/credentials/relay-ca.crt -showcerts </dev/null 2>/dev/null | openssl x509 -noout -subject -ext subjectAltName
```

`IP Address:192.168.0.220` が入っていれば、設定の URL（`https://192.168.0.220:8765/`）と一致しています。

# 第2章　Relayの側

## 2.1　サービス

> **実行先：VM 220**

```bash
hostnamectl && systemctl status ai-defense-relay.service --no-pager -l
```

構築時は Ubuntu 24.04.5 LTS で、`ai-defense-relay.service` は `active (running)`、VM 230（`192.168.0.33`）からの要求は `200` で記録されていました。

## 2.2　プログラム

```bash
sed -n '1,300p' /opt/ai-defense-relay/relay.py
```

確かめられた安全のための対策は次のとおりです。

- 接続元を `192.168.0.33` に限る
- Bearer トークンを `hmac.compare_digest()` で比べる
- Indexer への接続も CA 証明書で TLS を検証する
- Indexer の検索の件数と期間を制限する
- `_source` と `sanitize_alert()` の両方で、返す項目を限る（`full_log` や任意の `data` は返さない）
- `POST`・`PUT`・`DELETE` などの変更の要求を断る。TLS 1.2 より古いものを断る
- 同時に処理する要求は8つまで。Indexer の応答は 2MiB まで
- エラーの応答に、内部の例外や認証の情報を入れない

> **注意**　構築時に表示された relay.py には、第14部 4.1〜4.3 の内容に加えて、アクセスのログを「接続元のIPアドレスとステータス」だけにする変更と、同時に処理する要求を8つまでにする変更（`threading.BoundedSemaphore(8)`）が入っていました。この変更の手順は構築の記録にありません（不足情報メモ 14-A）。

## 2.3　サービスの定義

```bash
systemctl cat ai-defense-relay.service
```

専用のユーザー（root ではない）で動き、秘密の情報は `LoadCredential` で渡し、特権を持たず、ファイルシステムは原則として読み取り専用、メモリやタスクの数にも上限があります（第14部 5.1）。

## 2.4　待ち受け

```bash
ss -lntp | grep -E '(:8765|:9200)\b'
```

| サービス | 待ち受け |
|---|---|
| Relay | `192.168.0.220:8765`（決めたIPだけ） |
| Wazuh Indexer | `127.0.0.1:9200`（ローカルだけ） |

Indexer にはほかのホストから直接つなげず、Relay を通す作りになっています。

```bash
ufw status verbose
```

構築時、VM 220 の UFW は無効でした。Relay は決めた IP だけで待ち受け、アプリでも接続元を限っていますが、ネットワークの層での制限は別のものです。UFW を有効にすると Wazuh などの通信に影響するおそれがあるため、ここでは変えません（不足情報メモ 22-A）。

## 2.5　秘密の情報の権限

```bash
stat -c '%A %a %U:%G %n' /etc/credstore /etc/credstore/ai-defense-relay-token /etc/credstore/ai-defense-indexer-password /etc/credstore/ai-defense-indexer-ca /etc/credstore/ai-defense-relay-server-cert /etc/credstore/ai-defense-relay-server-key
```

`/etc/credstore` は `700 root:root`、中のファイルはすべて `600 root:root` でした。

# 第3章　Indexerの読み取り専用ユーザー

## 3.1　ディスクの上の設定ファイル

> **実行先：VM 220**

```bash
grep -n -A 12 -B 4 'ai-defense-reader' /etc/wazuh-indexer/opensearch-security/roles.yml /etc/wazuh-indexer/opensearch-security/roles_mapping.yml
```

```bash
grep -RIl --include='*.yml' --include='*.yaml' 'ai-defense-reader' /etc/wazuh-indexer/opensearch-security/
```

どちらも何も出ませんでした。ユーザーの名前だけを表示して確かめます（パスワードのハッシュは表示しません）。

```bash
find /etc/wazuh-indexer/opensearch-security -maxdepth 2 -type f -printf '%f\n' | sort
```

```bash
awk '/^[^[:space:]#][^:]*:/{name=$1; sub(/:$/,"",name); if(name!="") print name}' /etc/wazuh-indexer/opensearch-security/internal_users.yml
```

```bash
sed -n '1,260p' /etc/wazuh-indexer/opensearch-security/roles.yml && printf '\n--- ROLE MAPPINGS ---\n' && sed -n '1,260p' /etc/wazuh-indexer/opensearch-security/roles_mapping.yml
```

ディスクの上の `internal_users.yml`・`roles.yml`・`roles_mapping.yml` には、`ai-defense-reader` も `ai_defense_alerts_read` もありません。第13部では、この3つのファイルを直接書き換えず、`/root` に用意した合成済みのファイル（`/root/ai_defense_merged_*.yml`）を `securityadmin.sh` で Indexer に送ったため、このようになっています。

```bash
grep -nE 'authc:|authentication_backend|http_authenticator|type:|order:|http_enabled|transport_enabled|roles_key|userbase|usersearch|username_attribute|backend' /etc/wazuh-indexer/opensearch-security/config.yml
```

HTTP の認証は、Basic 認証と内部のユーザーデータベース（`type: intern`）です。

## 3.2　動いているIndexerでの認証

ディスクのファイルではなく、動いている Indexer が `ai-defense-reader` を認証するかを確かめます。パスワードは `/etc/credstore` から読み込み、表示しません。

```bash
python3 - <<'PY'
import base64, json, ssl, urllib.request, urllib.error

password = open(
    "/etc/credstore/ai-defense-indexer-password", "r"
).read().strip()

token = base64.b64encode(
    ("ai-defense-reader:" + password).encode()
).decode()

request = urllib.request.Request(
    "https://127.0.0.1:9200/_plugins/_security/authinfo",
    headers={"Authorization": "Basic " + token},
)

context = ssl.create_default_context(
    cafile="/etc/credstore/ai-defense-indexer-ca"
)

try:
    with urllib.request.urlopen(request, context=context, timeout=10) as response:
        data = json.loads(response.read())
        print("HTTP_STATUS:", response.status)
        for key in ("user_name", "backend_roles", "roles", "is_admin"):
            if key in data:
                print(f"{key}: {data[key]}")
except urllib.error.HTTPError as exc:
    print("HTTP_STATUS:", exc.code)
    print("AUTHENTICATION_OR_AUTHORIZATION_FAILED")
except Exception as exc:
    print("CHECK_ERROR:", type(exc).__name__)
PY
```

構築時は `HTTP_STATUS: 200` で、ロールは `own_index` と `ai_defense_alerts_read` でした。

## 3.3　管理のAPIは使えないこと

```bash
python3 - <<'PY'
import base64, json, ssl, urllib.request, urllib.error

password = open("/etc/credstore/ai-defense-indexer-password").read().strip()
auth = base64.b64encode(("ai-defense-reader:" + password).encode()).decode()
request = urllib.request.Request(
    "https://127.0.0.1:9200/_plugins/_security/api/roles/ai_defense_alerts_read",
    headers={"Authorization": "Basic " + auth},
)
context = ssl.create_default_context(cafile="/etc/credstore/ai-defense-indexer-ca")

try:
    with urllib.request.urlopen(request, context=context, timeout=10) as response:
        data = json.loads(response.read())
        print("HTTP_STATUS:", response.status)
        print(json.dumps(data, indent=2))
except urllib.error.HTTPError as exc:
    print("HTTP_STATUS:", exc.code)
    print("ROLE_DEFINITION_NOT_READABLE_BY_THIS_ACCOUNT")
except Exception as exc:
    print("CHECK_ERROR:", type(exc).__name__)
PY
```

`HTTP_STATUS: 403` でした。アラートを読むだけのユーザーには、ロールの定義を見る管理の権限は要りません。権限は足しません。

## 3.4　アラートの検索

本文は取らず（`_source: False`）、検索が許されているかだけを確かめます。

```bash
python3 - <<'PY'
import base64, json, ssl, urllib.request, urllib.error

password = open("/etc/credstore/ai-defense-indexer-password").read().strip()
auth = base64.b64encode(("ai-defense-reader:" + password).encode()).decode()

query = {
    "size": 1,
    "track_total_hits": False,
    "_source": False,
    "query": {
        "range": {
            "timestamp": {"gte": "now-15m"}
        }
    }
}

request = urllib.request.Request(
    "https://127.0.0.1:9200/wazuh-alerts-4.x-*/_search",
    data=json.dumps(query).encode(),
    headers={
        "Authorization": "Basic " + auth,
        "Content-Type": "application/json",
    },
    method="POST",
)

context = ssl.create_default_context(
    cafile="/etc/credstore/ai-defense-indexer-ca"
)

try:
    with urllib.request.urlopen(request, context=context, timeout=10) as response:
        data = json.loads(response.read())
        hits = data.get("hits", {}).get("hits", [])
        print("HTTP_STATUS:", response.status)
        print("SEARCH_API_ACCESS: OK")
        print("RETURNED_HITS:", len(hits))
except urllib.error.HTTPError as exc:
    print("HTTP_STATUS:", exc.code)
    print("SEARCH_API_ACCESS: DENIED")
except Exception as exc:
    print("CHECK_ERROR:", type(exc).__name__)
PY
```

## 3.5　返る項目

Relay と同じ10項目を指定して1件取り、返った項目の名前だけを表示します（値は表示しません）。

```bash
python3 - <<'PY'
import base64, json, ssl, urllib.request

password = open("/etc/credstore/ai-defense-indexer-password").read().strip()
auth = base64.b64encode(("ai-defense-reader:" + password).encode()).decode()

fields = [
    "timestamp", "agent.id", "agent.ip", "agent.name",
    "manager.name", "rule.level", "rule.description",
    "rule.id", "location", "decoder.name"
]

query = {
    "size": 1,
    "track_total_hits": False,
    "_source": fields,
    "query": {"range": {"timestamp": {"gte": "now-15m"}}}
}

request = urllib.request.Request(
    "https://127.0.0.1:9200/wazuh-alerts-4.x-*/_search",
    data=json.dumps(query).encode(),
    headers={"Authorization": "Basic " + auth, "Content-Type": "application/json"},
    method="POST"
)

context = ssl.create_default_context(
    cafile="/etc/credstore/ai-defense-indexer-ca"
)

with urllib.request.urlopen(request, context=context, timeout=10) as response:
    data = json.loads(response.read())
    hits = data.get("hits", {}).get("hits", [])
    print("HTTP_STATUS:", response.status)
    print("RETURNED_HITS:", len(hits))
    if hits:
        source = hits[0].get("_source", {})
        print("RETURNED_FIELDS:", sorted(source.keys()))
        forbidden = {"full_log", "data", "command", "pwd", "user"}
        print("FORBIDDEN_FIELDS_PRESENT:", sorted(forbidden.intersection(source)))
PY
```

構築時は、`agent`・`decoder`・`location`・`manager`・`rule`・`timestamp` の6つが返り、`full_log`・`data`・`command`・`pwd`・`user` は返りませんでした。

## 3.6　設定ファイルとバックアップ

```bash
ls -ld /etc/wazuh-indexer /etc/wazuh-indexer/opensearch-security
```

```bash
find /etc/wazuh-indexer/opensearch-security -maxdepth 1 -type f -printf '%f  %TY-%Tm-%Td %TH:%TM  %m\n' | sort
```

ディスクの上の `internal_users.yml` に、このユーザーの定義があるかを、パスワードのハッシュを出さずに確かめます。

```bash
python3 - <<'PY'
import yaml

path = "/etc/wazuh-indexer/opensearch-security/internal_users.yml"

with open(path, encoding="utf-8") as f:
    users = yaml.safe_load(f)

user = users.get("ai-defense-reader")

if user is None:
    print("DISK_USER_DEFINITION: NOT_FOUND")
else:
    print("DISK_USER_DEFINITION: FOUND")
    for key in ("reserved", "hidden", "backend_roles", "attributes"):
        if key in user:
            print(f"{key}: {user[key]}")
    print("PASSWORD_FIELD: PRESENT" if "hash" in user else "PASSWORD_FIELD: ABSENT")
PY
```

```bash
find /etc/wazuh-indexer -maxdepth 3 -type f \( -iname '*internal_users*' -o -iname '*roles*' -o -iname '*security*' \) -printf '%p\n' | sort
```

```bash
python3 - <<'PY'
import yaml
from pathlib import Path

base = Path("/etc/wazuh-indexer/internalusers-backup")

for path in sorted(base.glob("internal_users_*.yml.bkp")):
    with path.open(encoding="utf-8") as f:
        users = yaml.safe_load(f) or {}

    user = users.get("ai-defense-reader")
    print(f"\nFILE: {path.name}")
    print("USER_FOUND:", user is not None)

    if user is not None:
        for key in ("reserved", "hidden", "backend_roles", "attributes"):
            if key in user:
                print(f"{key}: {user[key]}")
        print("PASSWORD_HASH_PRESENT:", "hash" in user)
PY
```

構築時は、ディスクの上の `internal_users.yml` にも、3つのバックアップにも `ai-defense-reader` はありませんでした。

| 確認項目 | 結果 |
|---|---|
| 動いている Indexer の `ai-defense-reader` | ある（認証できる） |
| `ai_defense_alerts_read` ロール | 有効（検索できる） |
| ディスクの上の `internal_users.yml`・`roles.yml` | 定義がない |

動いている設定とディスクの上の YAML が一致していません。この状態で YAML を `securityadmin.sh` で適用し直すと、`ai-defense-reader` が消えて Relay が動かなくなります。**ディスクの上の YAML をそのまま適用し直さないでください**（不足情報メモ 22-B）。

# おわりに

第22部の点検の結果は次のとおりです。

| 対象 | 結果 |
|---|---|
| VM 230 の接続情報の権限・TLS・SAN | 問題なし |
| Relay のサービス・プログラム・待ち受け・秘密の情報の権限 | 問題なし |
| `ai-defense-reader` の認証・検索・返る項目 | 問題なし（管理のAPIは `403`） |
| VM 220 の UFW | 無効（ここでは変えない） |
| Indexer の動いている設定とディスクの YAML | 一致していない |

次の部では、Indexer のロールの中身と、設定の変更の記録（監査ログ）がどこに残るかを調べます。
