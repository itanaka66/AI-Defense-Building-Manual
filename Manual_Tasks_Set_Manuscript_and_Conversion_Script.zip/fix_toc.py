import sys, re, json, subprocess, zipfile, shutil, os
md, docx, mode = sys.argv[1], sys.argv[2], sys.argv[3]
check = len(sys.argv) > 4
SOFFICE = '/root/.claude/skills/synced/93df845f-f758-4b7d-9b65-042f3545c8c6_c28cc224-a416-4580-b970-aeb3e1f28ee1/docx/scripts/office/soffice.py'

# mirror margins for KDP (gutter on inside)
if mode == 'kdp':
    tmp = docx + '.tmp'
    with zipfile.ZipFile(docx) as zi, zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED) as zo:
        for it in zi.infolist():
            d = zi.read(it.filename)
            if it.filename == 'word/settings.xml' and b'mirrorMargins' not in d:
                d = re.sub(rb'(<w:settings[^>]*>)', rb'\1<w:mirrorMargins/>', d, count=1)
            if not it.filename.endswith('/'):
                zo.writestr(it, d)
    shutil.move(tmp, docx)

src = open(md, encoding='utf-8').read()
src = re.sub(r'^---\n[\s\S]*?\n---\n', '', src)
src = re.sub(r'```[\s\S]*?```', '', src)
heads = [m.group(2) for m in re.finditer(r'^(#{1,2}) (.*)$', re.sub(r'^```.*?^```', '', src, flags=re.S|re.M), re.M)]

outdir = os.path.dirname(os.path.abspath(docx))
subprocess.run(['python3', SOFFICE, '--headless', '--convert-to', 'pdf', '--outdir', outdir, docx], check=True, capture_output=True)
pdf = docx[:-5] + '.pdf'
txt = subprocess.run(['pdftotext', '-layout', pdf, '-'], capture_output=True, text=True).stdout
pages = [re.sub(r'\s+', '', p) for p in txt.split('\f')]
norm = lambda s: re.sub(r'\s+', '', s.replace('**', '').replace('`', ''))
# TOC occupies the pages listing all headings; start searching after the last TOC page
start = min(i for i, p in enumerate(pages) if norm(heads[-1]) in p) if heads else 0
res, cur = [], start + 1
for h in heads:
    k = cur
    while k < len(pages) and norm(h) not in pages[k]:
        k += 1
    if k >= len(pages):
        print('NOT FOUND', h); k = cur
    res.append(k + 1); cur = k
if check:
    old = json.load(open(docx + '.toc.json'))
    print('TOC stable' if old == res else 'TOC CHANGED', len(pages) - 1, 'pages')
else:
    json.dump(res, open(docx + '.toc.json', 'w'))
