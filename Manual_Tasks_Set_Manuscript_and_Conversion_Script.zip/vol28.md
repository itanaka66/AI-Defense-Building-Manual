---
title: "AI自律型サイバー防御システム 構築マニュアル 中編"
subtitle: "第28部　Collectorの点検と停止の原因"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」中編の第28部です。Wazuh のアラート（`alerts.json`）を PostgreSQL（LXC 109）に送る Collector（`/usr/local/lib/wazuh-collector/collector.py`、前編 第3部〜第9部）について、次のことを行います。

1. コードを読み、PostgreSQL に何を保存しているかを点検する（読み取りだけ）
2. 点検の途中で、Collector が**再起動を繰り返して止まっている**ことがわかったので、原因を調べる

原因は2つありました。前編 第9部で起きたことと同じです。

| # | 原因 |
|---|---|
| 1 | ログの切り替え（日ごとのローテーション）で新しくできた `alerts.json` に、Collector の読み取りのACLが付いていなかった |
| 2 | Collector が、前に読んでいたファイル（保存した inode）を探す途中で、前に作った試験用の隠しディレクトリ（`.acl-inheritance-test.bkv8vd`）に入れずに止まった |

本書では1つ目を直し、2つ目の原因を突き止めるところまでを扱います。復旧は第29部、再発の防止は第30部で行います。

## 本書の表記

- コマンドやプログラムは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 実行先は **security-core VM 220（root）** です。
- コードを表示するプログラムは、パスワード・トークン・接続文字列などを含む行を `[SENSITIVE LINE OMITTED]` に置き換えて表示します。

# 第1章　保存する内容の点検

## 1.1　関数の構成

```bash
python3 - <<'PY'
import re
p = "/usr/local/lib/wazuh-collector/collector.py"
patterns = re.compile(
    r'^\s*(async\s+)?def\s+|^\s*class\s+|INSERT_SQL|'
    r'extract_event|process_line|full_log|audit_request_body|'
    r'field_names|UniqueViolation|SAVEPOINT|ROLLBACK TO'
)
with open(p, encoding="utf-8") as f:
    for n, line in enumerate(f, 1):
        if patterns.search(line):
            if re.search(r'password|passwd|secret|token|dsn|api_key', line, re.I):
                print(f"{n}: [SENSITIVE LINE OMITTED]")
            else:
                print(f"{n}: {line.rstrip()[:180]}")
PY
```

`extract_event()` でイベントの項目を取り出し、`process_line()` から `INSERT_SQL` で保存する作りです。

## 1.2　取り出す項目とINSERT

```bash
python3 - <<'PY'
p = "/usr/local/lib/wazuh-collector/collector.py"
ranges = [(41, 80), (191, 248), (504, 525)]
with open(p, encoding="utf-8") as f:
    lines = f.readlines()
for start, end in ranges:
    print(f"\n===== collector.py:{start}-{end} =====")
    for n in range(start, min(end, len(lines)) + 1):
        line = lines[n-1]
        if any(x in line.lower() for x in ("password", "passwd", "secret", "token", "dsn", "api_key")):
            print(f"{n}: [SENSITIVE LINE OMITTED]")
        else:
            print(f"{n}: {line.rstrip()}")
PY
```

- INSERT する列は13に決まっている
- `full_log`・`audit_request_body`・イベントの `data` の全体は保存しない（`data` からは `srcip` と `srcport` だけを取る）
- `UniqueViolation` は SQLSTATE `23505`（同じ `event_id`）のときだけ「重複」として扱う
- DB への書き込みはトランザクションの中で行う

## 1.3　文字列の整え方

```bash
python3 - <<'PY'
p = "/usr/local/lib/wazuh-collector/collector.py"
ranges = [(126, 190)]
with open(p, encoding="utf-8") as f:
    lines = f.readlines()
for start, end in ranges:
    print(f"===== collector.py:{start}-{end} =====")
    for n in range(start, min(end, len(lines)) + 1):
        print(f"{n}: {lines[n-1].rstrip()}")
PY
```

`safe_text()` は、制御文字・見えない書式の文字を取り除き、前後の空白を取り、長さを制限します。MITRE の情報は `id`・`tactic`・`technique` の3つだけです。ただし、これは形を整える処理で、パスワードやユーザー名を意味で見つけて取り除く処理ではありません（`rule.description`・`agent.name` などはそのまま保存されます。不足情報メモ 28-A）。

## 1.4　読み続ける処理

```bash
python3 - <<'PY'
p = "/usr/local/lib/wazuh-collector/collector.py"
with open(p, encoding="utf-8") as f:
    lines = f.readlines()
for n in range(526, min(590, len(lines)) + 1):
    line = lines[n-1]
    if any(x in line.lower() for x in ("password", "passwd", "secret", "token", "dsn", "api_key")):
        print(f"{n}: [SENSITIVE LINE OMITTED]")
    else:
        print(f"{n}: {line.rstrip()}")
PY
```

```bash
python3 - <<'PY'
p = "/usr/local/lib/wazuh-collector/collector.py"
ranges = [(249, 296), (458, 503), (579, 680)]
with open(p, encoding="utf-8") as f:
    lines = f.readlines()
for start, end in ranges:
    print(f"\n===== collector.py:{start}-{end} =====")
    for n in range(start, min(end, len(lines)) + 1):
        print(f"{n}: {lines[n-1].rstrip()}")
PY
```

- PostgreSQL につながらないときは、その行の頭に戻り、5秒後にやり直す
- 処理に失敗したときも行の頭に戻り、接続を閉じてつなぎ直す
- 接続のエラーのログには、例外の種類の名前だけを書く（接続の情報を出さない）

```bash
python3 - <<'PY'
p = "/usr/local/lib/wazuh-collector/collector.py"
with open(p, encoding="utf-8") as f:
    lines = f.readlines()
for n in range(675, min(760, len(lines)) + 1):
    line = lines[n-1]
    if any(x in line.lower() for x in ("password", "passwd", "secret", "token", "dsn", "api_key")):
        print(f"{n}: [SENSITIVE LINE OMITTED]")
    else:
        print(f"{n}: {line.rstrip()}")
PY
```

- 読み取り位置（状態ファイル）は、一時ファイルに書いて `fsync` してから `os.replace` で置き換える（権限 `0600`）
- 長すぎる行は、中身をログに出さずに読み飛ばす
- ファイルが切り替わったら、新しい inode のファイルの先頭から読む
- 終わるときは、ファイルと DB の接続を閉じる

## 1.5　状態ファイルの検証

```bash
python3 - <<'PY'
p = "/usr/local/lib/wazuh-collector/collector.py"
with open(p, encoding="utf-8") as f:
    lines = f.readlines()
for n in range(297, 328):
    print(f"{n}: {lines[n-1].rstrip()}")
PY
```

`load_state()` は、中身が辞書でない・`inode` や `offset` が整数の範囲にないときは、先頭から読み直すのではなく `RuntimeError` で止まります。状態ファイルがないときだけ、初めての起動として扱います。

```bash
python3 - <<'PY'
p = "/usr/local/lib/wazuh-collector/collector.py"
with open(p, encoding="utf-8") as f:
    lines = f.readlines()
for n in range(81, 116):
    print(f"{n}: {lines[n-1].rstrip()}")
PY
```

`safe_integer()` は `bool`（Python では `int` の仲間）を整数として受け付けず、文字列は ASCII の数字だけ・20桁までに限ります。`parse_timestamp()` はタイムゾーンのない日時を受け付けません。

## 1.6　ファイルの開き方

```bash
python3 - <<'PY'
p = "/usr/local/lib/wazuh-collector/collector.py"
ranges = [(328, 457)]
with open(p, encoding="utf-8") as f:
    lines = f.readlines()
for start, end in ranges:
    print(f"===== collector.py:{start}-{end} =====")
    for n in range(start, min(end, len(lines)) + 1):
        line = lines[n-1]
        if any(x in line.lower() for x in ("password", "passwd", "secret", "token", "dsn", "api_key")):
            print(f"{n}: [SENSITIVE LINE OMITTED]")
        else:
            print(f"{n}: {line.rstrip()}")
PY
```

- 保存した inode と今のファイルを比べ、切り替わっていれば前の inode のファイルを探して続きを読む
- 前のファイルが見つからない・保存した位置がファイルより大きいときは、**黙って読み飛ばさずに止まる**
- ディレクトリを探すとき、シンボリックリンクはたどらない。圧縮したファイルは探さない

`safe_open_current_alert_file()` という名前ですが、中身は次の2行だけでした（コードの一部）。

```text
handle = ALERT_FILE.open("rb")
actual_stat = os.fstat(handle.fileno())
```

`O_NOFOLLOW`（シンボリックリンクを開かない）や通常のファイルかどうかの確認はありません。権限を確かめます。

```bash
python3 - <<'PY'
import os
import stat
from pathlib import Path

p = Path("/var/ossec/logs/alerts")
for path in (Path("/var/ossec"), Path("/var/ossec/logs"), p, p / "alerts.json"):
    try:
        s = path.lstat()
        print(
            f"{path}: "
            f"type={'symlink' if stat.S_ISLNK(s.st_mode) else 'regular' if stat.S_ISREG(s.st_mode) else 'directory' if stat.S_ISDIR(s.st_mode) else 'other'} "
            f"owner={s.st_uid}:{s.st_gid} "
            f"mode={stat.S_IMODE(s.st_mode):04o}"
        )
    except OSError as e:
        print(f"{path}: {type(e).__name__}")
PY
```

| 対象 | 持ち主 | 権限 |
|---|---|---|
| `/var/ossec` | root:110 | 0750 |
| `/var/ossec/logs` | 110:110 | 0770 |
| `/var/ossec/logs/alerts` | 110:110 | 0750 |
| `alerts.json` | 110:110 | 0640 |

`/var/ossec/logs` はグループ110が書き込めます。すぐに変える必要はないと判断しました（不足情報メモ 28-B）。

# 第2章　Collectorが止まっていた

## 2.1　サービスの状態

```bash
id
```

今のシェルは root です。Collector のサービスの状態を見ます。

```bash
systemctl list-units --type=service --all --no-legend | grep -i collector
```

`wazuh-collector.service` は `activating (auto-restart)`（再起動を繰り返している）でした。

```bash
systemctl show wazuh-collector.service \
  -p User -p Group -p DynamicUser -p MainPID \
  -p ExecMainCode -p ExecMainStatus \
  -p NRestarts -p Result
```

| 項目 | 値 |
|---|---|
| `User`・`Group` | `wazuh-collector` |
| `MainPID` | 0（プロセスがない） |
| `Result` | `exit-code` |
| `ExecMainStatus` | 1 |
| `NRestarts` | 350 |

## 2.2　1つ目の原因

```bash
journalctl -u wazuh-collector.service -n 50 --no-pager -o short-iso
```

起動のときに `alerts.json` を開けずに終わっていました。

```text
PermissionError: [Errno 13] Permission denied
/var/ossec/logs/alerts/alerts.json
```

```bash
printf '%s\n' '===== collector account ====='
id wazuh-collector
getent passwd wazuh-collector
getent group wazuh-collector
printf '%s\n' '===== directory permissions ====='
namei -l /var/ossec/logs/alerts/alerts.json
printf '%s\n' '===== ACL ====='
getfacl -p /var/ossec/logs /var/ossec/logs/alerts /var/ossec/logs/alerts/alerts.json
```

| 対象 | Collector の権限 |
|---|---|
| `/var/ossec/logs` | ACL で `--x`（通れる） |
| `/var/ossec/logs/alerts` | ACL で `r-x`（通れる） |
| `alerts.json` | **読み取りの権限がない** |

`alerts` ディレクトリには既定の ACL がありますが、ローテーションで新しくできた `alerts.json` には反映されていませんでした（前編 第9部 1.3 と同じです）。

```bash
runuser -u wazuh-collector -- test -r /var/ossec/logs/alerts/alerts.json
echo "READ_TEST_EXIT_CODE=$?"
```

`READ_TEST_EXIT_CODE=1` で、読めないことを確かめました。

## 2.3　読み取りのACLを足す

Collector のユーザーに**読み取りだけ**を足します。書き込みや削除の権限は足しません。

```bash
setfacl -m u:wazuh-collector:r-- /var/ossec/logs/alerts/alerts.json
```

```bash
runuser -u wazuh-collector -- test -r /var/ossec/logs/alerts/alerts.json
echo "READ_TEST_EXIT_CODE=$?"
getfacl -p /var/ossec/logs/alerts/alerts.json
```

`READ_TEST_EXIT_CODE=0` になり、ACL は `user:wazuh-collector:r--` だけでした。

## 2.4　2つ目の原因

systemd の自動の再起動で動き出したかを見ます。

```bash
systemctl status wazuh-collector.service --no-pager -l
```

```bash
journalctl -u wazuh-collector.service -n 35 --no-pager -o short-iso
```

まだ起動に失敗していました。今度は、前に読んでいたファイル（保存した inode）を探すときに、`/var/ossec/logs/alerts/.acl-inheritance-test.bkv8vd` に入れずに止まっていました。

```bash
stat -c 'TYPE=%F OWNER=%U:%G MODE=%a INODE=%i PATH=%n' /var/ossec/logs/alerts/.acl-inheritance-test.bkv8vd
getfacl -p /var/ossec/logs/alerts/.acl-inheritance-test.bkv8vd
```

| 項目 | 値 |
|---|---|
| 持ち主・権限 | `root:root`、`700` |
| Collector の ACL | `r-x` があるが、ACL のマスクが `---` |
| 実際の権限 | `---`（入れない） |

これは前編 第6部で ACL の継承を試したときに作ったディレクトリです（前編 第9部で「残ったまま」と記録しています）。

```bash
find /var/ossec/logs/alerts -maxdepth 1 -name '.acl-inheritance-test*' -printf '%M %u:%g %p\n'
```

```bash
find /var/ossec/logs/alerts/.acl-inheritance-test.bkv8vd -maxdepth 2 -printf '%y %M %u:%g %s %p\n'
```

```bash
find /var/ossec/logs/alerts/.acl-inheritance-test.bkv8vd -printf '%y %M %u:%g %s %p\n'
```

中は `2027/Jan/test.json`（0バイト）だけで、すべて `root:root` でした。本物のアラートのログではありません。

## 2.5　探す処理と保存した位置

```bash
sed -n '1,80p;328,365p' /usr/local/lib/wazuh-collector/collector.py
```

`find_inode_file()` は `alerts` の下のディレクトリをすべてたどり、1か所でも入れないと、探すこと全体をやめます（探しきれないまま「見つからない」と答えないための、安全側の作りです）。

保存した位置と、今のファイルを比べます（状態ファイルの全体は表示しません）。

```bash
python3 - <<'PY'
import json, os
from pathlib import Path

state_path = Path("/var/lib/wazuh-collector/state.json")
alert_path = Path("/var/ossec/logs/alerts/alerts.json")

try:
    state = json.loads(state_path.read_text())
    print("STATE_INODE:", state.get("inode"))
    print("STATE_OFFSET:", state.get("offset"))
except Exception as e:
    print("STATE_READ_ERROR:", type(e).__name__)

try:
    st = alert_path.stat()
    print("CURRENT_INODE:", st.st_ino)
    print("CURRENT_SIZE:", st.st_size)
except Exception as e:
    print("CURRENT_FILE_ERROR:", type(e).__name__)
PY
```

| 項目 | 値 |
|---|---|
| 保存した inode | 5409383 |
| 今の `alerts.json` の inode | 5409517 |
| 保存した位置（offset） | 6,433,808 |
| 今のファイルの大きさ | 564,829 バイト |

ローテーションのあとで、Collector は前の inode 5409383 のファイルを探す必要があります。探す処理を単に止めると、前のファイルの読み残しを取りこぼすおそれがあります。

```bash
find /var/ossec/logs/alerts -xdev -type f -inum 5409383 -printf 'FOUND=%p SIZE=%s OWNER=%u:%g MODE=%m\n'
```

inode 5409383 のファイルは見つかりませんでした。

```bash
sed -n '365,430p' /usr/local/lib/wazuh-collector/collector.py
```

前の inode が見つからないときは、`Previous alert file cannot be located; refusing unsafe resume` で止まる作りです。読み残しを黙って飛ばさないための、正しい安全策です。

# おわりに

第28部でわかったことは次のとおりです。

| 項目 | 結果 |
|---|---|
| 保存する内容 | 13列に限っている。`full_log`・`data` の全体は保存しない |
| 文字列の整え方 | 形を整えるだけで、秘密の情報を見つけて除く処理ではない |
| 停止の原因1 | 新しい `alerts.json` に読み取りの ACL がない → **足した** |
| 停止の原因2 | 試験用の隠しディレクトリに入れず、前のファイルを探せない |
| 前のファイル | inode 5409383 は見つからない（Collector は安全のため止まる） |

次の部では、前のファイルがどうなったかを確かめ、読み残しを出さずに Collector を動かし直します。
