import re,sys
def blocks(vol, head, n=None):
    s=open(f'vol{vol}.md',encoding='utf-8').read()
    lines=s.split('\n'); start=None
    for i,l in enumerate(lines):
        if re.match(r'^#{1,3} ',l) and l.split(' ',1)[1].startswith(head): start=i;break
    if start is None: raise SystemExit(f'NOHEAD {vol} {head}')
    end=len(lines);incode=False
    for j in range(start+1,len(lines)):
        if lines[j].startswith('```'): incode=not incode
        if not incode and re.match(r'^#{1,2} ',lines[j]): end=j;break
    seg='\n'.join(lines[start:end])
    bl=re.findall(r'```(\w*)\n(.*?)\n```',seg,re.S)
    return bl if n is None else [bl[n]]
if __name__=='__main__':
    v,h=sys.argv[1],sys.argv[2]
    for i,(lang,b) in enumerate(blocks(v,h)): print(f'--#{i} ({lang}) {len(b.splitlines())}L: '+b.splitlines()[0][:80])
