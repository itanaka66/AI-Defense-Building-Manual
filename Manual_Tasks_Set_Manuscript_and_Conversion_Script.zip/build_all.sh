#!/bin/bash
cd /home/claude
for f in $(seq 1 30 | sed "s/^/vol/") ops omnibus omnibus_chu; do
  ./build.sh $f.md out/${f}_A4 a4 > logs_$f.a4 2>&1 || echo "FAIL $f a4"
  ./build.sh $f.md out/${f}_KDP_6x9 kdp > logs_$f.kdp 2>&1 || echo "FAIL $f kdp"
  sl=1; case $f in omnibus*) sl=2;; esac
  pandoc $f.md -o out/${f}_Kindle.epub --toc --toc-depth=2 --split-level=$sl --css epub.css -f markdown-smart 2>/dev/null || echo "FAIL $f epub"
  echo "DONE $f $(date +%T)"
done
echo ALLDONE
