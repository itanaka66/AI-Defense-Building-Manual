---
title: "AI自律型サイバー防御システム 構築マニュアル 中編"
subtitle: "第25部　監査ログの保存先を設定する"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」中編の第25部です。第24部で、監査ログの出力先（`plugins.security.audit.type`）が設定されていないため、監査ログが保存されていないとわかりました。ここでは次のことを行います。

1. 出力先の候補（`internal_opensearch`）が、どこに・何を保存するかをコードで確かめる
2. 保存に失敗したときに、監査のメッセージがどこへ流れるかを確かめる
3. 記録される項目（リクエストの本文・ヘッダー・カテゴリー）を確かめる
4. 設定ファイルに2行を足し、Indexer を再起動する

守る条件は次のとおりです。

- Wazuh のアラートのインデックスと、監査ログを分ける
- `ai-defense-reader` に監査ログを読む権限を足さない
- Wazuh のアラートの収集と Relay を止めない（再起動のあいだを除く）
- リクエストの本文は記録しない（秘密の情報がまじるおそれがあるため）
- 変える前にバックアップを取る

## 本書の表記

- コマンドやプログラムは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 実行先は **security-core VM 220（root）** です。
- `javap` の出力は長いので、結果の要点だけを書きます。
- 構築の記録のうち、会話 (109) と (112) はいただいていません。その間の判断（設定の方針の承認など）は、前後の会話から読み取れる範囲で書いています。

# 第1章　設定ファイルの確認

使う予定の設定は次の1行です（このあと 3.4 で確定します）。

```text
plugins.security.audit.type: internal_opensearch
```

```bash
stat -c '%n | owner=%U:%G | mode=%a | size=%s bytes | modified=%y' /etc/wazuh-indexer/opensearch.yml
```

構築時は `wazuh-indexer:wazuh-indexer` の `660`、2152 バイトでした。この権限は変えません。

```bash
sed -n '1,240p' /etc/wazuh-indexer/opensearch.yml
```

監査の出力先の指定はなく、Indexer は `127.0.0.1` だけで待ち受けています。TLS・認証・ネットワークの設定には手を加えません。

# 第2章　internal_opensearchの動き

## 2.1　保存先のインデックス

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.sink.InternalOpenSearchSink | grep -n -B 5 -A 8 -Ei 'auditlog6|index|createIndex|mapping'
```

Security プラグイン 2.19.6.0 の `internal_opensearch` は、インデックスの名前が指定されていなければ、日付ごとの **`security-auditlog-YYYY.MM.dd`** に保存します（`auditlog6` ではありません）。

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.sink.AbstractInternalOpenSearchSink
```

- 監査のイベントは `Client.prepareIndex()` で Indexer の中に書き込まれる
- 監査のメッセージ（`AuditMessage.getAsMap()`）の内容がそのまま保存される
- 書き込みに失敗すると、`Unable to index audit log` がエラーのログに出る

## 2.2　保存に失敗したとき

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.sink.AuditLogSink
```

`AuditLogSink.store()` は次の順に処理します。

1. 主の出力先に保存する
2. 失敗したら、予備（fallback）の出力先に保存する
3. それも失敗したら、`System.err`（標準エラー出力）に監査のメッセージの全文を出す

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.sink.DebugSink
```

予備の `DebugSink` は、監査のメッセージの全文を Log4j に `INFO` で出します。

```bash
grep -nEi 'rootLogger|logger\..*(auditlog|DebugSink)|appender|fileName|filePattern|console' /etc/wazuh-indexer/log4j2.properties
```

| 項目 | 今の設定 |
|---|---|
| rootLogger | `INFO` |
| コンソールへの出力 | 有効 |
| ファイルへの出力 | 有効（`/var/log/wazuh-indexer/`、128MB ごと、合計 2GB まで） |

つまり、主の出力先への保存に失敗すると、監査のメッセージの全文が通常のログに出るおそれがあります。

## 2.3　予備の出力先の選び方

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.sink.SinkProvider | grep -n -B 8 -A 15 -E 'FALLBACKSINK_NAME|fallback|DebugSink|createSink'
```

| 予備の指定 | 動き |
|---|---|
| なし | `DebugSink` を自動で作る |
| `debug` | Log4j に全文を出す |
| `noop` | 監査のメッセージを捨てる |

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.sink.NoopSink
```

`NoopSink` は何も出力せず「成功」として返します。ログへの漏れは防げますが、監査の記録が欠けたことが隠れてしまうため、ここでは採用しません（予備は既定のままにします）。

# 第3章　何が記録されるか

## 3.1　リクエストの本文とヘッダー

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.impl.AuditMessage
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.impl.AuditMessage | grep -n -B 5 -A 35 -E 'addRestHeaders|addRestParams|addPath|addTransportHeaders'
```

- `log_request_body` が有効だと、REST のリクエストの本文を JSON にして `audit_request_body` に入れる
- 本文を `__SENSITIVE__` に置き換えるのは、パスワードを扱う一部の Security API だけ。ほかの本文（検索の条件・登録や更新のデータなど）はそのまま記録される
- `exclude_sensitive_headers` が有効だと、`Authorization` ヘッダーは記録しない

## 3.2　フィルターの既定の値

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c 'org.opensearch.security.auditlog.config.AuditConfig$Filter'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c 'org.opensearch.security.auditlog.config.AuditConfig$Filter$FilterEntries'
```

- `log_request_body` の既定の値は **true**
- `exclude_sensitive_headers` の既定の値は true
- `ignore_headers`・`ignore_url_params`・`ignore_requests`・`ignore_users` は、ワイルドカードで指定して記録から外せる

## 3.3　監査のカテゴリー

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c 'org.opensearch.security.auditlog.impl.AuditCategory'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p org.opensearch.security.auditlog.impl.AuditLogImpl
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.impl.AuditLogImpl | grep -n -A 45 -E 'logFailedLogin|logSucceededLogin|logMissingPrivileges|logGrantedPrivileges|logIndexEvent|logSecurityIndexAttempt|logSSLException'
```

`AuditLogImpl` は、有効かどうかを確かめたうえで、イベントを作る処理を親のクラス `AbstractAuditLog` に任せています。

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.impl.AbstractAuditLog | grep -n -B 4 -A 35 -E 'logFailedLogin|logSucceededLogin|logMissingPrivileges|logGrantedPrivileges|logIndexEvent|logBadHeaders|logSecurityIndexAttempt|logSSLException|logDocumentRead|logDocumentWritten|logDocumentDeleted'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.impl.AbstractAuditLog | grep -oE 'AuditCategory\.[A-Z_]+' | sort -u
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.impl.AuditCategory
```

カテゴリーは13種類です。このシステムで特に役に立つのは次のものです。

| カテゴリー | 意味 |
|---|---|
| `FAILED_LOGIN` | 認証の失敗 |
| `MISSING_PRIVILEGES` | 権限が足りずに断られた操作 |
| `BAD_HEADERS` | 正しくないヘッダー |
| `OPENDISTRO_SECURITY_INDEX_ATTEMPT` | セキュリティの内部のインデックスへの操作の試み |
| `SSL_EXCEPTION` | TLS の例外 |
| `INDEX_EVENT` | インデックスの操作 |
| `COMPLIANCE_*` | 文書の読み書き・内部の設定の読み書き |

認証の成功（`AUTHENTICATED`）と権限の許可（`GRANTED_PRIVILEGES`）は、今の設定で記録から外れています（前編 第23部）。

## 3.4　設定のキーの名前

まず、ログファイルにルーターの初期化のメッセージがないことを、圧縮されたログも含めて確かめます。

```bash
python3 - <<'PY'
from pathlib import Path
import gzip

base = Path("/var/log/wazuh-indexer")
patterns = (
    "Default endpoint could not be created",
    "No default storage available",
    "Message routing enabled",
    "audit log may not work",
    "message router is disabled",
)

count = 0
for path in sorted(base.glob("*server*")):
    try:
        opener = gzip.open if path.suffix == ".gz" else open
        with opener(path, "rt", encoding="utf-8", errors="replace") as f:
            for line in f:
                if any(p.lower() in line.lower() for p in patterns):
                    print(f"{path.name}: {line.rstrip()}")
                    count += 1
    except (OSError, EOFError):
        pass

print("MATCH_COUNT:", count)
PY
```

```bash
grep -nEi '^[[:space:]]*plugins\.security\.audit\.|^[[:space:]]*opendistro_security\.audit\.' /etc/wazuh-indexer/opensearch.yml
```

```bash
stat -c '%n | owner=%U:%G | mode=%a | size=%s | modified=%y' /etc/wazuh-indexer/opensearch.yml
```

```bash
tail -n 35 /etc/wazuh-indexer/opensearch.yml | nl -ba
```

設定はファイルの末尾に足します。リクエストの本文を記録しない設定のキーを、コードで確かめます。

```bash
/usr/share/wazuh-indexer/jdk/bin/jar tf /usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar | grep -E 'AuditConfig.*FilterEntries|FilterEntries.*class'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c 'org.opensearch.security.auditlog.config.AuditConfig$Filter$FilterEntries'
```

古い形式のキーは `opendistro_security.audit.log_request_body` でした。

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c 'org.opensearch.security.auditlog.config.AuditConfig$Filter' | grep -n -A90 -B8 'from(org.opensearch.common.settings.Settings)'
```

`fromSettingBoolean()` は、新しい形式のキーを先に見て、なければ古い形式のキーを見ます。新しい形式の名前の付け方を確かめます。

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c 'org.opensearch.security.auditlog.config.AuditConfig$Filter$FilterEntries' | grep -n -A35 -B5 'getKeyWithNamespace'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -v 'org.opensearch.security.auditlog.config.AuditConfig$Filter$FilterEntries' | grep -n -A18 -B3 'BootstrapMethods:'
```

`getKeyWithNamespace()` は接頭辞 `plugins.security.audit.config.` を使っていました。リクエストの本文を記録しない設定は次のとおりです。

```text
plugins.security.audit.config.log_request_body: false
```

出力先の設定は、別の名前の空間です。

```text
plugins.security.audit.type: internal_opensearch
```

# 第4章　設定して再起動する

## 4.1　今の値

```bash
python3 - <<'PY'
import json
import ssl
import urllib.request

ctx = ssl.create_default_context(cafile="/etc/wazuh-indexer/certs/root-ca.pem")
ctx.load_cert_chain(
    certfile="/etc/wazuh-indexer/certs/admin.pem",
    keyfile="/etc/wazuh-indexer/certs/admin-key.pem"
)

req = urllib.request.Request("https://127.0.0.1:9200/_plugins/_security/api/audit")
with urllib.request.urlopen(req, context=ctx, timeout=10) as res:
    data = json.load(res)

audit = data.get("config", {}).get("audit", {})
print("audit.enabled:", data.get("config", {}).get("enabled"))
print("audit.log_request_body:", audit.get("log_request_body"))
print("audit.exclude_sensitive_headers:", audit.get("exclude_sensitive_headers"))
print("audit.enable_rest:", audit.get("enable_rest"))
print("audit.enable_transport:", audit.get("enable_transport"))
PY
```

`log_request_body` は `True` でした。

## 4.2　バックアップ

```bash
cp -a /etc/wazuh-indexer/opensearch.yml "/etc/wazuh-indexer/opensearch.yml.pre-audit-$(date +%Y%m%d-%H%M%S)"
```

```bash
bash -c 'f=$(ls -1t /etc/wazuh-indexer/opensearch.yml.pre-audit-* | head -n 1); echo "BACKUP: $f"; stat -c "owner=%U:%G mode=%a size=%s" "$f"; cmp -s /etc/wazuh-indexer/opensearch.yml "$f" && echo "CONTENT_MATCH: yes" || echo "CONTENT_MATCH: no"'
```

構築時のバックアップは `opensearch.yml.pre-audit-20261121-082142` で、元のファイルと一致しました。

## 4.3　2行を足す

同じキーがすでにないことを確かめます。

```bash
grep -nE '^[[:space:]]*plugins\.security\.audit\.(type|config\.log_request_body):' /etc/wazuh-indexer/opensearch.yml
```

足すのは次の2行です。

```text
plugins.security.audit.type: internal_opensearch
plugins.security.audit.config.log_request_body: false
```

```bash
printf '\n# AI Defense: audit logging with request-body protection\nplugins.security.audit.type: internal_opensearch\nplugins.security.audit.config.log_request_body: false\n' >> /etc/wazuh-indexer/opensearch.yml
```

バックアップとの差分が、コメント1行と設定2行だけであることを確かめます。ファイル名は自分のバックアップの名前に置き換えます。

```bash
diff -u /etc/wazuh-indexer/opensearch.yml.pre-audit-20261121-082142 /etc/wazuh-indexer/opensearch.yml
```

```bash
python3 - <<'PY'
import yaml

path = "/etc/wazuh-indexer/opensearch.yml"
with open(path, encoding="utf-8") as f:
    config = yaml.safe_load(f)

assert config["plugins.security.audit.type"] == "internal_opensearch"
assert config["plugins.security.audit.config.log_request_body"] is False

print("YAML_SYNTAX: OK")
print("AUDIT_TYPE: OK")
print("REQUEST_BODY_LOGGING: disabled")
PY
```

## 4.4　再起動

再起動の前の状態を記録します。

```bash
systemctl show wazuh-indexer -p ActiveState -p SubState -p MainPID -p NRestarts -p ActiveEnterTimestamp
```

再起動のあいだは、Indexer の API や Wazuh の検索・Relay が一時的に使えなくなります。

```bash
systemctl restart wazuh-indexer
```

```bash
systemctl show wazuh-indexer -p ActiveState -p SubState -p MainPID -p NRestarts -p ActiveEnterTimestamp
```

構築時は `active`・`running`、新しい PID は 51059、`NRestarts=0` でした。

## 4.5　反映されたか

```bash
python3 - <<'PY'
import json
import ssl
import urllib.request

ctx = ssl.create_default_context(cafile="/etc/wazuh-indexer/certs/root-ca.pem")
ctx.load_cert_chain(
    certfile="/etc/wazuh-indexer/certs/admin.pem",
    keyfile="/etc/wazuh-indexer/certs/admin-key.pem"
)

req = urllib.request.Request("https://127.0.0.1:9200/_plugins/_security/api/audit")
with urllib.request.urlopen(req, context=ctx, timeout=15) as res:
    data = json.load(res)

config = data.get("config", {})
audit = config.get("audit", {})

print("API: OK")
print("AUDIT_ENABLED:", config.get("enabled"))
print("LOG_REQUEST_BODY:", audit.get("log_request_body"))
print("EXCLUDE_SENSITIVE_HEADERS:", audit.get("exclude_sensitive_headers"))
print("ENABLE_REST:", audit.get("enable_rest"))
print("ENABLE_TRANSPORT:", audit.get("enable_transport"))
PY
```

構築時は、`LOG_REQUEST_BODY: True` のままでした。設定ファイルに書いた `false` は、監査の API が返す設定には反映されていません。次の部で、この理由を調べて直します。

# おわりに

第25部で、`/etc/wazuh-indexer/opensearch.yml` に次の設定を足し、Indexer を再起動しました。

| 設定 | 値 | 結果 |
|---|---|---|
| `plugins.security.audit.type` | `internal_opensearch` | 監査ログを Indexer の中（`security-auditlog-YYYY.MM.dd`）に保存する |
| `plugins.security.audit.config.log_request_body` | `false` | 監査の API にはまだ反映されていない |

バックアップは `/etc/wazuh-indexer/opensearch.yml.pre-audit-*` です。
