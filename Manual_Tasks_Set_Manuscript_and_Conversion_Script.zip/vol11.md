---
title: "AI自律型サイバー防御システム 構築マニュアル 前編"
subtitle: "第11部　AI Defense Managerの土台づくり"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」前編の第11部です。第10部で作ったVM 230（`ai-defense-manager`、192.168.0.33）に、AIによる分析・判断・対処を受け持つアプリケーション「AI Defense Manager」の土台を作ります。

この部で作るのは、次の部分です。

- 専用のPython仮想環境と、専用の実行ユーザー
- FastAPIによるAPIの最小構成と、設定の管理
- AIに渡すデータ・AIから受け取るデータの型（スキーマ）と、その検証

## 本書の表記

- コマンドやプログラムは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 実行先はすべて **VM 230 ai-defense-manager（root）** です（特に断りがない場合）。

## 権限の方針

| 対象 | 所有者 | 権限 | 理由 |
|---|---|---|---|
| アプリケーション（`app`） | `root:ai-defense` | ディレクトリ `750`、ファイル `640` | 実行ユーザーは読めるが、書き換えられない |
| 設定（`config`） | root | root だけ | 秘密の情報を置く場所 |
| データ・ログ（`data`・`logs`） | `ai-defense` | — | 実行ユーザーが書き込む |
| 仮想環境（`venv`） | root | `755` | 実行ユーザーは使えるが、変更できない |

# 第1章　Python仮想環境

## 1.1　確認

```bash
python3 -m pip --version
```

システムには `pip` が入っていません（Ubuntu 24.04 ではシステムのPythonにパッケージを入れず、仮想環境を使います）。

```bash
python3 -m venv --help
```

```bash
ls -ld /opt/ai-defense-manager
```

## 1.2　作成

```bash
install -d -m 0755 /opt/ai-defense-manager
```

仮想環境を作るには `python3.12-venv`（`ensurepip`）が必要です。入っていないと作成に失敗するため、先に入れます。何が入るかを試してから入れます。

```bash
apt-get -s install python3.12-venv
```

```bash
apt-get install -y python3.12-venv
```

```bash
python3 -m venv /opt/ai-defense-manager/venv
```

```bash
/opt/ai-defense-manager/venv/bin/pip --version
```

```bash
/opt/ai-defense-manager/venv/bin/python --version
```

構築時は、pip 24.0、Python 3.12.3 でした。

# 第2章　ディレクトリと実行ユーザー

## 2.1　ディレクトリの構成

```bash
find /opt/ai-defense-manager -maxdepth 2 -type d -print
```

次の構成にします。

```text
/opt/ai-defense-manager/
├── venv/          # Python仮想環境
├── app/           # FastAPIアプリケーション
│   ├── api/       # REST API
│   ├── core/      # 設定・共通処理
│   ├── agents/    # AIエージェント
│   ├── schemas/   # JSONスキーマ
│   ├── services/  # 外部システム連携
│   └── policies/  # 決定論的ポリシー検証
├── config/        # 設定ファイル
├── data/          # アプリケーションデータ
├── logs/          # アプリケーションログ
└── tests/         # テスト
```

```bash
install -d -m 0750 /opt/ai-defense-manager/{app/{api,core,agents,schemas,services,policies},config,data,logs,tests}
```

```bash
find /opt/ai-defense-manager -maxdepth 2 -type d -not -path '*/venv*' | sort
```

## 2.2　専用の実行ユーザー

ログインに使っている `aidefense` は、管理用のグループにも入っている通常のユーザーです。アプリケーションは、ログインできない専用のシステムユーザー `ai-defense` で動かします。

```bash
id aidefense
```

```bash
ls -ld /opt/ai-defense-manager /opt/ai-defense-manager/{app,config,data,logs,tests}
```

```bash
useradd --system --user-group --home-dir /opt/ai-defense-manager --no-create-home --shell /usr/sbin/nologin ai-defense
```

```bash
id ai-defense
```

## 2.3　所有者と権限

データとログは、実行ユーザーが書き込めるようにします。

```bash
chown ai-defense:ai-defense /opt/ai-defense-manager/data /opt/ai-defense-manager/logs
```

```bash
ls -ld /opt/ai-defense-manager/{app,config,data,logs,tests}
```

アプリケーションは `root:ai-defense` にし、実行ユーザーが読めるが書き換えられないようにします。

```bash
find /opt/ai-defense-manager/app -maxdepth 2 -type d -printf '%M %u:%g %p\n' | sort
```

```bash
getent group ai-defense
```

```bash
chown -R root:ai-defense /opt/ai-defense-manager/app
```

```bash
find /opt/ai-defense-manager/app -type d -exec chmod 750 {} +
```

```bash
find /opt/ai-defense-manager/app -type f -exec chmod 640 {} +
```

```bash
find /opt/ai-defense-manager/app -printf '%M %u:%g %p\n' | sort
```

仮想環境は root の所有で `755` のままにします（実行ユーザーは使えますが、変更できません）。

```bash
ls -ld /opt/ai-defense-manager/venv
```

```bash
find /opt/ai-defense-manager/venv -maxdepth 2 -type d -printf '%M %u:%g %p\n' | sort
```

```bash
runuser -u ai-defense -- /opt/ai-defense-manager/venv/bin/python --version
```

# 第3章　基盤のパッケージ

## 3.1　インストール

```bash
/opt/ai-defense-manager/venv/bin/pip list
```

```bash
/opt/ai-defense-manager/venv/bin/pip config list
```

```bash
curl -I --max-time 10 https://pypi.org/simple/fastapi/
```

`HTTP/2 200` であれば、PyPIに接続できます。

```bash
/opt/ai-defense-manager/venv/bin/pip install fastapi uvicorn[standard] pydantic pydantic-settings httpx
```

## 3.2　確認

```bash
/opt/ai-defense-manager/venv/bin/pip check
```

`No broken requirements found.` を確認します。

```bash
/opt/ai-defense-manager/venv/bin/pip show fastapi uvicorn pydantic pydantic-settings httpx
```

```bash
runuser -u ai-defense -- /opt/ai-defense-manager/venv/bin/python -c "import fastapi, uvicorn, pydantic, pydantic_settings, httpx; print('FastAPI:', fastapi.__version__); print('Uvicorn:', uvicorn.__version__); print('Pydantic:', pydantic.__version__); print('HTTPX:', httpx.__version__); print('IMPORT_OK')"
```

```bash
stat -c '%A %U:%G %n' /opt/ai-defense-manager/config
```

## 3.3　入れたパッケージの記録

```bash
/opt/ai-defense-manager/venv/bin/pip freeze
```

```bash
/opt/ai-defense-manager/venv/bin/pip freeze > /opt/ai-defense-manager/requirements.lock
```

```bash
ls -l /opt/ai-defense-manager/requirements.lock
```

```bash
chown root:ai-defense /opt/ai-defense-manager/requirements.lock && chmod 640 /opt/ai-defense-manager/requirements.lock
```

```bash
runuser -u ai-defense -- cat /opt/ai-defense-manager/requirements.lock
```

構築時は、依存するものを含めて24個のパッケージでした。

# 第4章　APIの最小構成

## 4.1　main.py

まず、状態を返すだけの `/health` を持つ最小のAPIを作ります。

```bash
ls -l /opt/ai-defense-manager/app/main.py
```

```bash
cat > /opt/ai-defense-manager/app/main.py <<'PY'
from fastapi import FastAPI

app = FastAPI(
    title="AI Defense Manager",
    description="Autonomous AI Cyber Defense Management API",
    version="0.1.0",
)


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "service": "ai-defense-manager",
        "version": "0.1.0",
    }
PY
```

```bash
chown root:ai-defense /opt/ai-defense-manager/app/main.py && chmod 640 /opt/ai-defense-manager/app/main.py
```

```bash
runuser -u ai-defense -- /opt/ai-defense-manager/venv/bin/python -c "import sys; sys.path.insert(0, '/opt/ai-defense-manager'); from app.main import app; print('APP_IMPORT_OK:', app.title, app.version)"
```

## 4.2　起動と確認

8000番ポートが空いていることを確かめ、専用ユーザーで、自分自身（127.0.0.1）だけで待ち受けるように起動します。

```bash
ss -lntp 'sport = :8000'
```

```bash
runuser -u ai-defense -- /opt/ai-defense-manager/venv/bin/uvicorn app.main:app --app-dir /opt/ai-defense-manager --host 127.0.0.1 --port 8000
```

このコマンドは起動したまま止まらないため、確認は別の端末（SSHの接続をもう1つ）で行います。

```bash
curl -i http://127.0.0.1:8000/health
```

`HTTP/1.1 200 OK` と次の内容が返れば成功です。

```text
{
  "status": "ok",
  "service": "ai-defense-manager",
  "version": "0.1.0"
}
```

```bash
find /opt/ai-defense-manager/app -maxdepth 2 -type f -printf '%M %u:%g %p\n'
```

# 第5章　設定の管理

## 5.1　config.py

接続先などの設定を1か所にまとめ、環境変数（`AIDM_` で始まる名前）で上書きできるようにします。パスワードなどの秘密の情報は、ここには書きません。

```bash
runuser -u ai-defense -- /opt/ai-defense-manager/venv/bin/python -c "from pydantic_settings import BaseSettings; print('PYDANTIC_SETTINGS_OK')"
```

```bash
cat > /opt/ai-defense-manager/app/core/config.py <<'PY'
from pydantic import Field, HttpUrl
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="AIDM_",
        env_file=None,
        extra="ignore",
    )

    app_name: str = "AI Defense Manager"
    app_version: str = "0.1.0"

    api_host: str = "127.0.0.1"
    api_port: int = Field(default=8000, ge=1024, le=65535)

    ollama_base_url: HttpUrl = "http://192.168.0.180:11434/"

    wazuh_base_url: HttpUrl | None = None
    postgres_host: str | None = None
    postgres_port: int = Field(default=5432, ge=1, le=65535)
    postgres_database: str | None = None

    analysis_timeout_seconds: int = Field(default=60, ge=1, le=600)


settings = Settings()
PY
```

```bash
chown root:ai-defense /opt/ai-defense-manager/app/core/config.py && chmod 640 /opt/ai-defense-manager/app/core/config.py
```

## 5.2　読み込みと上書きの確認

```bash
runuser -u ai-defense -- /opt/ai-defense-manager/venv/bin/python -c "import sys; sys.path.insert(0, '/opt/ai-defense-manager'); from app.core.config import settings; print('CONFIG_OK'); print('APP:', settings.app_name); print('OLLAMA:', settings.ollama_base_url); print('API:', settings.api_host, settings.api_port); print('WAZUH:', settings.wazuh_base_url); print('POSTGRES:', settings.postgres_host)"
```

```bash
runuser -u ai-defense -- env AIDM_API_PORT=8100 /opt/ai-defense-manager/venv/bin/python -c "import sys; sys.path.insert(0, '/opt/ai-defense-manager'); from app.core.config import Settings; s=Settings(); print('ENV_OVERRIDE_OK' if s.api_port == 8100 else 'ENV_OVERRIDE_FAILED'); print('TEST_PORT:', s.api_port)"
```

`CONFIG_OK` と `ENV_OVERRIDE_OK` を確認します。

## 5.3　main.pyへの組み込み

```bash
curl -sS http://127.0.0.1:8000/health
```

```bash
cat > /opt/ai-defense-manager/app/main.py <<'PY'
from fastapi import FastAPI

from app.core.config import settings

app = FastAPI(
    title=settings.app_name,
    description="Autonomous AI Cyber Defense Management API",
    version=settings.app_version,
)


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "service": "ai-defense-manager",
        "version": settings.app_version,
    }
PY
```

```bash
chown root:ai-defense /opt/ai-defense-manager/app/main.py && chmod 640 /opt/ai-defense-manager/app/main.py
```

```bash
runuser -u ai-defense -- /opt/ai-defense-manager/venv/bin/python -c "import sys; sys.path.insert(0, '/opt/ai-defense-manager'); from app.main import app; from app.core.config import settings; print('APP_CONFIG_INTEGRATION_OK'); print('TITLE:', app.title); print('VERSION:', app.version); print('OLLAMA:', settings.ollama_base_url)"
```

起動中のUvicornを、起動した端末で `Ctrl+C` を押して止め、もう一度起動します。

```bash
runuser -u ai-defense -- /opt/ai-defense-manager/venv/bin/uvicorn app.main:app --app-dir /opt/ai-defense-manager --host 127.0.0.1 --port 8000
```

```bash
curl -i http://127.0.0.1:8000/health
```

```bash
curl -sS http://127.0.0.1:8000/health
```

設定を組み込んだ後も、4.2と同じ内容が返ります。

# 第6章　データの型（スキーマ）

AIに渡すデータと、AIから受け取るデータの形を、Pydantic のモデルで厳しく決めます。決められていない項目（たとえばログの全文 `full_log`）は受け付けません（`extra="forbid"`）。

```bash
find /opt/ai-defense-manager/app/schemas -maxdepth 1 -type f -printf '%f\n'
```

## 6.1　セキュリティイベント（security_event.py）

```bash
cat > /opt/ai-defense-manager/app/schemas/security_event.py <<'PY'
from datetime import datetime, timezone
from ipaddress import ip_address
from typing import Literal
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field, field_validator


class SecurityEvent(BaseModel):
    model_config = ConfigDict(extra="forbid")

    event_id: UUID = Field(default_factory=uuid4)
    source: Literal["wazuh", "prometheus", "victoriametrics", "internal"]
    observed_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc)
    )

    severity: Literal["info", "low", "medium", "high", "critical"]
    rule_id: str | None = Field(default=None, max_length=64)
    rule_description: str | None = Field(default=None, max_length=512)

    source_ip: str | None = None
    destination_ip: str | None = None

    agent_id: str | None = Field(default=None, max_length=64)
    agent_name: str | None = Field(default=None, max_length=128)

    event_category: str = Field(min_length=1, max_length=64)
    event_summary: str = Field(min_length=1, max_length=512)

    @field_validator("observed_at")
    @classmethod
    def require_timezone(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("observed_at must include a timezone")
        return value

    @field_validator("source_ip", "destination_ip")
    @classmethod
    def validate_ip_address(cls, value: str | None) -> str | None:
        if value is None:
            return None
        return str(ip_address(value))
PY
```

構文を確認します。実行ユーザーはアプリケーションのディレクトリに書き込めないため、`py_compile`（バイトコードを書き出す）ではなく、書き出さない方法で確かめます。

```bash
runuser -u ai-defense -- /opt/ai-defense-manager/venv/bin/python -c "from pathlib import Path; p=Path('/opt/ai-defense-manager/app/schemas/security_event.py'); compile(p.read_text(), str(p), 'exec'); print('SYNTAX_OK')"
```

貼り付けたときに端末の表示が崩れることがあるため、末尾が正しく書かれているかも確かめます。

```bash
tail -n 15 /opt/ai-defense-manager/app/schemas/security_event.py
```

最後が次の3行になっていれば正しく書かれています。

```text
if value is None:
    return None
return str(ip_address(value))
```

```bash
chown root:ai-defense /opt/ai-defense-manager/app/schemas/security_event.py && chmod 640 /opt/ai-defense-manager/app/schemas/security_event.py
```

不正なIPアドレスと、決められていない項目が拒否されることを確かめます。

```bash
runuser -u ai-defense -- /opt/ai-defense-manager/venv/bin/python -B - <<'PY'
import sys
sys.path.insert(0, "/opt/ai-defense-manager")

from app.schemas.security_event import SecurityEvent
from pydantic import ValidationError

base = {
    "source": "wazuh",
    "severity": "high",
    "event_category": "authentication",
    "event_summary": "Test event",
}

tests = [
    ("INVALID_IP_REJECTED", {**base, "source_ip": "invalid"}),
    ("EXTRA_FIELD_REJECTED", {**base, "full_log": "sensitive data"}),
]

for expected, data in tests:
    try:
        SecurityEvent(**data)
        print("FAILED:", expected)
    except ValidationError:
        print("PASS:", expected)
PY
```

## 6.2　AI分析の依頼（analysis.py）

1回にAIに渡すイベントは1〜100件、言語は日本語か英語に限ります。

```bash
cat > /opt/ai-defense-manager/app/schemas/analysis.py <<'PY'
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field

from app.schemas.security_event import SecurityEvent


class AIAnalysisRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    request_id: UUID = Field(default_factory=uuid4)
    events: list[SecurityEvent] = Field(min_length=1, max_length=100)
    analysis_context: str | None = Field(default=None, max_length=2000)
    requested_language: str = Field(default="ja", pattern=r"^(ja|en)$")
PY
```

```bash
chown root:ai-defense /opt/ai-defense-manager/app/schemas/analysis.py && chmod 640 /opt/ai-defense-manager/app/schemas/analysis.py
```

```bash
runuser -u ai-defense -- /opt/ai-defense-manager/venv/bin/python -B - <<'PY'
import sys
sys.path.insert(0, "/opt/ai-defense-manager")

from app.schemas.analysis import AIAnalysisRequest

request = AIAnalysisRequest(
    events=[
        {
            "source": "wazuh",
            "severity": "high",
            "event_category": "authentication",
            "event_summary": "Repeated authentication failures",
            "source_ip": "192.0.2.10",
        }
    ]
)

print("ANALYSIS_REQUEST_OK")
print("REQUEST_ID:", request.request_id)
print("EVENT_COUNT:", len(request.events))
print("LANGUAGE:", request.requested_language)
PY
```

## 6.3　AIの分析の結果（analysis_proposal.py）

AIが返す提案には、次の安全のための制約を付けます。

- 推奨する対処は、決められた6種類だけ
- 確からしさ（`confidence`）は 0.0〜1.0
- 根拠のイベントIDが必須
- IPの一時遮断の提案は、インターネット上のアドレス（グローバルIP）だけ、根拠のイベントが2件以上、期限は最大900秒（15分）、人の承認が必須
- 実際の遮断の処理は、ここでは作らない

```bash
cat > /opt/ai-defense-manager/app/schemas/analysis_proposal.py <<'PY'
from enum import Enum
from ipaddress import ip_address
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, model_validator


class RecommendedAction(str, Enum):
    NO_ACTION = "no_action"
    MONITOR = "monitor"
    COLLECT_EVIDENCE = "collect_evidence"
    NOTIFY = "notify"
    HUMAN_REVIEW = "human_review"
    TEMPORARY_BLOCK_IP = "temporary_block_ip"


class AIAnalysisProposal(BaseModel):
    model_config = ConfigDict(extra="forbid")

    summary: str = Field(min_length=1, max_length=2000)
    severity: str = Field(pattern=r"^(info|low|medium|high|critical)$")
    confidence: float = Field(ge=0.0, le=1.0)

    evidence_event_ids: list[UUID] = Field(min_length=1, max_length=100)

    recommended_action: RecommendedAction

    target_ip: str | None = None
    ttl_seconds: int | None = Field(default=None, ge=1, le=900)

    requires_human_approval: bool = True
    reasoning: str = Field(min_length=1, max_length=4000)

    @model_validator(mode="after")
    def validate_action_constraints(self):
        if self.recommended_action == RecommendedAction.TEMPORARY_BLOCK_IP:
            if self.target_ip is None:
                raise ValueError("target_ip is required for block proposals")

            if self.ttl_seconds is None:
                raise ValueError("ttl_seconds is required for block proposals")

            if len(set(self.evidence_event_ids)) < 2:
                raise ValueError("block proposals require at least two distinct evidence events")

            address = ip_address(self.target_ip)

            if not address.is_global:
                raise ValueError("only globally routable IP addresses may be proposed for blocking")

            if not self.requires_human_approval:
                raise ValueError("block proposals must require human approval")

        elif self.target_ip is not None or self.ttl_seconds is not None:
            raise ValueError("target_ip and ttl_seconds are only valid for block proposals")

        return self
PY
```

```bash
tail -n 25 /opt/ai-defense-manager/app/schemas/analysis_proposal.py
```

```bash
chown root:ai-defense /opt/ai-defense-manager/app/schemas/analysis_proposal.py && chmod 640 /opt/ai-defense-manager/app/schemas/analysis_proposal.py
```

```bash
runuser -u ai-defense -- /opt/ai-defense-manager/venv/bin/python -B -c "from pathlib import Path; p=Path('/opt/ai-defense-manager/app/schemas/analysis_proposal.py'); compile(p.read_text(), str(p), 'exec'); print('PROPOSAL_SYNTAX_OK')"
```

通常の提案、グローバルIPの遮断の提案が受け付けられ、プライベートIPの遮断の提案が拒否されることを確かめます。

```bash
runuser -u ai-defense -- /opt/ai-defense-manager/venv/bin/python -B - <<'PY'
import sys
from uuid import uuid4

sys.path.insert(0, "/opt/ai-defense-manager")

from app.schemas.analysis_proposal import AIAnalysisProposal

base = {
    "summary": "Repeated suspicious authentication attempts",
    "severity": "high",
    "confidence": 0.95,
    "evidence_event_ids": [uuid4(), uuid4()],
    "recommended_action": "human_review",
    "requires_human_approval": True,
    "reasoning": "Multiple correlated security events",
}

normal = AIAnalysisProposal(**{
    **base,
    "evidence_event_ids": [base["evidence_event_ids"][0]],
})
print("NORMAL_PROPOSAL_OK")

block = AIAnalysisProposal(**{
    **base,
    "recommended_action": "temporary_block_ip",
    "target_ip": "8.8.8.8",
    "ttl_seconds": 300,
})
print("PUBLIC_IP_BLOCK_PROPOSAL_OK")

try:
    AIAnalysisProposal(**{
        **base,
        "recommended_action": "temporary_block_ip",
        "target_ip": "192.168.0.1",
        "ttl_seconds": 300,
    })
    print("FAILED: PRIVATE_IP_ACCEPTED")
except ValueError:
    print("PRIVATE_IP_REJECTED")
PY
```

## 6.4　対処の候補（action.py）

AIの提案をもとに、Action Gateway（実際の対処を行う部分）に渡す「対処の候補」の型です。IPの一時遮断は、承認待ち（`pending`）から始まり、人が承認するまで実行されません。

```bash
ls -l /opt/ai-defense-manager/app/schemas/action.py
```

```bash
cat > /opt/ai-defense-manager/app/schemas/action.py <<'PY'
from enum import Enum
from ipaddress import ip_address
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field, model_validator


class ActionType(str, Enum):
    NOTIFY = "notify"
    COLLECT_EVIDENCE = "collect_evidence"
    TEMPORARY_BLOCK_IP = "temporary_block_ip"


class ApprovalStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


class ActionProposal(BaseModel):
    model_config = ConfigDict(extra="forbid")

    action_id: UUID = Field(default_factory=uuid4)
    source_analysis_id: UUID

    action_type: ActionType
    target_ip: str | None = None
    ttl_seconds: int | None = Field(default=None, ge=1, le=900)

    evidence_event_ids: list[UUID] = Field(min_length=1, max_length=100)

    approval_status: ApprovalStatus = ApprovalStatus.PENDING
    requires_human_approval: bool = True

    @model_validator(mode="after")
    def validate_action(self):
        if self.action_type == ActionType.TEMPORARY_BLOCK_IP:
            if self.target_ip is None:
                raise ValueError("target_ip is required")

            if self.ttl_seconds is None:
                raise ValueError("ttl_seconds is required")

            if len(set(self.evidence_event_ids)) < 2:
                raise ValueError("at least two distinct evidence events are required")

            if not ip_address(self.target_ip).is_global:
                raise ValueError("only globally routable IP addresses are allowed")

            if not self.requires_human_approval:
                raise ValueError("human approval is mandatory")

            if self.approval_status != ApprovalStatus.PENDING:
                raise ValueError("block proposals must start as pending")

        elif self.target_ip is not None or self.ttl_seconds is not None:
            raise ValueError("target_ip and ttl_seconds are only valid for block actions")

        return self
PY
```

```bash
tail -n 30 /opt/ai-defense-manager/app/schemas/action.py
```

```bash
chown root:ai-defense /opt/ai-defense-manager/app/schemas/action.py && chmod 640 /opt/ai-defense-manager/app/schemas/action.py
```

```bash
runuser -u ai-defense -- /opt/ai-defense-manager/venv/bin/python -B -c "from pathlib import Path; p=Path('/opt/ai-defense-manager/app/schemas/action.py'); compile(p.read_text(), str(p), 'exec'); print('ACTION_SYNTAX_OK')"
```

通知の候補とグローバルIPの遮断の候補（承認待ち）が受け付けられ、プライベートIP・最初から承認済みの遮断・根拠が1件だけの遮断が拒否されることを確かめます。

```bash
runuser -u ai-defense -- /opt/ai-defense-manager/venv/bin/python -B - <<'PY'
import sys
from uuid import uuid4

sys.path.insert(0, "/opt/ai-defense-manager")

from app.schemas.action import ActionProposal

analysis_id = uuid4()
event_ids = [uuid4(), uuid4()]

base = {
    "source_analysis_id": analysis_id,
    "evidence_event_ids": event_ids,
}

ActionProposal(**{
    **base,
    "action_type": "notify",
})
print("NOTIFY_ACTION_OK")

ActionProposal(**{
    **base,
    "action_type": "temporary_block_ip",
    "target_ip": "8.8.8.8",
    "ttl_seconds": 300,
})
print("PUBLIC_IP_BLOCK_PENDING_OK")

def must_reject(name, payload):
    try:
        ActionProposal(**payload)
    except ValueError:
        print(f"{name}_REJECTED")
    else:
        raise AssertionError(f"{name}_WAS_ACCEPTED")

must_reject("PRIVATE_IP", {
    **base,
    "action_type": "temporary_block_ip",
    "target_ip": "192.168.0.1",
    "ttl_seconds": 300,
})

must_reject("PREAPPROVED_BLOCK", {
    **base,
    "action_type": "temporary_block_ip",
    "target_ip": "8.8.8.8",
    "ttl_seconds": 300,
    "approval_status": "approved",
})

must_reject("INSUFFICIENT_EVIDENCE", {
    **base,
    "evidence_event_ids": [event_ids[0]],
    "action_type": "temporary_block_ip",
    "target_ip": "8.8.8.8",
    "ttl_seconds": 300,
})

print("ALL_ACTION_TESTS_PASSED")
PY
```

`ALL_ACTION_TESTS_PASSED` と表示されれば、5項目すべて合格です。

## 6.5　ファイルの確認と後片付け

```bash
find /opt/ai-defense-manager/app -maxdepth 2 -type f -printf '%P\n' | sort
```

構築時は、作業の途中で空の一時ファイル `analysis.py.tmp` ができていたため、削除しました（ない場合は不要です）。

```bash
rm -f /opt/ai-defense-manager/app/schemas/analysis.py.tmp
```

# 第11部のまとめ

## できたもの

| ファイル | 内容 |
|---|---|
| `/opt/ai-defense-manager/venv` | Python仮想環境（FastAPI・Uvicorn・Pydantic・pydantic-settings・HTTPX） |
| `/opt/ai-defense-manager/requirements.lock` | 入れたパッケージの一覧 |
| `app/main.py` | API（`/health`） |
| `app/core/config.py` | 設定（`AIDM_` の環境変数で上書き可） |
| `app/schemas/security_event.py` | セキュリティイベント |
| `app/schemas/analysis.py` | AI分析の依頼 |
| `app/schemas/analysis_proposal.py` | AIの分析の結果 |
| `app/schemas/action.py` | 対処の候補 |

## 安全のための決まり

- アプリケーションは、ログインできない専用ユーザー `ai-defense` で動かし、コードは書き換えられない。
- APIは自分自身（127.0.0.1）だけで待ち受ける。
- AIの出力は、決められた型と制約を通ったものだけを受け付ける。
- IPの遮断は、グローバルIP・根拠2件以上・最大15分・人の承認が必須で、承認待ちから始まる。

## 残っていること

- Uvicorn は手で起動しています（systemd のサービスにはしていません）。第12部の後、`kill` で停止しました。
- AIによる分析の処理（Ollamaとの連携）は、次の部で作ります。
