---
title: "AI自律型サイバー防御システム 構築マニュアル 前編"
subtitle: "第14部　アラート中継API（Relay）の構築"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」前編の第14部です。第13部で作った Indexer の読み取り専用ユーザーを使い、security-core の中に、AI Defense Manager（VM 230）へアラートを渡す「中継API（Relay）」を作ります。

Indexer はほかのホストに公開せず、Relay だけが次の条件で外からの接続を受け付けます。

- 待ち受けは `192.168.0.220:8765` だけ（HTTPS）
- サーバー証明書は、Relay 専用の内部CAで発行する
- 呼び出しには Bearer トークンが必要
- 返す項目は第13部 6.1 で決めた10項目だけ。検索の条件や件数の上限は Relay の側で決める
- 秘密の情報（Indexer のパスワード、トークン、秘密鍵）は、systemd の `LoadCredential` で渡す

## 本書の表記

- コマンドやプログラムは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 実行先は、特に断りがない場合 **security-core VM 220（root）** です。
- パスワード・トークン・秘密鍵の中身は、画面にもマニュアルにも出しません。

# 第1章　証明書とトークン

## 1.1　保存先

```bash
openssl version
```

```bash
ls -ld /etc/ai-defense-relay /etc/ai-defense-relay/* 2>/dev/null
```

```bash
install -d -m 700 -o root -g root /etc/ai-defense-relay
```

## 1.2　内部CA

Relay 専用の認証局（CA）を作ります。Indexer の CA とは別に管理します。

```bash
openssl req -x509 -newkey rsa:3072 -sha256 -days 3650 -nodes -keyout /etc/ai-defense-relay/ca.key -out /etc/ai-defense-relay/ca.crt -subj "/CN=AI-Defense-Relay-Internal-CA" -addext "basicConstraints=critical,CA:TRUE" -addext "keyUsage=critical,keyCertSign,cRLSign" && chmod 600 /etc/ai-defense-relay/ca.key && chmod 644 /etc/ai-defense-relay/ca.crt
```

## 1.3　サーバー証明書

`192.168.0.220` で接続するため、SAN に IP アドレスを入れます。

```bash
openssl req -new -newkey rsa:2048 -nodes -keyout /etc/ai-defense-relay/server.key -out /etc/ai-defense-relay/server.csr -subj "/CN=192.168.0.220" -addext "subjectAltName=IP:192.168.0.220" && chmod 600 /etc/ai-defense-relay/server.key /etc/ai-defense-relay/server.csr
```

```bash
printf '%s\n' 'subjectAltName=IP:192.168.0.220' 'extendedKeyUsage=serverAuth' 'keyUsage=critical,digitalSignature,keyEncipherment' 'basicConstraints=critical,CA:FALSE' > /etc/ai-defense-relay/server.ext && openssl x509 -req -in /etc/ai-defense-relay/server.csr -CA /etc/ai-defense-relay/ca.crt -CAkey /etc/ai-defense-relay/ca.key -CAcreateserial -out /etc/ai-defense-relay/server.crt -days 825 -sha256 -extfile /etc/ai-defense-relay/server.ext && chmod 644 /etc/ai-defense-relay/server.crt /etc/ai-defense-relay/server.ext
```

CAの署名・IPアドレス・用途・秘密鍵との対応を確かめます。

```bash
openssl verify -CAfile /etc/ai-defense-relay/ca.crt -verify_ip 192.168.0.220 -purpose sslserver /etc/ai-defense-relay/server.crt && test "$(openssl x509 -in /etc/ai-defense-relay/server.crt -pubkey -noout | openssl sha256)" = "$(openssl pkey -in /etc/ai-defense-relay/server.key -pubout | openssl sha256)" && echo "CERTIFICATE_AND_PRIVATE_KEY_VALID"
```

## 1.4　Bearerトークン

VM 230 が Relay を呼ぶときのトークンを作ります。画面には表示しません。

```bash
python3 -c 'import secrets,pathlib,os; p=pathlib.Path("/etc/ai-defense-relay/api.token"); p.write_text(secrets.token_urlsafe(48)+"\n"); os.chmod(p,0o600); print("RELAY_TOKEN_CREATED; mode=600")'
```

# 第2章　実行ユーザーと実行環境

## 2.1　専用ユーザー

```bash
systemd --version
```

構築時は systemd 255 で、`LoadCredential` を使えました。

```bash
getent passwd ai-defense-relay || echo "SERVICE_USER_NOT_FOUND"
```

```bash
useradd --system --user-group --no-create-home --home-dir /nonexistent --shell /usr/sbin/nologin ai-defense-relay
```

```bash
id ai-defense-relay
```

## 2.2　Pythonの仮想環境

security-core のシステムの Python には FastAPI などは入っていません。Relay は標準のライブラリだけで作ることにし、専用の仮想環境を用意します。

```bash
python3 -c 'import sys; print(sys.version); import fastapi,uvicorn,httpx; print("FASTAPI",fastapi.__version__); print("UVICORN",uvicorn.__version__); print("HTTPX",httpx.__version__)'
```

```bash
python3 -m venv --help >/dev/null && echo "VENV_AVAILABLE"
```

仮想環境の作成には `python3.12-venv` が必要です。

```bash
dpkg-query -W -f='${Status} ${Version}\n' python3.12-venv 2>/dev/null || echo "PACKAGE_NOT_INSTALLED"
```

```bash
apt-cache policy python3.12-venv
```

```bash
apt-get install -y python3.12-venv
```

ディレクトリを作り、専用ユーザーで仮想環境を作ります。

```bash
install -d -o ai-defense-relay -g ai-defense-relay -m 750 /opt/ai-defense-relay && runuser -u ai-defense-relay -- python3 -m venv /opt/ai-defense-relay/venv
```

構築時は、`python3.12-venv` を入れる前にこのコマンドを実行してディレクトリだけができたため、入れた後に仮想環境の作成だけをやり直しました。

```bash
runuser -u ai-defense-relay -- python3 -m venv /opt/ai-defense-relay/venv
```

```bash
runuser -u ai-defense-relay -- /opt/ai-defense-relay/venv/bin/python -m pip --version
```

```bash
runuser -u ai-defense-relay -- /opt/ai-defense-relay/venv/bin/python -c 'import http.server,ssl,urllib.request,json,ipaddress; print("HTTPS_SERVER_AND_REQUIRED_STDLIB_AVAILABLE")'
```

# 第3章　systemdで渡す秘密の情報

## 3.1　置き場所

Relay は専用ユーザーで動かし、秘密の情報は root だけが読めるファイルに置いたまま、systemd の `LoadCredential` で起動のときだけ渡します。

```bash
stat -c '%A %a %U:%G %n' /etc/ai-defense-relay /etc/ai-defense-relay/ca.crt /etc/ai-defense-relay/ca.key /etc/ai-defense-relay/server.crt /etc/ai-defense-relay/server.key /etc/ai-defense-relay/api.token /root/ai-defense-reader.password
```

```bash
install -d -o root -g root -m 700 /etc/credstore
```

## 3.2　ファイルの配置

```bash
install -o root -g root -m 600 /root/ai-defense-reader.password /etc/credstore/ai-defense-indexer-password && install -o root -g root -m 600 /etc/ai-defense-relay/api.token /etc/credstore/ai-defense-relay-token && install -o root -g root -m 600 /etc/ai-defense-relay/server.key /etc/credstore/ai-defense-relay-server-key && echo "SYSTEMD_CREDENTIAL_FILES_PREPARED"
```

```bash
stat -c '%A %a %U:%G %s bytes %n' /etc/credstore/ai-defense-indexer-password /etc/credstore/ai-defense-relay-token /etc/credstore/ai-defense-relay-server-key
```

```bash
install -o root -g root -m 600 /etc/ai-defense-relay/server.crt /etc/credstore/ai-defense-relay-server-cert && install -o root -g root -m 600 /etc/wazuh-indexer/certs/root-ca.pem /etc/credstore/ai-defense-indexer-ca && echo "TLS_CERTIFICATE_CREDENTIALS_PREPARED"
```

```bash
stat -c '%A %a %U:%G %s bytes %n' /etc/credstore/ai-defense-*
```

Relay のサーバー証明書の検証には、Indexer の CA ではなく Relay 専用の CA を使います（構築時は、最初に Indexer の CA で検証して失敗しました）。Relay の CA も配置します。

```bash
install -o root -g root -m 600 /etc/ai-defense-relay/ca.crt /etc/credstore/ai-defense-relay-ca && echo "RELAY_CA_CREDENTIAL_PREPARED"
```

```bash
openssl verify -CAfile /etc/credstore/ai-defense-relay-ca -verify_ip 192.168.0.220 -purpose sslserver /etc/credstore/ai-defense-relay-server-cert && test "$(openssl x509 -in /etc/credstore/ai-defense-relay-server-cert -pubkey -noout | openssl sha256)" = "$(openssl pkey -in /etc/credstore/ai-defense-relay-server-key -pubout | openssl sha256)" && echo "RELAY_TLS_CREDENTIALS_VALID"
```

| ファイル（`/etc/credstore/`） | 中身 |
|---|---|
| `ai-defense-indexer-password` | Indexer の `ai-defense-reader` のパスワード |
| `ai-defense-indexer-ca` | Indexer の CA 証明書 |
| `ai-defense-relay-token` | Bearer トークン |
| `ai-defense-relay-server-cert` | Relay のサーバー証明書 |
| `ai-defense-relay-server-key` | Relay のサーバーの秘密鍵 |
| `ai-defense-relay-ca` | Relay の CA 証明書 |

## 3.3　待ち受けの確認

```bash
ss -lntp | grep -E '(:8765[[:space:]]|:8765$)' || echo "PORT_8765_AVAILABLE"
```

```bash
ip -brief address show | grep '192\.168\.0\.220/'
```

# 第4章　Relayのプログラム

## 4.1　relay.py

Python の標準のライブラリだけで書いた、HTTPS のサーバーです。

- 接続元は VM 230（`192.168.0.33`）だけ。ほかからは `403`
- `Authorization: Bearer トークン` が一致しなければ `401`（比べるときは `hmac.compare_digest` を使う）
- 使えるのは `GET /health` と `GET /v1/alerts` だけ。`POST`・`PUT`・`DELETE`・`HEAD` は `405`
- `/v1/alerts` の引数は `limit`（1〜100、既定50）と `since_minutes`（1〜1440、既定15）だけ
- Indexer への問い合わせは Relay の中で組み立て、決めた10項目だけを返す（文字列は512文字まで）
- Indexer からの応答が2MBを超えたら返さない

```bash
cat > /opt/ai-defense-relay/relay.py <<'PY'
#!/usr/bin/env python3
import os
import json
import ssl
import hmac
import base64
import urllib.request
import urllib.error
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

BIND_HOST = "192.168.0.220"
BIND_PORT = 8765
ALLOWED_CLIENT = "192.168.0.33"
INDEXER_URL = "https://127.0.0.1:9200/wazuh-alerts-4.x-*/_search"

ALLOWED_FIELDS = (
    "timestamp",
    "agent.id",
    "agent.ip",
    "agent.name",
    "manager.name",
    "rule.level",
    "rule.description",
    "rule.id",
    "location",
    "decoder.name",
)

def credential(name):
    directory = os.environ.get("CREDENTIALS_DIRECTORY")
    if not directory:
        raise RuntimeError("Systemd credentials unavailable")
    return (Path(directory) / name).read_bytes().strip()

API_TOKEN = credential("relay-token")
INDEXER_PASSWORD = credential("indexer-password").decode("utf-8")

INDEXER_AUTH = "Basic " + base64.b64encode(
    ("ai-defense-reader:" + INDEXER_PASSWORD).encode()
).decode()

INDEXER_TLS = ssl.create_default_context(
    cafile=os.environ["CREDENTIALS_DIRECTORY"] + "/indexer-ca"
)

SERVER_TLS = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
SERVER_TLS.minimum_version = ssl.TLSVersion.TLSv1_2
SERVER_TLS.load_cert_chain(
    os.environ["CREDENTIALS_DIRECTORY"] + "/server-cert",
    os.environ["CREDENTIALS_DIRECTORY"] + "/server-key",
)

def sanitize_alert(source):
    result = {}
    for field in ALLOWED_FIELDS:
        value = source
        for part in field.split("."):
            if not isinstance(value, dict):
                value = None
                break
            value = value.get(part)

        if value is None:
            continue

        if field == "rule.level":
            if isinstance(value, int) and not isinstance(value, bool):
                result[field] = value
        elif isinstance(value, str):
            result[field] = value[:512]

    return result

class RelayHandler(BaseHTTPRequestHandler):
    server_version = "AI-Defense-Relay"
    sys_version = ""

    def log_message(self, fmt, *args):
        print("relay client=%s %s" % (self.client_address[0], fmt % args),
              flush=True)

    def send_json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.client_address[0] != ALLOWED_CLIENT:
            self.send_json(403, {"error": "forbidden"})
            return

        auth = self.headers.get("Authorization", "")
        expected = "Bearer " + API_TOKEN.decode("utf-8")
        if not hmac.compare_digest(auth, expected):
            self.send_json(401, {"error": "unauthorized"})
            return

        parsed = urlsplit(self.path)

        if parsed.path == "/health":
            self.send_json(200, {"status": "ok"})
            return

        if parsed.path != "/v1/alerts":
            self.send_json(404, {"error": "not_found"})
            return

        params = parse_qs(parsed.query, strict_parsing=True)
        if set(params) - {"limit", "since_minutes"}:
            self.send_json(400, {"error": "unsupported_parameter"})
            return
        if any(len(v) != 1 for v in params.values()):
            self.send_json(400, {"error": "invalid_parameter"})
            return

        try:
            limit = int(params.get("limit", ["50"])[0])
            since = int(params.get("since_minutes", ["15"])[0])
        except ValueError:
            self.send_json(400, {"error": "invalid_parameter"})
            return

        if not 1 <= limit <= 100 or not 1 <= since <= 1440:
            self.send_json(400, {"error": "parameter_out_of_range"})
            return

        query = {
            "size": limit,
            "track_total_hits": False,
            "sort": [{"timestamp": {"order": "desc"}}],
            "_source": list(ALLOWED_FIELDS),
            "query": {
                "range": {
                    "timestamp": {
                        "gte": "now-%dm" % since
                    }
                }
            }
        }

        request = urllib.request.Request(
            INDEXER_URL,
            data=json.dumps(query).encode("utf-8"),
            headers={
                "Authorization": INDEXER_AUTH,
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            method="POST",
        )

        try:
            with urllib.request.urlopen(
                request, context=INDEXER_TLS, timeout=10
            ) as response:
                raw = response.read(2 * 1024 * 1024 + 1)

            if len(raw) > 2 * 1024 * 1024:
                self.send_json(502, {"error": "upstream_response_too_large"})
                return

            data = json.loads(raw)
            hits = data.get("hits", {}).get("hits", [])
            alerts = [
                sanitize_alert(hit.get("_source", {}))
                for hit in hits
                if isinstance(hit.get("_source"), dict)
            ]
            self.send_json(200, {
                "count": len(alerts),
                "alerts": alerts
            })

        except Exception:
            self.send_json(502, {"error": "indexer_unavailable"})

    def do_POST(self):
        self.send_json(405, {"error": "method_not_allowed"})

    def do_PUT(self):
        self.send_json(405, {"error": "method_not_allowed"})

    def do_DELETE(self):
        self.send_json(405, {"error": "method_not_allowed"})

    def do_HEAD(self):
        self.send_json(405, {"error": "method_not_allowed"})

class RelayServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = False

def main():
    server = RelayServer((BIND_HOST, BIND_PORT), RelayHandler)
    server.socket = SERVER_TLS.wrap_socket(
        server.socket, server_side=True
    )
    print("AI Defense Relay listening on %s:%s" %
          (BIND_HOST, BIND_PORT), flush=True)
    server.serve_forever()

if __name__ == "__main__":
    main()
PY
chown root:ai-defense-relay /opt/ai-defense-relay/relay.py
chmod 640 /opt/ai-defense-relay/relay.py
```

## 4.2　構文の確認

```bash
python3 -m py_compile /opt/ai-defense-relay/relay.py
```

```bash
stat -c '%A %a %U:%G %s bytes' /opt/ai-defense-relay/relay.py && tail -n 25 /opt/ai-defense-relay/relay.py
```

```bash
sed -n '1,150p' /opt/ai-defense-relay/relay.py
```

```bash
sed -n '151,260p' /opt/ai-defense-relay/relay.py
```

## 4.3　問い合わせ文字列の検査を強める

`parse_qs(..., strict_parsing=True)` は、形の崩れた問い合わせ文字列で `ValueError` を出します。そのままでは処理が止まるため、`400` を返すように直します。

```bash
python3 - <<'PY'
from pathlib import Path

p = Path("/opt/ai-defense-relay/relay.py")
s = p.read_text()
old = '''        params = parse_qs(parsed.query, strict_parsing=True)
        if set(params) - {"limit", "since_minutes"}:
'''
new = '''        try:
            params = parse_qs(parsed.query, strict_parsing=True)
        except ValueError:
            self.send_json(400, {"error": "invalid_query"})
            return

        if set(params) - {"limit", "since_minutes"}:
'''
if old not in s:
    raise SystemExit("EXPECTED_CODE_NOT_FOUND; FILE_UNCHANGED")
p.write_text(s.replace(old, new, 1))
print("QUERY_VALIDATION_HARDENED")
PY
```

```bash
python3 -m py_compile /opt/ai-defense-relay/relay.py && echo "RELAY_SYNTAX_OK"
```

さらに、問い合わせ文字列の長さを128文字まで、引数の数を2つまでに制限します。

```bash
python3 - <<'PY'
from pathlib import Path

p = Path("/opt/ai-defense-relay/relay.py")
s = p.read_text()
old = '''        try:
            params = parse_qs(parsed.query, strict_parsing=True)
        except ValueError:
'''
new = '''        if len(parsed.query) > 128:
            self.send_json(400, {"error": "query_too_long"})
            return

        try:
            params = parse_qs(
                parsed.query, strict_parsing=True, max_num_fields=2
            )
        except ValueError:
'''
if old not in s:
    raise SystemExit("EXPECTED_CODE_NOT_FOUND; FILE_UNCHANGED")
p.write_text(s.replace(old, new, 1))
print("QUERY_LENGTH_AND_FIELD_LIMITS_ADDED")
PY
```

```bash
python3 -m py_compile /opt/ai-defense-relay/relay.py && echo "RELAY_SYNTAX_OK"
```

# 第5章　systemdのサービス

## 5.1　ユニットファイル

```bash
test ! -e /etc/systemd/system/ai-defense-relay.service && echo "SERVICE_UNIT_NAME_AVAILABLE" || echo "SERVICE_UNIT_ALREADY_EXISTS"
```

秘密の情報は `LoadCredential` で渡し、プロセスの権限は強く制限します。

- `LoadCredential=名前:パス`：起動のときだけ `$CREDENTIALS_DIRECTORY/名前` として読める
- `ProtectSystem=strict`・`ProtectHome=yes`：ファイルシステムを書き込み不可・ホームを見えなくする
- `CapabilityBoundingSet=`（空）・`NoNewPrivileges=yes`：特権を持たない
- `RestrictAddressFamilies=AF_INET`：IPv4 の通信だけ
- `MemoryMax=256M`・`TasksMax=32`：使う資源の上限

```bash
cat > /etc/systemd/system/ai-defense-relay.service <<'UNIT'
[Unit]
Description=AI Defense Wazuh Alert Read-only Relay
After=network.target wazuh-indexer.service
Wants=network.target

[Service]
Type=simple
User=ai-defense-relay
Group=ai-defense-relay
WorkingDirectory=/opt/ai-defense-relay

LoadCredential=relay-token:/etc/credstore/ai-defense-relay-token
LoadCredential=indexer-password:/etc/credstore/ai-defense-indexer-password
LoadCredential=indexer-ca:/etc/credstore/ai-defense-indexer-ca
LoadCredential=server-cert:/etc/credstore/ai-defense-relay-server-cert
LoadCredential=server-key:/etc/credstore/ai-defense-relay-server-key

ExecStart=/opt/ai-defense-relay/venv/bin/python /opt/ai-defense-relay/relay.py
Restart=on-failure
RestartSec=5
UMask=0077

NoNewPrivileges=yes
CapabilityBoundingSet=
AmbientCapabilities=
PrivateTmp=yes
PrivateDevices=yes
ProtectSystem=strict
ProtectHome=yes
ProtectKernelTunables=yes
ProtectKernelModules=yes
ProtectKernelLogs=yes
ProtectControlGroups=yes
ProtectClock=yes
ProtectHostname=yes
ProtectProc=invisible
ProcSubset=pid
RestrictSUIDSGID=yes
LockPersonality=yes
MemoryDenyWriteExecute=yes
RestrictRealtime=yes
SystemCallArchitectures=native
RestrictAddressFamilies=AF_INET

MemoryMax=256M
TasksMax=32
LimitNOFILE=1024

[Install]
WantedBy=multi-user.target
UNIT
```

```bash
tail -n 25 /etc/systemd/system/ai-defense-relay.service
```

```bash
systemd-analyze verify /etc/systemd/system/ai-defense-relay.service
```

## 5.2　起動前の確認

ファイルの権限と、専用ユーザーで Python と relay.py を読めることを確かめます。

```bash
stat -c '%a %U:%G %n' \
  /etc/credstore/ai-defense-relay-token \
  /etc/credstore/ai-defense-indexer-password \
  /etc/credstore/ai-defense-indexer-ca \
  /etc/credstore/ai-defense-relay-server-cert \
  /etc/credstore/ai-defense-relay-server-key
```

```bash
stat -c '%a %U:%G %n' \
  /opt/ai-defense-relay \
  /opt/ai-defense-relay/relay.py \
  /opt/ai-defense-relay/venv \
  /opt/ai-defense-relay/venv/bin/python
```

```bash
ls -l /opt/ai-defense-relay/venv/bin/python && readlink -f /opt/ai-defense-relay/venv/bin/python
```

```bash
runuser -u ai-defense-relay -- /opt/ai-defense-relay/venv/bin/python -c 'import sys; print(sys.version); print("PYTHON_EXECUTION_OK")'
```

```bash
runuser -u ai-defense-relay -- /opt/ai-defense-relay/venv/bin/python -c 'import ast, pathlib, ssl, urllib.request, http.server; p=pathlib.Path("/opt/ai-defense-relay/relay.py"); ast.parse(p.read_text()); print("RELAY_READ_OK"); print("STANDARD_LIBRARIES_OK")'
```

ユニットの内容と、relay.py が読む資格情報の名前が一致していることを確かめます。

```bash
systemd-analyze cat-config systemd/system/ai-defense-relay.service
```

```bash
grep -nE 'CREDENTIALS_DIRECTORY|credential\(|indexer-ca|server-cert|server-key|relay-token|indexer-password' /opt/ai-defense-relay/relay.py
```

アクセスのログに、問い合わせ文字列や認証の情報が残らないことも確かめます。

> **注意**　構築時にこの確認をした時点で、relay.py はすでに 4.1〜4.3 の内容から変わっていました（アクセスのログを「接続元のIPアドレスとステータス」だけにする `log_request` の上書き、同時に処理する要求を8つまでにする `threading.BoundedSemaphore(8)` の追加）。この変更の手順は構築の記録に残っていないため、本書には掲載していません（不足情報メモ 14-A）。

```bash
grep -nA12 -B3 'def log_message' /opt/ai-defense-relay/relay.py
```

```bash
systemctl daemon-reload && systemctl show ai-defense-relay.service -p LoadCredential -p User -p Group -p FragmentPath
```

`LoadCredential` は、中身を守るため `[unprintable]` と表示されます。

# 第6章　起動と接続の確認

## 6.1　起動

起動すると、`192.168.0.220:8765` で待ち受けを始めます。

```bash
systemctl start ai-defense-relay.service && systemctl status ai-defense-relay.service --no-pager -l
```

構築時の結果は `Active: active (running)` でした。なお、この時点では `disabled`（自動起動しない）のままです。

```bash
ss -lntp '( sport = :8765 )' && echo && journalctl -u ai-defense-relay.service -n 20 --no-pager
```

## 6.2　TLSの確認

```bash
timeout 5 openssl s_client -connect 192.168.0.220:8765 -CAfile /etc/ai-defense-relay/ca.crt -verify_ip 192.168.0.220 -verify_return_error -brief </dev/null
```

構築時の結果は次のとおりです。

- `Protocol version: TLSv1.3`
- `Peer certificate: CN = 192.168.0.220`
- `Verification: OK`

`Can't use SSL_get_servername` は、IPアドレスで接続したため SNI の名前を使えないという通知で、検証の失敗ではありません。

## 6.3　VM 230からの接続

> **実行先：ai-defense-manager VM 230（root）**

```bash
nc -vz -w 3 192.168.0.220 8765
```

`succeeded!` と表示されれば、VM 230 から Relay の待ち受けに届いています。

# おわりに

第14部では、security-core に次の中継APIを作りました。

| 項目 | 内容 |
|---|---|
| 待ち受け | `https://192.168.0.220:8765`（TLS 1.2以上） |
| 接続元 | `192.168.0.33`（VM 230）だけ |
| 認証 | Bearer トークン |
| API | `GET /health`、`GET /v1/alerts?limit=&since_minutes=` |
| 実行 | `ai-defense-relay.service`（専用ユーザー、`LoadCredential`） |

次の部では、VM 230 にトークンと CA 証明書を安全に渡し、Relay からアラートを受け取れるようにします。
