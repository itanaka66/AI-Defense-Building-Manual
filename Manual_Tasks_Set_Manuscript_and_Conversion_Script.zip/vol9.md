---
title: "AI自律型サイバー防御システム 構築マニュアル 前編"
subtitle: "第9部　Collectorの停止からの復旧と運用の点検"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」前編の第9部です。第8部で監視基盤が完成した後、次の段階（SOCデータ統合基盤）に進む前の確認で、Wazuh Collectorが止まっていることが見つかりました。第9部では、その原因を調べ、取りこぼしたアラートをDBに取り込み直して通常の収集に戻し、続けて監視・DB・時刻・イベントの内容を点検して、見つかった問題（多発していたイベント）に対処するまでを扱います。

第7部の「未対応の課題」に書いた「旧ファイルが圧縮された後の再開」が、実際に起きた事例です。

## 本書の表記

- コマンドやファイル内容は、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 各手順の冒頭に「実行先」を示します。
- 「実行結果（例）」は構築時の実際の出力です。inode・件数・時刻などは、お使いの環境では異なります。
- 状態ファイル（`state.json`）や接続情報の中身を表示するコマンドは載せていません。

## 起きていたこと（まとめ）

| 順番 | 内容 |
|---|---|
| 1 | 11月18日 23:53、Collectorは18日分の `alerts.json` を末尾まで読み、状態を保存した |
| 2 | 日付が変わって新しい `alerts.json` が作られたが、Collector用の読み取りACLがなく、読めずに異常終了をくり返した（自動再起動 10,005回） |
| 3 | その間に18日分のファイルは圧縮（`.json.gz`）され、保存してあったinodeのファイルがなくなった |
| 4 | 19日分も圧縮され、19日分のアラート（9,039件）は取り込まれないままになった |

# 第1章　停止の確認と1つ目の原因

## 1.1　Collectorの状態

**実行先：security-core VM 220（root）**

```bash
echo "=== COLLECTOR SERVICE ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts -p ExecMainStatus

echo
echo "=== ALERT FILE ==="
stat -c 'inode=%i size=%s mode=%a owner=%U:%G' \
  /var/ossec/logs/alerts/alerts.json

echo
echo "=== COLLECTOR STATE METADATA ==="
stat -c 'mode=%a owner=%U:%G size=%s' \
  /var/lib/wazuh-collector/state.json

echo
echo "=== COLLECTOR CODE HASH ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== RECENT COLLECTOR STATUS LOGS ==="
journalctl -u wazuh-collector --since "30 minutes ago" --no-pager \
  | grep -Ei 'connection established|inserted|duplicate|error|warning' \
  | sed -E 's/(password|token|secret)=([^ ]+)/\1=[REDACTED]/Ig' \
  | tail -30
```

構築時は `NRestarts=10005`、`MainPID=0`、`SubState=auto-restart` で、`alerts.json` を読むときの `PermissionError` がくり返し記録されていました。

## 1.2　権限の確認

**実行先：security-core VM 220（root）**

```bash
echo "=== OSSEC DIRECTORY ACL ==="
getfacl -p /var/ossec

echo
echo "=== LOGS DIRECTORY ACL ==="
getfacl -p /var/ossec/logs

echo
echo "=== SYSTEMD SECURITY SETTINGS ==="
systemctl show wazuh-collector \
  -p ProtectSystem -p ProtectHome -p PrivateUsers \
  -p ReadOnlyPaths -p InaccessiblePaths
```

親のディレクトリには通過の権限があり、systemdの制限も原因ではありませんでした。原因は、新しい `alerts.json`（`wazuh:wazuh`、`640`）に Collector 用の読み取りACLがないことでした。

## 1.3　alerts.jsonへの読み取りACLの追加

所有者・グループ・通常の権限は変えず、`wazuh-collector` の読み取りだけを追加します。

**実行先：security-core VM 220（root）**

```bash
setfacl -m u:wazuh-collector:r-- \
  /var/ossec/logs/alerts/alerts.json

echo "=== UPDATED FILE ACL ==="
getfacl -p /var/ossec/logs/alerts/alerts.json

echo
echo "=== READ TEST ==="
runuser -u wazuh-collector -- \
  test -r /var/ossec/logs/alerts/alerts.json
echo "read_test_exit_code=$?"
```

`read_test_exit_code=0` であれば読めます。自動再起動で戻るかを確かめます。

```bash
echo "=== WAIT FOR AUTO RECOVERY ==="
sleep 15

echo
echo "=== COLLECTOR SERVICE ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts -p ExecMainStatus

echo
echo "=== RECENT COLLECTOR LOGS ==="
journalctl -u wazuh-collector --since "2 minutes ago" --no-pager \
  | grep -Ei 'started|connection|inserted|duplicate|error|warning' \
  | tail -25
```

構築時は、これだけでは戻りませんでした。次の章の原因が残っていたためです。

# 第2章　2つ目の原因：保存したinodeの消失

## 2.1　調べて分かったこと

Collectorは起動するとき、保存したinodeが今の `alerts.json` でなければ、`alerts` ディレクトリの中を再帰的に探します（第6部）。構築時は、次の2つが重なっていました。

| 問題 | 内容 |
|---|---|
| 探索の失敗 | `alerts` の中に、以前の試験で作られた root 専用の隠しディレクトリ（`.acl-inheritance-test.bkv8vd`、`root:root`、`0700`）が残っていて、探索が権限エラーで止まる |
| inodeの消失 | 保存したinode（`5409146`）のファイルが、`/var/ossec/logs` の下にどこにもない |

隠しディレクトリは削除せず、そのまま残しています（後の手順で、探索しなくても起動できる状態に戻すためです）。

## 2.2　保存したinodeを探す

**実行先：security-core VM 220（root）**

```bash
echo "=== LOCATE SAVED INODE ==="
find /var/ossec/logs/alerts \
  -xdev -inum 5409146 \
  -printf 'inode=%i size=%s owner=%u:%g mode=%m path=%p\n' \
  2>&1

echo
echo "=== LIST ROTATED ALERT FILES ==="
find /var/ossec/logs/alerts/2026 \
  -type f -name '*.json' \
  -printf 'inode=%i size=%s owner=%u:%g path=%p\n' \
  2>&1 | sort

echo
echo "=== HIDDEN TEST DIRECTORY METADATA ==="
find /var/ossec/logs/alerts/.acl-inheritance-test.bkv8vd \
  -maxdepth 3 \
  -printf '%y inode=%i owner=%u:%g mode=%m path=%p\n' \
  2>&1
```

```bash
echo "=== SEARCH OLD INODE UNDER WAZUH LOGS ==="
find /var/ossec/logs -xdev -inum 5409146 \
  -printf 'inode=%i size=%s owner=%u:%g path=%p\n' 2>&1

echo
echo "=== CURRENT ALERT FILE LINK INFORMATION ==="
stat -c 'path=%n inode=%i links=%h size=%s mtime=%y' \
  /var/ossec/logs/alerts/alerts.json \
  /var/ossec/logs/alerts/2026/Nov/ossec-alerts-20.json

echo
echo "=== STATE FILE TIMESTAMPS ==="
stat -c 'owner=%U:%G mode=%a size=%s mtime=%y ctime=%z' \
  /var/lib/wazuh-collector/state.json

echo
echo "=== COLLECTOR ROTATION HISTORY ==="
journalctl -u wazuh-collector --since "2026-11-19 00:00:00" \
  --no-pager -o cat \
  | grep -Ei 'rotat|inode|resume|offset|initial start|previous alert|cannot be located' \
  | tail -60
```

`5409146` は、自分の環境の状態ファイルに保存されているinodeに置き換えます。構築時は見つからず、状態ファイルの更新時刻は11月18日 23:53のままでした。

## 2.3　ログのファイルの一覧

**実行先：security-core VM 220（root）**

```bash
echo "=== ALERT LOG FILE INVENTORY ==="
find /var/ossec/logs/alerts -xdev -type f \
  -printf '%TY-%Tm-%Td %TH:%TM:%TS inode=%i size=%s owner=%u:%g mode=%m %p\n' \
  | sort

echo
echo "=== LOG ROTATION CONFIGURATION ==="
grep -RInE 'alerts\.json|ossec-alerts|rotate|compress|daily|weekly' \
  /etc/logrotate.conf /etc/logrotate.d 2>/dev/null

echo
echo "=== CURRENT ALERT FILE TIMESTAMPS ==="
python3 - <<'PY'
import json
from pathlib import Path

p = Path("/var/ossec/logs/alerts/alerts.json")
count = 0
first = None
last = None
invalid = 0

with p.open("r", encoding="utf-8") as f:
    for line in f:
        try:
            obj = json.loads(line)
            ts = obj.get("timestamp")
            if ts is not None:
                first = first or ts
                last = ts
            count += 1
        except Exception:
            invalid += 1

print(f"valid_json_lines={count}")
print(f"invalid_lines={invalid}")
print(f"first_timestamp={first}")
print(f"last_timestamp={last}")
PY
```

17〜19日分は `.json.gz` に圧縮されていて、旧ファイルは圧縮されるとinodeが変わります。

## 2.4　圧縮ファイルと保存位置の照合

圧縮ファイルを展開しながら数え、保存してあった位置（オフセット）が、どの日のファイルのどこに当たるかを調べます。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import gzip
import json
from pathlib import Path

base = Path("/var/ossec/logs/alerts/2026/Nov")
target_offset = 2774739

for day in ("17", "18", "19"):
    path = base / f"ossec-alerts-{day}.json.gz"
    if not path.exists():
        continue

    total = 0
    lines = 0
    first = None
    last = None
    before = None
    after = None
    boundary = None

    with gzip.open(path, "rb") as f:
        while True:
            start = total
            line = f.readline()
            if not line:
                break

            total += len(line)
            lines += 1

            try:
                obj = json.loads(line)
                ts = obj.get("timestamp")
            except Exception:
                ts = None

            if first is None:
                first = ts
            last = ts

            if start <= target_offset < total:
                boundary = (start, total)
                before = ts
            elif total <= target_offset:
                before = ts
            elif after is None and start >= target_offset:
                after = ts

    print(f"FILE={path.name}")
    print(f"  uncompressed_bytes={total}")
    print(f"  lines={lines}")
    print(f"  first_timestamp={first}")
    print(f"  last_timestamp={last}")
    print(f"  saved_offset={target_offset}")
    print(f"  offset_within_file={target_offset <= total}")
    print(f"  boundary_line_byte_range={boundary}")
    print(f"  timestamp_at_or_before_offset={before}")
    print(f"  timestamp_after_offset={after}")
PY
```

`target_offset` は、自分の環境の状態ファイルに保存されている位置に置き換えます。

| 項目 | 構築時の値 |
|---|---|
| 保存してあった位置 | 2,774,739 バイト |
| `ossec-alerts-18.json.gz` の展開後の大きさ | 2,774,739 バイト（一致） |
| 18日分の最後のアラートの時刻 | 2026-11-18T23:53:10.688+0000 |
| 状態ファイルの更新時刻 | 2026-11-18 23:53:12 |

18日分は最後まで取り込み済みで、取り込まれていないのは19日分（`ossec-alerts-19.json.gz`）だと分かりました。

## 2.5　19日分と今日の分の境目の確認

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import gzip
import json
from pathlib import Path

files = [
    (Path("/var/ossec/logs/alerts/2026/Nov/ossec-alerts-19.json.gz"), True),
    (Path("/var/ossec/logs/alerts/alerts.json"), False),
]

for path, compressed in files:
    opener = gzip.open if compressed else open
    count = 0
    invalid = 0
    first = None
    last = None
    missing_id = 0
    missing_ts = 0

    with opener(path, "rb") as stream:
        for line in stream:
            if not line.strip():
                continue
            try:
                event = json.loads(line)
                event_id = event.get("id")
                timestamp = event.get("timestamp")

                if not isinstance(event_id, str) or not event_id:
                    missing_id += 1
                if not isinstance(timestamp, str):
                    missing_ts += 1
                    continue

                first = first or timestamp
                last = timestamp
                count += 1
            except Exception:
                invalid += 1

    print(f"FILE={path.name}")
    print(f"  events_with_timestamp={count}")
    print(f"  invalid_json={invalid}")
    print(f"  missing_event_id={missing_id}")
    print(f"  missing_timestamp={missing_ts}")
    print(f"  first_timestamp={first}")
    print(f"  last_timestamp={last}")
PY
```

| ファイル | 件数 | 時刻 |
|---|---:|---|
| `ossec-alerts-19.json.gz` | 9,039 | 最後 `00:00:01.339`（20日） |
| `alerts.json`（20日分） | 2,749 | 最初 `00:00:07.341` |

どちらも、壊れた行・IDのない行・時刻のない行は0件でした。19日分を取り込んでから20日分に続ければ、取りこぼしはありません。

# 第3章　復旧の方針と準備

## 3.1　方針

Collectorのソースに圧縮ファイルの対応を加えるのではなく、次の順で復旧します。Collectorのソース・systemdの設定・Wazuhのログ自体は変更しません。

1. 19日分（`ossec-alerts-19.json.gz`）の9,039件を、Collectorの既存の処理（`process_line()`）でDBに登録する。
2. すでに登録済みのイベントは、既存の重複処理（一意制約）で飛ばされる。
3. 全件の処理が終わった場合だけ、状態ファイルを今の `alerts.json` のinode・位置 `0` に進める。
4. Collectorは自動再起動で、今の `alerts.json` の先頭から通常の収集に戻る（保存したinodeが今のファイルなので、ディレクトリの探索は行われない）。

途中で失敗したときは状態ファイルを進めないため、もう一度実行しても重複処理で安全にやり直せます。

## 3.2　Collectorのバックアップ

**実行先：security-core VM 220（root）**

```bash
install -d -o root -g root -m 700 /root/wazuh-collector-recovery

cp -a /usr/local/lib/wazuh-collector/collector.py \
  /root/wazuh-collector-recovery/collector.py.before-recovery

sha256sum \
  /usr/local/lib/wazuh-collector/collector.py \
  /root/wazuh-collector-recovery/collector.py.before-recovery

stat -c '%n owner=%U:%G mode=%a size=%s' \
  /root/wazuh-collector-recovery/collector.py.before-recovery
```

## 3.3　CollectorのユーザーでのDBへの接続の確認

接続情報は表示せず、つながるかどうかだけを確かめます。

**実行先：security-core VM 220（root）**

```bash
runuser -u wazuh-collector -- python3 - <<'PY'
import sys
sys.path.insert(0, "/usr/local/lib/wazuh-collector")

import collector

try:
    with collector.psycopg.connect(**collector.DB_CONFIG) as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT 1")
            print("database_connection=OK")
            print("basic_query=OK")
except Exception as exc:
    print("database_connection=FAILED")
    print("error_type=" + type(exc).__name__)
PY
```

## 3.4　19日分のファイルへの読み取りACLの追加

**実行先：security-core VM 220（root）**

```bash
echo "=== ARCHIVE READ ACCESS ==="
if runuser -u wazuh-collector -- test -r \
  /var/ossec/logs/alerts/2026/Nov/ossec-alerts-19.json.gz; then
  echo "archive_readable=YES"
else
  echo "archive_readable=NO"
fi

echo
echo "=== ARCHIVE METADATA ==="
stat -c 'owner=%U group=%G mode=%a size=%s inode=%i' \
  /var/ossec/logs/alerts/2026/Nov/ossec-alerts-19.json.gz
```

```bash
getfacl -p \
  /var/ossec/logs/alerts/2026/Nov \
  /var/ossec/logs/alerts/2026/Nov/ossec-alerts-19.json.gz
```

`Nov` ディレクトリには Collector の読み取り・通過の権限があり、足りないのはファイル1つの読み取りだけでした。そのファイルだけに追加します。

```bash
setfacl -m u:wazuh-collector:r-- \
  /var/ossec/logs/alerts/2026/Nov/ossec-alerts-19.json.gz

echo "=== VERIFY ACL ==="
getfacl -p \
  /var/ossec/logs/alerts/2026/Nov/ossec-alerts-19.json.gz

echo
echo "=== VERIFY COLLECTOR ACCESS ==="
if runuser -u wazuh-collector -- test -r \
  /var/ossec/logs/alerts/2026/Nov/ossec-alerts-19.json.gz; then
  echo "archive_readable=YES"
else
  echo "archive_readable=NO"
fi
```

## 3.5　19日分の検証（DBには書き込まない）

Collectorの `extract_event()` で全件を検証します。

**実行先：security-core VM 220（root）**

```bash
runuser -u wazuh-collector -- python3 - <<'PY'
import gzip
import json
import sys

sys.path.insert(0, "/usr/local/lib/wazuh-collector")
import collector

path = "/var/ossec/logs/alerts/2026/Nov/ossec-alerts-19.json.gz"

total = 0
json_errors = 0
extract_errors = 0
missing_event_id = 0
missing_timestamp = 0
valid_events = 0

with gzip.open(path, "rt", encoding="utf-8") as f:
    for line in f:
        total += 1
        try:
            raw = json.loads(line)
        except (json.JSONDecodeError, UnicodeDecodeError):
            json_errors += 1
            continue

        try:
            event = collector.extract_event(raw)
        except Exception:
            extract_errors += 1
            continue

        if not event:
            extract_errors += 1
            continue

        if not event.get("event_id"):
            missing_event_id += 1
        if not event.get("event_timestamp"):
            missing_timestamp += 1

        if event.get("event_id") and event.get("event_timestamp"):
            valid_events += 1

print(f"total_lines={total}")
print(f"json_errors={json_errors}")
print(f"extract_errors={extract_errors}")
print(f"missing_event_id={missing_event_id}")
print(f"missing_timestamp={missing_timestamp}")
print(f"valid_events={valid_events}")
print("archive_validation=" +
      ("OK" if total == 9039 and json_errors == 0
       and extract_errors == 0 and missing_event_id == 0
       and missing_timestamp == 0 and valid_events == total
       else "FAILED"))
PY
```

`9039` は、2.5で数えた自分の環境の件数に置き換えます。構築時は `archive_validation=OK` でした。

# 第4章　19日分の取り込みと通常の収集への復帰

## 4.1　取り込み

**実行先：security-core VM 220（root）**

```bash
runuser -u wazuh-collector -- python3 - <<'PY'
import gzip
import logging
import os
import sys

sys.path.insert(0, "/usr/local/lib/wazuh-collector")
import collector

archive = "/var/ossec/logs/alerts/2026/Nov/ossec-alerts-19.json.gz"
expected_lines = 9039

# 処理前のファイル識別情報を保存
archive_inode_before = os.stat(archive).st_ino
current_inode_before = os.stat(collector.ALERT_FILE).st_ino

logging.disable(logging.CRITICAL)

processed = 0

try:
    with collector.psycopg.connect(**collector.DB_CONFIG) as conn:
        with gzip.open(archive, "rt", encoding="utf-8") as f:
            for line in f:
                collector.process_line(conn, line)
                processed += 1

    print(f"archive_lines_processed={processed}")

    if processed != expected_lines:
        raise RuntimeError("Unexpected archive line count; state not advanced")

    # 処理中にファイルがローテーションされていないことを確認
    archive_inode_after = os.stat(archive).st_ino
    current_inode_after = os.stat(collector.ALERT_FILE).st_ino

    if archive_inode_after != archive_inode_before:
        raise RuntimeError("Archive inode changed; state not advanced")

    if current_inode_after != current_inode_before:
        raise RuntimeError("Current alert inode changed; state not advanced")

    # 全件処理完了後に限り、現在のログの先頭から通常収集を開始
    collector.save_state(current_inode_after, 0)

    print("database_replay=COMPLETED")
    print("state_update=COMPLETED")
    print(f"current_alert_inode={current_inode_after}")
    print("recovery_result=SUCCESS")

except Exception as exc:
    print("recovery_result=FAILED")
    print("error_type=" + type(exc).__name__)
    print("state_update=NOT_CONFIRMED")
    raise
PY
```

`expected_lines` は自分の環境の件数に置き換えます。構築時は9,039件をすべて処理し、状態ファイルが今の `alerts.json`（inode `5409383`）の位置 `0` に進みました（`recovery_result=SUCCESS`）。

> 日付が変わる直前（ローテーションの直前）には実行しないでください。処理中に今の `alerts.json` が入れ替わると、状態ファイルを進めずに止まります。

## 4.2　通常の収集への復帰の確認

状態ファイルが今の `alerts.json` を指すようになったため、Collectorは次の自動再起動で、ディレクトリを探索せずに起動します。構築時は、取り込みの直後に次のログが出て、復帰しました。

```text
INFO Resuming current alert file
INFO PostgreSQL connection established
```

読み取り位置が今のファイルの末尾まで進んでいるかを確かめます。

**実行先：security-core VM 220（root）**

```bash
sleep 15

python3 - <<'PY'
import json
import os

state_path = "/var/lib/wazuh-collector/state.json"
alert_path = "/var/ossec/logs/alerts/alerts.json"

with open(state_path) as f:
    state = json.load(f)

st = os.stat(alert_path)

print(f"state_inode={state['inode']}")
print(f"alert_inode={st.st_ino}")
print(f"state_offset={state['offset']}")
print(f"alert_size={st.st_size}")
print(f"inode_match={state['inode'] == st.st_ino}")
print(f"at_or_near_eof={state['offset'] <= st.st_size}")
print(f"remaining_bytes={max(0, st.st_size - state['offset'])}")
PY

echo
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts
```

| 確認項目 | 構築時の結果 |
|---|---|
| 状態 | `active` / `running`（PID `88146`） |
| 状態ファイルと `alerts.json` のinode | `5409383` / `5409383`（一致） |
| 読み取り位置 | 5,879,391 バイト（ファイルの大きさと一致） |
| 残り | `0` バイト |

`NRestarts` は止まっていた間の自動再起動の回数を含むため、大きな値のままです。増えなくなっていれば問題ありません。

## 4.3　復帰後のエラーの確認

**実行先：security-core VM 220（root）**

```bash
echo "=== COLLECTOR SERVICE ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts -p ExecMainStatus

echo
echo "=== COLLECTOR LOGS (LAST 10 MINUTES) ==="
journalctl -u wazuh-collector --since "10 minutes ago" --no-pager \
  | tail -100

echo
echo "=== RECENT ERRORS ==="
journalctl -u wazuh-collector --since "10 minutes ago" --no-pager \
  | grep -iE 'error|exception|traceback|failed|critical|permission denied' \
  | tail -50 || true
```

10分前からのログには、復帰する前のエラーも含まれます。復帰した時刻（構築時は 04:44:17 UTC）からのログに絞って確認します。

```bash
echo "=== LOGS AFTER RECOVERY ==="
journalctl -u wazuh-collector \
  --since "2026-11-20 04:44:17" \
  --no-pager

echo
echo "=== ERRORS AFTER RECOVERY ==="
journalctl -u wazuh-collector \
  --since "2026-11-20 04:44:17" \
  --no-pager \
  | grep -iE 'error|exception|traceback|failed|critical|permission denied' \
  || echo "No errors after recovery"

echo
echo "=== CURRENT SERVICE ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts
```

構築時は、復帰後のログは「起動」「今のファイルから再開」「PostgreSQLに接続」だけで、エラーはありませんでした（`No errors after recovery`）。

## 4.4　DBのテーブルの確認

**実行先：LXC 109 postgresql（root）**

```bash
sudo -u postgres psql -X -d security_workbench \
  -c '\dn+' \
  -c '\dt incident.*' \
  -c '\d+ incident.alert_events'
```

テーブルの構成（主キー、時刻・重要度・ルール・送信元IPのインデックス）が変わっていないことを確認します。

# 第5章　SOC基盤の稼働の点検

復旧の後、次の段階（SOCデータ統合基盤）で使う各部品が正しく動いているかを、読み取りだけで点検しました。

## 5.1　VictoriaMetricsとメトリクス

**実行先：security-core VM 220（root）**

```bash
echo "=== VICTORIAMETRICS HEALTH ==="
curl -sS --max-time 5 -w '\nHTTP_STATUS=%{http_code}\n' \
  http://192.168.0.171:8428/health

echo
echo "=== PROMETHEUS METRICS QUERY ==="
curl -sS --max-time 10 -G \
  'http://192.168.0.171:8428/api/v1/query' \
  --data-urlencode 'query=up' \
  -w '\nHTTP_STATUS=%{http_code}\n'
```

5台の負荷・空きメモリ・ルートの空き容量を取得します。

```bash
VM='http://192.168.0.171:8428'

for QUERY in \
  'node_load1{job=~"pve-node|security-core|postgresql-node|prometheus-node|grafana-node"}' \
  'node_memory_MemAvailable_bytes{job=~"pve-node|security-core|postgresql-node|prometheus-node|grafana-node"}' \
  'node_filesystem_avail_bytes{job=~"pve-node|security-core|postgresql-node|prometheus-node|grafana-node",mountpoint="/"}'
do
  echo
  echo "=== $QUERY ==="
  curl -sS --max-time 10 -G "$VM/api/v1/query" \
    --data-urlencode "query=$QUERY"
  echo
done
```

構築時は、5台分のデータがそろって取得できました。

## 5.2　Wazuhのサービス

**実行先：security-core VM 220（root）**

```bash
echo "=== WAZUH SERVICES ==="
systemctl --no-pager --type=service --state=running \
  | grep -i wazuh || true

echo
echo "=== WAZUH RELATED LISTENING PORTS ==="
ss -lntp \
  | grep -E ':(55000|55001|1514|1515|514|9200|9100)\b' \
  || true

echo
echo "=== WAZUH MANAGER STATUS ==="
systemctl show wazuh-manager \
  -p ActiveState -p SubState -p MainPID -p ExecMainStatus

echo
echo "=== COLLECTOR STATUS ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts
```

## 5.3　Wazuh APIの応答と証明書

認証情報は使わず、APIが応答して認証を求めるかどうかだけを確かめます。

**実行先：security-core VM 220（root）**

```bash
curl -k -sS \
  -o /dev/null \
  -w 'HTTP status: %{http_code}\nTLS verify result: %{ssl_verify_result}\nConnect time: %{time_connect}s\nTotal time: %{time_total}s\n' \
  https://127.0.0.1:55000/
```

`HTTP status: 401` であれば、APIは動いていて、認証のないアクセスを拒否しています。`TLS verify result: 18` は自己署名の証明書という意味です（`-k` で検証を省いています）。

証明書の中身（秘密鍵ではなく、公開されている情報）を確認します。

```bash
echo | openssl s_client \
  -connect 127.0.0.1:55000 \
  -servername localhost 2>/dev/null \
  | openssl x509 -noout \
      -subject -issuer -dates -fingerprint -sha256
```

```bash
openssl s_client \
  -connect 127.0.0.1:55000 \
  -servername localhost </dev/null 2>/dev/null \
  | openssl x509 -noout -ext subjectAltName
```

| 項目 | 構築時の結果 |
|---|---|
| 発行者・対象 | `CN=wazuh.com`（自己署名） |
| SAN | `DNS:localhost` だけ |

`https://localhost:55000` で使うときは名前が一致します。IPアドレス（127.0.0.1、192.168.0.220）では一致しません。ほかのホストからAPIを使う段階で、接続先の名前と信頼するCAを決めることにし、ここでは証明書を作り直していません。

## 5.4　Wazuh Managerのエラーと警告

**実行先：security-core VM 220（root）**

```bash
echo "=== WAZUH MANAGER RECENT ERRORS ==="
journalctl -u wazuh-manager --since "30 minutes ago" \
  --no-pager -p err

echo
echo "=== WAZUH MANAGER RECENT WARNINGS ==="
journalctl -u wazuh-manager --since "30 minutes ago" \
  --no-pager -p warning | tail -30
```

構築時は、直近30分のエラー・警告はどちらもありませんでした。

# 第6章　DBに入ったイベントの点検

## 6.1　PostgreSQLとテーブルの権限

**実行先：LXC 109 postgresql（root）**

```bash
echo "=== POSTGRESQL SERVICE ==="
systemctl show postgresql \
  -p ActiveState -p SubState

echo
echo "=== DATABASE CONNECTION CONFIGURATION (SAFE FIELDS ONLY) ==="
runuser -u postgres -- psql -X -d security_workbench -Atc \
"SELECT current_database(), current_user, version();" \
| cut -c1-180
```

```bash
echo "=== ALERT EVENTS TABLE ==="
runuser -u postgres -- psql -X -d security_workbench -P pager=off -c \
"SELECT column_name, data_type, is_nullable
 FROM information_schema.columns
 WHERE table_schema = 'incident'
   AND table_name = 'alert_events'
 ORDER BY ordinal_position;"

echo
echo "=== COLLECTOR TABLE PRIVILEGES ==="
runuser -u postgres -- psql -X -d security_workbench -P pager=off -c \
"SELECT grantee, privilege_type
 FROM information_schema.role_table_grants
 WHERE table_schema = 'incident'
   AND table_name = 'alert_events'
   AND grantee = 'wazuh_collector'
 ORDER BY privilege_type;"
```

`wazuh_collector` の権限が `INSERT` だけであることを確認します（第3部の最小権限のまま）。

## 6.2　件数と重要度

**実行先：LXC 109 postgresql（root）**

```bash
runuser -u postgres -- psql -X -d security_workbench -P pager=off -c \
"SELECT
    COUNT(*) AS total_events,
    MIN(event_timestamp) AS oldest_event,
    MAX(event_timestamp) AS newest_event,
    COUNT(*) FILTER (WHERE event_timestamp > now() - interval '1 hour') AS last_1h,
    COUNT(*) FILTER (WHERE event_timestamp > now() - interval '24 hours') AS last_24h
 FROM incident.alert_events;"

echo
echo "=== EVENT COUNTS BY RULE LEVEL ==="
runuser -u postgres -- psql -X -d security_workbench -P pager=off -c \
"SELECT rule_level, COUNT(*) AS event_count
 FROM incident.alert_events
 GROUP BY rule_level
 ORDER BY rule_level DESC;"
```

```bash
runuser -u postgres -- psql -X -d security_workbench -P pager=off -c \
"SELECT
    date_trunc('minute', event_timestamp) AS minute,
    COUNT(*) AS events,
    COUNT(*) FILTER (WHERE rule_level >= 8) AS high_level_events,
    COUNT(*) FILTER (WHERE rule_level = 7) AS level_7_events,
    COUNT(*) FILTER (WHERE rule_level = 5) AS level_5_events
 FROM incident.alert_events
 WHERE event_timestamp > now() - interval '1 hour'
 GROUP BY 1
 ORDER BY 1 DESC
 LIMIT 15;"
```

```bash
runuser -u postgres -- psql -X -d security_workbench -P pager=off -c \
"SELECT
    date_bin(interval '5 minutes', event_timestamp, timestamptz '2000-01-01 00:00:00+00') AS time_bucket,
    COUNT(*) AS total,
    COUNT(*) FILTER (WHERE rule_level >= 8) AS level_8_plus,
    COUNT(*) FILTER (WHERE rule_level = 7) AS level_7,
    COUNT(*) FILTER (WHERE rule_level = 5) AS level_5,
    COUNT(*) FILTER (WHERE rule_level <= 4) AS level_4_or_lower
 FROM incident.alert_events
 WHERE event_timestamp > now() - interval '1 hour'
 GROUP BY 1
 ORDER BY 1 DESC;"
```

構築時は、04:40〜04:45 UTC の5分間に、レベル7のイベントが5,345件集中していました。

## 6.3　集中したイベントの正体

攻撃によるものか、復旧のときの影響かを、発生時刻とDBへの登録時刻で見分けます。

**実行先：LXC 109 postgresql（root）**

```bash
runuser -u postgres -- psql -X -d security_workbench -P pager=off -c \
"SELECT
    COUNT(*) AS events,
    MIN(event_timestamp) AS first_event_time,
    MAX(event_timestamp) AS last_event_time,
    MIN(ingested_at) AS first_ingested_at,
    MAX(ingested_at) AS last_ingested_at,
    ROUND(AVG(EXTRACT(EPOCH FROM (ingested_at - event_timestamp)))::numeric, 2) AS avg_delay_seconds,
    ROUND(MAX(EXTRACT(EPOCH FROM (ingested_at - event_timestamp)))::numeric, 2) AS max_delay_seconds
 FROM incident.alert_events
 WHERE event_timestamp >= timestamptz '2026-11-20 04:40:00+00'
   AND event_timestamp <  timestamptz '2026-11-20 04:45:00+00'
   AND rule_level = 7;"
```

```bash
runuser -u postgres -- psql -X -d security_workbench -P pager=off -c \
"SELECT
    date_trunc('minute', ingested_at) AS ingestion_minute,
    COUNT(*) AS events,
    MIN(ingested_at) AS first_ingested,
    MAX(ingested_at) AS last_ingested
 FROM incident.alert_events
 WHERE event_timestamp >= timestamptz '2026-11-20 04:40:00+00'
   AND event_timestamp <  timestamptz '2026-11-20 04:45:00+00'
   AND rule_level = 7
 GROUP BY 1
 ORDER BY 1;"
```

時刻の範囲は、自分の環境で集中が見つかった時間帯に置き換えます。

| 項目 | 構築時の結果 |
|---|---|
| 件数 | 5,345件 |
| イベントの発生時刻 | 04:43:57〜04:44:10 UTC（約12秒） |
| DBへの登録 | 04:44:48〜04:45:27 UTC |

発生も登録も、Collectorが復帰した時刻（04:44:17）の前後に集中しています。復帰の直後に今日の分をまとめて取り込んだことによるもので、攻撃の件数として扱わないことにしました。

## 6.4　取り込みの遅れの測定

集中した分を除いて、イベントが起きてからDBに登録されるまでの時間を測ります。

**実行先：LXC 109 postgresql（root）**

```bash
runuser -u postgres -- psql -X -d security_workbench -P pager=off -c \
"SELECT
    COUNT(*) AS events,
    ROUND(AVG(EXTRACT(EPOCH FROM (ingested_at - event_timestamp)))::numeric, 2) AS avg_delay_seconds,
    ROUND(
        percentile_cont(0.50) WITHIN GROUP (
            ORDER BY EXTRACT(EPOCH FROM (ingested_at - event_timestamp))
        )::numeric, 2
    ) AS p50_delay_seconds,
    ROUND(
        percentile_cont(0.95) WITHIN GROUP (
            ORDER BY EXTRACT(EPOCH FROM (ingested_at - event_timestamp))
        )::numeric, 2
    ) AS p95_delay_seconds,
    ROUND(MAX(EXTRACT(EPOCH FROM (ingested_at - event_timestamp)))::numeric, 2) AS max_delay_seconds
 FROM incident.alert_events
 WHERE ingested_at > now() - interval '1 hour'
   AND ingested_at - event_timestamp BETWEEN interval '0 seconds' AND interval '10 minutes'
   AND NOT (
       event_timestamp >= timestamptz '2026-11-20 04:40:00+00'
       AND event_timestamp < timestamptz '2026-11-20 04:45:00+00'
       AND rule_level = 7
   );"
```

構築時は、対象255件で平均170秒、中央値79秒、P95が541秒と、遅れが大きく出ました。Collectorが読み残しているのかを確かめます。

**実行先：security-core VM 220（root）**

```bash
echo "=== COLLECTOR STATE ==="
python3 - <<'PY'
import json
from pathlib import Path

p = Path("/var/lib/wazuh-collector/state.json")
state = json.loads(p.read_text())
print("state_inode:", state.get("inode"))
print("state_offset:", state.get("offset"))
PY

echo
echo "=== ACTIVE ALERT FILE ==="
stat -c 'inode=%i size=%s mtime=%y' \
  /var/ossec/logs/alerts/alerts.json

echo
echo "=== COLLECTOR STATUS ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts
```

構築時は、読み取り位置とファイルの大きさが一致していて（5,958,275バイト）、読み残しはありませんでした。遅れの原因は、読み残し以外にあることになります。

# 第7章　時刻の同期の確認

イベントの時刻（security-core）とDBへの登録の時刻（PostgreSQL）は、別のサーバーの時計で記録されます。時計がずれていると、遅れが大きく見えます。

## 7.1　security-core

**実行先：security-core VM 220（root）**

```bash
timedatectl status
```

構築時は、`System clock synchronized: yes`、`NTP service: active`（タイムゾーンはUTC）でした。

## 7.2　PostgreSQL（LXC 109）

**実行先：LXC 109 postgresql（root）**

```bash
timedatectl status
```

```bash
echo "=== TIME SYNC SERVICES ==="
systemctl is-active chrony.service systemd-timesyncd.service ntp.service 2>/dev/null

echo
echo "=== TIME SYNC STATUS ==="
systemctl list-units --type=service --all --no-legend \
  | grep -Ei 'chrony|timesyncd|ntp' \
  | sed -E 's/[[:space:]]+/ /g'
```

構築時は `System clock synchronized: yes` でしたが、`NTP service: inactive` で、LXCの中に時刻を合わせるサービスはありませんでした。LXCはProxmoxホストのカーネルの時計をそのまま使うため、ホスト側を確認します（タイムゾーンは Asia/Tokyo でしたが、DBの `timestamptz` はUTCで比べるため問題ありません）。

## 7.3　Proxmoxホスト

**実行先：Proxmoxホスト pve（root）**

```bash
echo "=== PVE TIME ==="
timedatectl status

echo
echo "=== TIME SYNC SERVICES ==="
systemctl is-active chrony.service systemd-timesyncd.service ntp.service 2>/dev/null

echo
echo "=== TIME SYNC PROCESSES ==="
ps -eo pid,comm,args \
  | grep -Ei '[c]hronyd|[n]tpd|[s]ystemd-timesyncd'
```

```bash
echo "=== CHRONY TRACKING ==="
chronyc tracking

echo
echo "=== CHRONY SOURCES ==="
chronyc sources -v
```

構築時は chrony で同期していて、時計のずれは1ミリ秒未満でした。数分の遅れは、時計のずれでは説明できません。

# 第8章　取り込みの遅れの再測定

## 8.1　集計用のロールの準備

DBの集計には、管理用のロール `dbadmin` を使うことにしました。読み取りだけの最小の権限を付けます。

**実行先：LXC 109 postgresql（root）**

```bash
echo "=== DBADMIN ROLE STATUS ==="
sudo -u postgres psql -X -d security_workbench -c "
SELECT
    rolname,
    rolsuper,
    rolcreatedb,
    rolcreaterole,
    rolcanlogin
FROM pg_roles
WHERE rolname = 'dbadmin';
"
```

```bash
sudo -u postgres psql -X -d security_workbench -c "
SELECT
    has_schema_privilege('dbadmin', 'incident', 'USAGE')
        AS schema_usage,
    has_table_privilege(
        'dbadmin',
        'incident.alert_events',
        'SELECT'
    ) AS alert_events_select;
"
```

構築時の `dbadmin` は、ログインできる通常のロール（スーパーユーザー・DB作成の権限なし）で、`incident` スキーマとテーブルの権限はありませんでした。参照だけを付けます。

```bash
sudo -u postgres psql -X -d security_workbench -v ON_ERROR_STOP=1 -c "
GRANT USAGE ON SCHEMA incident TO dbadmin;
GRANT SELECT ON TABLE incident.alert_events TO dbadmin;
"
```

```bash
sudo -u postgres psql -X -d security_workbench -c "
SELECT
    has_schema_privilege('dbadmin', 'incident', 'USAGE')
        AS schema_usage,
    has_table_privilege(
        'dbadmin', 'incident.alert_events', 'SELECT'
    ) AS can_select,
    has_table_privilege(
        'dbadmin', 'incident.alert_events', 'INSERT'
    ) AS can_insert,
    has_table_privilege(
        'dbadmin', 'incident.alert_events', 'UPDATE'
    ) AS can_update,
    has_table_privilege(
        'dbadmin', 'incident.alert_events', 'DELETE'
    ) AS can_delete;
"
```

`can_select` だけが `t`、ほかが `f` であることを確認します。

## 8.2　dbadminでの接続

`dbadmin` はOSのユーザーではないため `sudo -u dbadmin` では接続できません。localhost へのTCP接続（`scram-sha-256` の認証）で、パスワードを入力して接続します（パスワードは画面に表示されません。マニュアルにも記載しません）。

**実行先：LXC 109 postgresql（root）**

```bash
psql -X -h 127.0.0.1 -U dbadmin -d security_workbench -W -c "
SELECT
    current_user,
    current_database(),
    current_timestamp;
"
```

## 8.3　直近15分の遅れ

**実行先：LXC 109 postgresql（root）**

```bash
psql -X -h 127.0.0.1 -U dbadmin \
  -d security_workbench -W -c "
WITH recent AS (
    SELECT
        EXTRACT(EPOCH FROM (ingested_at - event_timestamp))
            AS delay_seconds
    FROM incident.alert_events
    WHERE ingested_at >= NOW() - INTERVAL '15 minutes'
)
SELECT
    COUNT(*) AS total_events,
    COUNT(*) FILTER (
        WHERE delay_seconds < 0
    ) AS negative_delay_events,
    ROUND(AVG(delay_seconds)::numeric, 2) AS avg_delay_seconds,
    ROUND(
        percentile_cont(0.50)
        WITHIN GROUP (ORDER BY delay_seconds)::numeric, 2
    ) AS p50_delay_seconds,
    ROUND(
        percentile_cont(0.95)
        WITHIN GROUP (ORDER BY delay_seconds)::numeric, 2
    ) AS p95_delay_seconds,
    ROUND(MAX(delay_seconds)::numeric, 2) AS max_delay_seconds
FROM recent;
"
```

構築時は、69件で平均1.28秒、中央値1.27秒、P95 1.79秒、最大1.84秒で、負の遅れ（時刻の逆転）は0件でした。

1分ごとにも確かめます。

```bash
psql -X -h 127.0.0.1 -U dbadmin \
  -d security_workbench -W -c "
SELECT
    date_trunc('minute', ingested_at) AS ingest_minute,
    COUNT(*) AS events,
    COUNT(*) FILTER (WHERE rule_level >= 8) AS high_level,
    ROUND(
        AVG(EXTRACT(EPOCH FROM (ingested_at - event_timestamp)))::numeric,
        2
    ) AS avg_delay_seconds,
    ROUND(
        MAX(EXTRACT(EPOCH FROM (ingested_at - event_timestamp)))::numeric,
        2
    ) AS max_delay_seconds
FROM incident.alert_events
WHERE ingested_at >= NOW() - INTERVAL '15 minutes'
GROUP BY 1
ORDER BY 1 DESC;
"
```

6.4で見えた大きな遅れは、復旧の直後に取り込みが集中したことによる一時的なもので、通常の運転では1〜2秒で登録されていることが分かりました。

# 第9章　多発していたイベントの原因と対処

## 9.1　ルールごとの件数

**実行先：LXC 109 postgresql（root）**

```bash
psql -X -P pager=off -h 127.0.0.1 -U dbadmin \
  -d security_workbench -W -c "
SELECT
    rule_id,
    rule_level,
    COUNT(*) AS event_count,
    MIN(event_timestamp) AS first_event,
    MAX(event_timestamp) AS last_event
FROM incident.alert_events
WHERE event_timestamp >= NOW() - INTERVAL '24 hours'
GROUP BY rule_id, rule_level
ORDER BY event_count DESC
LIMIT 20;
"
```

構築時は、ルール40704（レベル5、`Systemd: Service exited due to a failure.`）が11,905件で、ほかより大きく多くなっていました。

```bash
psql -X -P pager=off -h 127.0.0.1 -U dbadmin \
  -d security_workbench -W -c "
SELECT
    rule_id,
    rule_level,
    rule_description,
    rule_groups,
    agent_name,
    COUNT(*) AS event_count,
    MIN(event_timestamp) AS first_event,
    MAX(event_timestamp) AS last_event
FROM incident.alert_events
WHERE event_timestamp >= NOW() - INTERVAL '24 hours'
  AND rule_id IN (
      40704, 100103, 510, 2904, 23502,
      2902, 87203, 2901, 5501, 5502,
      5138, 550, 5407, 19011, 5901,
      5902, 100102
  )
GROUP BY
    rule_id,
    rule_level,
    rule_description,
    rule_groups,
    agent_name
ORDER BY event_count DESC
LIMIT 30;
"
```

`rule_id` の一覧は、自分の環境で9.1の上位に出たルールに置き換えます。

## 9.2　40704の内訳

**実行先：LXC 109 postgresql（root）**

```bash
psql -X -P pager=off -h 127.0.0.1 -U dbadmin \
  -d security_workbench -W -c "
SELECT
    agent_name,
    COUNT(*) AS total_events,
    MIN(event_timestamp) AS first_event,
    MAX(event_timestamp) AS last_event,
    MIN(ingested_at) AS first_ingested,
    MAX(ingested_at) AS last_ingested,
    COUNT(*) FILTER (
        WHERE ingested_at - event_timestamp > INTERVAL '5 minutes'
    ) AS delayed_over_5m,
    ROUND(
        AVG(EXTRACT(EPOCH FROM (ingested_at - event_timestamp)))::numeric,
        2
    ) AS avg_delay_seconds
FROM incident.alert_events
WHERE rule_id = 40704
  AND ingested_at >= NOW() - INTERVAL '24 hours'
GROUP BY agent_name
ORDER BY total_events DESC;
"
```

| ホスト | 件数（構築時） | 内容 |
|---|---:|---|
| security-core | 11,268 | 第4章の取り込みで、約16時間分がまとめて登録されたもの |
| postgresql | 225 | 今も約1分ごとに発生 |
| lxc-prometheus | 210 | 今も約1分ごとに発生 |
| lxc-grafana | 206 | 今も約1分ごとに発生 |

```bash
psql -X -P pager=off -h 127.0.0.1 -U dbadmin \
  -d security_workbench -W -c "
SELECT
    agent_name,
    COUNT(*) AS events,
    ROUND(
        percentile_cont(0.50)
        WITHIN GROUP (
            ORDER BY EXTRACT(EPOCH FROM (ingested_at - event_timestamp))
        )::numeric, 2
    ) AS p50_delay_seconds,
    ROUND(
        percentile_cont(0.95)
        WITHIN GROUP (
            ORDER BY EXTRACT(EPOCH FROM (ingested_at - event_timestamp))
        )::numeric, 2
    ) AS p95_delay_seconds,
    ROUND(
        MAX(EXTRACT(EPOCH FROM (ingested_at - event_timestamp)))::numeric,
        2
    ) AS max_delay_seconds,
    MAX(event_timestamp) AS last_event
FROM incident.alert_events
WHERE rule_id = 40704
  AND ingested_at >= NOW() - INTERVAL '15 minutes'
GROUP BY agent_name
ORDER BY events DESC;
"
```

直近15分では、3台とも遅れは2秒以内でした。取り込みは正常で、3台で実際にサービスの異常終了が起き続けていることになります。

## 9.3　失敗しているサービスの特定

DBにはログの全文（`full_log`）を保存していないため、Wazuhのアラートのファイルから、失敗したサービスの名前だけを取り出します。

**実行先：security-core VM 220（root）**

```bash
grep -h '"rule":{"level":5,"description":"Systemd: Service exited due to a failure."' \
  /var/ossec/logs/alerts/2026/Nov/ossec-alerts-20.json \
  | tail -n 20 \
  | python3 -c '
import sys,json,re
pattern = re.compile(r"[A-Za-z0-9_.@:-]+\.service")
for line in sys.stdin:
    try:
        x=json.loads(line)
        raw=x.get("full_log") or ""
        units=sorted(set(pattern.findall(raw)))
        print(json.dumps({
            "timestamp": x.get("timestamp"),
            "agent": x.get("agent",{}).get("name"),
            "service_units": units,
            "full_log_present": bool(raw)
        }, ensure_ascii=False))
    except Exception:
        print("JSON_PARSE_ERROR")
'
```

ファイル名の日付（`ossec-alerts-20.json`）は、調べる日に合わせます。構築時は、どれも `prometheus-node-exporter-ipmitool-sensor.service` でした。第8部で Node Exporter のパッケージを入れたときに一緒に入った、IPMIセンサーの値を集める補助のサービスです。

## 9.4　原因の確認

**実行先：LXC 105 lxc-grafana（root）**

```bash
echo "=== SERVICE STATE ==="
systemctl show prometheus-node-exporter-ipmitool-sensor.service \
  -p LoadState \
  -p ActiveState \
  -p SubState \
  -p Result \
  -p ExecMainCode \
  -p ExecMainStatus \
  -p NRestarts

echo
echo "=== RECENT SERVICE LOGS ==="
journalctl -u prometheus-node-exporter-ipmitool-sensor.service \
  --since "30 minutes ago" \
  --no-pager -n 30 -o short-iso
```

ログには、次のエラーがくり返し出ていました（postgresql・lxc-prometheus も同じでした）。

```text
Could not open device at /dev/ipmi0 or /dev/ipmi/0 or /dev/ipmidev/0:
No such file or directory
```

```bash
echo "=== UNIT DEFINITION ==="
systemctl cat prometheus-node-exporter-ipmitool-sensor.service

echo
echo "=== DEPENDENCY RELATIONSHIPS ==="
systemctl show prometheus-node-exporter-ipmitool-sensor.service \
  -p Requires -p Wants -p Requisite \
  -p Before -p After -p PartOf -p WantedBy \
  -p RequiredBy -p ConsistsOf
```

```bash
echo "=== TIMER DEFINITION ==="
systemctl cat prometheus-node-exporter-ipmitool-sensor.timer

echo
echo "=== TIMER STATE ==="
systemctl show prometheus-node-exporter-ipmitool-sensor.timer \
  -p LoadState -p ActiveState -p SubState \
  -p Triggers -p TriggeredBy -p OnCalendar -p OnUnitActiveSec

echo
echo "=== NODE EXPORTER STATE ==="
systemctl show prometheus-node-exporter.service \
  -p LoadState -p ActiveState -p SubState -p MainPID
```

```bash
echo "=== IPMI SYSFS ==="
ls -la /sys/class/ipmi/

echo
echo "=== IPMI DEVICE NODES ==="
for p in /dev/ipmi0 /dev/ipmi/0 /dev/ipmidev/0; do
  if [ -e "$p" ]; then
    ls -l "$p"
  else
    echo "$p : absent"
  fi
done

echo
echo "=== IPMI DEVICE REFERENCES ==="
find /sys/class/ipmi -maxdepth 2 -type l -printf '%p -> %l\n' 2>/dev/null
```

| 項目 | 構築時の状態 |
|---|---|
| `/sys/class/ipmi/ipmi0` | ある（LXCからホストの情報が見える） |
| `/dev/ipmi0` など | ない（LXCにはデバイスが渡されていない） |
| IPMI収集のタイマー | 1分ごとに実行 |
| Node Exporter本体 | 正常 |

タイマーの起動条件（`ConditionDirectoryNotEmpty=/sys/class/ipmi`）は満たされるため、1分ごとに収集が動き、デバイスを開けずに失敗していました。その失敗を Wazuh が40704として検知していました。

## 9.5　IPMI収集のタイマーの停止

Node Exporter本体・Prometheusの設定・転送は変えず、LXCの3台（lxc-grafana・postgresql・lxc-prometheus）で、IPMI収集のタイマーだけを止めて自動起動を無効にします。1台ずつ実行して確認します。

**実行先：LXC 105 lxc-grafana、LXC 109 postgresql、LXC 103 lxc-prometheus（それぞれ root）**

```bash
systemctl disable --now prometheus-node-exporter-ipmitool-sensor.timer
```

```bash
echo "=== IPMI TIMER ==="
systemctl show prometheus-node-exporter-ipmitool-sensor.timer \
  -p LoadState -p ActiveState -p UnitFileState

echo
echo "=== NODE EXPORTER ==="
systemctl show prometheus-node-exporter.service \
  -p LoadState -p ActiveState -p SubState -p MainPID
```

構築時は3台とも、タイマーが `inactive`・`disabled`、Node Exporterが `active` / `running` でした。

> 構築時に対処したのは、40704が続いていたLXCの3台だけです。Proxmoxホスト（`pve`、構築時は1件）と security-core（11,268件は過去の分の取り込み）は対象にしていません。

# 第9部のまとめ

## 原因と対処

| 原因 | 対処 |
|---|---|
| 新しい `alerts.json` に Collector 用の読み取りACLがなかった | `setfacl -m u:wazuh-collector:r--` で追加（1.3） |
| 保存したinodeのファイルが圧縮されてなくなり、探索も root 専用の隠しディレクトリで止まった | 19日分を既存の処理で取り込み、状態ファイルを今の `alerts.json` に進めた（第4章） |

## 変更したもの

| 対象 | 変更 |
|---|---|
| `/var/ossec/logs/alerts/alerts.json`（20日分） | Collector の読み取りACL |
| `/var/ossec/logs/alerts/2026/Nov/ossec-alerts-19.json.gz` | Collector の読み取りACL |
| `/var/lib/wazuh-collector/state.json` | 今の `alerts.json` のinode・位置 `0` |
| DB `incident.alert_events` | 19日分のアラート（重複は飛ばす） |

Collectorのソース、systemdの設定、Wazuhのログ自体は変更していません。バックアップは `/root/wazuh-collector-recovery/collector.py.before-recovery` にあります。

## 点検で分かったこと（第5章〜第9章）

| 項目 | 結果 |
|---|---|
| VictoriaMetrics・5台のメトリクス | 正常 |
| Wazuh Manager・API | 正常（APIは認証を要求。証明書は自己署名で、SANは `localhost` だけ） |
| 復旧の直後の大量のイベント | 過去の分の取り込みによるもの（攻撃ではない） |
| 時刻の同期 | 正常（ずれは1ミリ秒未満） |
| 通常の取り込みの遅れ | 1〜2秒 |
| ルール40704の多発 | LXCのIPMI収集タイマーの失敗。3台でタイマーを停止 |

DBの集計用に、`dbadmin` に `incident` スキーマの利用と `incident.alert_events` の参照の権限を付けました。

## 残った課題

- **【リスク・未対応】** 日付が変わると、Wazuh が新しい `alerts.json` を作ります。新しいファイルに Collector の読み取りACLが付かなければ、同じ停止がまた起きます。毎日のローテーションへの恒久的な対策（既定のACLなど）は行っていません。停止したときは、第1章（ACLの追加）と、必要に応じて第2章〜第4章（取りこぼした分の取り込み）の手順で復旧します。Collectorの状態（`NRestarts` の増加や `PermissionError`）を毎日確認してください。
- **【リスク・未対応】** `alerts` ディレクトリの中の root 専用の隠しディレクトリ（`.acl-inheritance-test.bkv8vd`）は削除しておらず、残ったままです。Collectorが再びディレクトリを探索すると（保存したinodeが今の `alerts.json` でないとき）、同じ権限エラーで止まります。
- Collectorは今も圧縮ファイル（`.json.gz`）を探索の対象にしません。止まっている間に旧ファイルが圧縮されたときは、第2章〜第4章と同じ手順で復旧します。
