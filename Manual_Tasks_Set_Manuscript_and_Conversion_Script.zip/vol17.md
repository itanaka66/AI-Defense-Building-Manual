---
title: "AI自律型サイバー防御システム 構築マニュアル 前編"
subtitle: "第17部　AI Defense Managerのサービス化と起動順序"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」前編の第17部です。第16部で Wazuh のアラートを AI の分析につなぎました。ここでは次の3つを行い、VM や Proxmox を再起動しても連携が動くようにします。

1. AI Defense Manager を systemd のサービスにする（`127.0.0.1:8000` だけで待ち受け）
2. Relay（VM 220）と AI Defense Manager（VM 230）を自動起動にする
3. Proxmox で、VM 220 を先に、VM 230 を後に起動するように順番を決める

## 本書の表記

- コマンドやプログラムは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 実行先は、各手順の「実行先」に示します。
  - **VM 230**：ai-defense-manager（root）
  - **VM 220**：security-core（root）
  - **pve**：Proxmox のホスト（root）

# 第1章　ファイルの権限をそろえる

> **実行先：VM 230**

第16部で作った3つのファイルは `root:root` の `644` でした。ほかのアプリのファイルと同じ `root:ai-defense` の `640` にそろえます。

```bash
chown root:ai-defense \
  /opt/ai-defense-manager/app/api/wazuh.py \
  /opt/ai-defense-manager/app/schemas/wazuh.py \
  /opt/ai-defense-manager/app/services/wazuh_relay.py \
&& chmod 640 \
  /opt/ai-defense-manager/app/api/wazuh.py \
  /opt/ai-defense-manager/app/schemas/wazuh.py \
  /opt/ai-defense-manager/app/services/wazuh_relay.py \
&& stat -c '%A %U:%G %n' \
  /opt/ai-defense-manager/app/api/wazuh.py \
  /opt/ai-defense-manager/app/schemas/wazuh.py \
  /opt/ai-defense-manager/app/services/wazuh_relay.py
```

サービスにする前に、実行ユーザー `ai-defense` でアプリ全体を読み込めることを確かめます（サーバーは起動しません）。

```bash
cd /opt/ai-defense-manager && runuser -u ai-defense -- ./venv/bin/python - <<'PY'
from app.main import app
from app.core.config import settings

print("APP_IMPORT_OK")
print("APP_NAME:", settings.app_name)
print("API_HOST:", settings.api_host)
print("API_PORT:", settings.api_port)
print("OLLAMA_URL:", settings.ollama_base_url)
print("OPENAPI_PATH_COUNT:", len(app.openapi()["paths"]))

for path in sorted(app.openapi()["paths"]):
    print("ROUTE:", path)

print("SERVICE_USER_IMPORT_TEST_OK")
PY
```

構築時は、`/health`、`/api/v1/analysis`、`/api/v1/wazuh/events`、`/api/v1/wazuh/analyze` の4つが出ました。

# 第2章　systemdのサービス

## 2.1　ユニットファイル

> **実行先：VM 230**

同じ名前のユニットがないことを確かめます。

```bash
systemctl list-unit-files --type=service | grep -E 'ai-defense-manager|ai-defense' || true
```

第14部の Relay と同じ考え方で、強く制限したサービスにします。

- 実行ユーザーは `ai-defense`
- 待ち受けは `127.0.0.1:8000` だけ（外には公開しない）
- ファイルシステムは原則として読み取り専用（`ProtectSystem=strict`）
- 特権を持たない。カーネルやデバイスに触れない
- メモリの上限は 1GiB。異常に終わったときだけ自動で再起動する

```bash
cat > /etc/systemd/system/ai-defense-manager.service <<'UNIT'
[Unit]
Description=AI Defense Manager API
After=network.target
Wants=network.target

[Service]
Type=simple
User=ai-defense
Group=ai-defense
WorkingDirectory=/opt/ai-defense-manager

ExecStart=/opt/ai-defense-manager/venv/bin/uvicorn app.main:app --host 127.0.0.1 --port 8000
Restart=on-failure
RestartSec=5
UMask=0077

NoNewPrivileges=yes
CapabilityBoundingSet=
AmbientCapabilities=
PrivateTmp=yes
PrivateDevices=yes
ProtectSystem=strict
ProtectHome=yes
ProtectKernelTunables=yes
ProtectKernelModules=yes
ProtectKernelLogs=yes
ProtectControlGroups=yes
ProtectClock=yes
ProtectHostname=yes
ProtectProc=invisible
ProcSubset=pid
RestrictSUIDSGID=yes
LockPersonality=yes
MemoryDenyWriteExecute=yes
RestrictRealtime=yes
SystemCallArchitectures=native
RestrictAddressFamilies=AF_INET

MemoryMax=1G
TasksMax=64
LimitNOFILE=4096

[Install]
WantedBy=multi-user.target
UNIT
```

貼り付けで末尾が乱れて見えることがあるので、最後まで書けたかを確かめます。

```bash
tail -n 15 /etc/systemd/system/ai-defense-manager.service
```

```bash
systemd-analyze verify /etc/systemd/system/ai-defense-manager.service
```

## 2.2　登録

```bash
systemctl daemon-reload && systemctl show ai-defense-manager.service -p LoadState -p ActiveState -p UnitFileState -p User -p Group -p ExecStart
```

`LoadState=loaded`、`ActiveState=inactive`（まだ止まっている）、`UnitFileState=disabled`、`User=ai-defense` となれば登録できています。

## 2.3　起動

```bash
systemctl start ai-defense-manager.service && systemctl status ai-defense-manager.service --no-pager -l
```

`active (running)` になれば起動できています。

```bash
ss -lntp '( sport = :8000 )' && curl --fail --silent --show-error --max-time 5 http://127.0.0.1:8000/health
```

構築時は、`127.0.0.1:8000` だけで待ち受け、`{"status":"ok","service":"ai-defense-manager","version":"0.1.0"}` が返りました。

# 第3章　HTTPでの確認

> **実行先：VM 230**（`/opt/ai-defense-manager` で実行）

## 3.1　アラートの取得

AI の分析はせず、Wazuh のアラートを5件取ります。

```bash
curl --fail --silent --show-error --max-time 20 \
  'http://127.0.0.1:8000/api/v1/wazuh/events?limit=5&since_minutes=60' \
  | ./venv/bin/python -c 'import json,sys; data=json.load(sys.stdin); print("EVENT_COUNT:",len(data)); [print({"severity":e["severity"],"rule_id":e["rule_id"],"agent_name":e["agent_name"],"event_category":e["event_category"],"event_summary":e["event_summary"]}) for e in data]; print("WAZUH_HTTP_API_OK")'
```

構築時は、Proxmox VE の認証成功が2件、ユーザー（グループ）の削除が1件、PAM のログインセッションの開始と終了が各1件、の5件が返りました。

## 3.2　AIの分析

最大5件を `qwen3:8b` に渡します。AI は分析と提案だけを行い、防御の操作は実行しません。

```bash
curl --fail --silent --show-error --max-time 180 \
  -X POST 'http://127.0.0.1:8000/api/v1/wazuh/analyze' \
  -H 'Content-Type: application/json' \
  -d '{
    "limit": 5,
    "since_minutes": 60,
    "analysis_context": "直近のWazuhセキュリティイベントを分析してください。防御操作は提案のみとし、実行しないでください。",
    "requested_language": "ja"
  }' \
  | ./venv/bin/python -c 'import json,sys; d=json.load(sys.stdin); print("severity:",d.get("severity")); print("confidence:",d.get("confidence")); print("recommended_action:",d.get("recommended_action")); print("requires_human_approval:",d.get("requires_human_approval")); print("evidence_event_count:",len(d.get("evidence_event_ids",[]))); print("target_ip:",d.get("target_ip")); print("ttl_seconds:",d.get("ttl_seconds")); print("summary:",d.get("summary")); print("reasoning:",d.get("reasoning")); print("WAZUH_HTTP_AI_ANALYSIS_OK")'
```

構築時は `severity: info`、`confidence: 0.8`、`recommended_action: no_action`、`evidence_event_count: 5` が返りました。

ここまでで、次の流れがつながりました。

```text
Wazuh Indexer（VM 220）
  → Relay（VM 220, HTTPS + Bearer）
  → AI Defense Manager（VM 230, 127.0.0.1:8000）
  → Ollama qwen3:8b（VM 101）
  → 防御の提案（JSON、実行はしない）
```

# 第4章　自動起動

## 4.1　今の状態

> **実行先：VM 230**

```bash
systemctl is-enabled ai-defense-manager.service; systemctl is-active ai-defense-manager.service; systemctl show ai-defense-manager.service -p After -p Wants -p Restart -p RestartSec -p User -p Group
```

> **実行先：VM 220**

```bash
systemctl is-enabled ai-defense-relay.service; systemctl is-active ai-defense-relay.service; systemctl show ai-defense-relay.service -p After -p Wants -p Restart -p RestartSec -p User -p Group
```

構築時は、どちらも `active` で `disabled`（自動起動しない）でした。Relay は `After=wazuh-indexer.service` により、Indexer の後に起動します。

## 4.2　有効にする

> **実行先：VM 220**

```bash
systemctl enable ai-defense-relay.service && systemctl is-enabled ai-defense-relay.service
```

> **実行先：VM 230**

```bash
systemctl enable ai-defense-manager.service && systemctl is-enabled ai-defense-manager.service
```

どちらも `enabled` と表示されれば完了です。動いているサービスには影響しません。

# 第5章　Proxmoxの起動順序

VM 220（Wazuh と Relay）が、VM 230（AI Defense Manager）より先に起動するようにします。

## 5.1　今の設定

> **実行先：pve**

```bash
for id in 220 230; do
  echo "===== VM $id ====="
  qm status "$id"
  qm config "$id" | grep -E '^(onboot|startup):' || echo "onboot/startup not configured"
done
```

構築時は、VM 220 は `onboot: 1`（自動起動）で順番は未設定、VM 230 は自動起動も順番も未設定でした。

## 5.2　順番を決める

動いている VM は止めません。

- VM 220：自動起動、順番1、起動してから次の VM まで120秒待つ
- VM 230：自動起動、順番2

```bash
qm set 220 --onboot 1 --startup order=1,up=120
```

```bash
qm set 230 --onboot 1 --startup order=2
```

```bash
for id in 220 230; do
  echo "===== VM $id ====="
  qm status "$id"
  qm config "$id" | grep -E '^(onboot|startup):'
done
```

構築時の結果は次のとおりです。

| 項目 | VM 220 security-core | VM 230 ai-defense-manager |
|---|---|---|
| `onboot` | `1` | `1` |
| `startup` | `order=1,up=120` | `order=2` |

# おわりに

第17部で、次の状態になりました。

| 対象 | 状態 |
|---|---|
| `ai-defense-manager.service`（VM 230） | 稼働中・自動起動、`127.0.0.1:8000` |
| `ai-defense-relay.service`（VM 220） | 稼働中・自動起動、`192.168.0.220:8765` |
| Proxmox の起動順 | VM 220 → 120秒待つ → VM 230 |

次の部では、AI の分析の結果を記録として残す仕組みを作ります。
