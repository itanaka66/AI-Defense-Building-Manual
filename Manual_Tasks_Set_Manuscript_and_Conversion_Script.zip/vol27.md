---
title: "AI自律型サイバー防御システム 構築マニュアル 中編"
subtitle: "第27部　監査ログが保存されていることを確かめる"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」中編の第27部です。第25部で監査ログの出力先を設定し、第26部でリクエストの本文を記録しないようにしました。ここでは、設定は変えずに**読み取りだけで**、次のことを確かめます。

1. 監査ログのインデックス（`security-auditlog-YYYY.MM.dd`）ができ、イベントが保存されている
2. 保存されたイベントに、リクエストの本文や認証のヘッダーが入っていない
3. 監査の設定が `.opendistro_security` に保存され、再起動のあとも読み込まれる作りである

本文やヘッダーの「値」は表示せず、項目の名前・件数・長さ・形だけを調べます。

## 本書の表記

- コマンドやプログラムは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 実行先は **security-core VM 220（root）** です。
- インデックスの名前 `security-auditlog-2026.11.21` は構築した日のものです。自分の環境の日付に置き換えてください。

# 第1章　保存先ができているか

## 1.1　起動のログ

```bash
journalctl -u wazuh-indexer -b --no-pager | grep -Ei 'audit|sink|message routing|default storage' | tail -n 60
```

構築時は何も出ませんでした。ログがないだけでは、出力先が作られていないとは言えません。

## 1.2　監査ログのインデックス

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/_cat/indices?format=json&h=index,health,status,docs.count,store.size' | python3 -c 'import json,sys; d=json.load(sys.stdin); rows=[x for x in d if "audit" in x.get("index","").lower()]; print("AUDIT_INDEX_COUNT:",len(rows)); [print(x) for x in rows]'
```

構築時は `security-auditlog-2026.11.21` があり、24件・103.7KB が保存されていました。監査ログは Indexer の中に保存されています。

## 1.3　yellowの理由

インデックスの状態は `yellow` でした。シャードを確かめます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/_cat/shards/security-auditlog-2026.11.21?format=json&h=index,shard,prirep,state,node,unassigned.reason'
```

| シャード | 状態 |
|---|---|
| プライマリ（p） | `STARTED`（node-1） |
| レプリカ（r） | `UNASSIGNED`（`INDEX_CREATED`） |

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/_cluster/health?pretty'
```

ノードは1つ、プライマリのシャード36個はすべて動いており、割り当てられていないのはこのインデックスのレプリカ1つだけでした。ノードが1つなので、レプリカを置く場所がないためです。保存の失敗ではありません。レプリカの数は変えず、`yellow` のままにします（不足情報メモ 27-A）。

# 第2章　何が保存されているか

## 2.1　1件の見本

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search?size=1&filter_path=hits.hits._source' | python3 -c 'import json,sys; d=json.load(sys.stdin); h=d.get("hits",{}).get("hits",[]); print("SAMPLE_COUNT:",len(h)); s=h[0].get("_source",{}) if h else {}; print("TOP_LEVEL_FIELDS:",sorted(s)); print("BODY_FIELD_NAMES:",sorted(k for k in s if any(x in k.lower() for x in ("body","payload","request"))))'
```

この1件には本文の項目はなく、REST のメソッド・パス・送信元・ユーザーなどの情報が保存されていました。ヘッダーと URL のパラメーターは、名前だけを見ます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search?size=1&filter_path=hits.hits._source.audit_rest_request_headers,hits.hits._source.audit_rest_request_params' | python3 -c 'import json,sys; d=json.load(sys.stdin); h=d.get("hits",{}).get("hits",[]); s=h[0].get("_source",{}) if h else {}; headers=s.get("audit_rest_request_headers"); params=s.get("audit_rest_request_params"); print("HEADER_FIELD_TYPE:",type(headers).__name__); print("HEADER_NAMES:",sorted(headers.keys()) if isinstance(headers,dict) else "not a map"); print("PARAM_FIELD_TYPE:",type(params).__name__); print("PARAM_NAMES:",sorted(params.keys()) if isinstance(params,dict) else "not a map")'
```

ヘッダーは `Accept`・`Host`・`User-Agent`、パラメーターは `filter_path` だけで、`Authorization` や `Cookie` はありませんでした。

## 2.2　すべてのイベント

本文らしい項目、認証のヘッダー、ヘッダーとパラメーターの名前、カテゴリーを数えます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search?size=100&filter_path=hits.hits._source' | python3 -c 'import json,sys,collections; d=json.load(sys.stdin); hs=d.get("hits",{}).get("hits",[]); body=[]; sensitive=[]; params=collections.Counter(); cats=collections.Counter(); headers=collections.Counter(); [cats.update([h.get("_source",{}).get("audit_category","UNKNOWN")]) for h in hs]; 
for h in hs:
 s=h.get("_source",{}); 
 for k in s:
  if any(x in k.lower() for x in ("request_body","requestbody","payload")): body.append(k)
 hd=s.get("audit_rest_request_headers",{}); 
 if isinstance(hd,dict):
  for k in hd:
   headers[k.lower()]+=1
   if k.lower() in ("authorization","proxy-authorization","cookie","set-cookie"): sensitive.append(k)
 p=s.get("audit_rest_request_params",{})
 if isinstance(p,dict): params.update(p.keys())
print("EVENTS_SCANNED:",len(hs)); print("BODY_FIELD_EVENT_COUNT:",len(body)); print("SENSITIVE_HEADER_EVENT_COUNT:",len(sensitive)); print("HEADER_NAME_COUNTS:",dict(headers)); print("PARAMETER_NAME_COUNTS:",dict(params)); print("AUDIT_CATEGORY_COUNTS:",dict(cats))'
```

構築時は86件を調べ、認証のヘッダーは0件でしたが、**本文らしい項目が15件**ありました。この15件を詳しく調べます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search?size=100&filter_path=hits.hits._source' | python3 -c 'import json,sys; d=json.load(sys.stdin); hs=d.get("hits",{}).get("hits",[]); n=0
for h in hs:
 s=h.get("_source",{}); ks=[k for k in s if any(x in k.lower() for x in ("request_body","requestbody","payload"))]
 if ks:
  n+=1
  print("EVENT",n,"TIMESTAMP:",s.get("@timestamp"),"CATEGORY:",s.get("audit_category"),"MATCHING_FIELD_NAMES:",ks)
print("MATCHING_EVENTS:",n,"SCANNED:",len(hs))'
```

15件とも、カテゴリーは `COMPLIANCE_INTERNAL_CONFIG_READ`（内部の設定の読み取り）、項目は `audit_request_body` でした。

## 2.3　audit_request_bodyの正体

値は表示せず、形だけを調べます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search?size=100&filter_path=hits.hits._source' | python3 -c 'import json,sys; d=json.load(sys.stdin); hs=d.get("hits",{}).get("hits",[]); n=0
for h in hs:
 s=h.get("_source",{})
 if "audit_request_body" in s:
  v=s["audit_request_body"]; n+=1
  empty=(v is None or v=="" or v=={} or v==[])
  length=len(v) if isinstance(v,(str,dict,list)) else None
  print("EVENT",n,"TIMESTAMP:",s.get("@timestamp"),"TYPE:",type(v).__name__,"IS_NULL:",v is None,"IS_EMPTY:",empty,"LENGTH:",length)
print("BODY_FIELD_EVENTS:",n)'
```

15件とも、25文字の文字列でした。内容が同じかを、ハッシュで比べます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search?size=100&filter_path=hits.hits._source' | python3 -c 'import json,sys,hashlib,collections; d=json.load(sys.stdin); vals=[h.get("_source",{}).get("audit_request_body") for h in d.get("hits",{}).get("hits",[]) if "audit_request_body" in h.get("_source",{})]; hashes=collections.Counter(hashlib.sha256(v.encode()).hexdigest() for v in vals if isinstance(v,str)); print("BODY_FIELD_COUNT:",len(vals)); print("UNIQUE_VALUE_COUNT:",len(hashes)); print("VALUE_FREQUENCIES:",sorted(hashes.values(),reverse=True)); print("ALL_VALUES_IDENTICAL:",len(hashes)==1 and len(vals)>0)'
```

15件すべて同じ値でした。文字の種類と形を調べます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search?size=100&filter_path=hits.hits._source' | python3 -c 'import json,sys; d=json.load(sys.stdin); vals=[h["_source"]["audit_request_body"] for h in d.get("hits",{}).get("hits",[]) if "audit_request_body" in h.get("_source",{})]; v=vals[0] if vals else ""; print("LENGTH:",len(v)); print("ASCII_ONLY:",v.isascii()); print("ALPHANUMERIC_ONLY:",v.isalnum()); print("JSON_PARSEABLE:",end=" "); 
try: json.loads(v); print("yes")
except Exception: print("no")
print("HAS_WHITESPACE:",any(c.isspace() for c in v)); print("HAS_BRACES:",any(c in "{}[]" for c in v)); print("HAS_COLON:",":" in v); print("HAS_QUOTES:",any(c in chr(34)+chr(39) for c in v))'
```

JSON として読めました。キーの名前と型だけを見ます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search?size=100&filter_path=hits.hits._source' | python3 -c 'import json,sys; d=json.load(sys.stdin); vals=[h["_source"]["audit_request_body"] for h in d.get("hits",{}).get("hits",[]) if "audit_request_body" in h.get("_source",{})]; v=json.loads(vals[0]) if vals else None; print("PARSED_TYPE:",type(v).__name__); print("TOP_LEVEL_KEYS:",sorted(v.keys()) if isinstance(v,dict) else "not_object"); 
for k,x in (v.items() if isinstance(v,dict) else []): print("FIELD:",k,"TYPE:",type(x).__name__,"LENGTH:",len(x) if isinstance(x,(str,dict,list)) else "n/a","NESTED_KEYS:",sorted(x.keys()) if isinstance(x,dict) else "n/a")'
```

形は次のとおりでした（値は伏せています）。

```text
{"field_names":[...]}
```

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search?size=100&filter_path=hits.hits._source' | python3 -c 'import json,sys; d=json.load(sys.stdin); vals=[json.loads(h["_source"]["audit_request_body"]) for h in d.get("hits",{}).get("hits",[]) if "audit_request_body" in h.get("_source",{})]; x=vals[0].get("field_names",[]) if vals else []; print("FIELD_NAMES_COUNT:",len(x)); print("ELEMENT_TYPES:",[type(v).__name__ for v in x]); print("ELEMENT_LENGTHS:",[len(v) if isinstance(v,(str,dict,list)) else None for v in x]); print("ALL_15_EVENTS_SAME_STRUCTURE:",all(v==vals[0] for v in vals))'
```

`field_names` の配列には5文字の文字列が1つだけで、15件とも同じ形でした。これは HTTP のリクエストの本文ではなく、内部の設定を読んだときの項目名の情報と考えられます。

## 2.4　カテゴリーごとの件数

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search?size=500&sort=@timestamp:desc&filter_path=hits.hits._source' | python3 -c 'import json,sys,collections; d=json.load(sys.stdin); hits=d.get("hits",{}).get("hits",[]); counts=collections.Counter(); body_counts=collections.Counter(); samples=collections.Counter(); 
for h in hits:
 s=h.get("_source",{}); c=s.get("audit_category","UNKNOWN"); counts[c]+=1
 if "audit_request_body" in s: body_counts[c]+=1
print("SCANNED_EVENTS:",len(hits)); print("CATEGORY_COUNTS:",dict(sorted(counts.items()))); print("BODY_FIELD_COUNTS_BY_CATEGORY:",dict(sorted(body_counts.items()))); print("BODY_FIELD_TOTAL:",sum(body_counts.values())); print("NON_COMPLIANCE_BODY_EVENTS:",sum(n for c,n in body_counts.items() if not c.startswith("COMPLIANCE_")))'
```

| カテゴリー | 件数 | `audit_request_body` あり |
|---|---:|---:|
| `COMPLIANCE_INTERNAL_CONFIG_READ` | 15 | 15 |
| `COMPLIANCE_INTERNAL_CONFIG_WRITE` | 1 | 0 |
| `FAILED_LOGIN` | 8 | 0 |
| `INDEX_EVENT` | 62 | 0 |

ふつうのイベント（`FAILED_LOGIN`・`INDEX_EVENT`）には本文の項目はありません。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search?size=500&sort=@timestamp:asc&filter_path=hits.hits._source.@timestamp,hits.hits._source.audit_category,hits.hits._source.audit_request_body' | python3 -c 'import json,sys,collections; d=json.load(sys.stdin); rows=[h["_source"] for h in d.get("hits",{}).get("hits",[]) if "audit_request_body" in h.get("_source",{})]; print("EVENT_COUNT:",len(rows)); print("FIRST_TIMESTAMP:",rows[0].get("@timestamp") if rows else "none"); print("LAST_TIMESTAMP:",rows[-1].get("@timestamp") if rows else "none"); print("CATEGORIES:",dict(collections.Counter(r.get("audit_category","UNKNOWN") for r in rows)))'
```

15件は 2026-11-21 08:27:45〜08:56:05（UTC）のものでした。

# 第3章　設定が残る作りか

## 3.1　今の設定

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/_plugins/_security/api/audit' | python3 -c 'import json,sys; d=json.load(sys.stdin); c=d.get("config",{}); a=c.get("audit",{}); print("AUDIT_ENABLED:",c.get("enabled")); print("LOG_REQUEST_BODY:",a.get("log_request_body")); print("EXCLUDE_SENSITIVE_HEADERS:",a.get("exclude_sensitive_headers")); print("ENABLE_REST:",a.get("enable_rest")); print("ENABLE_TRANSPORT:",a.get("enable_transport")); print("DISABLED_REST_CATEGORIES:",a.get("disabled_rest_categories")); print("DISABLED_TRANSPORT_CATEGORIES:",a.get("disabled_transport_categories"))'
```

`LOG_REQUEST_BODY: False` のままでした。

## 3.2　設定の文書

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/.opendistro_security/_doc/audit?filter_path=_index,_id,_version,_seq_no,_primary_term,found'
```

構築時は `found: true`、`_version: 2` でした。PATCH による変更は、文書として保存されています。

## 3.3　起動のときの読み込み

```bash
 /usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c org.opensearch.security.configuration.ConfigurationRepository | grep -n -A45 -B12 'setupAuditConfigurationIfAny'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c org.opensearch.security.configuration.ConfigurationLoaderSecurity7 | grep -n -A55 -B15 'isAuditConfigDocPresentInIndex'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c 'org.opensearch.security.configuration.ConfigurationLoaderSecurity7$1' | grep -n -A35 -B15 -E 'AUDIT|isAuditConfigDocPresentInIndex|AtomicBoolean|set:|noData|success'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c org.opensearch.security.configuration.ConfigurationRepository | grep -n -A35 -B15 -E 'auditLog\.setConfig|AuditConfig|onChange|executeConfigurationInitialization'
```

1. 設定は `.opendistro_security` の文書 `audit` に保存される
2. 起動のとき `ConfigurationLoaderSecurity7` が文書を読み、「文書がある」という印を立てる
3. `ConfigurationRepository` が読んだ設定を反映し、監査の設定の再読み込み（ホットリロード）を有効にする

この作りなので、再起動のあとも、PATCH で変えた設定が使われます（再起動して確かめることはしていません）。

なお、構築時には、設定が変わったときに `AuditLogImpl.setConfig()` を呼ぶクラスもコードで探しましたが、特定には至らず、必要性が低いとして打ち切りました。その手順は本書には載せていません。

# 第4章　集計で確かめる

## 4.1　集計がうまくいかない

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem -w '\nHTTP_STATUS:%{http_code}\n' 'https://127.0.0.1:9200/security-auditlog-*/_search?size=0&track_total_hits=true' | python3 -c 'import json,sys; s=sys.stdin.read(); body=s.split("\nHTTP_STATUS:")[0]; status=s.split("\nHTTP_STATUS:")[-1].strip() if "\nHTTP_STATUS:" in s else "unknown"; print("HTTP_STATUS:",status); d=json.loads(body); print("TOP_LEVEL_KEYS:",list(d.keys())); print("ERROR_TYPE:",d.get("error",{}).get("type") if isinstance(d.get("error"),dict) else None); print("ERROR_REASON:",d.get("error",{}).get("reason") if isinstance(d.get("error"),dict) else None); print("HITS_KEYS:",list(d.get("hits",{}).keys()))'
```

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/_cat/indices/security-auditlog-*?format=json&h=index,docs.count,status' | python3 -c 'import json,sys; d=json.load(sys.stdin); print("INDEX_COUNT:",len(d)); [print("INDEX:",x.get("index"),"DOCS:",x.get("docs.count"),"STATUS:",x.get("status")) for x in d]'
```

検索は `HTTP 200` で、インデックスには88件ありました。ところが、`audit_category` で集計しようとすると結果が返りません。応答のエラーを見ます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem -H 'Content-Type: application/json' 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search' -d '{"size":0,"track_total_hits":true,"aggs":{"categories":{"terms":{"field":"audit_category","size":30}}}}' | python3 -c 'import json,sys; d=json.load(sys.stdin); print("TOP_LEVEL_KEYS:",list(d)); print("ERROR:",d.get("error")); h=d.get("hits"); print("HITS_TYPE:",type(h).__name__); print("HITS_TOTAL:",h.get("total") if isinstance(h,dict) else None); print("AGGREGATIONS_TYPE:",type(d.get("aggregations")).__name__); print("AGGREGATION_KEYS:",list(d.get("aggregations",{})) if isinstance(d.get("aggregations"),dict) else None); print("SHARDS:",d.get("_shards"))'
```

`audit_category` は `text` 型で、集計に必要な `fielddata` が無効のため、すべてのシャードで集計が失敗していました。`fielddata` は有効にせず（メモリを多く使うため）、`keyword` 型の項目があるかを確かめます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_mapping' | python3 -c 'import json,sys; d=json.load(sys.stdin); m=next(iter(d.values())).get("mappings",{}).get("properties",{}); print("audit_category:",m.get("audit_category")); print("audit_request_body:",m.get("audit_request_body")); print("audit_rest_request_headers:",m.get("audit_rest_request_headers"))'
```

`audit_category.keyword` と `audit_request_body.keyword` がありました。

## 4.2　keywordで集計する

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem -H 'Content-Type: application/json' 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search' -d '{"size":0,"track_total_hits":true,"aggs":{"categories":{"terms":{"field":"audit_category.keyword","size":30}},"request_body_present":{"filter":{"exists":{"field":"audit_request_body"}}}}}' | python3 -c 'import json,sys; d=json.load(sys.stdin); print("ERROR_TYPE:",d.get("error",{}).get("type") if isinstance(d.get("error"),dict) else None); h=d.get("hits",{}); t=h.get("total"); print("TOTAL_EVENTS:",t.get("value") if isinstance(t,dict) else t); a=d.get("aggregations",{}); print("CATEGORIES:",{x["key"]:x["doc_count"] for x in a.get("categories",{}).get("buckets",[])}); print("REQUEST_BODY_PRESENT:",a.get("request_body_present",{}).get("doc_count"))'
```

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem -H 'Content-Type: application/json' 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search' -d '{"size":0,"aggs":{"categories":{"terms":{"field":"audit_category.keyword","size":30},"aggs":{"body_present":{"filter":{"exists":{"field":"audit_request_body"}}}}}}}' | python3 -c 'import json,sys; d=json.load(sys.stdin); print("ERROR_TYPE:",d.get("error",{}).get("type") if isinstance(d.get("error"),dict) else None); b=d.get("aggregations",{}).get("categories",{}).get("buckets",[]); [print("CATEGORY:",x["key"],"EVENTS:",x["doc_count"],"BODY_PRESENT:",x["body_present"]["doc_count"]) for x in b]'
```

| カテゴリー | 件数 | 本文の項目あり |
|---|---:|---:|
| `INDEX_EVENT` | 63 | 0 |
| `COMPLIANCE_INTERNAL_CONFIG_READ` | 17 | 17 |
| `FAILED_LOGIN` | 8 | 0 |
| `COMPLIANCE_INTERNAL_CONFIG_WRITE` | 1 | 0 |

## 4.3　17件の形

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem -H 'Content-Type: application/json' 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search' -d '{"size":20,"_source":["audit_category","audit_request_body"],"query":{"bool":{"filter":[{"term":{"audit_category.keyword":"COMPLIANCE_INTERNAL_CONFIG_READ"}},{"exists":{"field":"audit_request_body"}}]}}}' | python3 -c 'import json,sys; d=json.load(sys.stdin); h=d.get("hits",{}).get("hits",[]); print("SAMPLED_DOCS:",len(h)); import collections; stats=collections.Counter(); keys=collections.Counter(); shapes=collections.Counter(); 
for x in h:
 v=x.get("_source",{}).get("audit_request_body")
 if isinstance(v,str):
  stats[len(v)]+=1
  try:
   import json as j
   o=j.loads(v); shapes[type(o).__name__]+=1
   if isinstance(o,dict): keys[tuple(sorted(o.keys()))]+=1
  except Exception: shapes["invalid_json"]+=1
 else: shapes[type(v).__name__]+=1
print("LENGTH_COUNTS:",dict(stats)); print("JSON_SHAPES:",dict(shapes)); print("TOP_LEVEL_KEY_SETS:",{str(k):v for k,v in keys.items()})'
```

17件すべて、25文字の JSON で、キーは `field_names` だけでした。

## 4.4　設定とログの照合

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/_plugins/_security/api/audit' | python3 -c 'import json,sys; d=json.load(sys.stdin); c=d.get("config",{}); a=c.get("audit",{}); m=c.get("compliance",{}); print("AUDIT_ENABLED:",c.get("enabled")); print("LOG_REQUEST_BODY:",a.get("log_request_body")); print("EXCLUDE_SENSITIVE_HEADERS:",a.get("exclude_sensitive_headers")); print("REST_ENABLED:",a.get("enable_rest")); print("TRANSPORT_ENABLED:",a.get("enable_transport")); print("COMPLIANCE_ENABLED:",m.get("enabled")); print("COMPLIANCE_READ_METADATA_ONLY:",m.get("read_metadata_only")); print("COMPLIANCE_WRITE_METADATA_ONLY:",m.get("write_metadata_only"))'
```

| 項目 | 値 |
|---|---|
| 監査 | 有効 |
| REST・Transport の監査 | 有効 |
| リクエストの本文の記録 | `false` |
| 機密のヘッダーを除く | `true` |
| Compliance | 有効（読み取り・書き込みともメタデータだけ） |

# おわりに

第27部で、次のことを確かめました。

| 項目 | 結果 |
|---|---|
| 監査ログの保存 | `security-auditlog-YYYY.MM.dd` に保存されている（構築時 89件） |
| リクエストの本文 | ふつうのイベントには記録されていない |
| `audit_request_body` がある 17件 | 内部の設定の読み取りの固定の形（`{"field_names":[...]}`）だけ |
| 認証のヘッダー | 記録されていない |
| 設定 | `.opendistro_security` に保存され、起動のときに読み込まれる作り |
| インデックスの状態 | ノードが1つのため `yellow`（レプリカを置けない） |

すべての REST の操作・すべてのイベントの種類を試したわけではありません。次の部では、Wazuh のアラートを PostgreSQL に送る Collector を点検します。
