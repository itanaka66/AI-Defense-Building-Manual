---
title: "AI自律型サイバー防御システム 構築マニュアル 中編"
subtitle: "合本　第24部〜第30部"
author: "田中勇"
lang: ja-JP
---

# 中編について

本書は「AI自律型サイバー防御システム 構築マニュアル」の中編（第24部〜第30部）を1冊にまとめた合本です。前編で作った環境の上で、Wazuh Indexer の監査ログが保存されない原因をコードで突き止めて保存できるようにし、その点検の途中で見つかった Collector の停止を、読み残しを出さずに復旧して、同じ理由で止まらないように直します。

前編と同じ環境（Proxmox・VM 220 security-core・LXC 109 PostgreSQL など）を前提にしています。前提となる構成や手順は前編を見てください。

## 編と部の構成

本マニュアルは、構築の記録の量が多いため、次の2つの編に分けています。部の番号は編をまたいで通し番号です。

| 編 | 部 | 主な内容 |
|---|---|---|
| 前編 | 第1部〜第23部 | 防御基盤（Wazuh・Collector・PostgreSQL・監視）、AI Defense Manager、Wazuh の検索用ユーザー、中継API（Relay）、AI 分析とその保護、点検 |
| 中編 | 第24部〜第30部 | Wazuh Indexer の監査ログの有効化と検証、Collector の点検・復旧・再発防止 |

**前編**

| 部 | 題名 |
|---|---|
| 第1部 | 防御基盤の構築とWazuhによる監視 |
| 第2部 | PostgreSQLログの安全な監視と相関検知 |
| 第3部 | アラート保存Collectorの構築 |
| 第4部 | Collectorの監査と強化版の開発 |
| 第5部 | 強化版Collectorの本番反映 |
| 第6部 | データ整合性の検証と運用監査 |
| 第7部 | Collectorの耐障害性の仕上げ |
| 第8部 | 統合監視基盤の構築 |
| 第9部 | Collectorの停止からの復旧と運用の点検 |
| 第10部 | ディスク障害の対処とAI Defense Managerの準備 |
| 第11部 | AI Defense Managerの土台づくり |
| 第12部 | AI分析サービスとWazuh連携の調査 |
| 第13部 | Wazuh Indexerの読み取り専用ユーザー |
| 第14部 | アラート中継API（Relay）の構築 |
| 第15部 | Relayの接続情報をVM 230へ安全に渡す |
| 第16部 | WazuhアラートをAI分析につなぐ |
| 第17部 | AI Defense Managerのサービス化と起動順序 |
| 第18部 | 分析履歴をSQLiteに残す |
| 第19部 | LLMに渡す情報を最小にする |
| 第20部 | 信頼度の修正と保存データの保護 |
| 第21部 | VM 230のSSHを公開鍵認証に切り替える |
| 第22部 | Relayと接続情報の点検 |
| 第23部 | Indexerの権限と監査ログの調査 |

**中編**

| 部 | 題名 |
|---|---|
| 第24部 | 監査ログが保存されない原因を突き止める |
| 第25部 | 監査ログの保存先を設定する |
| 第26部 | 監査ログでリクエストの本文を記録しない |
| 第27部 | 監査ログが保存されていることを確かめる |
| 第28部 | Collectorの点検と停止の原因 |
| 第29部 | 読み残しを出さずにCollectorを動かし直す |
| 第30部 | Collectorが同じ理由で止まらないようにする |

# 第24部　監査ログが保存されない原因を突き止める
## はじめに

### 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」中編の第24部です。前編の第23部で、Wazuh Indexer（OpenSearch）のセキュリティの監査ログは「有効」なのに、保存先が見つからないことがわかりました。ここでは、設定は変えずに**読み取りだけで**、その理由を突き止めます。

調べ方は次の3段階です。

1. 管理者の API で、監査の設定・インデックス・Data Stream・クラスターの設定を確かめる
2. Indexer に付いている JDK の `javap`（Java のクラスを逆アセンブルする道具）で、Security プラグインのコードを読み、監査ログの出力先（Sink）がどう選ばれるかを調べる
3. 動いている Indexer の JVM に `jcmd` で接続し、読み込まれているクラスを確かめる（読み取りだけ）

わかった結論は次のとおりです。

- 監査ログの出力先は、設定 `plugins.security.audit.type` で選ばれる。**この設定には既定の値がない**
- 設定がないと、主の出力先（default Sink）が作られず、監査のメッセージを配る仕組み（ルーター）が無効になる
- ルーターが無効だと、監査の API で `enabled: true` になっていても、**監査のイベントはどこにも保存されない**
- この環境では、設定ファイル・クラスターの設定・起動の引数・環境変数のどこにも、出力先の指定がなかった

### 中編について

本書から「中編」です。前編（第1部〜第23部）で、Wazuh を中心とした防御基盤と、AI Defense Manager・中継API（Relay）による AI の分析までを作り、前編の最後（第23部）で、Wazuh Indexer の監査ログがどこにも保存されていないらしいことがわかりました。中編では、この監査ログを動くようにし、その途中で見つかった Collector の停止を直します。

| 部 | 内容 |
|---|---|
| 第24部 | 監査ログが保存されない原因をコードで突き止める |
| 第25部 | 監査ログの保存先を設定する |
| 第26部 | 監査ログにリクエストの本文を記録しない |
| 第27部 | 監査ログが保存されていることを確かめる |
| 第28部 | Collector の点検と、停止の原因 |
| 第29部 | 読み残しを出さずに Collector を動かし直す |
| 第30部 | Collector が同じ理由で止まらないようにする |

前編の手順と同じ環境（Proxmox・VM 220 security-core・LXC 109 PostgreSQL など）を前提にしています。一般的な PC で構築する場合の読み替えは、前編 第1部の「一般的なPCで構築する場合」を見てください。

### 編と部の構成

本マニュアルは、構築の記録の量が多いため、次の2つの編に分けています。部の番号は編をまたいで通し番号です。

| 編 | 部 | 主な内容 |
|---|---|---|
| 前編 | 第1部〜第23部 | 防御基盤（Wazuh・Collector・PostgreSQL・監視）、AI Defense Manager、Wazuh の検索用ユーザー、中継API（Relay）、AI 分析とその保護、点検 |
| 中編 | 第24部〜第30部 | Wazuh Indexer の監査ログの有効化と検証、Collector の点検・復旧・再発防止 |

**前編**

| 部 | 題名 |
|---|---|
| 第1部 | 防御基盤の構築とWazuhによる監視 |
| 第2部 | PostgreSQLログの安全な監視と相関検知 |
| 第3部 | アラート保存Collectorの構築 |
| 第4部 | Collectorの監査と強化版の開発 |
| 第5部 | 強化版Collectorの本番反映 |
| 第6部 | データ整合性の検証と運用監査 |
| 第7部 | Collectorの耐障害性の仕上げ |
| 第8部 | 統合監視基盤の構築 |
| 第9部 | Collectorの停止からの復旧と運用の点検 |
| 第10部 | ディスク障害の対処とAI Defense Managerの準備 |
| 第11部 | AI Defense Managerの土台づくり |
| 第12部 | AI分析サービスとWazuh連携の調査 |
| 第13部 | Wazuh Indexerの読み取り専用ユーザー |
| 第14部 | アラート中継API（Relay）の構築 |
| 第15部 | Relayの接続情報をVM 230へ安全に渡す |
| 第16部 | WazuhアラートをAI分析につなぐ |
| 第17部 | AI Defense Managerのサービス化と起動順序 |
| 第18部 | 分析履歴をSQLiteに残す |
| 第19部 | LLMに渡す情報を最小にする |
| 第20部 | 信頼度の修正と保存データの保護 |
| 第21部 | VM 230のSSHを公開鍵認証に切り替える |
| 第22部 | Relayと接続情報の点検 |
| 第23部 | Indexerの権限と監査ログの調査 |

**中編**

| 部 | 題名 |
|---|---|
| 第24部 | 監査ログが保存されない原因を突き止める |
| 第25部 | 監査ログの保存先を設定する |
| 第26部 | 監査ログでリクエストの本文を記録しない |
| 第27部 | 監査ログが保存されていることを確かめる |
| 第28部 | Collectorの点検と停止の原因 |
| 第29部 | 読み残しを出さずにCollectorを動かし直す |
| 第30部 | Collectorが同じ理由で止まらないようにする |

### 本書の表記

- コマンドやプログラムは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 実行先は **security-core VM 220（root）** です。
- 管理者の証明書（`admin.pem`・`admin-key.pem`）は Indexer に読み取りの問い合わせをするためだけに使い、中身は表示しません。
- `javap` の出力はとても長いので、本書では結果の要点だけを書きます。

## 第1章　APIで確かめる

### 1.1　インデックスの一覧

```bash
python3 - <<'PY'
import json
import ssl
import urllib.request

ctx = ssl.create_default_context(cafile="/etc/wazuh-indexer/certs/root-ca.pem")
ctx.load_cert_chain(
    certfile="/etc/wazuh-indexer/certs/admin.pem",
    keyfile="/etc/wazuh-indexer/certs/admin-key.pem"
)

url = (
    "https://127.0.0.1:9200/_cat/indices"
    "?format=json&h=index,health,status,docs.count,store.size&s=index"
)
req = urllib.request.Request(url)

with urllib.request.urlopen(req, context=ctx, timeout=10) as res:
    indices = json.loads(res.read())
    print("HTTP_STATUS:", res.status)
    for item in indices:
        name = item.get("index", "")
        if any(word in name.lower() for word in ("audit", "security", "compliance")):
            print(json.dumps(item, ensure_ascii=False))
PY
```

`auditlog6` や `auditlog6-YYYY.MM.dd` のような、監査ログのためのインデックスはありませんでした。

### 1.2　監査の設定

```bash
python3 - <<'PY'
import json
import ssl
import urllib.request

ctx = ssl.create_default_context(cafile="/etc/wazuh-indexer/certs/root-ca.pem")
ctx.load_cert_chain(
    certfile="/etc/wazuh-indexer/certs/admin.pem",
    keyfile="/etc/wazuh-indexer/certs/admin-key.pem"
)

url = "https://127.0.0.1:9200/_plugins/_security/api/audit"
req = urllib.request.Request(url)

with urllib.request.urlopen(req, context=ctx, timeout=10) as res:
    data = json.loads(res.read())
    audit = data.get("audit", {})
    print("HTTP_STATUS:", res.status)
    for key in (
        "enabled",
        "enable_rest",
        "enable_transport",
        "log_request_body",
        "resolve_indices",
        "disabled_rest_categories",
        "disabled_transport_categories",
    ):
        if key in audit:
            print(f"{key}: {json.dumps(audit[key], ensure_ascii=False)}")
    print("OTHER_TOP_LEVEL_KEYS:", sorted(k for k in data if k not in ("audit", "_readonly")))
PY
```

`HTTP_STATUS: 200` でしたが、設定は `config` の内側にあるため、このプログラムでは値が表示されませんでした。`config` の中を見ます。

```bash
python3 - <<'PY'
import json
import ssl
import urllib.request

ctx = ssl.create_default_context(cafile="/etc/wazuh-indexer/certs/root-ca.pem")
ctx.load_cert_chain(
    certfile="/etc/wazuh-indexer/certs/admin.pem",
    keyfile="/etc/wazuh-indexer/certs/admin-key.pem"
)

req = urllib.request.Request(
    "https://127.0.0.1:9200/_plugins/_security/api/audit"
)

with urllib.request.urlopen(req, context=ctx, timeout=10) as res:
    data = json.loads(res.read())
    config = data.get("config", {})
    print("HTTP_STATUS:", res.status)
    print("CONFIG_TYPE:", type(config).__name__)
    if isinstance(config, dict):
        for key, value in config.items():
            if isinstance(value, dict):
                print(f"{key}:")
                for subkey, subvalue in value.items():
                    if any(word in subkey.lower() for word in ("index", "type", "enabled", "log", "audit")):
                        print(f"  {subkey}: {json.dumps(subvalue, ensure_ascii=False)}")
            elif any(word in key.lower() for word in ("index", "type", "enabled", "log", "audit")):
                print(f"{key}: {json.dumps(value, ensure_ascii=False)}")
    else:
        print("CONFIG_VALUE_TYPE:", type(config).__name__)
PY
```

監査は有効で、`log_request_body`（リクエストの本文の記録）が `true` でした。

### 1.3　すべてのインデックス

```bash
python3 - <<'PY'
import json
import ssl
import urllib.request

ctx = ssl.create_default_context(cafile="/etc/wazuh-indexer/certs/root-ca.pem")
ctx.load_cert_chain(
    certfile="/etc/wazuh-indexer/certs/admin.pem",
    keyfile="/etc/wazuh-indexer/certs/admin-key.pem"
)

url = "https://127.0.0.1:9200/_cat/indices?format=json&h=index,docs.count,store.size&s=index"
req = urllib.request.Request(url)

with urllib.request.urlopen(req, context=ctx, timeout=10) as res:
    indices = json.loads(res.read())
    print("HTTP_STATUS:", res.status)
    print("TOTAL_INDICES:", len(indices))
    for item in indices:
        name = item.get("index", "")
        if name.startswith(".") or any(
            word in name.lower()
            for word in ("audit", "security", "compliance", "log")
        ):
            print(json.dumps(item, ensure_ascii=False))
PY
```

全25個のインデックスの中に、監査ログのものと判断できるインデックスはありませんでした。

```bash
journalctl -u wazuh-indexer --since "2026-11-20 00:00:00" --no-pager -o cat | grep -Ei 'audit|compliance|auditlog|opensearch.security.audit|security audit' | sed -E 's/(password|token|authorization)([=: ]+)[^ ]+/\1\2[REDACTED]/Ig' | tail -n 40
```

Indexer のログにも、監査の初期化やエラーの記録はありませんでした。

### 1.4　監査の設定のすべての項目

```bash
python3 - <<'PY'
import json
import ssl
import urllib.request

ctx = ssl.create_default_context(cafile="/etc/wazuh-indexer/certs/root-ca.pem")
ctx.load_cert_chain(
    certfile="/etc/wazuh-indexer/certs/admin.pem",
    keyfile="/etc/wazuh-indexer/certs/admin-key.pem"
)

req = urllib.request.Request(
    "https://127.0.0.1:9200/_plugins/_security/api/audit"
)

with urllib.request.urlopen(req, context=ctx, timeout=10) as res:
    data = json.loads(res.read())
    print("HTTP_STATUS:", res.status)

    def show_keys(obj, prefix=""):
        if isinstance(obj, dict):
            for key, value in obj.items():
                path = f"{prefix}.{key}" if prefix else key
                if isinstance(value, dict):
                    print(path + ":")
                    show_keys(value, path)
                else:
                    print(path, "=", json.dumps(value, ensure_ascii=False))
        else:
            print("CONFIG_TYPE:", type(obj).__name__)

    show_keys(data.get("config", {}))
PY
```

| 項目 | 値 |
|---|---|
| 監査の全体 | 有効 |
| REST・Transport の監査 | 有効 |
| 記録しないカテゴリー | `AUTHENTICATED`・`GRANTED_PRIVILEGES` |
| `compliance.read_metadata_only`・`write_metadata_only` | `true` |

項目の中に、出力先（Sink）を決めるものはありませんでした。

## 第2章　Securityプラグインのコードを読む

### 2.1　プラグインのファイル

```bash
grep -RniE 'auditlog6|internal_opensearch|audit.*index|index.*audit' /usr/share/wazuh-indexer/plugins/opensearch-security 2>/dev/null | head -n 40
```

プラグインは JAR（ZIP 形式）なので、`grep` では中を探せません。

```bash
find /usr/share/wazuh-indexer/plugins/opensearch-security -maxdepth 2 -type f \( -name '*.jar' -o -name 'plugin-descriptor.properties' \) -printf '%f\n' | sort
```

Security プラグインは `opensearch-security-2.19.6.0.jar` でした。`unzip` は入っていないので、パッケージは足さずに、Python の標準のライブラリで JAR の中の一覧を見ます。

```bash
python3 - <<'PY'
from zipfile import ZipFile

path = "/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar"
keywords = ("audit", "compliance", "indexhandler", "indexmanager", "logsink", "logwriter")

with ZipFile(path) as jar:
    matches = [
        name for name in jar.namelist()
        if any(word in name.lower().replace("_", "") for word in keywords)
    ]

print("MATCH_COUNT:", len(matches))
for name in matches[:80]:
    print(name)
PY
```

監査ログの出力先として、次の実装がありました。

| クラス | 出力先 |
|---|---|
| `InternalOpenSearchSink` | Indexer の中のインデックス |
| `InternalOpenSearchDataStreamSink` | Indexer の中の Data Stream |
| `ExternalOpenSearchSink` | 外部の OpenSearch |
| `Log4JSink` | ログファイル |
| `KafkaSink`・`WebhookSink` | Kafka・Webhook |
| `DebugSink`・`NoopSink` | デバッグ用・何もしない |

```bash
python3 - <<'PY'
from zipfile import ZipFile

path = "/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar"
with ZipFile(path) as jar:
    print(jar.read("static_config/static_audit.yml").decode("utf-8"))
PY
```

標準の監査設定（`static_audit.yml`）の中身は `_readonly: []` だけで、出力先はわかりませんでした。

### 2.2　設定ファイルに出力先の指定があるか

```bash
grep -RniE 'plugins\.security\.audit\.(type|config\.type|config\.index)|audit\.type|auditlog6|internal_opensearch|external_opensearch' /etc/wazuh-indexer /etc/default 2>/dev/null
```

見つかったのは設定例のファイル（`opensearch.yml.example`）だけでした。

### 2.3　javap

OS に `javap` は入っていませんが、Indexer に付いている JDK にあります。

```bash
find /usr/share/wazuh-indexer /usr/lib/jvm -type f \( -name 'jcmd' -o -name 'jstack' -o -name 'javap' \) -print 2>/dev/null | head -n 30
```

### 2.4　出力先を選ぶ処理（SinkProvider）

```bash
 /usr/share/wazuh-indexer/jdk/bin/javap -classpath /usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar -p -c org.opensearch.security.auditlog.sink.SinkProvider
```

- `plugins.security.audit.type` が出力先を選ぶ
- `internal_opensearch` なら `InternalOpenSearchSink`、`internal_opensearch_data_stream` なら Data Stream に出力する

```bash
journalctl -u wazuh-indexer --since "2026-11-17 00:00:00" --no-pager -o cat | grep -Ei 'SinkProvider|sink .*created|Default endpoint could not be created|Audit logging unavailable|InternalOpenSearchSink|DebugSink|NoopSink'
```

出力先に関するログは0件でした。実際に読み込まれる設定ファイルを確かめます（値は表示しません）。

```bash
python3 - <<'PY'
from pathlib import Path

paths = [
    Path("/etc/wazuh-indexer/opensearch.yml"),
    Path("/usr/share/wazuh-indexer/config/opensearch.yml"),
]

for path in paths:
    print(f"\nFILE: {path}")
    print("EXISTS:", path.exists())
    if not path.exists():
        continue

    for number, line in enumerate(path.read_text(errors="replace").splitlines(), 1):
        stripped = line.strip()
        if "plugins.security.audit" in stripped:
            print(f"{number}: {stripped.split(':', 1)[0]}: [VALUE HIDDEN]")
PY
```

設定ファイルは `/etc/wazuh-indexer/opensearch.yml` で、`plugins.security.audit.*` の指定はありませんでした。

### 2.5　設定の既定の値

設定の登録の部分を見ます。

```bash
 /usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/lib/*:/usr/share/wazuh-indexer/plugins/opensearch-security/*' -p -c org.opensearch.security.OpenSearchSecurityPlugin | grep -n -B 5 -A 8 'plugins.security.audit.type'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/lib/*:/usr/share/wazuh-indexer/plugins/opensearch-security/*' -p -c org.opensearch.security.OpenSearchSecurityPlugin | sed -n '2400,2455p'
```

`plugins.security.audit.type` は `Setting.simpleString()` で登録されていて、**既定の値が渡されていません**。設定ファイルに書かなければ、`internal_opensearch` などが自動で選ばれることはありません。

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/lib/*:/usr/share/wazuh-indexer/plugins/opensearch-security/*' -p -c org.opensearch.security.auditlog.sink.SinkProvider | grep -n -B 12 -A 18 -E 'DebugSink|NoopSink|createSink|Default endpoint could not be created|Audit logging unavailable'
```

- 出力先の種類が指定されていないと、`createSink()` は `null` を返す
- `DebugSink` は、主の出力先の代わりではなく、保存に失敗したときの予備（fallback）として作られる
- 主の出力先が作れなければ、エラーを記録して初期化を終える

## 第3章　ほかの経路で設定されていないか

### 3.1　Data Stream

```bash
python3 - <<'PY'
import json
import ssl
import urllib.request
import urllib.error

ctx = ssl.create_default_context(cafile="/etc/wazuh-indexer/certs/root-ca.pem")
ctx.load_cert_chain(
    certfile="/etc/wazuh-indexer/certs/admin.pem",
    keyfile="/etc/wazuh-indexer/certs/admin-key.pem"
)

for path in ("/_data_stream", "/_cat/data_streams?format=json"):
    req = urllib.request.Request("https://127.0.0.1:9200" + path)
    try:
        with urllib.request.urlopen(req, context=ctx, timeout=10) as r:
            data = json.loads(r.read())
            if path == "/_data_stream":
                names = [x.get("name") for x in data.get("data_streams", [])]
            else:
                names = [x.get("name") for x in data]
            print(path, "HTTP", r.status)
            print("DATA_STREAM_NAMES:", names)
    except urllib.error.HTTPError as e:
        print(path, "HTTP", e.code)
    except Exception as e:
        print(path, "ERROR:", type(e).__name__)
PY
```

`/_data_stream` は `HTTP 200` で、Data Stream は0件でした（`_cat/data_streams` は `400` でしたが、前者で空とわかります）。

### 3.2　起動の引数と環境変数

```bash
pid=$(systemctl show wazuh-indexer -p MainPID --value); if [ "$pid" -gt 0 ]; then tr '\0' '\n' < "/proc/$pid/cmdline" | grep -Ei 'audit|opensearch.yml|config' | sed -E 's/(password|token|secret)([^=]*)=.*/\1\2=[REDACTED]/I'; else echo "Indexer PID not found"; fi
```

環境変数は、名前だけを表示します（値は隠します）。

```bash
pid=$(systemctl show wazuh-indexer -p MainPID --value); if [ "$pid" -gt 0 ]; then tr '\0' '\n' < "/proc/$pid/environ" | grep -Ei 'audit|opensearch|config' | sed -E 's/=.*/=[VALUE HIDDEN]/'; else echo "Indexer PID not found"; fi
```

どちらにも、監査の出力先の指定はありませんでした。

### 3.3　クラスターの設定

永続の設定・一時の設定・既定の値のすべてから、`plugins.security.audit` を含むものを探します。

```bash
python3 - <<'PY'
import json
import ssl
import urllib.request

ctx = ssl.create_default_context(cafile="/etc/wazuh-indexer/certs/root-ca.pem")
ctx.load_cert_chain(
    certfile="/etc/wazuh-indexer/certs/admin.pem",
    keyfile="/etc/wazuh-indexer/certs/admin-key.pem"
)

url = "https://127.0.0.1:9200/_cluster/settings?include_defaults=true&flat_settings=true"
req = urllib.request.Request(url)

with urllib.request.urlopen(req, context=ctx, timeout=10) as r:
    data = json.loads(r.read())

for section in ("persistent", "transient", "defaults"):
    settings = data.get(section, {})
    matches = {
        k: ("[VALUE HIDDEN]" if any(x in k.lower() for x in ("password", "token", "secret")) else v)
        for k, v in settings.items()
        if "plugins.security.audit" in k.lower()
    }
    print(section.upper(), json.dumps(matches, ensure_ascii=False))
PY
```

どれにも指定はありませんでした。

### 3.4　出力先が null のとき

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/lib/*:/usr/share/wazuh-indexer/plugins/opensearch-security/*' -p -c org.opensearch.security.auditlog.sink.SinkProvider | sed -n '251,380p'
```

`createSink()` は、はじめに出力先を `null` にし、種類が `null` ならそのまま戻ります。もう1つの指定の方法（`plugins.security.audit.endpoints`）も確かめます。

```bash
grep -nEi 'plugins\.security\.audit\.(type|endpoints)|audit.*(type|endpoint)' /etc/wazuh-indexer/opensearch.yml /etc/wazuh-indexer/opensearch-security/opensearch.yml 2>/dev/null
```

0件でした。

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/lib/*:/usr/share/wazuh-indexer/plugins/opensearch-security/*' -p -c org.opensearch.security.auditlog.sink.SinkProvider | sed -n '1,115p'
```

`SinkProvider` の初期化は次のとおりです。

1. 予備（fallback）が指定されていなければ `DebugSink` を作る
2. 主の出力先（default）は `plugins.security.audit.type` から作る
3. 主の出力先が作れなければ、エラーを記録して初期化を終える

```bash
journalctl -u wazuh-indexer --since "2026-11-17 00:00:00" --no-pager -o cat | grep -Ei 'AuditLog|AuditLogger|AuditLogSink|SinkProvider|auditlog|audit logger|audit logging'
```

監査に関するログは0件でした。

## 第4章　イベントが配られる経路

### 4.1　監査のクラス

OS に `jar` は入っていないので、Indexer の JDK の `jar` を使います。

```bash
/usr/share/wazuh-indexer/jdk/bin/jar tf /usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar | grep -Ei 'audit.*(logger|log|sink)|Audit.*(Logger|Log|Sink)|AuditLog'
```

監査のイベントを受け取るのは `AuditLogImpl`、出力先に配るのは `AuditMessageRouter` です。

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/lib/*:/usr/share/wazuh-indexer/plugins/opensearch-security/*' -p org.opensearch.security.auditlog.impl.AuditLogImpl
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/lib/*:/usr/share/wazuh-indexer/plugins/opensearch-security/*' -p -c org.opensearch.security.auditlog.impl.AuditLogImpl | grep -n -A 45 -B 8 -E 'enableRoutes|save\('
```

バイトコードを読み解くと、保存の処理は次の形です（Java で書き直したもの）。

```text
protected void save(AuditMessage message) {
    if (enabled) {
        messageRouter.route(message);
    }
}
```

### 4.2　ルーター

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/lib/*:/usr/share/wazuh-indexer/plugins/opensearch-security/*' -p -c org.opensearch.security.auditlog.routing.AuditMessageRouter
```

- 主の出力先が `null` なら、ルーターは無効（`isEnabled()` が false）
- 無効のときにイベントが来ると、`#route(AuditMessage) called but message router is disabled` というエラーを出して終わる

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/lib/*:/usr/share/wazuh-indexer/plugins/opensearch-security/*' -p -c org.opensearch.security.auditlog.impl.AuditLogImpl | sed -n '1,110p'
```

`setConfig()` は次の形でした。

```text
enabled = auditConfig.isEnabled() && messageRouterEnabled;
```

つまり、監査の API で `enabled: true` でも、主の出力先がなければ `messageRouterEnabled` が false になり、監査は実際には働きません。

### 4.3　起動のときのメッセージ

```bash
journalctl -u wazuh-indexer --since "2026-11-17 00:00:00" --no-pager -o cat | grep -Ei 'Message routing enabled|No default storage available|Default endpoint could not be created|audit log may not work properly|message router is disabled'
```

```bash
grep -RniE 'Message routing enabled|No default storage available|Default endpoint could not be created|message router is disabled|audit log may not work properly' /var/log/wazuh-indexer/ 2>/dev/null
```

journal にもログファイルにも、該当するメッセージはありませんでした。

## 第5章　動いているJVMを見る

### 5.1　起動の時刻

```bash
ps -eo pid,lstart,etime,args | grep '[o]rg.opensearch.bootstrap.OpenSearch'
```

構築時の Indexer は PID 1238 で、2026年11月20日 06:56:11 に起動していました（調べた期間に起動が含まれます）。

### 5.2　jcmd

`jcmd` は動いている JVM に接続して情報を取る道具です。ここでは読み取りのコマンドだけを使います。PID は自分の環境のものに置き換えてください。

```bash
/usr/share/wazuh-indexer/jdk/bin/jcmd 1238 VM.version
```

```bash
/usr/share/wazuh-indexer/jdk/bin/jcmd 1238 help
```

構築時は OpenJDK 21.0.11 でした。読み込まれている監査のクラスを確かめます。

```bash
/usr/share/wazuh-indexer/jdk/bin/jcmd 1238 VM.classes | grep -Ei 'org\.opensearch\.security\.auditlog|SinkProvider|AuditMessageRouter'
```

`AuditLogImpl`・`AuditMessageRouter`・`SinkProvider`・`DebugSink`・`InternalOpenSearchSink`・`ExternalOpenSearchSink` などは読み込まれていました。ただし、クラスが読み込まれていることと、出力先が実際に選ばれて動いていることは別です。

## おわりに

第24部で突き止めたことは次のとおりです。

| 項目 | 結果 |
|---|---|
| 監査の API の設定 | 有効（`log_request_body: true`） |
| `plugins.security.audit.type` | どこにも指定がない（既定の値もない） |
| 主の出力先（default Sink） | 作られない |
| ルーター | 無効になる |
| 監査ログ | **保存されていない**と考えられる |

次の部では、`plugins.security.audit.type` を設定して監査ログを Indexer の中に保存するようにし、リクエストの本文を記録しないようにします。

# 第25部　監査ログの保存先を設定する
## はじめに

### 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」中編の第25部です。第24部で、監査ログの出力先（`plugins.security.audit.type`）が設定されていないため、監査ログが保存されていないとわかりました。ここでは次のことを行います。

1. 出力先の候補（`internal_opensearch`）が、どこに・何を保存するかをコードで確かめる
2. 保存に失敗したときに、監査のメッセージがどこへ流れるかを確かめる
3. 記録される項目（リクエストの本文・ヘッダー・カテゴリー）を確かめる
4. 設定ファイルに2行を足し、Indexer を再起動する

守る条件は次のとおりです。

- Wazuh のアラートのインデックスと、監査ログを分ける
- `ai-defense-reader` に監査ログを読む権限を足さない
- Wazuh のアラートの収集と Relay を止めない（再起動のあいだを除く）
- リクエストの本文は記録しない（秘密の情報がまじるおそれがあるため）
- 変える前にバックアップを取る

### 本書の表記

- コマンドやプログラムは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 実行先は **security-core VM 220（root）** です。
- `javap` の出力は長いので、結果の要点だけを書きます。
- 構築の記録のうち、会話 (109) と (112) はいただいていません。その間の判断（設定の方針の承認など）は、前後の会話から読み取れる範囲で書いています。

## 第1章　設定ファイルの確認

使う予定の設定は次の1行です（このあと 3.4 で確定します）。

```text
plugins.security.audit.type: internal_opensearch
```

```bash
stat -c '%n | owner=%U:%G | mode=%a | size=%s bytes | modified=%y' /etc/wazuh-indexer/opensearch.yml
```

構築時は `wazuh-indexer:wazuh-indexer` の `660`、2152 バイトでした。この権限は変えません。

```bash
sed -n '1,240p' /etc/wazuh-indexer/opensearch.yml
```

監査の出力先の指定はなく、Indexer は `127.0.0.1` だけで待ち受けています。TLS・認証・ネットワークの設定には手を加えません。

## 第2章　internal_opensearchの動き

### 2.1　保存先のインデックス

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.sink.InternalOpenSearchSink | grep -n -B 5 -A 8 -Ei 'auditlog6|index|createIndex|mapping'
```

Security プラグイン 2.19.6.0 の `internal_opensearch` は、インデックスの名前が指定されていなければ、日付ごとの **`security-auditlog-YYYY.MM.dd`** に保存します（`auditlog6` ではありません）。

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.sink.AbstractInternalOpenSearchSink
```

- 監査のイベントは `Client.prepareIndex()` で Indexer の中に書き込まれる
- 監査のメッセージ（`AuditMessage.getAsMap()`）の内容がそのまま保存される
- 書き込みに失敗すると、`Unable to index audit log` がエラーのログに出る

### 2.2　保存に失敗したとき

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.sink.AuditLogSink
```

`AuditLogSink.store()` は次の順に処理します。

1. 主の出力先に保存する
2. 失敗したら、予備（fallback）の出力先に保存する
3. それも失敗したら、`System.err`（標準エラー出力）に監査のメッセージの全文を出す

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.sink.DebugSink
```

予備の `DebugSink` は、監査のメッセージの全文を Log4j に `INFO` で出します。

```bash
grep -nEi 'rootLogger|logger\..*(auditlog|DebugSink)|appender|fileName|filePattern|console' /etc/wazuh-indexer/log4j2.properties
```

| 項目 | 今の設定 |
|---|---|
| rootLogger | `INFO` |
| コンソールへの出力 | 有効 |
| ファイルへの出力 | 有効（`/var/log/wazuh-indexer/`、128MB ごと、合計 2GB まで） |

つまり、主の出力先への保存に失敗すると、監査のメッセージの全文が通常のログに出るおそれがあります。

### 2.3　予備の出力先の選び方

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.sink.SinkProvider | grep -n -B 8 -A 15 -E 'FALLBACKSINK_NAME|fallback|DebugSink|createSink'
```

| 予備の指定 | 動き |
|---|---|
| なし | `DebugSink` を自動で作る |
| `debug` | Log4j に全文を出す |
| `noop` | 監査のメッセージを捨てる |

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.sink.NoopSink
```

`NoopSink` は何も出力せず「成功」として返します。ログへの漏れは防げますが、監査の記録が欠けたことが隠れてしまうため、ここでは採用しません（予備は既定のままにします）。

## 第3章　何が記録されるか

### 3.1　リクエストの本文とヘッダー

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.impl.AuditMessage
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.impl.AuditMessage | grep -n -B 5 -A 35 -E 'addRestHeaders|addRestParams|addPath|addTransportHeaders'
```

- `log_request_body` が有効だと、REST のリクエストの本文を JSON にして `audit_request_body` に入れる
- 本文を `__SENSITIVE__` に置き換えるのは、パスワードを扱う一部の Security API だけ。ほかの本文（検索の条件・登録や更新のデータなど）はそのまま記録される
- `exclude_sensitive_headers` が有効だと、`Authorization` ヘッダーは記録しない

### 3.2　フィルターの既定の値

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c 'org.opensearch.security.auditlog.config.AuditConfig$Filter'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c 'org.opensearch.security.auditlog.config.AuditConfig$Filter$FilterEntries'
```

- `log_request_body` の既定の値は **true**
- `exclude_sensitive_headers` の既定の値は true
- `ignore_headers`・`ignore_url_params`・`ignore_requests`・`ignore_users` は、ワイルドカードで指定して記録から外せる

### 3.3　監査のカテゴリー

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c 'org.opensearch.security.auditlog.impl.AuditCategory'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p org.opensearch.security.auditlog.impl.AuditLogImpl
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.impl.AuditLogImpl | grep -n -A 45 -E 'logFailedLogin|logSucceededLogin|logMissingPrivileges|logGrantedPrivileges|logIndexEvent|logSecurityIndexAttempt|logSSLException'
```

`AuditLogImpl` は、有効かどうかを確かめたうえで、イベントを作る処理を親のクラス `AbstractAuditLog` に任せています。

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.impl.AbstractAuditLog | grep -n -B 4 -A 35 -E 'logFailedLogin|logSucceededLogin|logMissingPrivileges|logGrantedPrivileges|logIndexEvent|logBadHeaders|logSecurityIndexAttempt|logSSLException|logDocumentRead|logDocumentWritten|logDocumentDeleted'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.impl.AbstractAuditLog | grep -oE 'AuditCategory\.[A-Z_]+' | sort -u
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar' -p -c org.opensearch.security.auditlog.impl.AuditCategory
```

カテゴリーは13種類です。このシステムで特に役に立つのは次のものです。

| カテゴリー | 意味 |
|---|---|
| `FAILED_LOGIN` | 認証の失敗 |
| `MISSING_PRIVILEGES` | 権限が足りずに断られた操作 |
| `BAD_HEADERS` | 正しくないヘッダー |
| `OPENDISTRO_SECURITY_INDEX_ATTEMPT` | セキュリティの内部のインデックスへの操作の試み |
| `SSL_EXCEPTION` | TLS の例外 |
| `INDEX_EVENT` | インデックスの操作 |
| `COMPLIANCE_*` | 文書の読み書き・内部の設定の読み書き |

認証の成功（`AUTHENTICATED`）と権限の許可（`GRANTED_PRIVILEGES`）は、今の設定で記録から外れています（前編 第23部）。

### 3.4　設定のキーの名前

まず、ログファイルにルーターの初期化のメッセージがないことを、圧縮されたログも含めて確かめます。

```bash
python3 - <<'PY'
from pathlib import Path
import gzip

base = Path("/var/log/wazuh-indexer")
patterns = (
    "Default endpoint could not be created",
    "No default storage available",
    "Message routing enabled",
    "audit log may not work",
    "message router is disabled",
)

count = 0
for path in sorted(base.glob("*server*")):
    try:
        opener = gzip.open if path.suffix == ".gz" else open
        with opener(path, "rt", encoding="utf-8", errors="replace") as f:
            for line in f:
                if any(p.lower() in line.lower() for p in patterns):
                    print(f"{path.name}: {line.rstrip()}")
                    count += 1
    except (OSError, EOFError):
        pass

print("MATCH_COUNT:", count)
PY
```

```bash
grep -nEi '^[[:space:]]*plugins\.security\.audit\.|^[[:space:]]*opendistro_security\.audit\.' /etc/wazuh-indexer/opensearch.yml
```

```bash
stat -c '%n | owner=%U:%G | mode=%a | size=%s | modified=%y' /etc/wazuh-indexer/opensearch.yml
```

```bash
tail -n 35 /etc/wazuh-indexer/opensearch.yml | nl -ba
```

設定はファイルの末尾に足します。リクエストの本文を記録しない設定のキーを、コードで確かめます。

```bash
/usr/share/wazuh-indexer/jdk/bin/jar tf /usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar | grep -E 'AuditConfig.*FilterEntries|FilterEntries.*class'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c 'org.opensearch.security.auditlog.config.AuditConfig$Filter$FilterEntries'
```

古い形式のキーは `opendistro_security.audit.log_request_body` でした。

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c 'org.opensearch.security.auditlog.config.AuditConfig$Filter' | grep -n -A90 -B8 'from(org.opensearch.common.settings.Settings)'
```

`fromSettingBoolean()` は、新しい形式のキーを先に見て、なければ古い形式のキーを見ます。新しい形式の名前の付け方を確かめます。

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c 'org.opensearch.security.auditlog.config.AuditConfig$Filter$FilterEntries' | grep -n -A35 -B5 'getKeyWithNamespace'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -v 'org.opensearch.security.auditlog.config.AuditConfig$Filter$FilterEntries' | grep -n -A18 -B3 'BootstrapMethods:'
```

`getKeyWithNamespace()` は接頭辞 `plugins.security.audit.config.` を使っていました。リクエストの本文を記録しない設定は次のとおりです。

```text
plugins.security.audit.config.log_request_body: false
```

出力先の設定は、別の名前の空間です。

```text
plugins.security.audit.type: internal_opensearch
```

## 第4章　設定して再起動する

### 4.1　今の値

```bash
python3 - <<'PY'
import json
import ssl
import urllib.request

ctx = ssl.create_default_context(cafile="/etc/wazuh-indexer/certs/root-ca.pem")
ctx.load_cert_chain(
    certfile="/etc/wazuh-indexer/certs/admin.pem",
    keyfile="/etc/wazuh-indexer/certs/admin-key.pem"
)

req = urllib.request.Request("https://127.0.0.1:9200/_plugins/_security/api/audit")
with urllib.request.urlopen(req, context=ctx, timeout=10) as res:
    data = json.load(res)

audit = data.get("config", {}).get("audit", {})
print("audit.enabled:", data.get("config", {}).get("enabled"))
print("audit.log_request_body:", audit.get("log_request_body"))
print("audit.exclude_sensitive_headers:", audit.get("exclude_sensitive_headers"))
print("audit.enable_rest:", audit.get("enable_rest"))
print("audit.enable_transport:", audit.get("enable_transport"))
PY
```

`log_request_body` は `True` でした。

### 4.2　バックアップ

```bash
cp -a /etc/wazuh-indexer/opensearch.yml "/etc/wazuh-indexer/opensearch.yml.pre-audit-$(date +%Y%m%d-%H%M%S)"
```

```bash
bash -c 'f=$(ls -1t /etc/wazuh-indexer/opensearch.yml.pre-audit-* | head -n 1); echo "BACKUP: $f"; stat -c "owner=%U:%G mode=%a size=%s" "$f"; cmp -s /etc/wazuh-indexer/opensearch.yml "$f" && echo "CONTENT_MATCH: yes" || echo "CONTENT_MATCH: no"'
```

構築時のバックアップは `opensearch.yml.pre-audit-20261121-082142` で、元のファイルと一致しました。

### 4.3　2行を足す

同じキーがすでにないことを確かめます。

```bash
grep -nE '^[[:space:]]*plugins\.security\.audit\.(type|config\.log_request_body):' /etc/wazuh-indexer/opensearch.yml
```

足すのは次の2行です。

```text
plugins.security.audit.type: internal_opensearch
plugins.security.audit.config.log_request_body: false
```

```bash
printf '\n# AI Defense: audit logging with request-body protection\nplugins.security.audit.type: internal_opensearch\nplugins.security.audit.config.log_request_body: false\n' >> /etc/wazuh-indexer/opensearch.yml
```

バックアップとの差分が、コメント1行と設定2行だけであることを確かめます。ファイル名は自分のバックアップの名前に置き換えます。

```bash
diff -u /etc/wazuh-indexer/opensearch.yml.pre-audit-20261121-082142 /etc/wazuh-indexer/opensearch.yml
```

```bash
python3 - <<'PY'
import yaml

path = "/etc/wazuh-indexer/opensearch.yml"
with open(path, encoding="utf-8") as f:
    config = yaml.safe_load(f)

assert config["plugins.security.audit.type"] == "internal_opensearch"
assert config["plugins.security.audit.config.log_request_body"] is False

print("YAML_SYNTAX: OK")
print("AUDIT_TYPE: OK")
print("REQUEST_BODY_LOGGING: disabled")
PY
```

### 4.4　再起動

再起動の前の状態を記録します。

```bash
systemctl show wazuh-indexer -p ActiveState -p SubState -p MainPID -p NRestarts -p ActiveEnterTimestamp
```

再起動のあいだは、Indexer の API や Wazuh の検索・Relay が一時的に使えなくなります。

```bash
systemctl restart wazuh-indexer
```

```bash
systemctl show wazuh-indexer -p ActiveState -p SubState -p MainPID -p NRestarts -p ActiveEnterTimestamp
```

構築時は `active`・`running`、新しい PID は 51059、`NRestarts=0` でした。

### 4.5　反映されたか

```bash
python3 - <<'PY'
import json
import ssl
import urllib.request

ctx = ssl.create_default_context(cafile="/etc/wazuh-indexer/certs/root-ca.pem")
ctx.load_cert_chain(
    certfile="/etc/wazuh-indexer/certs/admin.pem",
    keyfile="/etc/wazuh-indexer/certs/admin-key.pem"
)

req = urllib.request.Request("https://127.0.0.1:9200/_plugins/_security/api/audit")
with urllib.request.urlopen(req, context=ctx, timeout=15) as res:
    data = json.load(res)

config = data.get("config", {})
audit = config.get("audit", {})

print("API: OK")
print("AUDIT_ENABLED:", config.get("enabled"))
print("LOG_REQUEST_BODY:", audit.get("log_request_body"))
print("EXCLUDE_SENSITIVE_HEADERS:", audit.get("exclude_sensitive_headers"))
print("ENABLE_REST:", audit.get("enable_rest"))
print("ENABLE_TRANSPORT:", audit.get("enable_transport"))
PY
```

構築時は、`LOG_REQUEST_BODY: True` のままでした。設定ファイルに書いた `false` は、監査の API が返す設定には反映されていません。次の部で、この理由を調べて直します。

## おわりに

第25部で、`/etc/wazuh-indexer/opensearch.yml` に次の設定を足し、Indexer を再起動しました。

| 設定 | 値 | 結果 |
|---|---|---|
| `plugins.security.audit.type` | `internal_opensearch` | 監査ログを Indexer の中（`security-auditlog-YYYY.MM.dd`）に保存する |
| `plugins.security.audit.config.log_request_body` | `false` | 監査の API にはまだ反映されていない |

バックアップは `/etc/wazuh-indexer/opensearch.yml.pre-audit-*` です。

# 第26部　監査ログでリクエストの本文を記録しない
## はじめに

### 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」中編の第26部です。第25部で `opensearch.yml` に `plugins.security.audit.config.log_request_body: false` を書いて Indexer を再起動しましたが、監査の API は `log_request_body: true` を返したままでした。ここでは、その理由をコードで突き止め、**監査の API（PATCH）で `log_request_body` だけを `false` にします**。

わかった理由は次のとおりです。

- 監査の設定は、Indexer の内部のインデックス `.opendistro_security` の中の文書 `audit` にも保存されている（動的な設定）
- 起動のとき、この文書が**あれば**それを使い、**なければ**`opensearch.yml` から設定を作る
- この環境では文書 `audit` があるため、`opensearch.yml` の `log_request_body: false` は使われない

### 本書の表記

- コマンドやプログラムは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 実行先は **security-core VM 220（root）** です。
- 管理者の証明書（`admin.pem`・`admin-key.pem`）で Indexer に接続します。`admin` ユーザーのパスワードは使いません。
- `javap` の出力は長いので、結果の要点だけを書きます。

## 第1章　設定はどこから読まれるか

### 1.1　ノードの設定とファイル

```bash
python3 - <<'PY'
import json
import ssl
import urllib.request

ctx = ssl.create_default_context(cafile="/etc/wazuh-indexer/certs/root-ca.pem")
ctx.load_cert_chain(
    certfile="/etc/wazuh-indexer/certs/admin.pem",
    keyfile="/etc/wazuh-indexer/certs/admin-key.pem"
)

url = "https://127.0.0.1:9200/_nodes/settings?flat_settings=true"
req = urllib.request.Request(url)

with urllib.request.urlopen(req, context=ctx, timeout=15) as res:
    data = json.load(res)

for node_id, node in data.get("nodes", {}).items():
    settings = node.get("settings", {})
    print("NODE:", node.get("name", node_id))
    for key in sorted(settings):
        if "audit" in key.lower():
            value = settings[key]
            if any(x in key.lower() for x in ("password", "token", "secret", "credential")):
                value = "[REDACTED]"
            print(f"{key} = {value}")
PY
```

ノードの設定の API には、監査の設定は1つも出てきませんでした（出てこないことだけでは、読み込まれていないとは言えません）。

```bash
grep -nE '^[[:space:]]*plugins\.security\.audit\.(type|config\.log_request_body):' /etc/wazuh-indexer/opensearch.yml && stat -c '%U:%G %a %s' /etc/wazuh-indexer/opensearch.yml
```

ファイルには2行があり、持ち主と権限も変わっていません。

### 1.2　AuditConfigの作られ方

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p 'org.opensearch.security.auditlog.config.AuditConfig'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c 'org.opensearch.security.auditlog.config.AuditConfig' | sed -n '/public static org.opensearch.security.auditlog.config.AuditConfig from(/,/public static java.util.Set/p'
```

`AuditConfig.from(Settings)` は、ノードの設定（`opensearch.yml`）から監査の設定を作ります。

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c 'org.opensearch.security.auditlog.impl.AuditLogImpl' | sed -n '/setConfig(/,/enableRoutes(/p'
```

`setConfig()` は受け取った設定をそのまま使います。`AuditLogImpl` が値を `true` に戻しているわけではありません。

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/lib/*:/usr/share/wazuh-indexer/plugins/opensearch-security/*' -p -c org.opensearch.security.OpenSearchSecurityPlugin | grep -n -B 8 -A 12 'AuditLogImpl.setConfig\|setConfig:(Lorg/opensearch/security/auditlog/config/AuditConfig'
```

`OpenSearchSecurityPlugin` から直接は呼ばれていません。設定を扱うクラスを探します。

```bash
/usr/share/wazuh-indexer/jdk/bin/jar tf /usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar | grep -Ei 'Audit|ConfigurationRepository|DynamicConfig|ConfigUpdate'
```

動的な設定を読み込むのは `ConfigurationRepository`、監査の API は `AuditApiAction` です。

### 1.3　ConfigurationRepository

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c org.opensearch.security.configuration.ConfigurationRepository | grep -n -B 8 -A 12 -Ei 'AuditConfig|auditLog|auditLogImpl|setConfig|onChange'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c org.opensearch.security.configuration.ConfigurationRepository | sed -n '/private void setupAuditConfigurationIfAny/,/private boolean createSecurityIndexIfAbsent/p'
```

`setupAuditConfigurationIfAny()` は、`.opendistro_security` に監査の設定の文書があるかで分かれます。

| 文書 | 動き |
|---|---|
| ある | `AuditConfig.from(settings)` を呼ばない（文書の設定を使う） |
| ない | `opensearch.yml` から設定を作って使う |

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c org.opensearch.security.configuration.ConfigurationLoaderSecurity7 | sed -n '/isAuditConfigDocPresentInIndex/,/^[[:space:]]*public/p'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c 'org.opensearch.security.configuration.ConfigurationLoaderSecurity7$2' | grep -n -B 10 -A 18 -Ei 'audit|isAuditConfigDocPresentInIndex|set\(|toConfig|AUDIT'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c 'org.opensearch.security.configuration.ConfigurationLoaderSecurity7$1' | grep -n -B 8 -A 16 -Ei 'audit|isAuditConfigDocPresentInIndex|success|CType|set\('
```

文書 `audit` が読めれば `isAuditConfigDocPresentInIndex = true`、なければ `false` にして、`opensearch.yml` から初期の設定を作ります。

```bash
journalctl -u wazuh-indexer --since "2026-11-21 08:20:00" --no-pager | grep -Ei 'Hot-reloading of audit configuration|Audit configuration settings found|Using configuration with defaults from opensearch settings'
```

ログには、どちらの経路を通ったかの記録はありませんでした。

## 第2章　文書があるかを確かめる

### 2.1　管理者の証明書

`admin` ユーザーのパスワードは使わず（わからなくてもリセットはしません）、管理者の証明書で接続します。

```bash
find /etc/wazuh-indexer -maxdepth 3 -type f \( -iname '*admin*.pem' -o -iname '*root-ca*.pem' -o -iname '*admin*.crt' -o -iname '*admin*.key' \) -printf '%p\n'
```

```bash
openssl x509 -in /etc/wazuh-indexer/certs/admin.pem -noout -subject -issuer -dates -ext extendedKeyUsage
```

構築時は CN が `admin`、有効期間は 2026年11月17日〜2036年11月14日でした。

### 2.2　文書 audit

文書の中身は取らず、あるかどうかだけを確かめます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/.opendistro_security/_doc/audit?filter_path=_index,_id,found'
```

構築時の結果は次のとおりで、文書はありました。

```text
_index: .opendistro_security
_id: audit
found: true
```

これで、`opensearch.yml` の変更が反映されなかった理由がわかりました。なお、この文書の `audit` は JSON ではなく、内部の形式の文字列（940文字）で保存されていたため、ここからは値を取り出していません。値は監査の API で確かめます。

### 2.3　監査のAPIでの値

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/_plugins/_security/api/audit' | python3 -c 'import json,sys; d=json.load(sys.stdin); print("log_request_body =",d["config"]["audit"].get("log_request_body","<not found>"))'
```

`log_request_body = True` でした。API の応答では、設定は `config` の下の `audit` の直下にあります。

```text
config
 ├─ compliance
 ├─ enabled
 └─ audit
```

## 第3章　監査のAPIで変える

### 3.1　変え方を確かめる

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c org.opensearch.security.dlic.rest.api.AuditApiAction
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c 'org.opensearch.security.dlic.rest.api.AuditApiAction$2'
```

- 監査の API は `PUT /_plugins/_security/api/audit/config` と `PATCH /_plugins/_security/api/audit` を受け付ける
- 変更は、監査の設定の再読み込み（ホットリロード）が有効なときだけできる（文書があるので有効）

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c org.opensearch.security.dlic.rest.api.AuditApiAction | grep -A100 -B10 'processPatchRequest\|lambda\$auditApiRequestHandlers\$2'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c org.opensearch.security.dlic.rest.api.AbstractApiAction | grep -A100 -B10 -E 'processPatchRequest|processPutRequest|processChangeRequest'
```

| 方法 | 動き |
|---|---|
| `PUT` | 設定の全体を置き換える（今回は使わない） |
| `PATCH` | 今の設定を読み、JSON Patch（`add`・`replace`・`remove`）を当てる。変わった項目だけを検証する |

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c 'org.opensearch.security.dlic.rest.api.AuditApiAction$AuditRequestContentValidator'
```

変更した後の設定の全体も検証されます。REST と Transport の記録しないカテゴリーなど、ほかの設定は今のまま残す必要があります。

### 3.2　今の設定

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/_plugins/_security/api/audit' | python3 -c 'import json,sys; d=json.load(sys.stdin); a=d["config"]["audit"]; print("log_request_body:",a.get("log_request_body")); print("exclude_sensitive_headers:",a.get("exclude_sensitive_headers")); print("enable_rest:",a.get("enable_rest")); print("enable_transport:",a.get("enable_transport")); print("disabled_rest_categories:",a.get("disabled_rest_categories")); print("disabled_transport_categories:",a.get("disabled_transport_categories")); print("ignore_users_count:",len(a.get("ignore_users",[]))); print("ignore_requests_count:",len(a.get("ignore_requests",[]))); print("ignore_headers_count:",len(a.get("ignore_headers",[]))); print("ignore_url_params_count:",len(a.get("ignore_url_params",[])))'
```

| 項目 | 今の値 |
|---|---|
| `log_request_body` | `true` |
| `exclude_sensitive_headers` | `true` |
| `enable_rest`・`enable_transport` | `true` |
| 記録しないカテゴリー（REST・Transport） | `AUTHENTICATED`・`GRANTED_PRIVILEGES` |
| `ignore_users` | 1件 |

JSON Patch の場所（JSON Pointer）と、読み取り専用の項目を確かめます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/_plugins/_security/api/audit' | python3 -c 'import json,sys; d=json.load(sys.stdin); c=d.get("config",{}); print("config_keys:",list(c)); print("audit_is_object:",isinstance(c.get("audit"),dict)); print("audit_pointer_value:",c.get("audit",{}).get("log_request_body")); print("readonly_paths:",d.get("_readonly"))'
```

`readonly_paths: []`（読み取り専用の項目はない）でした。変える場所は `/config/audit/log_request_body` です。

### 3.3　PATCH

`log_request_body` だけを `false` にします。ほかの監査の設定には触れません。Indexer の再起動は要りません。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem -X PATCH 'https://127.0.0.1:9200/_plugins/_security/api/audit' -H 'Content-Type: application/json' -d '[{"op":"replace","path":"/config/audit/log_request_body","value":false}]' -w '\nHTTP_STATUS:%{http_code}\n'
```

構築時は `Resource updated.` と `HTTP_STATUS:200` が返りました。

### 3.4　反映の確認

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/_plugins/_security/api/audit' | python3 -c 'import json,sys; d=json.load(sys.stdin); a=d["config"]["audit"]; print("AUDIT_ENABLED:",d["config"].get("enabled")); print("LOG_REQUEST_BODY:",a.get("log_request_body")); print("EXCLUDE_SENSITIVE_HEADERS:",a.get("exclude_sensitive_headers")); print("ENABLE_REST:",a.get("enable_rest")); print("ENABLE_TRANSPORT:",a.get("enable_transport")); print("DISABLED_REST_CATEGORIES:",a.get("disabled_rest_categories")); print("DISABLED_TRANSPORT_CATEGORIES:",a.get("disabled_transport_categories"))'
```

| 項目 | 結果 |
|---|---|
| 監査の全体 | 有効 |
| `LOG_REQUEST_BODY` | `False` |
| `EXCLUDE_SENSITIVE_HEADERS` | `True` |
| REST・Transport の監査 | 有効 |
| 記録しないカテゴリー | 変わらず |

これは監査ログに本文を記録しない設定です。ほかのアプリのログなどに本文が出ないことまでは保証しません。

## おわりに

第26部で、監査の設定がどこから読まれるかを突き止め、監査の API の PATCH で `log_request_body` を `false` にしました（再起動なし）。

| 設定の場所 | 役割 |
|---|---|
| `opensearch.yml` | 出力先（`plugins.security.audit.type`）。監査の文書がないときの初期の値 |
| `.opendistro_security` の文書 `audit` | 動いている監査の設定。監査の API（PATCH）で変える |

次の部では、監査ログが実際に保存されているか、本文が記録されていないかを確かめます。

# 第27部　監査ログが保存されていることを確かめる
## はじめに

### 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」中編の第27部です。第25部で監査ログの出力先を設定し、第26部でリクエストの本文を記録しないようにしました。ここでは、設定は変えずに**読み取りだけで**、次のことを確かめます。

1. 監査ログのインデックス（`security-auditlog-YYYY.MM.dd`）ができ、イベントが保存されている
2. 保存されたイベントに、リクエストの本文や認証のヘッダーが入っていない
3. 監査の設定が `.opendistro_security` に保存され、再起動のあとも読み込まれる作りである

本文やヘッダーの「値」は表示せず、項目の名前・件数・長さ・形だけを調べます。

### 本書の表記

- コマンドやプログラムは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 実行先は **security-core VM 220（root）** です。
- インデックスの名前 `security-auditlog-2026.11.21` は構築した日のものです。自分の環境の日付に置き換えてください。

## 第1章　保存先ができているか

### 1.1　起動のログ

```bash
journalctl -u wazuh-indexer -b --no-pager | grep -Ei 'audit|sink|message routing|default storage' | tail -n 60
```

構築時は何も出ませんでした。ログがないだけでは、出力先が作られていないとは言えません。

### 1.2　監査ログのインデックス

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/_cat/indices?format=json&h=index,health,status,docs.count,store.size' | python3 -c 'import json,sys; d=json.load(sys.stdin); rows=[x for x in d if "audit" in x.get("index","").lower()]; print("AUDIT_INDEX_COUNT:",len(rows)); [print(x) for x in rows]'
```

構築時は `security-auditlog-2026.11.21` があり、24件・103.7KB が保存されていました。監査ログは Indexer の中に保存されています。

### 1.3　yellowの理由

インデックスの状態は `yellow` でした。シャードを確かめます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/_cat/shards/security-auditlog-2026.11.21?format=json&h=index,shard,prirep,state,node,unassigned.reason'
```

| シャード | 状態 |
|---|---|
| プライマリ（p） | `STARTED`（node-1） |
| レプリカ（r） | `UNASSIGNED`（`INDEX_CREATED`） |

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/_cluster/health?pretty'
```

ノードは1つ、プライマリのシャード36個はすべて動いており、割り当てられていないのはこのインデックスのレプリカ1つだけでした。ノードが1つなので、レプリカを置く場所がないためです。保存の失敗ではありません。レプリカの数は変えず、`yellow` のままにします（不足情報メモ 27-A）。

## 第2章　何が保存されているか

### 2.1　1件の見本

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search?size=1&filter_path=hits.hits._source' | python3 -c 'import json,sys; d=json.load(sys.stdin); h=d.get("hits",{}).get("hits",[]); print("SAMPLE_COUNT:",len(h)); s=h[0].get("_source",{}) if h else {}; print("TOP_LEVEL_FIELDS:",sorted(s)); print("BODY_FIELD_NAMES:",sorted(k for k in s if any(x in k.lower() for x in ("body","payload","request"))))'
```

この1件には本文の項目はなく、REST のメソッド・パス・送信元・ユーザーなどの情報が保存されていました。ヘッダーと URL のパラメーターは、名前だけを見ます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search?size=1&filter_path=hits.hits._source.audit_rest_request_headers,hits.hits._source.audit_rest_request_params' | python3 -c 'import json,sys; d=json.load(sys.stdin); h=d.get("hits",{}).get("hits",[]); s=h[0].get("_source",{}) if h else {}; headers=s.get("audit_rest_request_headers"); params=s.get("audit_rest_request_params"); print("HEADER_FIELD_TYPE:",type(headers).__name__); print("HEADER_NAMES:",sorted(headers.keys()) if isinstance(headers,dict) else "not a map"); print("PARAM_FIELD_TYPE:",type(params).__name__); print("PARAM_NAMES:",sorted(params.keys()) if isinstance(params,dict) else "not a map")'
```

ヘッダーは `Accept`・`Host`・`User-Agent`、パラメーターは `filter_path` だけで、`Authorization` や `Cookie` はありませんでした。

### 2.2　すべてのイベント

本文らしい項目、認証のヘッダー、ヘッダーとパラメーターの名前、カテゴリーを数えます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search?size=100&filter_path=hits.hits._source' | python3 -c 'import json,sys,collections; d=json.load(sys.stdin); hs=d.get("hits",{}).get("hits",[]); body=[]; sensitive=[]; params=collections.Counter(); cats=collections.Counter(); headers=collections.Counter(); [cats.update([h.get("_source",{}).get("audit_category","UNKNOWN")]) for h in hs]; 
for h in hs:
 s=h.get("_source",{}); 
 for k in s:
  if any(x in k.lower() for x in ("request_body","requestbody","payload")): body.append(k)
 hd=s.get("audit_rest_request_headers",{}); 
 if isinstance(hd,dict):
  for k in hd:
   headers[k.lower()]+=1
   if k.lower() in ("authorization","proxy-authorization","cookie","set-cookie"): sensitive.append(k)
 p=s.get("audit_rest_request_params",{})
 if isinstance(p,dict): params.update(p.keys())
print("EVENTS_SCANNED:",len(hs)); print("BODY_FIELD_EVENT_COUNT:",len(body)); print("SENSITIVE_HEADER_EVENT_COUNT:",len(sensitive)); print("HEADER_NAME_COUNTS:",dict(headers)); print("PARAMETER_NAME_COUNTS:",dict(params)); print("AUDIT_CATEGORY_COUNTS:",dict(cats))'
```

構築時は86件を調べ、認証のヘッダーは0件でしたが、**本文らしい項目が15件**ありました。この15件を詳しく調べます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search?size=100&filter_path=hits.hits._source' | python3 -c 'import json,sys; d=json.load(sys.stdin); hs=d.get("hits",{}).get("hits",[]); n=0
for h in hs:
 s=h.get("_source",{}); ks=[k for k in s if any(x in k.lower() for x in ("request_body","requestbody","payload"))]
 if ks:
  n+=1
  print("EVENT",n,"TIMESTAMP:",s.get("@timestamp"),"CATEGORY:",s.get("audit_category"),"MATCHING_FIELD_NAMES:",ks)
print("MATCHING_EVENTS:",n,"SCANNED:",len(hs))'
```

15件とも、カテゴリーは `COMPLIANCE_INTERNAL_CONFIG_READ`（内部の設定の読み取り）、項目は `audit_request_body` でした。

### 2.3　audit_request_bodyの正体

値は表示せず、形だけを調べます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search?size=100&filter_path=hits.hits._source' | python3 -c 'import json,sys; d=json.load(sys.stdin); hs=d.get("hits",{}).get("hits",[]); n=0
for h in hs:
 s=h.get("_source",{})
 if "audit_request_body" in s:
  v=s["audit_request_body"]; n+=1
  empty=(v is None or v=="" or v=={} or v==[])
  length=len(v) if isinstance(v,(str,dict,list)) else None
  print("EVENT",n,"TIMESTAMP:",s.get("@timestamp"),"TYPE:",type(v).__name__,"IS_NULL:",v is None,"IS_EMPTY:",empty,"LENGTH:",length)
print("BODY_FIELD_EVENTS:",n)'
```

15件とも、25文字の文字列でした。内容が同じかを、ハッシュで比べます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search?size=100&filter_path=hits.hits._source' | python3 -c 'import json,sys,hashlib,collections; d=json.load(sys.stdin); vals=[h.get("_source",{}).get("audit_request_body") for h in d.get("hits",{}).get("hits",[]) if "audit_request_body" in h.get("_source",{})]; hashes=collections.Counter(hashlib.sha256(v.encode()).hexdigest() for v in vals if isinstance(v,str)); print("BODY_FIELD_COUNT:",len(vals)); print("UNIQUE_VALUE_COUNT:",len(hashes)); print("VALUE_FREQUENCIES:",sorted(hashes.values(),reverse=True)); print("ALL_VALUES_IDENTICAL:",len(hashes)==1 and len(vals)>0)'
```

15件すべて同じ値でした。文字の種類と形を調べます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search?size=100&filter_path=hits.hits._source' | python3 -c 'import json,sys; d=json.load(sys.stdin); vals=[h["_source"]["audit_request_body"] for h in d.get("hits",{}).get("hits",[]) if "audit_request_body" in h.get("_source",{})]; v=vals[0] if vals else ""; print("LENGTH:",len(v)); print("ASCII_ONLY:",v.isascii()); print("ALPHANUMERIC_ONLY:",v.isalnum()); print("JSON_PARSEABLE:",end=" "); 
try: json.loads(v); print("yes")
except Exception: print("no")
print("HAS_WHITESPACE:",any(c.isspace() for c in v)); print("HAS_BRACES:",any(c in "{}[]" for c in v)); print("HAS_COLON:",":" in v); print("HAS_QUOTES:",any(c in chr(34)+chr(39) for c in v))'
```

JSON として読めました。キーの名前と型だけを見ます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search?size=100&filter_path=hits.hits._source' | python3 -c 'import json,sys; d=json.load(sys.stdin); vals=[h["_source"]["audit_request_body"] for h in d.get("hits",{}).get("hits",[]) if "audit_request_body" in h.get("_source",{})]; v=json.loads(vals[0]) if vals else None; print("PARSED_TYPE:",type(v).__name__); print("TOP_LEVEL_KEYS:",sorted(v.keys()) if isinstance(v,dict) else "not_object"); 
for k,x in (v.items() if isinstance(v,dict) else []): print("FIELD:",k,"TYPE:",type(x).__name__,"LENGTH:",len(x) if isinstance(x,(str,dict,list)) else "n/a","NESTED_KEYS:",sorted(x.keys()) if isinstance(x,dict) else "n/a")'
```

形は次のとおりでした（値は伏せています）。

```text
{"field_names":[...]}
```

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search?size=100&filter_path=hits.hits._source' | python3 -c 'import json,sys; d=json.load(sys.stdin); vals=[json.loads(h["_source"]["audit_request_body"]) for h in d.get("hits",{}).get("hits",[]) if "audit_request_body" in h.get("_source",{})]; x=vals[0].get("field_names",[]) if vals else []; print("FIELD_NAMES_COUNT:",len(x)); print("ELEMENT_TYPES:",[type(v).__name__ for v in x]); print("ELEMENT_LENGTHS:",[len(v) if isinstance(v,(str,dict,list)) else None for v in x]); print("ALL_15_EVENTS_SAME_STRUCTURE:",all(v==vals[0] for v in vals))'
```

`field_names` の配列には5文字の文字列が1つだけで、15件とも同じ形でした。これは HTTP のリクエストの本文ではなく、内部の設定を読んだときの項目名の情報と考えられます。

### 2.4　カテゴリーごとの件数

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search?size=500&sort=@timestamp:desc&filter_path=hits.hits._source' | python3 -c 'import json,sys,collections; d=json.load(sys.stdin); hits=d.get("hits",{}).get("hits",[]); counts=collections.Counter(); body_counts=collections.Counter(); samples=collections.Counter(); 
for h in hits:
 s=h.get("_source",{}); c=s.get("audit_category","UNKNOWN"); counts[c]+=1
 if "audit_request_body" in s: body_counts[c]+=1
print("SCANNED_EVENTS:",len(hits)); print("CATEGORY_COUNTS:",dict(sorted(counts.items()))); print("BODY_FIELD_COUNTS_BY_CATEGORY:",dict(sorted(body_counts.items()))); print("BODY_FIELD_TOTAL:",sum(body_counts.values())); print("NON_COMPLIANCE_BODY_EVENTS:",sum(n for c,n in body_counts.items() if not c.startswith("COMPLIANCE_")))'
```

| カテゴリー | 件数 | `audit_request_body` あり |
|---|---:|---:|
| `COMPLIANCE_INTERNAL_CONFIG_READ` | 15 | 15 |
| `COMPLIANCE_INTERNAL_CONFIG_WRITE` | 1 | 0 |
| `FAILED_LOGIN` | 8 | 0 |
| `INDEX_EVENT` | 62 | 0 |

ふつうのイベント（`FAILED_LOGIN`・`INDEX_EVENT`）には本文の項目はありません。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search?size=500&sort=@timestamp:asc&filter_path=hits.hits._source.@timestamp,hits.hits._source.audit_category,hits.hits._source.audit_request_body' | python3 -c 'import json,sys,collections; d=json.load(sys.stdin); rows=[h["_source"] for h in d.get("hits",{}).get("hits",[]) if "audit_request_body" in h.get("_source",{})]; print("EVENT_COUNT:",len(rows)); print("FIRST_TIMESTAMP:",rows[0].get("@timestamp") if rows else "none"); print("LAST_TIMESTAMP:",rows[-1].get("@timestamp") if rows else "none"); print("CATEGORIES:",dict(collections.Counter(r.get("audit_category","UNKNOWN") for r in rows)))'
```

15件は 2026-11-21 08:27:45〜08:56:05（UTC）のものでした。

## 第3章　設定が残る作りか

### 3.1　今の設定

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/_plugins/_security/api/audit' | python3 -c 'import json,sys; d=json.load(sys.stdin); c=d.get("config",{}); a=c.get("audit",{}); print("AUDIT_ENABLED:",c.get("enabled")); print("LOG_REQUEST_BODY:",a.get("log_request_body")); print("EXCLUDE_SENSITIVE_HEADERS:",a.get("exclude_sensitive_headers")); print("ENABLE_REST:",a.get("enable_rest")); print("ENABLE_TRANSPORT:",a.get("enable_transport")); print("DISABLED_REST_CATEGORIES:",a.get("disabled_rest_categories")); print("DISABLED_TRANSPORT_CATEGORIES:",a.get("disabled_transport_categories"))'
```

`LOG_REQUEST_BODY: False` のままでした。

### 3.2　設定の文書

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/.opendistro_security/_doc/audit?filter_path=_index,_id,_version,_seq_no,_primary_term,found'
```

構築時は `found: true`、`_version: 2` でした。PATCH による変更は、文書として保存されています。

### 3.3　起動のときの読み込み

```bash
 /usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c org.opensearch.security.configuration.ConfigurationRepository | grep -n -A45 -B12 'setupAuditConfigurationIfAny'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c org.opensearch.security.configuration.ConfigurationLoaderSecurity7 | grep -n -A55 -B15 'isAuditConfigDocPresentInIndex'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c 'org.opensearch.security.configuration.ConfigurationLoaderSecurity7$1' | grep -n -A35 -B15 -E 'AUDIT|isAuditConfigDocPresentInIndex|AtomicBoolean|set:|noData|success'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c org.opensearch.security.configuration.ConfigurationRepository | grep -n -A35 -B15 -E 'auditLog\.setConfig|AuditConfig|onChange|executeConfigurationInitialization'
```

1. 設定は `.opendistro_security` の文書 `audit` に保存される
2. 起動のとき `ConfigurationLoaderSecurity7` が文書を読み、「文書がある」という印を立てる
3. `ConfigurationRepository` が読んだ設定を反映し、監査の設定の再読み込み（ホットリロード）を有効にする

この作りなので、再起動のあとも、PATCH で変えた設定が使われます（再起動して確かめることはしていません）。

なお、構築時には、設定が変わったときに `AuditLogImpl.setConfig()` を呼ぶクラスもコードで探しましたが、特定には至らず、必要性が低いとして打ち切りました。その手順は本書には載せていません。

## 第4章　集計で確かめる

### 4.1　集計がうまくいかない

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem -w '\nHTTP_STATUS:%{http_code}\n' 'https://127.0.0.1:9200/security-auditlog-*/_search?size=0&track_total_hits=true' | python3 -c 'import json,sys; s=sys.stdin.read(); body=s.split("\nHTTP_STATUS:")[0]; status=s.split("\nHTTP_STATUS:")[-1].strip() if "\nHTTP_STATUS:" in s else "unknown"; print("HTTP_STATUS:",status); d=json.loads(body); print("TOP_LEVEL_KEYS:",list(d.keys())); print("ERROR_TYPE:",d.get("error",{}).get("type") if isinstance(d.get("error"),dict) else None); print("ERROR_REASON:",d.get("error",{}).get("reason") if isinstance(d.get("error"),dict) else None); print("HITS_KEYS:",list(d.get("hits",{}).keys()))'
```

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/_cat/indices/security-auditlog-*?format=json&h=index,docs.count,status' | python3 -c 'import json,sys; d=json.load(sys.stdin); print("INDEX_COUNT:",len(d)); [print("INDEX:",x.get("index"),"DOCS:",x.get("docs.count"),"STATUS:",x.get("status")) for x in d]'
```

検索は `HTTP 200` で、インデックスには88件ありました。ところが、`audit_category` で集計しようとすると結果が返りません。応答のエラーを見ます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem -H 'Content-Type: application/json' 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search' -d '{"size":0,"track_total_hits":true,"aggs":{"categories":{"terms":{"field":"audit_category","size":30}}}}' | python3 -c 'import json,sys; d=json.load(sys.stdin); print("TOP_LEVEL_KEYS:",list(d)); print("ERROR:",d.get("error")); h=d.get("hits"); print("HITS_TYPE:",type(h).__name__); print("HITS_TOTAL:",h.get("total") if isinstance(h,dict) else None); print("AGGREGATIONS_TYPE:",type(d.get("aggregations")).__name__); print("AGGREGATION_KEYS:",list(d.get("aggregations",{})) if isinstance(d.get("aggregations"),dict) else None); print("SHARDS:",d.get("_shards"))'
```

`audit_category` は `text` 型で、集計に必要な `fielddata` が無効のため、すべてのシャードで集計が失敗していました。`fielddata` は有効にせず（メモリを多く使うため）、`keyword` 型の項目があるかを確かめます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_mapping' | python3 -c 'import json,sys; d=json.load(sys.stdin); m=next(iter(d.values())).get("mappings",{}).get("properties",{}); print("audit_category:",m.get("audit_category")); print("audit_request_body:",m.get("audit_request_body")); print("audit_rest_request_headers:",m.get("audit_rest_request_headers"))'
```

`audit_category.keyword` と `audit_request_body.keyword` がありました。

### 4.2　keywordで集計する

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem -H 'Content-Type: application/json' 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search' -d '{"size":0,"track_total_hits":true,"aggs":{"categories":{"terms":{"field":"audit_category.keyword","size":30}},"request_body_present":{"filter":{"exists":{"field":"audit_request_body"}}}}}' | python3 -c 'import json,sys; d=json.load(sys.stdin); print("ERROR_TYPE:",d.get("error",{}).get("type") if isinstance(d.get("error"),dict) else None); h=d.get("hits",{}); t=h.get("total"); print("TOTAL_EVENTS:",t.get("value") if isinstance(t,dict) else t); a=d.get("aggregations",{}); print("CATEGORIES:",{x["key"]:x["doc_count"] for x in a.get("categories",{}).get("buckets",[])}); print("REQUEST_BODY_PRESENT:",a.get("request_body_present",{}).get("doc_count"))'
```

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem -H 'Content-Type: application/json' 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search' -d '{"size":0,"aggs":{"categories":{"terms":{"field":"audit_category.keyword","size":30},"aggs":{"body_present":{"filter":{"exists":{"field":"audit_request_body"}}}}}}}' | python3 -c 'import json,sys; d=json.load(sys.stdin); print("ERROR_TYPE:",d.get("error",{}).get("type") if isinstance(d.get("error"),dict) else None); b=d.get("aggregations",{}).get("categories",{}).get("buckets",[]); [print("CATEGORY:",x["key"],"EVENTS:",x["doc_count"],"BODY_PRESENT:",x["body_present"]["doc_count"]) for x in b]'
```

| カテゴリー | 件数 | 本文の項目あり |
|---|---:|---:|
| `INDEX_EVENT` | 63 | 0 |
| `COMPLIANCE_INTERNAL_CONFIG_READ` | 17 | 17 |
| `FAILED_LOGIN` | 8 | 0 |
| `COMPLIANCE_INTERNAL_CONFIG_WRITE` | 1 | 0 |

### 4.3　17件の形

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem -H 'Content-Type: application/json' 'https://127.0.0.1:9200/security-auditlog-2026.11.21/_search' -d '{"size":20,"_source":["audit_category","audit_request_body"],"query":{"bool":{"filter":[{"term":{"audit_category.keyword":"COMPLIANCE_INTERNAL_CONFIG_READ"}},{"exists":{"field":"audit_request_body"}}]}}}' | python3 -c 'import json,sys; d=json.load(sys.stdin); h=d.get("hits",{}).get("hits",[]); print("SAMPLED_DOCS:",len(h)); import collections; stats=collections.Counter(); keys=collections.Counter(); shapes=collections.Counter(); 
for x in h:
 v=x.get("_source",{}).get("audit_request_body")
 if isinstance(v,str):
  stats[len(v)]+=1
  try:
   import json as j
   o=j.loads(v); shapes[type(o).__name__]+=1
   if isinstance(o,dict): keys[tuple(sorted(o.keys()))]+=1
  except Exception: shapes["invalid_json"]+=1
 else: shapes[type(v).__name__]+=1
print("LENGTH_COUNTS:",dict(stats)); print("JSON_SHAPES:",dict(shapes)); print("TOP_LEVEL_KEY_SETS:",{str(k):v for k,v in keys.items()})'
```

17件すべて、25文字の JSON で、キーは `field_names` だけでした。

### 4.4　設定とログの照合

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/_plugins/_security/api/audit' | python3 -c 'import json,sys; d=json.load(sys.stdin); c=d.get("config",{}); a=c.get("audit",{}); m=c.get("compliance",{}); print("AUDIT_ENABLED:",c.get("enabled")); print("LOG_REQUEST_BODY:",a.get("log_request_body")); print("EXCLUDE_SENSITIVE_HEADERS:",a.get("exclude_sensitive_headers")); print("REST_ENABLED:",a.get("enable_rest")); print("TRANSPORT_ENABLED:",a.get("enable_transport")); print("COMPLIANCE_ENABLED:",m.get("enabled")); print("COMPLIANCE_READ_METADATA_ONLY:",m.get("read_metadata_only")); print("COMPLIANCE_WRITE_METADATA_ONLY:",m.get("write_metadata_only"))'
```

| 項目 | 値 |
|---|---|
| 監査 | 有効 |
| REST・Transport の監査 | 有効 |
| リクエストの本文の記録 | `false` |
| 機密のヘッダーを除く | `true` |
| Compliance | 有効（読み取り・書き込みともメタデータだけ） |

## おわりに

第27部で、次のことを確かめました。

| 項目 | 結果 |
|---|---|
| 監査ログの保存 | `security-auditlog-YYYY.MM.dd` に保存されている（構築時 89件） |
| リクエストの本文 | ふつうのイベントには記録されていない |
| `audit_request_body` がある 17件 | 内部の設定の読み取りの固定の形（`{"field_names":[...]}`）だけ |
| 認証のヘッダー | 記録されていない |
| 設定 | `.opendistro_security` に保存され、起動のときに読み込まれる作り |
| インデックスの状態 | ノードが1つのため `yellow`（レプリカを置けない） |

すべての REST の操作・すべてのイベントの種類を試したわけではありません。次の部では、Wazuh のアラートを PostgreSQL に送る Collector を点検します。

# 第28部　Collectorの点検と停止の原因
## はじめに

### 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」中編の第28部です。Wazuh のアラート（`alerts.json`）を PostgreSQL（LXC 109）に送る Collector（`/usr/local/lib/wazuh-collector/collector.py`、前編 第3部〜第9部）について、次のことを行います。

1. コードを読み、PostgreSQL に何を保存しているかを点検する（読み取りだけ）
2. 点検の途中で、Collector が**再起動を繰り返して止まっている**ことがわかったので、原因を調べる

原因は2つありました。前編 第9部で起きたことと同じです。

| # | 原因 |
|---|---|
| 1 | ログの切り替え（日ごとのローテーション）で新しくできた `alerts.json` に、Collector の読み取りのACLが付いていなかった |
| 2 | Collector が、前に読んでいたファイル（保存した inode）を探す途中で、前に作った試験用の隠しディレクトリ（`.acl-inheritance-test.bkv8vd`）に入れずに止まった |

本書では1つ目を直し、2つ目の原因を突き止めるところまでを扱います。復旧は第29部、再発の防止は第30部で行います。

### 本書の表記

- コマンドやプログラムは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 実行先は **security-core VM 220（root）** です。
- コードを表示するプログラムは、パスワード・トークン・接続文字列などを含む行を `[SENSITIVE LINE OMITTED]` に置き換えて表示します。

## 第1章　保存する内容の点検

### 1.1　関数の構成

```bash
python3 - <<'PY'
import re
p = "/usr/local/lib/wazuh-collector/collector.py"
patterns = re.compile(
    r'^\s*(async\s+)?def\s+|^\s*class\s+|INSERT_SQL|'
    r'extract_event|process_line|full_log|audit_request_body|'
    r'field_names|UniqueViolation|SAVEPOINT|ROLLBACK TO'
)
with open(p, encoding="utf-8") as f:
    for n, line in enumerate(f, 1):
        if patterns.search(line):
            if re.search(r'password|passwd|secret|token|dsn|api_key', line, re.I):
                print(f"{n}: [SENSITIVE LINE OMITTED]")
            else:
                print(f"{n}: {line.rstrip()[:180]}")
PY
```

`extract_event()` でイベントの項目を取り出し、`process_line()` から `INSERT_SQL` で保存する作りです。

### 1.2　取り出す項目とINSERT

```bash
python3 - <<'PY'
p = "/usr/local/lib/wazuh-collector/collector.py"
ranges = [(41, 80), (191, 248), (504, 525)]
with open(p, encoding="utf-8") as f:
    lines = f.readlines()
for start, end in ranges:
    print(f"\n===== collector.py:{start}-{end} =====")
    for n in range(start, min(end, len(lines)) + 1):
        line = lines[n-1]
        if any(x in line.lower() for x in ("password", "passwd", "secret", "token", "dsn", "api_key")):
            print(f"{n}: [SENSITIVE LINE OMITTED]")
        else:
            print(f"{n}: {line.rstrip()}")
PY
```

- INSERT する列は13に決まっている
- `full_log`・`audit_request_body`・イベントの `data` の全体は保存しない（`data` からは `srcip` と `srcport` だけを取る）
- `UniqueViolation` は SQLSTATE `23505`（同じ `event_id`）のときだけ「重複」として扱う
- DB への書き込みはトランザクションの中で行う

### 1.3　文字列の整え方

```bash
python3 - <<'PY'
p = "/usr/local/lib/wazuh-collector/collector.py"
ranges = [(126, 190)]
with open(p, encoding="utf-8") as f:
    lines = f.readlines()
for start, end in ranges:
    print(f"===== collector.py:{start}-{end} =====")
    for n in range(start, min(end, len(lines)) + 1):
        print(f"{n}: {lines[n-1].rstrip()}")
PY
```

`safe_text()` は、制御文字・見えない書式の文字を取り除き、前後の空白を取り、長さを制限します。MITRE の情報は `id`・`tactic`・`technique` の3つだけです。ただし、これは形を整える処理で、パスワードやユーザー名を意味で見つけて取り除く処理ではありません（`rule.description`・`agent.name` などはそのまま保存されます。不足情報メモ 28-A）。

### 1.4　読み続ける処理

```bash
python3 - <<'PY'
p = "/usr/local/lib/wazuh-collector/collector.py"
with open(p, encoding="utf-8") as f:
    lines = f.readlines()
for n in range(526, min(590, len(lines)) + 1):
    line = lines[n-1]
    if any(x in line.lower() for x in ("password", "passwd", "secret", "token", "dsn", "api_key")):
        print(f"{n}: [SENSITIVE LINE OMITTED]")
    else:
        print(f"{n}: {line.rstrip()}")
PY
```

```bash
python3 - <<'PY'
p = "/usr/local/lib/wazuh-collector/collector.py"
ranges = [(249, 296), (458, 503), (579, 680)]
with open(p, encoding="utf-8") as f:
    lines = f.readlines()
for start, end in ranges:
    print(f"\n===== collector.py:{start}-{end} =====")
    for n in range(start, min(end, len(lines)) + 1):
        print(f"{n}: {lines[n-1].rstrip()}")
PY
```

- PostgreSQL につながらないときは、その行の頭に戻り、5秒後にやり直す
- 処理に失敗したときも行の頭に戻り、接続を閉じてつなぎ直す
- 接続のエラーのログには、例外の種類の名前だけを書く（接続の情報を出さない）

```bash
python3 - <<'PY'
p = "/usr/local/lib/wazuh-collector/collector.py"
with open(p, encoding="utf-8") as f:
    lines = f.readlines()
for n in range(675, min(760, len(lines)) + 1):
    line = lines[n-1]
    if any(x in line.lower() for x in ("password", "passwd", "secret", "token", "dsn", "api_key")):
        print(f"{n}: [SENSITIVE LINE OMITTED]")
    else:
        print(f"{n}: {line.rstrip()}")
PY
```

- 読み取り位置（状態ファイル）は、一時ファイルに書いて `fsync` してから `os.replace` で置き換える（権限 `0600`）
- 長すぎる行は、中身をログに出さずに読み飛ばす
- ファイルが切り替わったら、新しい inode のファイルの先頭から読む
- 終わるときは、ファイルと DB の接続を閉じる

### 1.5　状態ファイルの検証

```bash
python3 - <<'PY'
p = "/usr/local/lib/wazuh-collector/collector.py"
with open(p, encoding="utf-8") as f:
    lines = f.readlines()
for n in range(297, 328):
    print(f"{n}: {lines[n-1].rstrip()}")
PY
```

`load_state()` は、中身が辞書でない・`inode` や `offset` が整数の範囲にないときは、先頭から読み直すのではなく `RuntimeError` で止まります。状態ファイルがないときだけ、初めての起動として扱います。

```bash
python3 - <<'PY'
p = "/usr/local/lib/wazuh-collector/collector.py"
with open(p, encoding="utf-8") as f:
    lines = f.readlines()
for n in range(81, 116):
    print(f"{n}: {lines[n-1].rstrip()}")
PY
```

`safe_integer()` は `bool`（Python では `int` の仲間）を整数として受け付けず、文字列は ASCII の数字だけ・20桁までに限ります。`parse_timestamp()` はタイムゾーンのない日時を受け付けません。

### 1.6　ファイルの開き方

```bash
python3 - <<'PY'
p = "/usr/local/lib/wazuh-collector/collector.py"
ranges = [(328, 457)]
with open(p, encoding="utf-8") as f:
    lines = f.readlines()
for start, end in ranges:
    print(f"===== collector.py:{start}-{end} =====")
    for n in range(start, min(end, len(lines)) + 1):
        line = lines[n-1]
        if any(x in line.lower() for x in ("password", "passwd", "secret", "token", "dsn", "api_key")):
            print(f"{n}: [SENSITIVE LINE OMITTED]")
        else:
            print(f"{n}: {line.rstrip()}")
PY
```

- 保存した inode と今のファイルを比べ、切り替わっていれば前の inode のファイルを探して続きを読む
- 前のファイルが見つからない・保存した位置がファイルより大きいときは、**黙って読み飛ばさずに止まる**
- ディレクトリを探すとき、シンボリックリンクはたどらない。圧縮したファイルは探さない

`safe_open_current_alert_file()` という名前ですが、中身は次の2行だけでした（コードの一部）。

```text
handle = ALERT_FILE.open("rb")
actual_stat = os.fstat(handle.fileno())
```

`O_NOFOLLOW`（シンボリックリンクを開かない）や通常のファイルかどうかの確認はありません。権限を確かめます。

```bash
python3 - <<'PY'
import os
import stat
from pathlib import Path

p = Path("/var/ossec/logs/alerts")
for path in (Path("/var/ossec"), Path("/var/ossec/logs"), p, p / "alerts.json"):
    try:
        s = path.lstat()
        print(
            f"{path}: "
            f"type={'symlink' if stat.S_ISLNK(s.st_mode) else 'regular' if stat.S_ISREG(s.st_mode) else 'directory' if stat.S_ISDIR(s.st_mode) else 'other'} "
            f"owner={s.st_uid}:{s.st_gid} "
            f"mode={stat.S_IMODE(s.st_mode):04o}"
        )
    except OSError as e:
        print(f"{path}: {type(e).__name__}")
PY
```

| 対象 | 持ち主 | 権限 |
|---|---|---|
| `/var/ossec` | root:110 | 0750 |
| `/var/ossec/logs` | 110:110 | 0770 |
| `/var/ossec/logs/alerts` | 110:110 | 0750 |
| `alerts.json` | 110:110 | 0640 |

`/var/ossec/logs` はグループ110が書き込めます。すぐに変える必要はないと判断しました（不足情報メモ 28-B）。

## 第2章　Collectorが止まっていた

### 2.1　サービスの状態

```bash
id
```

今のシェルは root です。Collector のサービスの状態を見ます。

```bash
systemctl list-units --type=service --all --no-legend | grep -i collector
```

`wazuh-collector.service` は `activating (auto-restart)`（再起動を繰り返している）でした。

```bash
systemctl show wazuh-collector.service \
  -p User -p Group -p DynamicUser -p MainPID \
  -p ExecMainCode -p ExecMainStatus \
  -p NRestarts -p Result
```

| 項目 | 値 |
|---|---|
| `User`・`Group` | `wazuh-collector` |
| `MainPID` | 0（プロセスがない） |
| `Result` | `exit-code` |
| `ExecMainStatus` | 1 |
| `NRestarts` | 350 |

### 2.2　1つ目の原因

```bash
journalctl -u wazuh-collector.service -n 50 --no-pager -o short-iso
```

起動のときに `alerts.json` を開けずに終わっていました。

```text
PermissionError: [Errno 13] Permission denied
/var/ossec/logs/alerts/alerts.json
```

```bash
printf '%s\n' '===== collector account ====='
id wazuh-collector
getent passwd wazuh-collector
getent group wazuh-collector
printf '%s\n' '===== directory permissions ====='
namei -l /var/ossec/logs/alerts/alerts.json
printf '%s\n' '===== ACL ====='
getfacl -p /var/ossec/logs /var/ossec/logs/alerts /var/ossec/logs/alerts/alerts.json
```

| 対象 | Collector の権限 |
|---|---|
| `/var/ossec/logs` | ACL で `--x`（通れる） |
| `/var/ossec/logs/alerts` | ACL で `r-x`（通れる） |
| `alerts.json` | **読み取りの権限がない** |

`alerts` ディレクトリには既定の ACL がありますが、ローテーションで新しくできた `alerts.json` には反映されていませんでした（前編 第9部 1.3 と同じです）。

```bash
runuser -u wazuh-collector -- test -r /var/ossec/logs/alerts/alerts.json
echo "READ_TEST_EXIT_CODE=$?"
```

`READ_TEST_EXIT_CODE=1` で、読めないことを確かめました。

### 2.3　読み取りのACLを足す

Collector のユーザーに**読み取りだけ**を足します。書き込みや削除の権限は足しません。

```bash
setfacl -m u:wazuh-collector:r-- /var/ossec/logs/alerts/alerts.json
```

```bash
runuser -u wazuh-collector -- test -r /var/ossec/logs/alerts/alerts.json
echo "READ_TEST_EXIT_CODE=$?"
getfacl -p /var/ossec/logs/alerts/alerts.json
```

`READ_TEST_EXIT_CODE=0` になり、ACL は `user:wazuh-collector:r--` だけでした。

### 2.4　2つ目の原因

systemd の自動の再起動で動き出したかを見ます。

```bash
systemctl status wazuh-collector.service --no-pager -l
```

```bash
journalctl -u wazuh-collector.service -n 35 --no-pager -o short-iso
```

まだ起動に失敗していました。今度は、前に読んでいたファイル（保存した inode）を探すときに、`/var/ossec/logs/alerts/.acl-inheritance-test.bkv8vd` に入れずに止まっていました。

```bash
stat -c 'TYPE=%F OWNER=%U:%G MODE=%a INODE=%i PATH=%n' /var/ossec/logs/alerts/.acl-inheritance-test.bkv8vd
getfacl -p /var/ossec/logs/alerts/.acl-inheritance-test.bkv8vd
```

| 項目 | 値 |
|---|---|
| 持ち主・権限 | `root:root`、`700` |
| Collector の ACL | `r-x` があるが、ACL のマスクが `---` |
| 実際の権限 | `---`（入れない） |

これは前編 第6部で ACL の継承を試したときに作ったディレクトリです（前編 第9部で「残ったまま」と記録しています）。

```bash
find /var/ossec/logs/alerts -maxdepth 1 -name '.acl-inheritance-test*' -printf '%M %u:%g %p\n'
```

```bash
find /var/ossec/logs/alerts/.acl-inheritance-test.bkv8vd -maxdepth 2 -printf '%y %M %u:%g %s %p\n'
```

```bash
find /var/ossec/logs/alerts/.acl-inheritance-test.bkv8vd -printf '%y %M %u:%g %s %p\n'
```

中は `2027/Jan/test.json`（0バイト）だけで、すべて `root:root` でした。本物のアラートのログではありません。

### 2.5　探す処理と保存した位置

```bash
sed -n '1,80p;328,365p' /usr/local/lib/wazuh-collector/collector.py
```

`find_inode_file()` は `alerts` の下のディレクトリをすべてたどり、1か所でも入れないと、探すこと全体をやめます（探しきれないまま「見つからない」と答えないための、安全側の作りです）。

保存した位置と、今のファイルを比べます（状態ファイルの全体は表示しません）。

```bash
python3 - <<'PY'
import json, os
from pathlib import Path

state_path = Path("/var/lib/wazuh-collector/state.json")
alert_path = Path("/var/ossec/logs/alerts/alerts.json")

try:
    state = json.loads(state_path.read_text())
    print("STATE_INODE:", state.get("inode"))
    print("STATE_OFFSET:", state.get("offset"))
except Exception as e:
    print("STATE_READ_ERROR:", type(e).__name__)

try:
    st = alert_path.stat()
    print("CURRENT_INODE:", st.st_ino)
    print("CURRENT_SIZE:", st.st_size)
except Exception as e:
    print("CURRENT_FILE_ERROR:", type(e).__name__)
PY
```

| 項目 | 値 |
|---|---|
| 保存した inode | 5409383 |
| 今の `alerts.json` の inode | 5409517 |
| 保存した位置（offset） | 6,433,808 |
| 今のファイルの大きさ | 564,829 バイト |

ローテーションのあとで、Collector は前の inode 5409383 のファイルを探す必要があります。探す処理を単に止めると、前のファイルの読み残しを取りこぼすおそれがあります。

```bash
find /var/ossec/logs/alerts -xdev -type f -inum 5409383 -printf 'FOUND=%p SIZE=%s OWNER=%u:%g MODE=%m\n'
```

inode 5409383 のファイルは見つかりませんでした。

```bash
sed -n '365,430p' /usr/local/lib/wazuh-collector/collector.py
```

前の inode が見つからないときは、`Previous alert file cannot be located; refusing unsafe resume` で止まる作りです。読み残しを黙って飛ばさないための、正しい安全策です。

## おわりに

第28部でわかったことは次のとおりです。

| 項目 | 結果 |
|---|---|
| 保存する内容 | 13列に限っている。`full_log`・`data` の全体は保存しない |
| 文字列の整え方 | 形を整えるだけで、秘密の情報を見つけて除く処理ではない |
| 停止の原因1 | 新しい `alerts.json` に読み取りの ACL がない → **足した** |
| 停止の原因2 | 試験用の隠しディレクトリに入れず、前のファイルを探せない |
| 前のファイル | inode 5409383 は見つからない（Collector は安全のため止まる） |

次の部では、前のファイルがどうなったかを確かめ、読み残しを出さずに Collector を動かし直します。

# 第29部　読み残しを出さずにCollectorを動かし直す
## はじめに

### 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」中編の第29部です。第28部で、Collector は「前に読んでいたファイル（inode 5409383）が見つからない」ため、安全のために起動を止めていることがわかりました。ここでは次のことを行います。

1. 前のファイルがどうなったかを、ログのファイル・圧縮ファイル・チェックサムで確かめる
2. 保存した読み取り位置が、前のファイルの**最後**だったことを確かめる
3. PostgreSQL の重複を防ぐ仕組みを確かめたうえで、読み取り位置を「今の `alerts.json` の先頭」に書き換える
4. Collector を動かし、PostgreSQL に取り込まれたことを確かめる

読み取り位置を勝手に今のファイルの最後に進めると、読み残しが出ます。根拠を1つずつ確かめてから進めます。

### 本書の表記

- コマンドやプログラムは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 実行先は、各手順の「実行先」に示します。
  - **VM 220**：security-core（root）
  - **postgresql**：LXC 109（192.168.0.151）。OS のユーザー `postgres`
- アラートの本文は表示しません。PostgreSQL のパスワードは `.pgpass` から読み、表示しません。
- inode・大きさ・時刻・件数は構築時のものです。自分の環境の値に置き換えてください。

## 第1章　前のファイルを探す

> **実行先：VM 220**

### 1.1　ログのファイル

```bash
find /var/ossec/logs/alerts -maxdepth 3 -type f -printf '%i %s %M %u:%g %p\n' | sort -k6
```

11月17日〜20日の圧縮した JSON のログ（`2026/Nov/ossec-alerts-*.json.gz`）と、21日の今のログが残っていました。inode 5409383 はありません。Collector の探す処理は `.json` で終わるファイルだけを対象にし、`.json.gz` は探しません。

```bash
if command -v lsof >/dev/null 2>&1; then lsof -nP +L1 2>/dev/null | grep -E '5409383|alerts' || true; else echo "lsof_NOT_INSTALLED"; fi
```

消されたあとも開いたままになっているファイルもありませんでした。

```bash
stat -c 'INODE=%i SIZE=%s MTIME=%y PATH=%n' /var/ossec/logs/alerts/2026/Nov/ossec-alerts-*.json*
```

JSON のログは日ごとに切り替わり、17〜20日の分が圧縮され、21日の分が今の `alerts.json` になっています。

### 1.2　20日の分の大きさ

```bash
gzip -l /var/ossec/logs/alerts/2026/Nov/ossec-alerts-*.json.gz
```

20日の分を展開したときの大きさは **6,433,808 バイト**で、保存した読み取り位置と同じでした。

```bash
gzip -t /var/ossec/logs/alerts/2026/Nov/ossec-alerts-20.json.gz
echo "GZIP_TEST_EXIT_CODE=$?"
```

圧縮ファイルは壊れていません（`GZIP_TEST_EXIT_CODE=0`）。展開しながら（ディスクには書かずに）、行の数と形を調べます。

```bash
python3 - <<'PY'
import gzip, json

path = "/var/ossec/logs/alerts/2026/Nov/ossec-alerts-20.json.gz"
total = 0
lines = 0
invalid = 0
last_byte = None

with gzip.open(path, "rb") as f:
    while True:
        chunk = f.readline()
        if not chunk:
            break
        total += len(chunk)
        lines += 1
        last_byte = chunk[-1:]
        try:
            json.loads(chunk)
        except Exception:
            invalid += 1

print("UNCOMPRESSED_BYTES:", total)
print("LINE_COUNT:", lines)
print("INVALID_JSON_LINES:", invalid)
print("ENDS_WITH_NEWLINE:", last_byte == b"\n")
print("SAVED_OFFSET_MATCH:", total == 6433808)
PY
```

| 項目 | 結果 |
|---|---|
| 展開した大きさ | 6,433,808 バイト（保存した位置と一致） |
| 行の数 | 10,293 |
| JSON として読めない行 | 0 |
| 最後の改行 | あり |

### 1.3　時刻とチェックサム

```bash
stat -c 'MTIME=%y CTIME=%z SIZE=%s PATH=%n' /var/lib/wazuh-collector/state.json /var/ossec/logs/alerts/2026/Nov/ossec-alerts-20.json.gz /var/ossec/logs/alerts/2026/Nov/ossec-alerts-20.json.sum
file /var/ossec/logs/alerts/2026/Nov/ossec-alerts-20.json.sum
```

状態ファイルの保存は 11月20日 23:54:26（UTC）、20日の分の圧縮は 11月21日 00:00:10（UTC）でした。保存したときは、20日の分が今のファイルでした。

Wazuh が作ったチェックサムのファイル（37バイト）を見ます。

```bash
cat /var/ossec/logs/alerts/2026/Nov/ossec-alerts-20.json.sum
```

圧縮する前の 20日の分の SHA-256 が記録されていました。

```text
7b07b435669a8c98892f4919295644c21bfdb35522f3747e21366f6ba0aafe79
```

展開しながら SHA-256 を計算し、記録と比べます。値は自分の環境の `.sum` の値に置き換えてください。

```bash
python3 - <<'PY'
import gzip, hashlib

path = "/var/ossec/logs/alerts/2026/Nov/ossec-alerts-20.json.gz"
expected = "7b07b435669a8c98892f4919295644c21bfdb35522f3747e21366f6ba0aafe79"

h = hashlib.sha256()
size = 0

with gzip.open(path, "rb") as f:
    while True:
        chunk = f.read(1024 * 1024)
        if not chunk:
            break
        h.update(chunk)
        size += len(chunk)

actual = h.hexdigest()
print("UNCOMPRESSED_BYTES:", size)
print("ACTUAL_SHA256:", actual)
print("EXPECTED_SHA256:", expected)
print("CHECKSUM_MATCH:", actual == expected)
PY
```

`CHECKSUM_MATCH: True` でした。

### 1.4　今のファイル

```bash
python3 - <<'PY'
import json
from pathlib import Path

p = Path("/var/ossec/logs/alerts/alerts.json")
size = 0
lines = 0
invalid = 0
last_byte = None

with p.open("rb") as f:
    while True:
        line = f.readline()
        if not line:
            break
        size += len(line)
        lines += 1
        last_byte = line[-1:]
        try:
            json.loads(line)
        except Exception:
            invalid += 1

print("CURRENT_INODE:", p.stat().st_ino)
print("CURRENT_BYTES:", size)
print("LINE_COUNT:", lines)
print("INVALID_JSON_LINES:", invalid)
print("ENDS_WITH_NEWLINE:", last_byte == b"\n")
PY
```

21日の分も、読めない行はありませんでした。境目の時刻を比べます。

```bash
python3 - <<'PY'
import gzip, json

archive = "/var/ossec/logs/alerts/2026/Nov/ossec-alerts-20.json.gz"
current = "/var/ossec/logs/alerts/alerts.json"

last = None
with gzip.open(archive, "rb") as f:
    for line in f:
        if line.strip():
            last = json.loads(line)

with open(current, "rb") as f:
    first = json.loads(f.readline())

print("ARCHIVE_LAST_TIMESTAMP:", last.get("timestamp"))
print("CURRENT_FIRST_TIMESTAMP:", first.get("timestamp"))
PY
```

| 項目 | 時刻（UTC） |
|---|---|
| 20日の分の最後のイベント | 11/20 23:54:26.205 |
| 状態ファイルの保存 | 11/20 23:54:26.714 |
| 21日の分の最初のイベント | 11/21 00:09:26.253 |

保存した読み取り位置は、20日の分の最後に当たります。したがって、**今の `alerts.json`（inode 5409517）を先頭（offset 0）から読めばよい**ことになります。ただし、この15分のあいだにアラートがなかったことまでは証明できません。

### 1.5　重複を防ぐ仕組み

21日の分の一部は、Collector がまだ動いていたときに取り込まれている可能性があります。先頭から読み直しても二重に登録されないかを確かめます。

```bash
PGPASSFILE=/etc/wazuh-collector/.pgpass psql "host=postgresql.neomedia.mydns.jp hostaddr=192.168.0.151 port=5432 dbname=security_workbench user=wazuh_collector sslmode=verify-full sslrootcert=/etc/ssl/certs/postgresql-server-ca.pem" -X -A -F '|' -c "SELECT i.relname AS index_name, ix.indisunique AS is_unique, pg_get_indexdef(i.oid) AS index_definition FROM pg_class t JOIN pg_namespace n ON n.oid=t.relnamespace JOIN pg_index ix ON ix.indrelid=t.oid JOIN pg_class i ON i.oid=ix.indexrelid WHERE n.nspname='incident' AND t.relname='alert_events' ORDER BY i.relname;"
```

構築時の結果（要点）は次のとおりで、`event_id` が主キー（一意）でした。

```text
alert_events_pkey
UNIQUE (event_id)
```

Collector の側の処理も確かめます。

```bash
grep -n -A45 -B15 'UniqueViolation\|def process_line' /usr/local/lib/wazuh-collector/collector.py
```

```bash
sed -n '555,610p' /usr/local/lib/wazuh-collector/collector.py
```

```bash
sed -n '600,665p' /usr/local/lib/wazuh-collector/collector.py
```

1. 1件ずつ別のトランザクションで INSERT する
2. `event_id` の重複（SQLSTATE `23505`）なら取り消して次へ進む
3. INSERT の成功・重複のどちらでも、そのあとで読み取り位置を保存する
4. DB や保存に失敗したら、行の頭に戻ってやり直す
5. ファイルが切り替わったら、新しい inode と offset 0 を先に保存してから切り替える

## 第2章　読み取り位置を書き換える

> **実行先：VM 220**

### 2.1　止める

```bash
systemctl stop wazuh-collector.service
```

```bash
systemctl is-active wazuh-collector.service
systemctl show wazuh-collector.service -p MainPID -p NRestarts -p ActiveState -p SubState
```

`inactive`、`MainPID=0` で、状態ファイルを書き換えるプロセスがないことを確かめます。

### 2.2　バックアップ

```bash
backup="/var/lib/wazuh-collector/state.json.pre-recovery-20261121"; test ! -e "$backup" && cp -a /var/lib/wazuh-collector/state.json "$backup" && sha256sum /var/lib/wazuh-collector/state.json "$backup" && cmp -s /var/lib/wazuh-collector/state.json "$backup" && echo "BACKUP_VERIFY=OK"
```

`BACKUP_VERIFY=OK` を確かめます。

### 2.3　書き換え

新しい読み取り位置は次のとおりです。

```text
{"inode": 5409517, "offset": 0}
```

今の状態ファイルが予想どおり（inode 5409383・offset 6433808）で、`alerts.json` の inode が 5409517 のときだけ書き換えます。違えば何もせずに止まります。書き換えは一時ファイルに書いてから置き換え、権限と持ち主は元のままにします。

```bash
python3 - <<'PY'
import json, os, stat, tempfile

state_path = "/var/lib/wazuh-collector/state.json"
backup_path = "/var/lib/wazuh-collector/state.json.pre-recovery-20261121"
alert_path = "/var/ossec/logs/alerts/alerts.json"

with open(state_path, encoding="utf-8") as f:
    old_state = json.load(f)
with open(backup_path, "rb") as f:
    backup_bytes = f.read()

if old_state != {"inode": 5409383, "offset": 6433808}:
    raise SystemExit("ABORT: state.json differs from expected old state")
if os.stat(alert_path).st_ino != 5409517:
    raise SystemExit("ABORT: alerts.json inode changed")
if not backup_bytes:
    raise SystemExit("ABORT: backup is empty")

st = os.stat(state_path)
directory = os.path.dirname(state_path)
fd, temp_path = tempfile.mkstemp(prefix=".state.json.recovery.", dir=directory)

try:
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump({"inode": 5409517, "offset": 0}, f)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())

    os.chmod(temp_path, stat.S_IMODE(st.st_mode))
    os.chown(temp_path, st.st_uid, st.st_gid)
    os.replace(temp_path, state_path)

    dir_fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(dir_fd)
    finally:
        os.close(dir_fd)
except Exception:
    if os.path.exists(temp_path):
        os.unlink(temp_path)
    raise

with open(state_path, encoding="utf-8") as f:
    result = json.load(f)

print("NEW_STATE:", json.dumps(result, sort_keys=True))
print("STATE_UPDATE:", "OK" if result == {"inode": 5409517, "offset": 0} else "FAILED")
print("BACKUP_PRESERVED:", os.path.exists(backup_path))
PY
```

### 2.4　動かす

```bash
systemctl start wazuh-collector.service
```

```bash
systemctl is-active wazuh-collector.service
systemctl show wazuh-collector.service -p MainPID -p NRestarts -p ActiveState -p SubState
```

構築時は `active`・`running`（PID 13542）でした。`NRestarts=874` は止める前までの回数の合計です。

```bash
journalctl -u wazuh-collector.service -n 60 --no-pager -o short-iso
```

```bash
journalctl -u wazuh-collector.service --since "2026-11-21 10:45:00" --no-pager -o short-iso | tail -n 40
```

動かしたあとのログに、次の2行がありました。

```text
INFO Resuming current alert file
INFO PostgreSQL connection established
```

### 2.5　読み進んでいるか

```bash
python3 - <<'PY'
import json, os

state_path = "/var/lib/wazuh-collector/state.json"
alert_path = "/var/ossec/logs/alerts/alerts.json"

with open(state_path, encoding="utf-8") as f:
    state = json.load(f)

st = os.stat(alert_path)
print("STATE_INODE:", state["inode"])
print("STATE_OFFSET:", state["offset"])
print("CURRENT_INODE:", st.st_ino)
print("CURRENT_SIZE:", st.st_size)
print("INODE_MATCH:", state["inode"] == st.st_ino)
print("OFFSET_WITHIN_FILE:", 0 <= state["offset"] <= st.st_size)
PY
```

読み取り位置（858,191）がファイルの大きさと同じになり、最後まで読んだことがわかりました。

```bash
systemctl is-active wazuh-collector.service
journalctl -u wazuh-collector.service --since "2026-11-21 10:45:00" --no-pager -o cat | grep -E 'ERROR|WARNING|Duplicate alert skipped|PostgreSQL connection|Resuming current alert'
```

動かしたあとに、エラーや警告はありませんでした。

## 第3章　PostgreSQLで確かめる

> **実行先：postgresql**（OS のユーザー `postgres`）

`wazuh_collector` は INSERT だけの権限なので、権限は足さず、PostgreSQL の管理者で読み取りだけの SQL を実行します。

```bash
psql -d security_workbench -X -P pager=off -c "
SELECT
    COUNT(*) AS events_last_30m,
    MIN(event_timestamp) AS first_event,
    MAX(event_timestamp) AS latest_event
FROM incident.alert_events
WHERE event_timestamp >= NOW() - INTERVAL '30 minutes';
"
```

直近30分のイベントは143件でした。取り込んだ時刻の列があるかを確かめます。

```bash
psql -d security_workbench -X -P pager=off -c "
SELECT column_name, data_type
FROM information_schema.columns
WHERE table_schema = 'incident'
  AND table_name = 'alert_events'
ORDER BY ordinal_position;
"
```

`ingested_at` がありました。Collector を動かした時刻（10:45:16 UTC）より後に取り込まれた件数を数えます。時刻は自分の環境のものに置き換えます。

```bash
psql -d security_workbench -X -P pager=off -c "
SELECT
    COUNT(*) AS ingested_after_restart,
    COUNT(DISTINCT event_id) AS unique_event_ids,
    MIN(ingested_at) AS first_ingested_at,
    MAX(ingested_at) AS latest_ingested_at
FROM incident.alert_events
WHERE ingested_at >= TIMESTAMPTZ '2026-11-21 10:45:16+00';
"
```

| 項目 | 結果 |
|---|---|
| 動かしたあとの登録 | 1,318件 |
| 異なる `event_id` | 1,318件（重複なし） |
| 最初の登録 | 10:45:16.110 UTC |
| 最後の登録 | 10:58:41.944 UTC |

```bash
psql -d security_workbench -X -P pager=off -c "
SELECT
    COUNT(*) AS ingested_last_5m,
    MAX(ingested_at) AS latest_ingested_at
FROM incident.alert_events
WHERE ingested_at >= NOW() - INTERVAL '5 minutes';
"
```

直近5分は1件でした。新しいアラートが少ないだけの可能性があるので、読み残しがないかを VM 220 で確かめます。

> **実行先：VM 220**

```bash
python3 - <<'PY'
import json, os

with open("/var/lib/wazuh-collector/state.json", encoding="utf-8") as f:
    state = json.load(f)

st = os.stat("/var/ossec/logs/alerts/alerts.json")
print("STATE_INODE:", state["inode"])
print("STATE_OFFSET:", state["offset"])
print("CURRENT_INODE:", st.st_ino)
print("CURRENT_SIZE:", st.st_size)
print("INODE_MATCH:", state["inode"] == st.st_ino)
print("OFFSET_AT_EOF:", state["offset"] == st.st_size)
print("UNPROCESSED_BYTES:", max(0, st.st_size - state["offset"]) if state["inode"] == st.st_ino else "ROTATION")
PY
```

`UNPROCESSED_BYTES: 0`（読み残しなし）でした。

```bash
systemctl show wazuh-collector.service -p ActiveState -p SubState -p MainPID -p NRestarts
```

## おわりに

第29部で、Collector を読み残しなしに動かし直しました。

| 項目 | 結果 |
|---|---|
| 前のファイル | 20日の分の圧縮ファイル。大きさ・行・チェックサムで確認 |
| 読み取り位置 | inode 5409517・offset 0 に書き換え（バックアップは `state.json.pre-recovery-20261121`） |
| PostgreSQL | 1,318件を登録、重複 0 |
| 読み残し | 0 バイト |

ローテーションの前後でイベントが欠けていないことまでは証明していません。また、試験用の隠しディレクトリは残ったままなので、次にファイルが切り替わったとき、同じ理由で止まるおそれがあります。次の部で、これを防ぎます。

# 第30部　Collectorが同じ理由で止まらないようにする
## はじめに

### 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」中編の第30部です。第28部・第29部で、Collector は試験用の隠しディレクトリ（`.acl-inheritance-test.bkv8vd`）に入れずに止まっていたことを突き止め、読み取り位置を直して動かし直しました。ただし、このディレクトリは残っているため、次にファイルが切り替わったときにまた止まるおそれがあります。

ここでは、ディレクトリを消したり Collector の権限を広げたりするのではなく、**前のファイルを探すときに、名前が `.` で始まるディレクトリ（隠しディレクトリ）を探さない**ように、Collector のコードを2行だけ直します。

- 本物のアラートの置き場（`2026/Nov` など）は、これまでどおり探す
- ふつうのディレクトリに入れないときのエラーは、これまでどおり止まる（握りつぶさない）
- シンボリックリンクをたどらない作りは変えない

最後に、ログの切り替え（ローテーション）のときの処理と、状態ファイル・重複の扱いをコードで確かめます。

### 本書の表記

- コマンドやプログラムは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 実行先は、各手順の「実行先」に示します。
  - **VM 220**：security-core（root）
  - **postgresql**：LXC 109（192.168.0.151）。OS のユーザー `postgres`

## 第1章　隠しディレクトリの正体

> **実行先：VM 220**

```bash
find /var/ossec/logs/alerts/.acl-inheritance-test.bkv8vd -maxdepth 5 -printf '%y %M %u:%g %s bytes %TY-%Tm-%Td %TH:%TM:%TS %p\n'
```

2026年11月18日に作られ、すべて `root:root`、中は `2027/Jan/test.json`（0バイト）だけでした。前編 第6部で ACL の継承を試したときに作ったものです。作ったスクリプトが残っていないかを探します。

```bash
grep -R -n -F --exclude='*.pyc' --exclude='*.log' '.acl-inheritance-test' /root /usr/local /etc 2>/dev/null | head -n 40
```

0件でした。ACL を見ます。

```bash
getfacl -p /var/ossec/logs/alerts /var/ossec/logs/alerts/.acl-inheritance-test.bkv8vd /var/ossec/logs/alerts/.acl-inheritance-test.bkv8vd/2027 /var/ossec/logs/alerts/.acl-inheritance-test.bkv8vd/2027/Jan /var/ossec/logs/alerts/.acl-inheritance-test.bkv8vd/2027/Jan/test.json
```

いちばん上のディレクトリだけ、次の状態でした（要点）。

```text
user:wazuh-collector:r-x
mask::---
effective:---
```

ACL の項目はあるものの、マスクが `---` のため、実際には入れません。

## 第2章　探す処理を直す

### 2.1　今のコード

```bash
sed -n '300,365p' /usr/local/lib/wazuh-collector/collector.py
```

`find_inode_file()` は、次の部分で、隠しディレクトリも含めてすべてのディレクトリを探す対象に入れていました。

```text
if entry.is_dir(follow_symlinks=False):
    pending.append(Path(entry.path))
    continue
```

`alerts` の直下と、本物の置き場の形を確かめます。

```bash
find /var/ossec/logs/alerts -mindepth 1 -maxdepth 1 -type d -printf '%f\n'
```

```bash
find /var/ossec/logs/alerts/2026 -type d -printf '%P\n' | head -50
```

直下のディレクトリは `2026` と `.acl-inheritance-test.bkv8vd` の2つで、本物は `2026/Nov` でした。隠しディレクトリを除いても、本物は探せます。

```bash
stat -c '%A %U:%G %s bytes %y %n' /usr/local/lib/wazuh-collector/collector.py && python3 -m py_compile /usr/local/lib/wazuh-collector/collector.py
```

```bash
sed -n '365,455p' /usr/local/lib/wazuh-collector/collector.py
```

`open_initial_file()` は、前のファイルが見つからなければ起動を止めます。この安全策は変えません。変えるのは次の形です。

```text
if entry.is_dir(follow_symlinks=False):
    if entry.name.startswith("."):
        continue
    pending.append(Path(entry.path))
    continue
```

### 2.2　バックアップ

動いている Collector には触れずに、ファイルのバックアップを取ります。

```bash
cp -a /usr/local/lib/wazuh-collector/collector.py /usr/local/lib/wazuh-collector/collector.py.pre-hidden-dir-fix-20261121 && sha256sum /usr/local/lib/wazuh-collector/collector.py /usr/local/lib/wazuh-collector/collector.py.pre-hidden-dir-fix-20261121
```

2つの SHA-256 が同じであることを確かめます。

### 2.3　直す

直す場所がちょうど1か所あるときだけ書き換えます。

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/usr/local/lib/wazuh-collector/collector.py")
source = path.read_text()

old = '''                if entry.is_dir(follow_symlinks=False):
                    pending.append(Path(entry.path))
                    continue
'''

new = '''                if entry.is_dir(follow_symlinks=False):
                    if entry.name.startswith("."):
                        continue
                    pending.append(Path(entry.path))
                    continue
'''

count = source.count(old)
if count != 1:
    raise SystemExit(f"安全確認失敗: 対象コードが {count} 件。変更していません")

path.write_text(source.replace(old, new, 1))
print("修正完了: 隠しディレクトリを探索対象から除外")
PY
```

```bash
python3 -m py_compile /usr/local/lib/wazuh-collector/collector.py && diff -u /usr/local/lib/wazuh-collector/collector.py.pre-hidden-dir-fix-20261121 /usr/local/lib/wazuh-collector/collector.py
```

差分は `if entry.name.startswith("."):` と `continue` の2行だけでした。

### 2.4　Collectorのユーザーで試す

`find_inode_file()` だけを取り出し、Collector のユーザーで、存在しない inode を探させます。隠しディレクトリに入れなくても、`None`（見つからない）を返して正常に終われば成功です。DB には接続しません。

```bash
runuser -u wazuh-collector -- python3 - <<'PY'
import ast
import os
from pathlib import Path

source_path = "/usr/local/lib/wazuh-collector/collector.py"
source = Path(source_path).read_text()
tree = ast.parse(source)

function = next(
    node for node in tree.body
    if isinstance(node, ast.FunctionDef)
    and node.name == "find_inode_file"
)

namespace = {
    "os": os,
    "Path": Path,
    "ALERT_DIR": Path("/var/ossec/logs/alerts"),
}

exec(compile(ast.Module(body=[function], type_ignores=[]), source_path, "exec"), namespace)

result = namespace["find_inode_file"](9223372036854775807)

print("RESULT:", result)
print("TEST: PASS" if result is None else "TEST: UNEXPECTED MATCH")
PY
```

`TEST: PASS` でした。

## 第3章　反映する

### 3.1　再起動

```bash
systemctl show wazuh-collector.service -p MainPID -p NRestarts -p ActiveState -p SubState
```

今のプロセス（PID 13542）は直す前のコードで動いています。再起動して読み込ませます。再起動のあいだは少しだけ収集が止まりますが、状態ファイルの位置から続けます。

```bash
systemctl restart wazuh-collector.service
```

```bash
systemctl show wazuh-collector.service -p MainPID -p NRestarts -p ActiveState -p SubState
```

構築時は PID 14203、`NRestarts=0`、`active`・`running` でした。

```bash
journalctl -u wazuh-collector.service -n 30 --no-pager
```

```bash
journalctl -u wazuh-collector.service --since "2026-11-21 11:09:00" --no-pager
```

`Resuming current alert file` があり、隠しディレクトリの `PermissionError` は出ていませんでした。

### 3.2　PostgreSQLの接続のログがない

```bash
systemctl status wazuh-collector.service --no-pager -l
```

```bash
sed -n '500,570p' /usr/local/lib/wazuh-collector/collector.py
```

Collector は、**読んでいない行が来たときに初めて** PostgreSQL につなぎます。最後まで読み終えていて、新しいアラートが来ていなければ、接続のログは出ません。

```bash
python3 - <<'PY'
import json, os
state_path = "/var/lib/wazuh-collector/state.json"
alert_path = "/var/ossec/logs/alerts/alerts.json"

with open(state_path) as f:
    state = json.load(f)

st = os.stat(alert_path)

print("STATE_INODE:", state["inode"])
print("STATE_OFFSET:", state["offset"])
print("CURRENT_INODE:", st.st_ino)
print("CURRENT_SIZE:", st.st_size)
print("INODE_MATCH:", state["inode"] == st.st_ino)
print("OFFSET_AT_EOF:", state["offset"] == st.st_size)
print("UNPROCESSED_BYTES:", max(0, st.st_size - state["offset"]) if state["inode"] == st.st_ino else "inode mismatch")
PY
```

```bash
stat -c 'ALERT_FILE_SIZE=%s MODIFIED=%y INODE=%i' /var/ossec/logs/alerts/alerts.json && journalctl -u wazuh-collector.service --since "2026-11-21 11:09:11 UTC" --no-pager
```

読み残しは0で、`alerts.json` は再起動の前から更新されていませんでした。

### 3.3　接続の確認

Collector のユーザーで、Collector と同じ接続の設定（`DB_CONFIG`）を使い、`SELECT 1` だけを実行します。接続の情報は表示しません。

```bash
runuser -u wazuh-collector -- python3 - <<'PY'
import importlib.util
from pathlib import Path

path = Path("/usr/local/lib/wazuh-collector/collector.py")
spec = importlib.util.spec_from_file_location("collector_check", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

try:
    with module.psycopg.connect(**module.DB_CONFIG) as connection:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            result = cursor.fetchone()[0]
    print("POSTGRESQL_READ_ONLY_TEST:", "PASS" if result == 1 else "FAIL")
except Exception as error:
    print("POSTGRESQL_READ_ONLY_TEST: FAIL")
    print("ERROR_TYPE:", type(error).__name__)
PY
```

`POSTGRESQL_READ_ONLY_TEST: PASS` でした。しばらくして、新しいアラートが来たあとのログを見ます。

```bash
journalctl -u wazuh-collector.service --since "2026-11-21 11:09:11 UTC" --no-pager | grep -E 'ERROR|WARNING|PostgreSQL connection established|Alert processing failed|Duplicate alert skipped'
```

```text
Nov 21 11:12:08
INFO PostgreSQL connection established
```

> **実行先：postgresql**（OS のユーザー `postgres`。すでに `postgres` で入っているので `sudo` は使いません）

```bash
psql -d security_workbench -c "SELECT COUNT(*) AS recent_events, COUNT(DISTINCT event_id) AS distinct_events, MAX(ingested_at) AS latest_ingested_at FROM incident.alert_events WHERE ingested_at >= TIMESTAMPTZ '2026-11-21 11:09:11+00';"
```

再起動のあとに3件（異なる `event_id` も3件）が保存されていました。

## 第4章　ローテーションの処理の確認

> **実行先：VM 220**

```bash
sed -n '550,735p' /usr/local/lib/wazuh-collector/collector.py
```

| 状況 | Collector の動き |
|---|---|
| ふつうの行 | PostgreSQL に保存してから位置を保存する |
| PostgreSQL につながらない・保存に失敗 | 行の頭に戻ってやり直す |
| ファイルの最後が途中の行 | 切り替わるのを待つ |
| 途中の行のまま切り替わった | その行を捨てて、新しい inode に切り替える |
| 最後まで読んで切り替わった | 新しい inode に切り替える |
| 位置の保存に失敗 | 新しいファイルに切り替えずにやり直す |

```bash
grep -n -A75 -B10 '^def save_state\|^def load_state\|^def read_alert_line' /usr/local/lib/wazuh-collector/collector.py
```

`save_state()` は、同じディレクトリの一時ファイルに `0600` で書き、`flush()` と `fsync()` をしてから `os.replace()` で置き換え、ディレクトリも `fsync()` します。処理の順番は次のとおりです。

```text
PostgreSQL INSERT
       ↓
トランザクション確定
       ↓
save_state(inode, offset)
```

```bash
grep -n -A45 -B15 'INSERT_SQL\|event_id' /usr/local/lib/wazuh-collector/collector.py | head -120
```

`event_id` は Wazuh のアラートの `alert["id"]` で、重複（SQLSTATE `23505`）だけを「すでにある」として扱います。INSERT を確定してから位置を進めるので、保存と位置の保存のあいだで止まって同じ行を読み直しても、二重には登録されません。

## おわりに

第30部で、Collector が隠しディレクトリで止まらないようにしました。

| 項目 | 結果 |
|---|---|
| 直したところ | `find_inode_file()` で、名前が `.` で始まるディレクトリを探さない（2行） |
| バックアップ | `collector.py.pre-hidden-dir-fix-20261121` |
| 試験 | Collector のユーザーで `TEST: PASS` |
| 反映 | 再起動して `NRestarts=0`、PostgreSQL への保存も確認 |
| 隠しディレクトリ | 消していない（残っていても Collector は止まらない） |

構築時は、このあと Wazuh のログの切り替えが `copytruncate` かどうかなど、ローテーションの方式の確認に進みましたが、その結果は受け取った記録の範囲にはありません（不足情報メモ 30-B）。
