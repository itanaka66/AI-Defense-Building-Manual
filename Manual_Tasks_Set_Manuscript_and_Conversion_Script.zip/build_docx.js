// Usage: node build_docx.js input.md output.docx [a4|kdp]
const fs = require('fs');
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell,
  WidthType, ShadingType, BorderStyle, AlignmentType, Footer, PageNumber,
  LevelFormat, PageBreak, TabStopType, LeaderType,
} = require('docx');

const [, , inPath, outPath, mode = 'a4'] = process.argv;
const KDP = mode === 'kdp';
let src = fs.readFileSync(inPath, 'utf8');

// front matter
const meta = {};
const fm = src.match(/^---\n([\s\S]*?)\n---\n/);
if (fm) {
  fm[1].split('\n').forEach(l => { const m = l.match(/^(\w+):\s*"?(.*?)"?$/); if (m) meta[m[1]] = m[2]; });
  src = src.slice(fm[0].length);
}

// page geometry (DXA)
const page = KDP
  ? { w: 8640, h: 12960, top: 1080, bottom: 1080, inner: 1260, outer: 900 }   // 6x9in
  : { w: 11906, h: 16838, top: 1440, bottom: 1440, inner: 1300, outer: 1300 }; // A4
const textW = page.w - page.inner - page.outer;

const SZ = KDP
  ? { body: 19, code: 14, table: 16, h1: 30, h2: 24, h3: 21, title: 40, sub: 24 }
  : { body: 21, code: 17, table: 18, h1: 34, h2: 27, h3: 23, title: 48, sub: 28 };
const BODY = 'Yu Mincho', HEAD = 'Yu Gothic', MONO = 'Consolas', MONO_EA = 'MS Gothic';

function runs(text, base = {}) {
  // inline **bold** and `code`
  const out = [];
  const re = /(\*\*([^*]+)\*\*|`([^`]+)`)/g;
  let last = 0, m;
  while ((m = re.exec(text))) {
    if (m.index > last) out.push(new TextRun({ text: text.slice(last, m.index), ...base }));
    if (m[2] !== undefined) out.push(new TextRun({ text: m[2], bold: true, ...base }));
    else out.push(new TextRun({ text: m[3], font: { ascii: MONO, hAnsi: MONO, eastAsia: MONO_EA }, size: (base.size || SZ.body) - 2, shading: { type: ShadingType.CLEAR, fill: 'EFEFEF', color: 'auto' } }));
    last = re.lastIndex;
  }
  if (last < text.length) out.push(new TextRun({ text: text.slice(last), ...base }));
  return out;
}

const children = [];
// title page
(meta.title || '').split(' ').forEach((t, k, a) => children.push(new Paragraph({ spacing: { before: k === 0 ? (KDP ? 2400 : 3600) : 0, after: k === a.length - 1 ? 400 : 60 }, alignment: AlignmentType.CENTER, children: [new TextRun({ text: t, bold: true, size: SZ.title, font: HEAD })] })));
if (meta.subtitle) children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 1200 }, children: [new TextRun({ text: meta.subtitle, size: SZ.sub, font: HEAD })] }));
if (meta.author) children.push(new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: meta.author, size: SZ.body + 2, font: HEAD })] }));
children.push(new Paragraph({ children: [new PageBreak()] }));
children.push(new Paragraph({ heading: HeadingLevel.HEADING_1, pageBreakBefore: false, children: [new TextRun('目次')] }));
const tocPages = fs.existsSync(outPath + '.toc.json') ? JSON.parse(fs.readFileSync(outPath + '.toc.json', 'utf8')) : null;
const heads = [...src.replace(/^```[\s\S]*?^```/gm, '').matchAll(/^(#{1,2}) (.*)$/gm)].map(m => ({ lv: m[1].length, t: m[2] }));
heads.forEach((h, k) => children.push(new Paragraph({
  indent: { left: h.lv === 2 ? 360 : 0 }, spacing: { before: h.lv === 1 ? 100 : 0, after: 20 },
  children: [new TextRun({ text: h.t, bold: h.lv === 1, size: SZ.table + 1, font: h.lv === 1 ? HEAD : BODY }),
    new TextRun({ text: '\t' + String(tocPages ? tocPages[k] : 0), size: SZ.table + 1 })],
  tabStops: [{ type: TabStopType.RIGHT, position: textW, leader: LeaderType.DOT }],
})));

const lines = src.split('\n');
let i = 0, numCount = 1;
const border = { style: BorderStyle.SINGLE, size: 4, color: 'BBBBBB', space: 4 };

function codeBlock(codeLines) {
  const n = codeLines.length;
  codeLines.forEach((l, k) => {
    children.push(new Paragraph({
      spacing: { before: k === 0 ? 120 : 0, after: k === n - 1 ? 160 : 0, line: 240 },
      shading: { type: ShadingType.CLEAR, fill: 'F4F4F4', color: 'auto' },
      border: { left: border, right: border, ...(k === 0 ? { top: border } : {}), ...(k === n - 1 ? { bottom: border } : {}) },
      indent: { left: 120, right: 120 },
      keepLines: true,
      children: [new TextRun({ text: l === '' ? ' ' : l, font: { ascii: MONO, hAnsi: MONO, eastAsia: MONO_EA, cs: MONO }, size: SZ.code })],
    }));
  });
}

function table(rows) {
  const cells = rows.map(r => r.replace(/^\||\|$/g, '').split('|').map(c => c.trim()));
  const header = cells[0], body = cells.slice(2);
  const ncol = header.length;
  const len = Array(ncol).fill(10);
  [header, ...body].forEach(r => r.forEach((c, j) => { const L = [...c.replace(/[*`]/g, '')].reduce((a, ch) => a + (ch.charCodeAt(0) > 255 ? 2 : 1), 0); len[j] = Math.max(len[j], Math.min(L, 40)); }));
  const tot = len.reduce((a, b) => a + b, 0);
  const widths = len.map(l => Math.floor(textW * l / tot));
  widths[ncol - 1] += textW - widths.reduce((a, b) => a + b, 0);
  const mk = (r, hdr) => new TableRow({
    tableHeader: hdr, cantSplit: true,
    children: Array.from({ length: ncol }, (_, j) => new TableCell({
      width: { size: widths[j], type: WidthType.DXA },
      shading: hdr ? { type: ShadingType.CLEAR, fill: 'E3E8EF', color: 'auto' } : undefined,
      margins: { top: 40, bottom: 40, left: 80, right: 80 },
      children: [new Paragraph({ children: runs(r[j] || '', { size: SZ.table, bold: hdr || undefined }) })],
    })),
  });
  children.push(new Table({ width: { size: textW, type: WidthType.DXA }, columnWidths: widths, rows: [mk(header, true), ...body.map(r => mk(r, false))] }));
  children.push(new Paragraph({ spacing: { after: 60 }, children: [] }));
}

while (i < lines.length) {
  const l = lines[i];
  if (l.startsWith('```')) {
    const buf = []; i++;
    while (i < lines.length && !lines[i].startsWith('```')) buf.push(lines[i++]);
    i++; codeBlock(buf); continue;
  }
  if (/^\|/.test(l)) { const buf = []; while (i < lines.length && /^\|/.test(lines[i])) buf.push(lines[i++]); table(buf); continue; }
  let m;
  if ((m = l.match(/^(#{1,3}) (.*)$/))) {
    const lv = m[1].length;
    const h = [HeadingLevel.HEADING_1, HeadingLevel.HEADING_2, HeadingLevel.HEADING_3][lv - 1];
    children.push(new Paragraph({ heading: h, pageBreakBefore: lv === 1, children: [new TextRun(m[2])] }));
    i++; continue;
  }
  if ((m = l.match(/^> ?(.*)$/))) {
    const buf = []; while (i < lines.length && /^>/.test(lines[i])) buf.push(lines[i++].replace(/^> ?/, ''));
    const items = buf.filter(x => x.trim() !== '');
    items.forEach((x, k) => children.push(new Paragraph({
      shading: { type: ShadingType.CLEAR, fill: 'FFF7E0', color: 'auto' },
      border: { left: { style: BorderStyle.SINGLE, size: 18, color: 'E0A800' } },
      keepNext: k < items.length - 1, keepLines: true, indent: { left: x.startsWith('- ') ? 360 : 120 }, spacing: { before: k === 0 ? 120 : 0, after: k === items.length - 1 ? 160 : 40 },
      children: runs(x.startsWith('- ') ? '・' + x.slice(2) : x),
    })));
    continue;
  }
  if ((m = l.match(/^- (.*)$/))) { children.push(new Paragraph({ numbering: { reference: 'bul', level: 0 }, children: runs(m[1]) })); i++; continue; }
  if ((m = l.match(/^(\d+)\. (.*)$/))) {
    // restart numbering per list block
    children.push(new Paragraph({ numbering: { reference: 'num', level: 0, instance: numCount }, children: runs(m[2]) }));
    i++;
    if (!(lines[i] || '').match(/^\d+\. /)) numCount++;
    continue;
  }
  if (l.trim() === '') { i++; continue; }
  const buf = [l]; i++;
  while (i < lines.length && lines[i].trim() !== '' && !/^(#|```|\||> |- |\d+\. )/.test(lines[i])) buf.push(lines[i++]);
  children.push(new Paragraph({ children: runs(buf.join('')) }));
}

const hp = (size, before, after) => ({ run: { font: HEAD, size, bold: true, color: '1F3A5F' }, paragraph: { spacing: { before, after }, keepNext: true, keepLines: true } });
const doc = new Document({
  creator: meta.author || '', title: meta.title || '',
  styles: {
    default: { document: { run: { font: { ascii: BODY, hAnsi: BODY, eastAsia: BODY }, size: SZ.body }, paragraph: { spacing: { after: 100, line: 300, lineRule: "auto" } } } },
    paragraphStyles: [
      { id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true, ...hp(SZ.h1, 240, 240) },
      { id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true, ...hp(SZ.h2, 300, 120) },
      { id: 'Heading3', name: 'Heading 3', basedOn: 'Normal', next: 'Normal', quickFormat: true, ...hp(SZ.h3, 200, 80) },
    ],
  },
  numbering: { config: [
    { reference: 'bul', levels: [{ level: 0, format: LevelFormat.BULLET, text: '・', alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 400, hanging: 300 } } } }] },
    { reference: 'num', levels: [{ level: 0, format: LevelFormat.DECIMAL, text: '%1.', alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 420, hanging: 320 } } } }] },
  ] },
  sections: [{
    properties: { page: { size: { width: page.w, height: page.h }, margin: { top: page.top, bottom: page.bottom, left: page.inner, right: page.outer, header: 500, footer: 500 } } },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ children: [PageNumber.CURRENT], size: SZ.table })] })] }) },
    children,
  }],
});
Packer.toBuffer(doc).then(b => fs.writeFileSync(outPath, b));
