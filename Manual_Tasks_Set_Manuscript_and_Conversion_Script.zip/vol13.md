---
title: "AI自律型サイバー防御システム 構築マニュアル 前編"
subtitle: "第13部　Wazuh Indexerの読み取り専用ユーザー"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」前編の第13部です。第12部の調査で、AI Defense Manager が読むアラートは Wazuh Indexer から取ることにしました。第13部では、Indexer に、Wazuh のアラートだけを読み取れる専用のロールとユーザーを作り、権限の範囲を確かめます。

## 本書の表記

- コマンドやプログラムは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 実行先はすべて **security-core VM 220（root）** です。
- パスワード・パスワードのハッシュ・秘密鍵は、画面にもマニュアルにも出しません。
- バックアップのディレクトリ名（`wazuh-security-backup-20261120-120052`）は構築時のものです。自分の環境で作られた名前に置き換えます。

## 作るもの

| 種類 | 名前 | 内容 |
|---|---|---|
| ロール | `ai_defense_alerts_read` | `wazuh-alerts-4.x-*` だけを読み取る（`read`）。クラスターの権限なし |
| ユーザー | `ai-defense-reader` | Indexer の内部ユーザー |
| ロールの割り当て | `ai_defense_alerts_read` → `ai-defense-reader` | |

既存の `manage_wazuh_index` は削除・管理・書き込みの権限も含むため使いません。

# 第1章　調査

## 1.1　アラートを読む既存のロール

```bash
python3 -c 'import yaml; d=yaml.safe_load(open("/etc/wazuh-indexer/opensearch-security/roles.yml")); [(print("\n### "+k),print(yaml.safe_dump(v,sort_keys=False,allow_unicode=True))) for k,v in d.items() if isinstance(v,dict) and any("wazuh-alerts" in str(x) for x in v.get("index_permissions",[]))]'
```

構築時は、何も表示されませんでした。`wazuh-alerts` だけを読むロールは、既存にはありません。

## 1.2　アラートのインデックスの名前

```bash
grep -nE '"index_patterns"|"index_pattern"|"index"' /etc/filebeat/wazuh-template.json
```

```bash
python3 -c 'import json; d=json.load(open("/etc/filebeat/wazuh-template.json")); print(json.dumps(d.get("index_patterns"),ensure_ascii=False,indent=2))'
```

アラートのインデックスは `wazuh-alerts-4.x-*` です。`wazuh-archives-4.x-*` も対象のパターンにありますが、Filebeat で archives は無効のため、AIの分析の対象には含めません。

## 1.3　既存のロールの割り当てとユーザー

ユーザー名とロールの割り当てだけを表示します（パスワードのハッシュは表示しません）。

```bash
python3 -c 'import yaml; d=yaml.safe_load(open("/etc/wazuh-indexer/opensearch-security/roles_mapping.yml")); [(print("\n### "+k),print(yaml.safe_dump({x:v.get(x) for x in ("reserved","backend_roles","hosts","users") if x in v},sort_keys=False,allow_unicode=True))) for k,v in d.items() if isinstance(v,dict)]'
```

```bash
python3 -c 'import yaml; d=yaml.safe_load(open("/etc/wazuh-indexer/opensearch-security/internal_users.yml")); print("\n".join(k for k,v in d.items() if isinstance(v,dict)))'
```

`ai-defense-reader` という名前が使われていないことを確認します。

```bash
python3 -c 'import yaml; d=yaml.safe_load(open("/etc/wazuh-indexer/opensearch-security/action_groups.yml")); print("\n".join(k for k,v in d.items() if isinstance(v,dict)))'
```

`action_groups.yml` に独自の定義はありません。`read` は Indexer に組み込みの権限のまとまりです。

## 1.4　設定を反映する道具

Indexer のセキュリティの設定は、`securityadmin.sh` で反映します。Java は Indexer に同梱のもの（`/usr/share/wazuh-indexer/jdk`）を使います。

```bash
ls -l /usr/share/wazuh-indexer/plugins/opensearch-security/tools/securityadmin.sh
```

```bash
command -v java && java -version 2>&1
```

```bash
ls -ld /usr/share/wazuh-indexer/jdk /usr/share/wazuh-indexer/jdk/bin/java 2>/dev/null
```

```bash
OPENSEARCH_JAVA_HOME=/usr/share/wazuh-indexer/jdk /usr/share/wazuh-indexer/plugins/opensearch-security/tools/securityadmin.sh -h
```

# 第2章　定義ファイルの準備

## 2.1　バックアップ

```bash
backup_dir="/root/wazuh-security-backup-$(date +%Y%m%d-%H%M%S)" && install -d -m 700 "$backup_dir" && cp -a /etc/wazuh-indexer/opensearch-security/{roles.yml,roles_mapping.yml,internal_users.yml} "$backup_dir/" && chmod 600 "$backup_dir"/* && echo "BACKUP_OK: $backup_dir"
```

表示されたディレクトリ名を控えておきます。

## 2.2　ロール

```bash
cat > /root/ai_defense_alerts_read.yml <<'YAML'
_meta:
  type: "roles"
  config_version: 2

ai_defense_alerts_read:
  reserved: false
  hidden: false
  cluster_permissions: []
  index_permissions:
    - index_patterns:
        - "wazuh-alerts-4.x-*"
      dls: ""
      fls: []
      masked_fields: []
      allowed_actions:
        - "read"
  tenant_permissions: []
YAML
chmod 600 /root/ai_defense_alerts_read.yml
```

```bash
python3 -c 'import yaml; p="/root/ai_defense_alerts_read.yml"; d=yaml.safe_load(open(p)); r=d["ai_defense_alerts_read"]; assert d["_meta"]["type"]=="roles"; assert r["index_permissions"][0]["index_patterns"]==["wazuh-alerts-4.x-*"]; assert r["index_permissions"][0]["allowed_actions"]==["read"]; assert r["cluster_permissions"]==[]; print("YAML_OK"); print("INDEX_PATTERN:",r["index_permissions"][0]["index_patterns"]); print("ALLOWED_ACTIONS:",r["index_permissions"][0]["allowed_actions"]); print("CLUSTER_PERMISSIONS:",r["cluster_permissions"])'
```

## 2.3　ロールの割り当て

```bash
cat > /root/ai_defense_alerts_mapping.yml <<'YAML'
_meta:
  type: "rolesmapping"
  config_version: 2

ai_defense_alerts_read:
  reserved: false
  backend_roles: []
  hosts: []
  users:
    - "ai-defense-reader"
YAML
chmod 600 /root/ai_defense_alerts_mapping.yml
```

```bash
python3 -c 'import yaml; p="/root/ai_defense_alerts_mapping.yml"; d=yaml.safe_load(open(p)); r=d["ai_defense_alerts_read"]; assert d["_meta"]["type"]=="rolesmapping"; assert r["users"]==["ai-defense-reader"]; assert r["backend_roles"]==[]; assert r["hosts"]==[]; print("MAPPING_YAML_OK"); print("ROLE: ai_defense_alerts_read"); print("USER:",r["users"][0])'
```

## 2.4　パスワードのハッシュ

Indexer の内部ユーザーには、パスワードそのものではなく、bcrypt のハッシュを登録します。`hash.sh` はパスワードを対話で尋ねるため、出力をファイルに直接書き出すと動きません（`Cannot allocate a console`）。`script` を使って、画面とのやり取りを記録しながら実行します。

```bash
ls -l /usr/share/wazuh-indexer/plugins/opensearch-security/tools/hash.sh
```

```bash
sed -n '1,120p' /usr/share/wazuh-indexer/plugins/opensearch-security/tools/hash.sh
```

```bash
command -v script
```

```bash
umask 077; script -q -c 'OPENSEARCH_JAVA_HOME=/usr/share/wazuh-indexer/jdk /usr/share/wazuh-indexer/plugins/opensearch-security/tools/hash.sh' /root/ai-defense-reader.hash.transcript
```

`[Password:]` と表示されたら、`ai-defense-reader` 用のランダムなパスワードを入力します（画面には表示されません）。パスワードとハッシュは、チャットや記録に残しません。

記録の中からハッシュだけを取り出し、root だけが読めるファイルにします。

```bash
python3 -c 'import re,pathlib; p=pathlib.Path("/root/ai-defense-reader.hash.transcript"); s=p.read_text(errors="replace") if p.exists() else ""; m=re.findall(r"\$(?:2[aby]|argon2id)\$[^\s\x1b]+",s); print("TRANSCRIPT_EXISTS:",p.exists()); print("HASH_COUNT:",len(m)); print("HASH_LENGTH:",len(m[-1]) if m else 0); print("RESULT:", "HASH_FOUND" if m else "HASH_NOT_FOUND")'
```

```bash
python3 -c 'import re,pathlib; s=pathlib.Path("/root/ai-defense-reader.hash.transcript").read_text(errors="replace"); m=re.findall(r"\$2[aby]\$\d{2}\$[./A-Za-z0-9]{53}",s); assert len(m)==1, f"Expected one bcrypt hash, found {len(m)}"; p=pathlib.Path("/root/ai-defense-reader.hash"); p.write_text(m[0]+"\n"); p.chmod(0o600); print("HASH_FILE_CREATED; FORMAT=bcrypt; LENGTH=60; MODE=600")'
```

## 2.5　ユーザー

```bash
python3 - <<'PY'
import yaml
from pathlib import Path

password_hash = Path("/root/ai-defense-reader.hash").read_text().strip()
assert len(password_hash) == 60 and password_hash.startswith("$2")

config = {
    "_meta": {"type": "internalusers", "config_version": 2},
    "ai-defense-reader": {
        "hash": password_hash,
        "reserved": False,
        "backend_roles": [],
        "description": "Read-only access to Wazuh alert indices for AI Defense Manager"
    }
}

path = Path("/root/ai_defense_internal_user.yml")
path.write_text(yaml.safe_dump(config, sort_keys=False))
path.chmod(0o600)
print("INTERNAL_USER_FILE_CREATED")
print("USERNAME: ai-defense-reader")
print("HASH_FORMAT: bcrypt")
print("FILE_MODE: 600")
PY
```

## 2.6　3つのファイルの検証

```bash
python3 - <<'PY'
import yaml
from pathlib import Path

files = {
    "/root/ai_defense_alerts_read.yml": ("roles", "ai_defense_alerts_read"),
    "/root/ai_defense_alerts_mapping.yml": ("rolesmapping", "ai_defense_alerts_read"),
    "/root/ai_defense_internal_user.yml": ("internalusers", "ai-defense-reader"),
}

for filename, (expected_type, expected_name) in files.items():
    path = Path(filename)
    data = yaml.safe_load(path.read_text())
    assert data["_meta"]["type"] == expected_type
    assert expected_name in data
    assert path.stat().st_mode & 0o077 == 0
    print(f"OK: {path.name}")

role = yaml.safe_load(Path("/root/ai_defense_alerts_read.yml").read_text())
mapping = yaml.safe_load(Path("/root/ai_defense_alerts_mapping.yml").read_text())
user = yaml.safe_load(Path("/root/ai_defense_internal_user.yml").read_text())

assert role["ai_defense_alerts_read"]["index_permissions"][0]["index_patterns"] == ["wazuh-alerts-4.x-*"]
assert role["ai_defense_alerts_read"]["index_permissions"][0]["allowed_actions"] == ["read"]
assert mapping["ai_defense_alerts_read"]["users"] == ["ai-defense-reader"]
assert len(user["ai-defense-reader"]["hash"]) == 60

print("ALL_VALIDATION_OK")
PY
```

## 2.7　管理者の証明書の確認

`securityadmin.sh` は管理者の証明書で Indexer に接続します。証明書の Subject が、Indexer に登録された管理者（`admin_dn`）と一致することを確かめます。

```bash
openssl x509 -in /etc/wazuh-indexer/certs/admin.pem -noout -subject -nameopt RFC2253
```

```bash
grep -nA5 -B2 'plugins.security.authcz.admin_dn' /etc/wazuh-indexer/opensearch.yml
```

構築時の Subject は `CN=admin,OU=Wazuh,O=Wazuh,...` で、`admin_dn` と一致していました。

# 第3章　Indexerへの反映

## 3.1　注意：securityadmin.sh -f は種類ごとに丸ごと置き換える

`securityadmin.sh -f ファイル -t 種類` は、その種類（`roles`・`rolesmapping`・`internalusers`）の設定を、指定したファイルの内容で**丸ごと置き換え**ます。追加したい分だけのファイル（第2章で作った3つ）をそのまま反映すると、既存のロール・割り当て・ユーザーが消えます。

構築時は、最初に追加分だけのファイルを反映してしまい、既存のロール（`manage_wazuh_index`・`security_analytics_read_access` など）が見えなくなりました。2.1のバックアップに追加分を足した「統合したファイル」を作り、反映し直して元に戻しています。この章では、最初から統合したファイルを反映する手順を示します。

## 3.2　バックアップの内容の確認

```bash
python3 - <<'PY'
import yaml
from pathlib import Path

p = Path("/root/wazuh-security-backup-20261120-120052/roles.yml")
data = yaml.safe_load(p.read_text())
print("BACKUP_ROLES:")
for name in sorted(data):
    if name != "_meta":
        print(" ", name)
PY
```

構築時のバックアップには、37個のロールがありました。

## 3.3　統合したファイルの作成

バックアップの3つのファイルに、第2章の追加分を1件ずつ足します。既存の項目はそのまま残し、追加する名前がすでにあるときは止まります。

```bash
python3 - <<'PY'
import copy
import stat
import yaml
from pathlib import Path

backup = Path("/root/wazuh-security-backup-20261120-120052")

specs = [
    ("roles.yml", "roles.yml", "/root/ai_defense_alerts_read.yml",
     "ai_defense_alerts_read"),
    ("roles_mapping.yml", "rolesmapping.yml",
     "/root/ai_defense_alerts_mapping.yml", "ai_defense_alerts_read"),
    ("internal_users.yml", "internalusers.yml",
     "/root/ai_defense_internal_user.yml", "ai-defense-reader"),
]

for source_name, output_name, addition_name, new_key in specs:
    source = backup / source_name
    addition = Path(addition_name)
    output = Path("/root/ai_defense_merged_" + output_name)

    original = yaml.safe_load(source.read_text())
    extra = yaml.safe_load(addition.read_text())

    assert "_meta" in original and "_meta" in extra
    assert new_key not in original, f"{new_key} already exists in backup"
    merged = copy.deepcopy(original)
    merged[new_key] = extra[new_key]

    output.write_text(yaml.safe_dump(
        merged, sort_keys=False, allow_unicode=True
    ))
    output.chmod(0o600)

    check = yaml.safe_load(output.read_text())
    assert set(check) == set(original) | {new_key}
    assert check["_meta"] == original["_meta"]
    assert stat.S_IMODE(output.stat().st_mode) == 0o600

    print(
        f"CREATED: {output.name}; "
        f"original_entries={len(original)-1}; "
        f"merged_entries={len(check)-1}; "
        f"new_entry={new_key}; mode=600"
    )

print("MERGED_CONFIGS_VALIDATED")
PY
```

## 3.4　反映

管理者の証明書で接続し、3種類を1つずつ反映します。それぞれ `Done with success` と表示されることを確認します。

```bash
OPENSEARCH_JAVA_HOME=/usr/share/wazuh-indexer/jdk /usr/share/wazuh-indexer/plugins/opensearch-security/tools/securityadmin.sh -h 127.0.0.1 -p 9200 -cacert /etc/wazuh-indexer/certs/root-ca.pem -cert /etc/wazuh-indexer/certs/admin.pem -key /etc/wazuh-indexer/certs/admin-key.pem -f /root/ai_defense_merged_roles.yml -t roles
```

```bash
OPENSEARCH_JAVA_HOME=/usr/share/wazuh-indexer/jdk /usr/share/wazuh-indexer/plugins/opensearch-security/tools/securityadmin.sh -h 127.0.0.1 -p 9200 -cacert /etc/wazuh-indexer/certs/root-ca.pem -cert /etc/wazuh-indexer/certs/admin.pem -key /etc/wazuh-indexer/certs/admin-key.pem -f /root/ai_defense_merged_rolesmapping.yml -t rolesmapping
```

```bash
OPENSEARCH_JAVA_HOME=/usr/share/wazuh-indexer/jdk /usr/share/wazuh-indexer/plugins/opensearch-security/tools/securityadmin.sh -h 127.0.0.1 -p 9200 -cacert /etc/wazuh-indexer/certs/root-ca.pem -cert /etc/wazuh-indexer/certs/admin.pem -key /etc/wazuh-indexer/certs/admin-key.pem -f /root/ai_defense_merged_internalusers.yml -t internalusers
```

# 第4章　反映の確認

## 4.1　必要な項目があるか

```bash
python3 - <<'PY'
import json
import subprocess

base = "https://127.0.0.1:9200/_plugins/_security/api"
cert = "/etc/wazuh-indexer/certs/admin.pem"
key = "/etc/wazuh-indexer/certs/admin-key.pem"
ca = "/etc/wazuh-indexer/certs/root-ca.pem"

expected = {
    "roles": {
        "ai_defense_alerts_read",
        "manage_wazuh_index",
        "security_analytics_read_access",
    },
    "rolesmapping": {"ai_defense_alerts_read"},
    "internalusers": {"ai-defense-reader"},
}

for kind, required in expected.items():
    result = subprocess.run(
        ["curl", "-fsS", "--cacert", ca, "--cert", cert, "--key", key,
         f"{base}/{kind}"],
        capture_output=True, text=True
    )
    if result.returncode:
        raise SystemExit(f"{kind}: API_QUERY_FAILED: {result.stderr.strip()}")

    data = json.loads(result.stdout)
    names = set(data)
    missing = required - names
    print(
        f"{kind}: entries={len(names)}; "
        f"required_present={not missing}; "
        f"missing={sorted(missing)}"
    )
    if missing:
        raise SystemExit(f"{kind}: VALIDATION_FAILED")

print("SECURITY_CONFIG_VALIDATION_OK")
PY
```

## 4.2　既存の項目がすべて残っているか

バックアップにあった項目が、反映した後もすべてあることを確かめます。

```bash
python3 - <<'PY'
import json
import subprocess
import yaml
from pathlib import Path

base = "https://127.0.0.1:9200/_plugins/_security/api"
cert = "/etc/wazuh-indexer/certs/admin.pem"
key = "/etc/wazuh-indexer/certs/admin-key.pem"
ca = "/etc/wazuh-indexer/certs/root-ca.pem"
backup = Path("/root/wazuh-security-backup-20261120-120052")

checks = [
    ("roles", "roles.yml"),
    ("rolesmapping", "roles_mapping.yml"),
    ("internalusers", "internal_users.yml"),
]

for api_name, backup_name in checks:
    original = yaml.safe_load((backup / backup_name).read_text())
    result = subprocess.run(
        ["curl", "-fsS", "--cacert", ca, "--cert", cert, "--key", key,
         f"{base}/{api_name}"],
        capture_output=True, text=True, check=True
    )
    current = json.loads(result.stdout)
    expected = set(original) - {"_meta"}
    missing = expected - set(current)
    print(
        f"{api_name}: backup_entries={len(expected)}; "
        f"current_entries={len(current)}; "
        f"missing_entries={len(missing)}"
    )
    if missing:
        print("MISSING:", ", ".join(sorted(missing)))
        raise SystemExit("PRESERVATION_CHECK_FAILED")

print("ALL_BACKUP_ENTRIES_PRESERVED")
PY
```

`ALL_BACKUP_ENTRIES_PRESERVED` を確認します。

## 4.3　ユーザーの認証

パスワードは `getpass` で入力し、画面には表示しません。

```bash
python3 - <<'PY'
import getpass
import json
import urllib.request
import urllib.error
import ssl
import base64

password = getpass.getpass("ai-defense-reader password: ")
context = ssl.create_default_context(
    cafile="/etc/wazuh-indexer/certs/root-ca.pem"
)
url = "https://127.0.0.1:9200/_plugins/_security/authinfo"
token = base64.b64encode(
    ("ai-defense-reader:" + password).encode()
).decode()
request = urllib.request.Request(
    url, headers={"Authorization": "Basic " + token}
)

try:
    with urllib.request.urlopen(request, context=context, timeout=10) as response:
        data = json.loads(response.read())
        print("HTTP_STATUS:", response.status)
        print("USER:", data.get("user_name"))
        print("BACKEND_ROLES:", data.get("backend_roles"))
        print("ROLES:", data.get("roles"))
        print("AUTHENTICATION_TEST_OK")
except urllib.error.HTTPError as e:
    print("HTTP_STATUS:", e.code)
    print("AUTHENTICATION_TEST_FAILED")
except Exception as e:
    print("CONNECTION_TEST_FAILED:", type(e).__name__, str(e))
finally:
    password = None
    token = None
PY
```

## 4.4　読み取れる範囲

アラートは読め、それ以外は拒否されることを確かめます。

```bash
python3 - <<'PY'
import getpass
import ssl
import json
import base64
import urllib.request
import urllib.error

password = getpass.getpass("ai-defense-reader password: ")
ctx = ssl.create_default_context(
    cafile="/etc/wazuh-indexer/certs/root-ca.pem"
)
token = base64.b64encode(
    ("ai-defense-reader:" + password).encode()
).decode()

tests = [
    ("ALERTS_READ", "https://127.0.0.1:9200/wazuh-alerts-4.x-*/_search?size=0"),
    ("ARCHIVES_DENIED", "https://127.0.0.1:9200/wazuh-archives-4.x-*/_search?size=0"),
]

for name, url in tests:
    req = urllib.request.Request(
        url,
        headers={"Authorization": "Basic " + token}
    )
    try:
        with urllib.request.urlopen(req, context=ctx, timeout=15) as response:
            print(name, "HTTP", response.status)
            if name == "ARCHIVES_DENIED":
                print("SCOPE_TEST_FAILED: archives unexpectedly accessible")
            else:
                print("ALERTS_READ_ALLOWED")
    except urllib.error.HTTPError as e:
        print(name, "HTTP", e.code)
        if name == "ARCHIVES_DENIED" and e.code == 403:
            print("ARCHIVES_ACCESS_DENIED_OK")
        elif name == "ALERTS_READ":
            print("ALERTS_READ_FAILED")
    except Exception as e:
        print(name, "ERROR", type(e).__name__, str(e))

password = None
token = None
PY
```

構築時は、archives も HTTP 200 になりました。archives のインデックスが存在しない（対象が0件）ためで、権限の確認にはなりません。実際にあるインデックスを調べ、そこで拒否されるかを確かめます。

```bash
curl -fsS --cacert /etc/wazuh-indexer/certs/root-ca.pem \
  --cert /etc/wazuh-indexer/certs/admin.pem \
  --key /etc/wazuh-indexer/certs/admin-key.pem \
  'https://127.0.0.1:9200/_cat/indices/wazuh-*?h=index&s=index'
```

```bash
python3 - <<'PY'
import getpass
import ssl
import base64
import urllib.request
import urllib.error

password = getpass.getpass("ai-defense-reader password: ")
token = base64.b64encode(
    ("ai-defense-reader:" + password).encode()
).decode()

ctx = ssl.create_default_context(
    cafile="/etc/wazuh-indexer/certs/root-ca.pem"
)
req = urllib.request.Request(
    "https://127.0.0.1:9200/wazuh-monitoring-2026.47w/_search?size=0",
    headers={"Authorization": "Basic " + token}
)

try:
    with urllib.request.urlopen(req, context=ctx, timeout=15) as response:
        print("MONITORING_ACCESS: HTTP", response.status)
        print("SCOPE_TEST_FAILED: unexpected access")
except urllib.error.HTTPError as e:
    print("MONITORING_ACCESS: HTTP", e.code)
    if e.code == 403:
        print("MONITORING_ACCESS_DENIED_OK")
    else:
        print("SCOPE_TEST_INCONCLUSIVE")
except Exception as e:
    print("TEST_ERROR:", type(e).__name__, str(e))

password = None
token = None
PY
```

インデックス名（`wazuh-monitoring-2026.47w`）は、上の一覧にある自分の環境の名前に置き換えます。

| テスト | 構築時の結果 |
|---|---|
| ユーザーの認証 | HTTP 200 |
| アラートの検索 | HTTP 200 |
| monitoring の検索 | HTTP 403（拒否） |
| archives の検索 | インデックスがないため判定できない |

# 第5章　パスワードの作り直しとファイルでの管理

## 5.1　作り直す理由

2.4で入力したパスワードは、どこにも保存していません。記録（`ai-defense-reader.hash.transcript`）にもハッシュがあるだけで、パスワードそのものは残っていません。ハッシュから元のパスワードを戻すこともできません。

次の部で作る中継のサービスがこのユーザーで Indexer に接続するため、ランダムなパスワードを作り直し、root だけが読めるファイルに保存します。ロールと権限は変えず、パスワードだけを変えます。

```bash
ls -l /root/ai-defense-reader.hash /root/ai_defense_merged_internalusers.yml
```

```bash
ls -l /root/ai-defense-reader.hash.transcript
```

```bash
file /root/ai-defense-reader.hash.transcript
```

中身は表示せず、パスワードが含まれていないことだけを確かめます。

```bash
python3 -c 'from pathlib import Path; p=Path("/root/ai-defense-reader.hash.transcript"); s=p.read_text(errors="replace"); print("PASSWORD_INPUT_PRESENT" if any(x in s.lower() for x in ("password", "enter password", "re-enter")) else "NO_PASSWORD_PROMPT_MARKER"); print("LINE_COUNT:", len(s.splitlines()))'
```

```bash
python3 -c 'from pathlib import Path; s=Path("/root/ai-defense-reader.hash.transcript").read_text(errors="replace"); [(print(f"LINE {i}: length={len(x)}, bcrypt_hash={x.strip().startswith(("$2a$","$2b$","$2y$"))}")) for i,x in enumerate(s.splitlines(),1)]'
```

## 5.2　パスワードとハッシュの作成

`hash.sh` は、`-env` で環境変数からパスワードを受け取れます。コマンドの引数に書かないため、プロセスの一覧や履歴に残りません。

```bash
sed -n '1,160p' /usr/share/wazuh-indexer/plugins/opensearch-security/tools/hash.sh
```

```bash
OPENSEARCH_JAVA_HOME=/usr/share/wazuh-indexer/jdk /usr/share/wazuh-indexer/plugins/opensearch-security/tools/hash.sh -h
```

ランダムなパスワードを作り、root だけが読めるファイル（`600`）に保存します。画面には表示しません。

```bash
python3 -c 'import secrets, pathlib, os; p=pathlib.Path("/root/ai-defense-reader.password"); p.write_text(secrets.token_urlsafe(48)+"\n"); os.chmod(p,0o600); print("PASSWORD_FILE_CREATED; mode=600")'
```

```bash
umask 077; IFS= read -r AI_DEFENSE_READER_PASSWORD < /root/ai-defense-reader.password; export AI_DEFENSE_READER_PASSWORD; OPENSEARCH_JAVA_HOME=/usr/share/wazuh-indexer/jdk /usr/share/wazuh-indexer/plugins/opensearch-security/tools/hash.sh -env AI_DEFENSE_READER_PASSWORD > /root/ai-defense-reader.new.hash && chmod 600 /root/ai-defense-reader.new.hash; unset AI_DEFENSE_READER_PASSWORD
```

```bash
python3 -c 'from pathlib import Path; import os,re; p=Path("/root/ai-defense-reader.new.hash"); s=p.read_text().strip(); print("FILE_EXISTS:",p.is_file()); print("MODE:",oct(p.stat().st_mode & 0o777)); print("BCRYPT_VALID:",bool(re.fullmatch(r"\$2[aby]\$\d{2}\$[./A-Za-z0-9]{53}",s)))'
```

## 5.3　反映

3.3で作った統合したユーザーのファイルの、`ai-defense-reader` のハッシュだけを新しいものに入れ替えたファイルを作り、反映します（ほかのユーザーはそのまま残ります）。

```bash
python3 -c 'import yaml; p="/root/ai_defense_merged_internalusers.yml"; d=yaml.safe_load(open(p)); u=d["ai-defense-reader"]; print("USER_PRESENT:", "ai-defense-reader" in d); print("FIELDS:", sorted(u.keys())); print("DESCRIPTION:", u.get("description")); print("HASH_PRESENT:", bool(u.get("hash")))'
```

```bash
python3 -c 'import yaml, pathlib, os; src=pathlib.Path("/root/ai_defense_merged_internalusers.yml"); hp=pathlib.Path("/root/ai-defense-reader.new.hash"); dst=pathlib.Path("/root/ai_defense_merged_internalusers.updated.yml"); d=yaml.safe_load(src.read_text()); d["ai-defense-reader"]["hash"]=hp.read_text().strip(); dst.write_text(yaml.safe_dump(d,sort_keys=False,allow_unicode=True)); os.chmod(dst,0o600); print("UPDATED_CONFIG_CREATED; users=",len(d)-1,"; mode=600")'
```

```bash
OPENSEARCH_JAVA_HOME=/usr/share/wazuh-indexer/jdk /usr/share/wazuh-indexer/plugins/opensearch-security/tools/securityadmin.sh -h 127.0.0.1 -p 9200 -cacert /etc/wazuh-indexer/certs/root-ca.pem -cert /etc/wazuh-indexer/certs/admin.pem -key /etc/wazuh-indexer/certs/admin-key.pem -f /root/ai_defense_merged_internalusers.updated.yml -t internalusers
```

> 3.3の統合したファイルは、反映した時点のバックアップをもとにしています。その後に Indexer のユーザーを追加・変更していた場合は、このファイルで反映すると、その変更が消えます。その場合は、反映する前に最新の設定から作り直してください。

## 5.4　新しいパスワードでの確認

パスワードはファイルから読み、画面には出しません。

```bash
python3 - <<'PY'
import json
import urllib.request
import urllib.error
import base64
from pathlib import Path
from ssl import create_default_context

password = Path("/root/ai-defense-reader.password").read_text().strip()
token = base64.b64encode(f"ai-defense-reader:{password}".encode()).decode()
req = urllib.request.Request(
    "https://127.0.0.1:9200/_plugins/_security/authinfo",
    headers={"Authorization": f"Basic {token}"}
)
ctx = create_default_context(cafile="/etc/wazuh-indexer/certs/root-ca.pem")
try:
    with urllib.request.urlopen(req, context=ctx, timeout=10) as r:
        data = json.load(r)
        print("HTTP_STATUS:", r.status)
        print("USER:", data.get("user_name"))
        print("ROLE_PRESENT:", "ai_defense_alerts_read" in data.get("roles", []))
        print("AUTHENTICATION_TEST_OK")
except urllib.error.HTTPError as e:
    print("HTTP_STATUS:", e.code)
    print("AUTHENTICATION_TEST_FAILED")
PY
```

```bash
python3 - <<'PY'
import json, urllib.request, urllib.error, base64
from pathlib import Path
from ssl import create_default_context

password = Path("/root/ai-defense-reader.password").read_text().strip()
auth = base64.b64encode(f"ai-defense-reader:{password}".encode()).decode()
ctx = create_default_context(cafile="/etc/wazuh-indexer/certs/root-ca.pem")

for index, label in [
    ("wazuh-alerts-4.x-*/_search?size=0", "ALERTS"),
    ("wazuh-monitoring-*/_search?size=0", "MONITORING"),
]:
    req = urllib.request.Request(
        f"https://127.0.0.1:9200/{index}",
        headers={"Authorization": f"Basic {auth}"}
    )
    try:
        with urllib.request.urlopen(req, context=ctx, timeout=15) as r:
            print(label, "HTTP", r.status)
    except urllib.error.HTTPError as e:
        print(label, "HTTP", e.code)
PY
```

`ALERTS HTTP 200`、`MONITORING HTTP 403` であれば、範囲は正しく限られています。

# 第6章　中継APIの準備

## 6.1　アラートの項目

AI Defense Manager に渡す項目を決めるため、最新のアラートを1件だけ取り、項目の名前だけを表示します（中身は表示しません）。

```bash
python3 - <<'PY'
import json, urllib.request, base64
from pathlib import Path
from ssl import create_default_context

password = Path("/root/ai-defense-reader.password").read_text().strip()
auth = base64.b64encode(f"ai-defense-reader:{password}".encode()).decode()
body = json.dumps({
    "size": 1,
    "sort": [{"timestamp": {"order": "desc"}}],
    "_source": [
        "timestamp", "rule.id", "rule.level", "rule.description",
        "agent.id", "agent.name", "agent.ip", "manager.name",
        "location", "decoder.name", "data.srcip", "data.dstip",
        "data.srcport", "data.dstport", "data.protocol", "data.action"
    ]
}).encode()
req = urllib.request.Request(
    "https://127.0.0.1:9200/wazuh-alerts-4.x-*/_search",
    data=body,
    headers={"Authorization": f"Basic {auth}", "Content-Type": "application/json"}
)
ctx = create_default_context(cafile="/etc/wazuh-indexer/certs/root-ca.pem")
with urllib.request.urlopen(req, context=ctx, timeout=20) as r:
    result = json.load(r)
source = result["hits"]["hits"][0].get("_source", {}) if result["hits"]["hits"] else {}
def paths(obj, prefix=""):
    out = []
    for k, v in obj.items():
        p = f"{prefix}.{k}" if prefix else k
        out.append(p)
        if isinstance(v, dict):
            out.extend(paths(v, p))
    return out
print("MATCH_COUNT:", result["hits"]["total"]["value"] if isinstance(result["hits"]["total"], dict) else result["hits"]["total"])
print("RETURNED_FIELD_PATHS:")
for field in paths(source):
    print(field)
PY
```

中継APIで返すのは、次の10項目だけにします。`full_log`、任意の `data`、ユーザー名・コマンド・パスワードなどは返しません。

| 分類 | 項目 |
|---|---|
| 時刻 | `timestamp` |
| ルール | `rule.id`、`rule.level`、`rule.description` |
| エージェント | `agent.id`、`agent.name`、`agent.ip` |
| 管理サーバー | `manager.name` |
| 検知の情報 | `location`、`decoder.name` |

それぞれの型を確かめます（このユーザーにはマッピングを読む権限がないため、実際のアラート1件で調べます）。

```bash
python3 - <<'PY'
import json, urllib.request, urllib.error, base64
from pathlib import Path
from ssl import create_default_context

password = Path("/root/ai-defense-reader.password").read_text().strip()
auth = base64.b64encode(f"ai-defense-reader:{password}".encode()).decode()
body = json.dumps({
    "size": 1,
    "sort": [{"timestamp": {"order": "desc"}}],
    "_source": [
        "timestamp", "rule.id", "rule.level", "rule.description",
        "agent.id", "agent.name", "agent.ip", "manager.name",
        "location", "decoder.name"
    ]
}).encode()
req = urllib.request.Request(
    "https://127.0.0.1:9200/wazuh-alerts-4.x-*/_search",
    data=body,
    headers={"Authorization": f"Basic {auth}", "Content-Type": "application/json"}
)
ctx = create_default_context(cafile="/etc/wazuh-indexer/certs/root-ca.pem")
with urllib.request.urlopen(req, context=ctx, timeout=20) as r:
    result = json.load(r)

def walk(obj, prefix=""):
    for k, v in obj.items():
        path = f"{prefix}.{k}" if prefix else k
        if isinstance(v, dict):
            yield from walk(v, path)
        else:
            yield path, type(v).__name__

hits = result.get("hits", {}).get("hits", [])
print("SAMPLE_FOUND:", bool(hits))
if hits:
    for path, typ in sorted(walk(hits[0].get("_source", {}))):
        print(f"{path}: {typ}")
PY
```

構築時は、`rule.level` が整数で、ほかの9項目は文字列でした。

## 6.2　ネットワークとファイアウォール

中継APIは security-core に置き、VM 230 から接続します。今の待ち受けとファイアウォールを確かめます。

```bash
ss -lntp
```

構築時は、Indexer（9200・9300）は 127.0.0.1 だけで待ち受けていて、外に公開されていませんでした。

```bash
ufw status verbose
```

```bash
nft list ruleset
```

```bash
systemctl is-active firewalld
```

構築時は、ufw は `inactive`、nftables のルールはなし、firewalld も `inactive` で、security-core にはOSのファイアウォールがありませんでした。

```bash
ip -br addr
```

```bash
ip route
```

```bash
ip route get 192.168.0.33
```

security-core には2つのネットワーク（`enp6s18`：192.168.0.220、`enp6s19`：192.168.1.220）があり、VM 230（192.168.0.33）へは `enp6s18`（192.168.0.220）から届きます。中継APIは `192.168.0.220` だけで待ち受けることにします。

```bash
python3 --version
```

構築時は Python 3.12.3 で、標準のライブラリだけで中継APIを作れることを確かめました。

# 第13部のまとめ

## できたもの

| 種類 | 名前・場所 |
|---|---|
| Indexerのロール | `ai_defense_alerts_read`（`wazuh-alerts-4.x-*` の `read` だけ） |
| Indexerのユーザー | `ai-defense-reader` |
| パスワード | `/root/ai-defense-reader.password`（root だけ、`600`） |
| 設定のバックアップ | `/root/wazuh-security-backup-（日時）/` |
| 統合した設定 | `/root/ai_defense_merged_*.yml`、`/root/ai_defense_merged_internalusers.updated.yml` |

## 確かめたこと

- アラートは読め、monitoring は拒否される。
- 既存のロール・割り当て・ユーザーは、バックアップと比べてすべて残っている。
- Indexer は 127.0.0.1 だけで待ち受けていて、外に公開していない。

## 注意と残っていること

- `securityadmin.sh -f` は、その種類の設定を丸ごと置き換えます。追加するときは、必ず今の設定に足したファイルを反映してください（3.1）。
- **【リスク・未対応】** security-core には、OSのファイアウォール（ufw・nftables・firewalld）がありません。
- `/root` に、パスワードのハッシュ・記録・設定のファイルが残っています（いずれも root だけが読める）。不要になったものの片付けは行っていません。
- 中継APIそのもの（証明書・トークン・サービス）は、次の部で作ります。
