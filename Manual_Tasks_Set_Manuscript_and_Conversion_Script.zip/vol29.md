---
title: "AI自律型サイバー防御システム 構築マニュアル 中編"
subtitle: "第29部　読み残しを出さずにCollectorを動かし直す"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」中編の第29部です。第28部で、Collector は「前に読んでいたファイル（inode 5409383）が見つからない」ため、安全のために起動を止めていることがわかりました。ここでは次のことを行います。

1. 前のファイルがどうなったかを、ログのファイル・圧縮ファイル・チェックサムで確かめる
2. 保存した読み取り位置が、前のファイルの**最後**だったことを確かめる
3. PostgreSQL の重複を防ぐ仕組みを確かめたうえで、読み取り位置を「今の `alerts.json` の先頭」に書き換える
4. Collector を動かし、PostgreSQL に取り込まれたことを確かめる

読み取り位置を勝手に今のファイルの最後に進めると、読み残しが出ます。根拠を1つずつ確かめてから進めます。

## 本書の表記

- コマンドやプログラムは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 実行先は、各手順の「実行先」に示します。
  - **VM 220**：security-core（root）
  - **postgresql**：LXC 109（192.168.0.151）。OS のユーザー `postgres`
- アラートの本文は表示しません。PostgreSQL のパスワードは `.pgpass` から読み、表示しません。
- inode・大きさ・時刻・件数は構築時のものです。自分の環境の値に置き換えてください。

# 第1章　前のファイルを探す

> **実行先：VM 220**

## 1.1　ログのファイル

```bash
find /var/ossec/logs/alerts -maxdepth 3 -type f -printf '%i %s %M %u:%g %p\n' | sort -k6
```

11月17日〜20日の圧縮した JSON のログ（`2026/Nov/ossec-alerts-*.json.gz`）と、21日の今のログが残っていました。inode 5409383 はありません。Collector の探す処理は `.json` で終わるファイルだけを対象にし、`.json.gz` は探しません。

```bash
if command -v lsof >/dev/null 2>&1; then lsof -nP +L1 2>/dev/null | grep -E '5409383|alerts' || true; else echo "lsof_NOT_INSTALLED"; fi
```

消されたあとも開いたままになっているファイルもありませんでした。

```bash
stat -c 'INODE=%i SIZE=%s MTIME=%y PATH=%n' /var/ossec/logs/alerts/2026/Nov/ossec-alerts-*.json*
```

JSON のログは日ごとに切り替わり、17〜20日の分が圧縮され、21日の分が今の `alerts.json` になっています。

## 1.2　20日の分の大きさ

```bash
gzip -l /var/ossec/logs/alerts/2026/Nov/ossec-alerts-*.json.gz
```

20日の分を展開したときの大きさは **6,433,808 バイト**で、保存した読み取り位置と同じでした。

```bash
gzip -t /var/ossec/logs/alerts/2026/Nov/ossec-alerts-20.json.gz
echo "GZIP_TEST_EXIT_CODE=$?"
```

圧縮ファイルは壊れていません（`GZIP_TEST_EXIT_CODE=0`）。展開しながら（ディスクには書かずに）、行の数と形を調べます。

```bash
python3 - <<'PY'
import gzip, json

path = "/var/ossec/logs/alerts/2026/Nov/ossec-alerts-20.json.gz"
total = 0
lines = 0
invalid = 0
last_byte = None

with gzip.open(path, "rb") as f:
    while True:
        chunk = f.readline()
        if not chunk:
            break
        total += len(chunk)
        lines += 1
        last_byte = chunk[-1:]
        try:
            json.loads(chunk)
        except Exception:
            invalid += 1

print("UNCOMPRESSED_BYTES:", total)
print("LINE_COUNT:", lines)
print("INVALID_JSON_LINES:", invalid)
print("ENDS_WITH_NEWLINE:", last_byte == b"\n")
print("SAVED_OFFSET_MATCH:", total == 6433808)
PY
```

| 項目 | 結果 |
|---|---|
| 展開した大きさ | 6,433,808 バイト（保存した位置と一致） |
| 行の数 | 10,293 |
| JSON として読めない行 | 0 |
| 最後の改行 | あり |

## 1.3　時刻とチェックサム

```bash
stat -c 'MTIME=%y CTIME=%z SIZE=%s PATH=%n' /var/lib/wazuh-collector/state.json /var/ossec/logs/alerts/2026/Nov/ossec-alerts-20.json.gz /var/ossec/logs/alerts/2026/Nov/ossec-alerts-20.json.sum
file /var/ossec/logs/alerts/2026/Nov/ossec-alerts-20.json.sum
```

状態ファイルの保存は 11月20日 23:54:26（UTC）、20日の分の圧縮は 11月21日 00:00:10（UTC）でした。保存したときは、20日の分が今のファイルでした。

Wazuh が作ったチェックサムのファイル（37バイト）を見ます。

```bash
cat /var/ossec/logs/alerts/2026/Nov/ossec-alerts-20.json.sum
```

圧縮する前の 20日の分の SHA-256 が記録されていました。

```text
7b07b435669a8c98892f4919295644c21bfdb35522f3747e21366f6ba0aafe79
```

展開しながら SHA-256 を計算し、記録と比べます。値は自分の環境の `.sum` の値に置き換えてください。

```bash
python3 - <<'PY'
import gzip, hashlib

path = "/var/ossec/logs/alerts/2026/Nov/ossec-alerts-20.json.gz"
expected = "7b07b435669a8c98892f4919295644c21bfdb35522f3747e21366f6ba0aafe79"

h = hashlib.sha256()
size = 0

with gzip.open(path, "rb") as f:
    while True:
        chunk = f.read(1024 * 1024)
        if not chunk:
            break
        h.update(chunk)
        size += len(chunk)

actual = h.hexdigest()
print("UNCOMPRESSED_BYTES:", size)
print("ACTUAL_SHA256:", actual)
print("EXPECTED_SHA256:", expected)
print("CHECKSUM_MATCH:", actual == expected)
PY
```

`CHECKSUM_MATCH: True` でした。

## 1.4　今のファイル

```bash
python3 - <<'PY'
import json
from pathlib import Path

p = Path("/var/ossec/logs/alerts/alerts.json")
size = 0
lines = 0
invalid = 0
last_byte = None

with p.open("rb") as f:
    while True:
        line = f.readline()
        if not line:
            break
        size += len(line)
        lines += 1
        last_byte = line[-1:]
        try:
            json.loads(line)
        except Exception:
            invalid += 1

print("CURRENT_INODE:", p.stat().st_ino)
print("CURRENT_BYTES:", size)
print("LINE_COUNT:", lines)
print("INVALID_JSON_LINES:", invalid)
print("ENDS_WITH_NEWLINE:", last_byte == b"\n")
PY
```

21日の分も、読めない行はありませんでした。境目の時刻を比べます。

```bash
python3 - <<'PY'
import gzip, json

archive = "/var/ossec/logs/alerts/2026/Nov/ossec-alerts-20.json.gz"
current = "/var/ossec/logs/alerts/alerts.json"

last = None
with gzip.open(archive, "rb") as f:
    for line in f:
        if line.strip():
            last = json.loads(line)

with open(current, "rb") as f:
    first = json.loads(f.readline())

print("ARCHIVE_LAST_TIMESTAMP:", last.get("timestamp"))
print("CURRENT_FIRST_TIMESTAMP:", first.get("timestamp"))
PY
```

| 項目 | 時刻（UTC） |
|---|---|
| 20日の分の最後のイベント | 11/20 23:54:26.205 |
| 状態ファイルの保存 | 11/20 23:54:26.714 |
| 21日の分の最初のイベント | 11/21 00:09:26.253 |

保存した読み取り位置は、20日の分の最後に当たります。したがって、**今の `alerts.json`（inode 5409517）を先頭（offset 0）から読めばよい**ことになります。ただし、この15分のあいだにアラートがなかったことまでは証明できません。

## 1.5　重複を防ぐ仕組み

21日の分の一部は、Collector がまだ動いていたときに取り込まれている可能性があります。先頭から読み直しても二重に登録されないかを確かめます。

```bash
PGPASSFILE=/etc/wazuh-collector/.pgpass psql "host=postgresql.neomedia.mydns.jp hostaddr=192.168.0.151 port=5432 dbname=security_workbench user=wazuh_collector sslmode=verify-full sslrootcert=/etc/ssl/certs/postgresql-server-ca.pem" -X -A -F '|' -c "SELECT i.relname AS index_name, ix.indisunique AS is_unique, pg_get_indexdef(i.oid) AS index_definition FROM pg_class t JOIN pg_namespace n ON n.oid=t.relnamespace JOIN pg_index ix ON ix.indrelid=t.oid JOIN pg_class i ON i.oid=ix.indexrelid WHERE n.nspname='incident' AND t.relname='alert_events' ORDER BY i.relname;"
```

構築時の結果（要点）は次のとおりで、`event_id` が主キー（一意）でした。

```text
alert_events_pkey
UNIQUE (event_id)
```

Collector の側の処理も確かめます。

```bash
grep -n -A45 -B15 'UniqueViolation\|def process_line' /usr/local/lib/wazuh-collector/collector.py
```

```bash
sed -n '555,610p' /usr/local/lib/wazuh-collector/collector.py
```

```bash
sed -n '600,665p' /usr/local/lib/wazuh-collector/collector.py
```

1. 1件ずつ別のトランザクションで INSERT する
2. `event_id` の重複（SQLSTATE `23505`）なら取り消して次へ進む
3. INSERT の成功・重複のどちらでも、そのあとで読み取り位置を保存する
4. DB や保存に失敗したら、行の頭に戻ってやり直す
5. ファイルが切り替わったら、新しい inode と offset 0 を先に保存してから切り替える

# 第2章　読み取り位置を書き換える

> **実行先：VM 220**

## 2.1　止める

```bash
systemctl stop wazuh-collector.service
```

```bash
systemctl is-active wazuh-collector.service
systemctl show wazuh-collector.service -p MainPID -p NRestarts -p ActiveState -p SubState
```

`inactive`、`MainPID=0` で、状態ファイルを書き換えるプロセスがないことを確かめます。

## 2.2　バックアップ

```bash
backup="/var/lib/wazuh-collector/state.json.pre-recovery-20261121"; test ! -e "$backup" && cp -a /var/lib/wazuh-collector/state.json "$backup" && sha256sum /var/lib/wazuh-collector/state.json "$backup" && cmp -s /var/lib/wazuh-collector/state.json "$backup" && echo "BACKUP_VERIFY=OK"
```

`BACKUP_VERIFY=OK` を確かめます。

## 2.3　書き換え

新しい読み取り位置は次のとおりです。

```text
{"inode": 5409517, "offset": 0}
```

今の状態ファイルが予想どおり（inode 5409383・offset 6433808）で、`alerts.json` の inode が 5409517 のときだけ書き換えます。違えば何もせずに止まります。書き換えは一時ファイルに書いてから置き換え、権限と持ち主は元のままにします。

```bash
python3 - <<'PY'
import json, os, stat, tempfile

state_path = "/var/lib/wazuh-collector/state.json"
backup_path = "/var/lib/wazuh-collector/state.json.pre-recovery-20261121"
alert_path = "/var/ossec/logs/alerts/alerts.json"

with open(state_path, encoding="utf-8") as f:
    old_state = json.load(f)
with open(backup_path, "rb") as f:
    backup_bytes = f.read()

if old_state != {"inode": 5409383, "offset": 6433808}:
    raise SystemExit("ABORT: state.json differs from expected old state")
if os.stat(alert_path).st_ino != 5409517:
    raise SystemExit("ABORT: alerts.json inode changed")
if not backup_bytes:
    raise SystemExit("ABORT: backup is empty")

st = os.stat(state_path)
directory = os.path.dirname(state_path)
fd, temp_path = tempfile.mkstemp(prefix=".state.json.recovery.", dir=directory)

try:
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump({"inode": 5409517, "offset": 0}, f)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())

    os.chmod(temp_path, stat.S_IMODE(st.st_mode))
    os.chown(temp_path, st.st_uid, st.st_gid)
    os.replace(temp_path, state_path)

    dir_fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(dir_fd)
    finally:
        os.close(dir_fd)
except Exception:
    if os.path.exists(temp_path):
        os.unlink(temp_path)
    raise

with open(state_path, encoding="utf-8") as f:
    result = json.load(f)

print("NEW_STATE:", json.dumps(result, sort_keys=True))
print("STATE_UPDATE:", "OK" if result == {"inode": 5409517, "offset": 0} else "FAILED")
print("BACKUP_PRESERVED:", os.path.exists(backup_path))
PY
```

## 2.4　動かす

```bash
systemctl start wazuh-collector.service
```

```bash
systemctl is-active wazuh-collector.service
systemctl show wazuh-collector.service -p MainPID -p NRestarts -p ActiveState -p SubState
```

構築時は `active`・`running`（PID 13542）でした。`NRestarts=874` は止める前までの回数の合計です。

```bash
journalctl -u wazuh-collector.service -n 60 --no-pager -o short-iso
```

```bash
journalctl -u wazuh-collector.service --since "2026-11-21 10:45:00" --no-pager -o short-iso | tail -n 40
```

動かしたあとのログに、次の2行がありました。

```text
INFO Resuming current alert file
INFO PostgreSQL connection established
```

## 2.5　読み進んでいるか

```bash
python3 - <<'PY'
import json, os

state_path = "/var/lib/wazuh-collector/state.json"
alert_path = "/var/ossec/logs/alerts/alerts.json"

with open(state_path, encoding="utf-8") as f:
    state = json.load(f)

st = os.stat(alert_path)
print("STATE_INODE:", state["inode"])
print("STATE_OFFSET:", state["offset"])
print("CURRENT_INODE:", st.st_ino)
print("CURRENT_SIZE:", st.st_size)
print("INODE_MATCH:", state["inode"] == st.st_ino)
print("OFFSET_WITHIN_FILE:", 0 <= state["offset"] <= st.st_size)
PY
```

読み取り位置（858,191）がファイルの大きさと同じになり、最後まで読んだことがわかりました。

```bash
systemctl is-active wazuh-collector.service
journalctl -u wazuh-collector.service --since "2026-11-21 10:45:00" --no-pager -o cat | grep -E 'ERROR|WARNING|Duplicate alert skipped|PostgreSQL connection|Resuming current alert'
```

動かしたあとに、エラーや警告はありませんでした。

# 第3章　PostgreSQLで確かめる

> **実行先：postgresql**（OS のユーザー `postgres`）

`wazuh_collector` は INSERT だけの権限なので、権限は足さず、PostgreSQL の管理者で読み取りだけの SQL を実行します。

```bash
psql -d security_workbench -X -P pager=off -c "
SELECT
    COUNT(*) AS events_last_30m,
    MIN(event_timestamp) AS first_event,
    MAX(event_timestamp) AS latest_event
FROM incident.alert_events
WHERE event_timestamp >= NOW() - INTERVAL '30 minutes';
"
```

直近30分のイベントは143件でした。取り込んだ時刻の列があるかを確かめます。

```bash
psql -d security_workbench -X -P pager=off -c "
SELECT column_name, data_type
FROM information_schema.columns
WHERE table_schema = 'incident'
  AND table_name = 'alert_events'
ORDER BY ordinal_position;
"
```

`ingested_at` がありました。Collector を動かした時刻（10:45:16 UTC）より後に取り込まれた件数を数えます。時刻は自分の環境のものに置き換えます。

```bash
psql -d security_workbench -X -P pager=off -c "
SELECT
    COUNT(*) AS ingested_after_restart,
    COUNT(DISTINCT event_id) AS unique_event_ids,
    MIN(ingested_at) AS first_ingested_at,
    MAX(ingested_at) AS latest_ingested_at
FROM incident.alert_events
WHERE ingested_at >= TIMESTAMPTZ '2026-11-21 10:45:16+00';
"
```

| 項目 | 結果 |
|---|---|
| 動かしたあとの登録 | 1,318件 |
| 異なる `event_id` | 1,318件（重複なし） |
| 最初の登録 | 10:45:16.110 UTC |
| 最後の登録 | 10:58:41.944 UTC |

```bash
psql -d security_workbench -X -P pager=off -c "
SELECT
    COUNT(*) AS ingested_last_5m,
    MAX(ingested_at) AS latest_ingested_at
FROM incident.alert_events
WHERE ingested_at >= NOW() - INTERVAL '5 minutes';
"
```

直近5分は1件でした。新しいアラートが少ないだけの可能性があるので、読み残しがないかを VM 220 で確かめます。

> **実行先：VM 220**

```bash
python3 - <<'PY'
import json, os

with open("/var/lib/wazuh-collector/state.json", encoding="utf-8") as f:
    state = json.load(f)

st = os.stat("/var/ossec/logs/alerts/alerts.json")
print("STATE_INODE:", state["inode"])
print("STATE_OFFSET:", state["offset"])
print("CURRENT_INODE:", st.st_ino)
print("CURRENT_SIZE:", st.st_size)
print("INODE_MATCH:", state["inode"] == st.st_ino)
print("OFFSET_AT_EOF:", state["offset"] == st.st_size)
print("UNPROCESSED_BYTES:", max(0, st.st_size - state["offset"]) if state["inode"] == st.st_ino else "ROTATION")
PY
```

`UNPROCESSED_BYTES: 0`（読み残しなし）でした。

```bash
systemctl show wazuh-collector.service -p ActiveState -p SubState -p MainPID -p NRestarts
```

# おわりに

第29部で、Collector を読み残しなしに動かし直しました。

| 項目 | 結果 |
|---|---|
| 前のファイル | 20日の分の圧縮ファイル。大きさ・行・チェックサムで確認 |
| 読み取り位置 | inode 5409517・offset 0 に書き換え（バックアップは `state.json.pre-recovery-20261121`） |
| PostgreSQL | 1,318件を登録、重複 0 |
| 読み残し | 0 バイト |

ローテーションの前後でイベントが欠けていないことまでは証明していません。また、試験用の隠しディレクトリは残ったままなので、次にファイルが切り替わったとき、同じ理由で止まるおそれがあります。次の部で、これを防ぎます。
