---
title: "AI自律型サイバー防御システム 構築マニュアル 前編"
subtitle: "第18部　分析履歴をSQLiteに残す"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」前編の第18部です。AI の分析の結果と、その根拠になったイベント、防御の提案と承認の状態を、VM 230 の中の SQLite に記録します。

PostgreSQL のサーバーは、当面は使いません（構築時に「当面は VM 230 内の SQLite で保存する」方針にしました）。SQLite なら Python の標準のライブラリ（`sqlite3`）だけで作れ、パッケージを足す必要がありません。

| 項目 | 設計 |
|---|---|
| DB | SQLite 3 |
| 保存先 | `/opt/ai-defense-manager/data/ai-defense.db` |
| ジャーナル | WAL |
| DBへのアクセス | Python 標準の `sqlite3` |
| 実行ユーザー | `ai-defense` |
| トランザクション | 分析の結果と証拠のイベントをまとめて保存する |
| 同じ分析 | 分析するたびに別の記録にする |
| 承認 | 初めの状態は `pending` |
| 防御の実行 | 今回は作らない |

テーブルは次の5つです。

| テーブル | 中身 |
|---|---|
| `analysis_runs` | AI の分析の実行の記録 |
| `analysis_evidence` | 分析の対象にしたイベントの識別子・要約 |
| `action_proposals` | AI が提案した防御の内容 |
| `action_approvals` | 人による承認・却下の状態 |
| `audit_logs` | 操作の記録（監査ログ） |

Wazuh の生のログ（`full_log`）、任意の `data`、コマンド、ユーザー名、認証の情報は保存しません。

## 本書の表記

- コマンドやプログラムは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 実行先は **ai-defense-manager VM 230（root）** です。

# 第1章　今の状態を確かめる

## 1.1　PostgreSQLの設定

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
from app.core.config import settings

print("POSTGRES_HOST:", settings.postgres_host or "NOT_CONFIGURED")
print("POSTGRES_PORT:", settings.postgres_port)
print("POSTGRES_DATABASE:", settings.postgres_database or "NOT_CONFIGURED")
print("POSTGRES_CONFIG_CHECK_OK")
PY
```

構築時は、ホストとデータベース名が未設定でした。

## 1.2　既存のDBとDBのコード

```bash
cd /opt/ai-defense-manager && find . -maxdepth 3 -type f \( -name '*.db' -o -name '*.sqlite' -o -name '*.sqlite3' \) -printf '%p\n' | sort
```

```bash
cd /opt/ai-defense-manager && grep -RInE 'sqlalchemy|sqlite3|create_engine|AsyncSession|sessionmaker|DATABASE_URL|postgres' app requirements.lock --exclude='*.pyc' | head -n 100
```

構築時は、SQLite のファイルも、SQLAlchemy も、DB を扱うコードもありませんでした（PostgreSQL は設定の項目だけ）。

## 1.3　保存先

```bash
ls -ld /var/lib /var/lib/ai-defense-manager /opt/ai-defense-manager/data /opt/ai-defense-manager/logs 2>/dev/null
```

`/opt/ai-defense-manager/data` は `ai-defense:ai-defense` の `750` です。実行ユーザーの持ち物なので、ここに DB を置きます。

```text
/opt/ai-defense-manager/data/ai-defense.db
```

```bash
cd /opt/ai-defense-manager && runuser -u ai-defense -- ./venv/bin/python - <<'PY'
import sqlite3

print("SQLITE_VERSION:", sqlite3.sqlite_version)
print("THREAD_SAFETY:", sqlite3.threadsafety)

conn = sqlite3.connect(":memory:")
print("JOURNAL_MODE:", conn.execute("PRAGMA journal_mode").fetchone()[0])
conn.close()

print("SQLITE_CHECK_OK")
PY
```

構築時は SQLite 3.45.1、`THREAD_SAFETY: 3` でした。

## 1.4　組み込む場所の確認

```bash
cd /opt/ai-defense-manager && find app -maxdepth 3 -type f -name '*.py' -printf '%p\n' | sort
```

```bash
cd /opt/ai-defense-manager && sed -n '1,260p' app/api/wazuh.py
```

```bash
cd /opt/ai-defense-manager && sed -n '1,280p' app/schemas/analysis_proposal.py && echo '===== SECURITY EVENT =====' && sed -n '1,260p' app/schemas/security_event.py
```

```bash
cd /opt/ai-defense-manager && sed -n '1,240p' app/main.py && echo '===== ANALYSIS API =====' && sed -n '1,240p' app/api/analysis.py
```

```bash
cd /opt/ai-defense-manager && sed -n '1,300p' app/services/wazuh_relay.py
```

```bash
cd /opt/ai-defense-manager && sed -n '1,320p' app/services/ai_analysis.py
```

わかったことは次のとおりです。

- `SecurityEvent.event_id` は、VM 230 で `uuid4()` により作られる ID です。Wazuh の元のイベントIDではありません。同じアラートを取り直すと別の ID になることがあります。そのため、Wazuh の元の ID と見誤るような列の名前は使いません。
- `ai_analysis.py` は AI への問い合わせと JSON の検証だけをしています。DB の処理はここには混ぜず、API の層で、分析が成功した後に保存します。

# 第2章　履歴を保存するサービス

## 2.1　バックアップ

変更するファイルのバックアップを取ります。

```bash
BACKUP="/root/ai-defense-backup-$(date +%Y%m%d-%H%M%S)" && install -d -m 700 "$BACKUP" && cd /opt/ai-defense-manager && cp --parents app/main.py app/api/analysis.py app/api/wazuh.py app/schemas/analysis.py app/schemas/analysis_proposal.py app/schemas/security_event.py app/core/config.py "$BACKUP" && chmod -R go-rwx "$BACKUP" && echo "BACKUP_DIR=$BACKUP" && find "$BACKUP" -type f -printf '%P\n' | sort
```

## 2.2　analysis_history.py

DB の初期化と、分析の結果の保存を作ります。

- SQL はすべてプレースホルダー（`?`）を使う
- 5つのテーブルへの書き込みは1つのトランザクションにまとめ、途中で失敗したら何も残さない
- 提案の証拠のイベントIDが、入力したイベントに含まれていなければ保存しない
- `no_action`（何もしない）の提案は、承認を `not_required` にする

```bash
cd /opt/ai-defense-manager && cat > app/services/analysis_history.py <<'PY'
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from app.schemas.analysis import AIAnalysisRequest
from app.schemas.analysis_proposal import AIAnalysisProposal


DB_PATH = Path("/opt/ai-defense-manager/data/ai-defense.db")


SCHEMA = """
CREATE TABLE IF NOT EXISTS analysis_runs (
    run_id TEXT PRIMARY KEY,
    created_at TEXT NOT NULL,
    severity TEXT NOT NULL,
    confidence REAL NOT NULL CHECK(confidence BETWEEN 0 AND 1),
    summary TEXT NOT NULL,
    recommended_action TEXT NOT NULL,
    reasoning TEXT NOT NULL,
    evidence_count INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'completed'
);

CREATE TABLE IF NOT EXISTS analysis_evidence (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL,
    event_id TEXT NOT NULL,
    source TEXT NOT NULL,
    observed_at TEXT NOT NULL,
    severity TEXT NOT NULL,
    rule_id TEXT,
    event_summary TEXT NOT NULL,
    FOREIGN KEY(run_id) REFERENCES analysis_runs(run_id),
    UNIQUE(run_id, event_id)
);

CREATE TABLE IF NOT EXISTS action_proposals (
    proposal_id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL UNIQUE,
    action_type TEXT NOT NULL,
    target_ip TEXT,
    ttl_seconds INTEGER,
    requires_human_approval INTEGER NOT NULL,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(run_id) REFERENCES analysis_runs(run_id)
);

CREATE TABLE IF NOT EXISTS action_approvals (
    approval_id TEXT PRIMARY KEY,
    proposal_id TEXT NOT NULL UNIQUE,
    decision TEXT NOT NULL,
    decided_by TEXT,
    decided_at TEXT,
    FOREIGN KEY(proposal_id) REFERENCES action_proposals(proposal_id)
);

CREATE TABLE IF NOT EXISTS audit_logs (
    audit_id INTEGER PRIMARY KEY AUTOINCREMENT,
    occurred_at TEXT NOT NULL,
    actor TEXT NOT NULL,
    action TEXT NOT NULL,
    target_type TEXT NOT NULL,
    target_id TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_analysis_runs_created_at
    ON analysis_runs(created_at);

CREATE INDEX IF NOT EXISTS idx_analysis_evidence_event_id
    ON analysis_evidence(event_id);

CREATE INDEX IF NOT EXISTS idx_action_proposals_status
    ON action_proposals(status);

CREATE INDEX IF NOT EXISTS idx_audit_logs_occurred_at
    ON audit_logs(occurred_at);
"""


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(
        DB_PATH,
        timeout=5.0,
    )
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 5000")
    conn.execute("PRAGMA synchronous = FULL")
    return conn


def initialize_database() -> None:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)

    with _connect() as conn:
        conn.execute("PRAGMA journal_mode = WAL")
        conn.executescript(SCHEMA)


def save_analysis(
    request: AIAnalysisRequest,
    proposal: AIAnalysisProposal,
) -> str:
    event_ids = {event.event_id for event in request.events}

    if not set(proposal.evidence_event_ids).issubset(event_ids):
        raise ValueError("Proposal contains unknown evidence event IDs")

    run_id = str(uuid4())
    proposal_id = str(uuid4())
    now = datetime.now(timezone.utc).isoformat()

    action_requires_approval = (
        proposal.requires_human_approval
        and proposal.recommended_action.value != "no_action"
    )

    proposal_status = (
        "pending"
        if action_requires_approval
        else "not_required"
    )

    approval_decision = (
        "pending"
        if action_requires_approval
        else "not_required"
    )

    with _connect() as conn:
        conn.execute("BEGIN IMMEDIATE")

        conn.execute(
            """
            INSERT INTO analysis_runs (
                run_id, created_at, severity, confidence, summary,
                recommended_action, reasoning, evidence_count, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'completed')
            """,
            (
                run_id,
                now,
                proposal.severity,
                proposal.confidence,
                proposal.summary,
                proposal.recommended_action.value,
                proposal.reasoning,
                len(request.events),
            ),
        )

        for event in request.events:
            conn.execute(
                """
                INSERT INTO analysis_evidence (
                    run_id, event_id, source, observed_at,
                    severity, rule_id, event_summary
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    run_id,
                    str(event.event_id),
                    event.source,
                    event.observed_at.isoformat(),
                    event.severity,
                    event.rule_id,
                    event.event_summary,
                ),
            )

        conn.execute(
            """
            INSERT INTO action_proposals (
                proposal_id, run_id, action_type, target_ip,
                ttl_seconds, requires_human_approval,
                status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                proposal_id,
                run_id,
                proposal.recommended_action.value,
                proposal.target_ip,
                proposal.ttl_seconds,
                int(proposal.requires_human_approval),
                proposal_status,
                now,
            ),
        )

        conn.execute(
            """
            INSERT INTO action_approvals (
                approval_id, proposal_id, decision
            ) VALUES (?, ?, ?)
            """,
            (
                str(uuid4()),
                proposal_id,
                approval_decision,
            ),
        )

        conn.execute(
            """
            INSERT INTO audit_logs (
                occurred_at, actor, action, target_type, target_id
            ) VALUES (?, 'ai-defense-manager', 'analysis_created',
                      'analysis_run', ?)
            """,
            (now, run_id),
        )

    return run_id
PY
chown root:ai-defense app/services/analysis_history.py
chmod 640 app/services/analysis_history.py
```

```bash
cd /opt/ai-defense-manager && ls -l app/services/analysis_history.py && ./venv/bin/python -m py_compile app/services/analysis_history.py
```

## 2.3　接続を確実に閉じる

`sqlite3` の接続は、`with` 文だけでは閉じられません（`with` はトランザクションの確定・取り消しだけを行います）。接続を必ず閉じる `_connection()` を足し、使っていない `import json` を外します。

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
from pathlib import Path

path = Path("app/services/analysis_history.py")
source = path.read_text(encoding="utf-8")

source = source.replace(
    "import json\nimport sqlite3\n",
    "import sqlite3\nfrom contextlib import contextmanager\n",
)
source = source.replace(
    "\ndef initialize_database() -> None:\n",
    """
@contextmanager
def _connection():
    conn = _connect()
    try:
        with conn:
            yield conn
    finally:
        conn.close()


def initialize_database() -> None:
""",
)
source = source.replace("with _connect() as conn:", "with _connection() as conn:")

path.write_text(source, encoding="utf-8")
print("CONNECTION_CLOSE_PATCH_APPLIED")
PY
```

```bash
cd /opt/ai-defense-manager && ./venv/bin/python -m py_compile app/services/analysis_history.py && grep -nE '^(import|from contextlib|def _connection|def initialize_database|def save_analysis)|with _connection' app/services/analysis_history.py
```

## 2.4　一時的なDBで試す

本番の DB はまだ作らず、一時的なディレクトリの中の DB で次を確かめます。

1. 5つのテーブルができる
2. 分析の結果・証拠のイベント・承認の状態が保存される
3. 保存の途中で失敗したとき（同じイベントを2回入れる）、途中までのデータが残らない

```bash
cd /opt/ai-defense-manager && runuser -u ai-defense -- ./venv/bin/python - <<'PY'
import sqlite3
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from app.schemas.analysis import AIAnalysisRequest
from app.schemas.analysis_proposal import AIAnalysisProposal, RecommendedAction
from app.schemas.security_event import SecurityEvent
import app.services.analysis_history as history

with tempfile.TemporaryDirectory() as tmp:
    history.DB_PATH = Path(tmp) / "test.db"
    history.initialize_database()

    event_id = uuid4()
    event = SecurityEvent(
        event_id=event_id,
        source="wazuh",
        observed_at=datetime.now(timezone.utc),
        severity="medium",
        rule_id="100001",
        event_category="authentication",
        event_summary="Test security event",
    )

    request = AIAnalysisRequest(
        events=[event],
        requested_language="ja",
    )
    proposal = AIAnalysisProposal(
        summary="Test analysis",
        severity="medium",
        confidence=0.95,
        evidence_event_ids=[event_id],
        recommended_action=RecommendedAction.MONITOR,
        requires_human_approval=True,
        reasoning="Test only",
    )

    run_id = history.save_analysis(request, proposal)
    print("SAVE_TEST: OK")
    print("RUN_ID_CREATED:", bool(run_id))

    duplicate_request = AIAnalysisRequest(
        events=[event, event],
        requested_language="ja",
    )

    try:
        history.save_analysis(duplicate_request, proposal)
        raise AssertionError("Expected transaction failure did not occur")
    except sqlite3.IntegrityError:
        print("ROLLBACK_TEST: OK")

    with sqlite3.connect(history.DB_PATH) as conn:
        tables = {
            row[0]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            )
        }
        expected = {
            "analysis_runs",
            "analysis_evidence",
            "action_proposals",
            "action_approvals",
            "audit_logs",
        }
        assert expected.issubset(tables), tables

        counts = {
            table: conn.execute(
                f"SELECT COUNT(*) FROM {table}"
            ).fetchone()[0]
            for table in sorted(expected)
        }
        mode = conn.execute("PRAGMA journal_mode").fetchone()[0]

    print("TABLES:", sorted(expected))
    print("COUNTS:", counts)
    print("JOURNAL_MODE:", mode)

    assert counts["analysis_runs"] == 1
    assert counts["analysis_evidence"] == 1
    assert counts["action_proposals"] == 1
    assert counts["action_approvals"] == 1
    assert counts["audit_logs"] == 1
    assert mode.lower() == "wal"

print("SQLITE_HISTORY_TESTS_OK")
PY
```

`SQLITE_HISTORY_TESTS_OK` が出れば成功です。一時的な DB は自動で消えます。

# 第3章　APIに組み込む

## 3.1　request_idも保存する

```bash
cd /opt/ai-defense-manager && sed -n '1,220p' app/schemas/analysis.py
```

`AIAnalysisRequest` には `request_id` があるので、同じリクエストの再送を見分けるために保存します。また、SQLite への書き込みは `asyncio.to_thread()` で行い、FastAPI の処理を長く止めないようにします。

API への組み込み方は次のとおりです。

- 分析が成功した後に保存する
- 保存に失敗したら `503` を返す（保存できなかった分析の結果を、成功として返さない）
- アプリの起動のとき（`lifespan`）に DB を初期化する

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
from pathlib import Path

p = Path("app/services/analysis_history.py")
s = p.read_text(encoding="utf-8")
s = s.replace(
    "    run_id TEXT PRIMARY KEY,\n    created_at TEXT NOT NULL,",
    "    run_id TEXT PRIMARY KEY,\n    request_id TEXT NOT NULL,\n    created_at TEXT NOT NULL,",
)
s = s.replace(
    "                run_id, created_at, severity, confidence, summary,\n                recommended_action, reasoning, evidence_count, status\n            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'completed')",
    "                run_id, request_id, created_at, severity, confidence, summary,\n                recommended_action, reasoning, evidence_count, status\n            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'completed')",
)
s = s.replace(
    "                run_id,\n                now,\n                proposal.severity,",
    "                run_id,\n                str(request.request_id),\n                now,\n                proposal.severity,",
)
p.write_text(s, encoding="utf-8")

Path("app/api/analysis.py").write_text('''import asyncio
import sqlite3

from fastapi import APIRouter, HTTPException

from app.schemas.analysis import AIAnalysisRequest
from app.schemas.analysis_proposal import AIAnalysisProposal
from app.services.ai_analysis import AIAnalysisError, analyze_events
from app.services.analysis_history import save_analysis

router = APIRouter(prefix="/api/v1", tags=["AI Analysis"])


@router.post(
    "/analysis",
    response_model=AIAnalysisProposal,
)
async def create_analysis(
    request: AIAnalysisRequest,
) -> AIAnalysisProposal:
    try:
        proposal = await analyze_events(request)
    except AIAnalysisError as exc:
        raise HTTPException(
            status_code=502,
            detail="AI analysis failed or returned an invalid response",
        ) from exc

    try:
        await asyncio.to_thread(save_analysis, request, proposal)
    except (sqlite3.Error, OSError) as exc:
        raise HTTPException(
            status_code=503,
            detail="Analysis succeeded but history could not be saved",
        ) from exc

    return proposal
''', encoding="utf-8")

Path("app/api/wazuh.py").write_text('''import asyncio
import sqlite3

from fastapi import APIRouter, HTTPException, Query

from app.schemas.analysis import AIAnalysisRequest
from app.schemas.analysis_proposal import AIAnalysisProposal
from app.schemas.security_event import SecurityEvent
from app.schemas.wazuh import WazuhAnalysisRequest
from app.services.ai_analysis import AIAnalysisError, analyze_events
from app.services.analysis_history import save_analysis
from app.services.wazuh_relay import WazuhRelayError, fetch_wazuh_events

router = APIRouter(prefix="/api/v1/wazuh", tags=["Wazuh"])


@router.get("/events", response_model=list[SecurityEvent])
async def get_wazuh_events(
    limit: int = Query(default=50, ge=1, le=100),
    since_minutes: int = Query(default=60, ge=1, le=1440),
) -> list[SecurityEvent]:
    try:
        return await fetch_wazuh_events(
            limit=limit,
            since_minutes=since_minutes,
        )
    except WazuhRelayError as exc:
        raise HTTPException(
            status_code=502,
            detail="Wazuh alert retrieval or validation failed",
        ) from exc


@router.post("/analyze", response_model=AIAnalysisProposal)
async def analyze_wazuh_events(
    request: WazuhAnalysisRequest,
) -> AIAnalysisProposal:
    try:
        events = await fetch_wazuh_events(
            limit=request.limit,
            since_minutes=request.since_minutes,
        )

        if not events:
            raise HTTPException(
                status_code=404,
                detail="No Wazuh alerts found in the requested time range",
            )

        analysis_request = AIAnalysisRequest(
            events=events,
            analysis_context=request.analysis_context,
            requested_language=request.requested_language,
        )

        proposal = await analyze_events(analysis_request)

    except WazuhRelayError as exc:
        raise HTTPException(
            status_code=502,
            detail="Wazuh alert retrieval or validation failed",
        ) from exc
    except AIAnalysisError as exc:
        raise HTTPException(
            status_code=502,
            detail="AI analysis failed or returned an invalid response",
        ) from exc

    try:
        await asyncio.to_thread(
            save_analysis,
            analysis_request,
            proposal,
        )
    except (sqlite3.Error, OSError) as exc:
        raise HTTPException(
            status_code=503,
            detail="Analysis succeeded but history could not be saved",
        ) from exc

    return proposal
''', encoding="utf-8")

Path("app/main.py").write_text('''from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.core.config import settings
from app.api.analysis import router as analysis_router
from app.api.wazuh import router as wazuh_router
from app.services.analysis_history import initialize_database


@asynccontextmanager
async def lifespan(app: FastAPI):
    initialize_database()
    yield


app = FastAPI(
    title=settings.app_name,
    description="Autonomous AI Cyber Defense Management API",
    version=settings.app_version,
    lifespan=lifespan,
)

app.include_router(analysis_router)
app.include_router(wazuh_router)


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "service": "ai-defense-manager",
        "version": settings.app_version,
    }
''', encoding="utf-8")

print("API_HISTORY_INTEGRATION_WRITTEN")
PY
```

## 3.2　構文とルートの確認

```bash
cd /opt/ai-defense-manager && ./venv/bin/python -m py_compile app/main.py app/api/analysis.py app/api/wazuh.py app/services/analysis_history.py && runuser -u ai-defense -- ./venv/bin/python - <<'PY'
from app.main import app

for route in app.routes:
    methods = getattr(route, "methods", None)
    path = getattr(route, "path", None)
    if path:
        print(",".join(sorted(methods or [])), path)

print("API_IMPORT_CHECK_OK")
PY
```

第16部 3.3 と同じく、この一覧には `/api/v1/...` が出てきません（FastAPI がルーターを遅れて組み込むため）。ルーターと OpenAPI で確かめます。

```bash
cd /opt/ai-defense-manager && runuser -u ai-defense -- ./venv/bin/python - <<'PY'
from app.main import app
from app.api.analysis import router as analysis_router
from app.api.wazuh import router as wazuh_router

print("===== ANALYSIS ROUTER =====")
for route in analysis_router.routes:
    print(getattr(route, "path", None), getattr(route, "methods", None))

print("===== WAZUH ROUTER =====")
for route in wazuh_router.routes:
    print(getattr(route, "path", None), getattr(route, "methods", None))

print("===== OPENAPI PATHS =====")
for path, methods in app.openapi()["paths"].items():
    print(path, sorted(methods.keys()))

PY
```

`/api/v1/analysis`（POST）、`/api/v1/wazuh/events`（GET）、`/api/v1/wazuh/analyze`（POST）、`/health`（GET）がそろっていれば正常です。

## 3.3　変更後の保存のテスト

`request_id` が保存され、承認の初めの状態が `pending` になることを、一時的な DB で確かめます。

```bash
cd /opt/ai-defense-manager && runuser -u ai-defense -- ./venv/bin/python - <<'PY'
import sqlite3
import tempfile
from pathlib import Path
from datetime import datetime, timezone
from uuid import uuid4

from app.schemas.analysis import AIAnalysisRequest
from app.schemas.analysis_proposal import AIAnalysisProposal, RecommendedAction
from app.schemas.security_event import SecurityEvent
import app.services.analysis_history as history

with tempfile.TemporaryDirectory() as tmp:
    history.DB_PATH = Path(tmp) / "test.db"
    history.initialize_database()

    event_id = uuid4()
    request = AIAnalysisRequest(
        events=[
            SecurityEvent(
                event_id=event_id,
                source="wazuh",
                observed_at=datetime.now(timezone.utc),
                severity="medium",
                rule_id="100001",
                event_category="authentication",
                event_summary="Test event",
            )
        ],
        requested_language="ja",
    )

    proposal = AIAnalysisProposal(
        summary="Test analysis",
        severity="medium",
        confidence=0.95,
        evidence_event_ids=[event_id],
        recommended_action=RecommendedAction.MONITOR,
        requires_human_approval=True,
        reasoning="Test only",
    )

    run_id = history.save_analysis(request, proposal)

    with sqlite3.connect(history.DB_PATH) as conn:
        row = conn.execute(
            "SELECT request_id, severity, evidence_count FROM analysis_runs WHERE run_id=?",
            (run_id,),
        ).fetchone()
        approval = conn.execute(
            "SELECT decision FROM action_approvals"
        ).fetchone()[0]

    assert row[0] == str(request.request_id)
    assert row[1:] == ("medium", 1)
    assert approval == "pending"

    print("REQUEST_ID_PERSISTENCE: OK")
    print("ANALYSIS_RECORD: OK")
    print("APPROVAL_DEFAULT:", approval)
    print("UPDATED_SCHEMA_TEST_OK")
PY
```

# 第4章　systemdの書き込みの許可

## 4.1　ReadWritePaths

第17部のサービスは `ProtectSystem=strict` で、ファイルシステムに書き込めません。

```bash
systemctl cat ai-defense-manager.service | grep -E '^(User|Group|ProtectSystem|ReadWritePaths|ReadOnlyPaths|WorkingDirectory|ExecStart)='
```

DB を置く `data` ディレクトリだけ、書き込みを許可します。ほかの保護の設定は変えません。ユニットファイルそのものは書き換えず、追加の設定ファイル（ドロップイン）にします。

```bash
install -d -o root -g root -m 755 /etc/systemd/system/ai-defense-manager.service.d && cat > /etc/systemd/system/ai-defense-manager.service.d/20-sqlite.conf <<'EOF'
[Service]
ReadWritePaths=/opt/ai-defense-manager/data
EOF
chmod 644 /etc/systemd/system/ai-defense-manager.service.d/20-sqlite.conf && cat /etc/systemd/system/ai-defense-manager.service.d/20-sqlite.conf
```

```bash
systemd-analyze verify ai-defense-manager.service && systemctl daemon-reload && systemctl show ai-defense-manager.service -p ProtectSystem -p ReadWritePaths -p User -p Group
```

`ProtectSystem=strict` のまま、`ReadWritePaths=/opt/ai-defense-manager/data` が効いていれば成功です。

## 4.2　保存先の権限

```bash
stat -c '%A %a %U:%G %n' /opt/ai-defense-manager/data
```

```bash
runuser -u ai-defense -- test -w /opt/ai-defense-manager/data && echo "SQLITE_DATA_WRITABLE: OK" || echo "SQLITE_DATA_WRITABLE: NG"
```

# 第5章　本番のDBを作る

## 5.1　初期化

```bash
cd /opt/ai-defense-manager && runuser -u ai-defense -- ./venv/bin/python -c 'from app.services.analysis_history import initialize_database; initialize_database(); print("SQLITE_INITIALIZATION: OK")'
```

```bash
stat -c '%A %a %U:%G %s bytes %n' /opt/ai-defense-manager/data/ai-defense.db && cd /opt/ai-defense-manager && runuser -u ai-defense -- ./venv/bin/python -c 'import sqlite3; p="/opt/ai-defense-manager/data/ai-defense.db"; c=sqlite3.connect(p); print("JOURNAL_MODE:", c.execute("PRAGMA journal_mode").fetchone()[0]); print("TABLES:", ", ".join(r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type=\"table\" ORDER BY name"))); c.close()'
```

`JOURNAL_MODE: wal` と5つのテーブルが表示されれば成功です。

## 5.2　DBファイルの権限

構築時は、DB ファイルが `644` で作られました。ディレクトリが `750` なのでほかのユーザーは入れませんが、分析の記録や監査の記録が入るため、`600`（持ち主だけ）にします。

```bash
chmod 600 /opt/ai-defense-manager/data/ai-defense.db && stat -c '%A %a %U:%G %n' /opt/ai-defense-manager/data/ai-defense.db && ls -la /opt/ai-defense-manager/data/
```

WAL と SHM のファイル（`-wal`・`-shm`）は、接続が終わると消えることがあります。ないのは正常です。

# 第6章　サービスへの反映

## 6.1　再起動の前

```bash
systemctl status ai-defense-manager.service --no-pager -l
```

```bash
curl -sS -i http://127.0.0.1:8000/health
```

今動いているプロセスは、履歴の機能を入れる前に起動したものです。新しいコードを使うには再起動が必要です。

## 6.2　再起動

再起動のあいだ、`127.0.0.1:8000` の API は少し止まります。

```bash
systemctl restart ai-defense-manager.service && systemctl status ai-defense-manager.service --no-pager -l
```

```bash
journalctl -u ai-defense-manager.service -n 30 --no-pager
```

`Application startup complete` が出て、DB の初期化でエラーが出ていなければ成功です。

```bash
curl -sS -i http://127.0.0.1:8000/health
```

```bash
curl -sS -i 'http://127.0.0.1:8000/api/v1/wazuh/events?limit=5&since_minutes=60'
```

## 6.3　分析して保存されるか

`POST /api/v1/wazuh/analyze` は JSON の本文が必要です（本文なしで送ると `422` になります）。すべての項目に既定の値があるので、`{}` を送れば、直近60分・最大50件・日本語で分析します。

```bash
sed -n '1,240p' /opt/ai-defense-manager/app/api/wazuh.py
```

```bash
cat /opt/ai-defense-manager/app/schemas/wazuh.py
```

```bash
curl -sS -i -X POST http://127.0.0.1:8000/api/v1/wazuh/analyze -H 'Content-Type: application/json' -d '{}'
```

構築時は `HTTP 200` で、`severity: info`、`recommended_action: no_action`、証拠のイベントは8件でした。

DB を読み取り専用で開き、保存されたかを確かめます。

```bash
cd /opt/ai-defense-manager && runuser -u ai-defense -- ./venv/bin/python - <<'PY'
import sqlite3

db = "/opt/ai-defense-manager/data/ai-defense.db"
conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True)

for table in ("analysis_runs", "analysis_evidence", "action_proposals", "action_approvals", "audit_logs"):
    count = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
    print(f"{table}: {count}")

row = conn.execute("""
    SELECT severity, recommended_action, evidence_count, status
    FROM analysis_runs
    ORDER BY created_at DESC
    LIMIT 1
""").fetchone()

print("LATEST_ANALYSIS:", row)
conn.close()
PY
```

構築時の件数は次のとおりで、最新の記録は `('info', 'no_action', 8, 'completed')` でした。

| テーブル | 件数 |
|---|---:|
| `analysis_runs` | 2 |
| `analysis_evidence` | 16 |
| `action_proposals` | 2 |
| `action_approvals` | 2 |
| `audit_logs` | 2 |

# おわりに

第18部で、AI の分析の結果を SQLite に残すようにしました。

| 項目 | 状態 |
|---|---|
| DB | `/opt/ai-defense-manager/data/ai-defense.db`（`ai-defense` の `600`、WAL） |
| テーブル | 5つ（分析・証拠・提案・承認・監査） |
| systemd | `ProtectSystem=strict` のまま、`data` だけ書き込みを許可 |
| 保存 | 分析が成功した後に保存。失敗したら `503` |

次の部では、SQLite に保存する内容と、LLM に送る内容を見直し、余計な情報を出さないようにします。
