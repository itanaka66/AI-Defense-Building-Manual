---
title: "AI自律型サイバー防御システム 構築マニュアル 前編"
subtitle: "第2部　PostgreSQLログの安全な監視と相関検知"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」前編の第2部です。第1部で構築したWazuh環境に、PostgreSQL（LXC 109）のログ監視を加えます。SQL文やユーザー名などをWazuhへ送らずに、認証失敗などのイベントだけを安全に取り出し、送信元IPごとのブルートフォース検知までを構築します。

- PostgreSQLログの調査と、SQL文を転送しない方式の決定（第1章）
- サニタイズフィルターの作成とサービス化（第2〜3章）
- Wazuh Agentの監視設定とManager側の検知ルール（第4〜5章）
- 認証失敗の相関検知（第6章）
- 接続元IPの取得と、送信元IPごとの相関検知の本番化（第7〜8章）

## 本書の表記

- コマンドやファイル内容は、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 各手順の冒頭に「実行先」を示します。`root@pve` はProxmoxホスト、`root@security-core` はVM 220を表します。LXC 109への操作は、Proxmoxホストから `pct exec 109 --` で実行します。
- 「実行結果（例）」は構築時の実際の出力です。お使いの環境では、件数や日時などが異なります。

## 第1部終了時点の状態

| Agent ID | 名前 | 対象 | 状態 |
|---:|---|---|---|
| 000 | security-core | VM 220（Manager、`192.168.0.220`） | Active/Local |
| 001 | pve | Proxmoxホスト | Active |
| 002 | lxc-prometheus | LXC 103 | Active |
| 003 | lxc-grafana | LXC 105 | Active |
| 004 | postgresql | LXC 109（PostgreSQL 17、`192.168.0.151`） | Active |

# 第1章　PostgreSQLログの調査

この章では、PostgreSQLのログがどこに、どの形式で出力されているかを調べます。PostgreSQLの設定はまだ変更しません。

## 1.1　ログ設定と設定ファイルの確認

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
echo "===== POSTGRESQL LOG SETTINGS ====="
runuser -u postgres -- psql -X -At -c "
SHOW log_destination;
SHOW logging_collector;
SHOW log_directory;
SHOW log_filename;
SHOW log_rotation_age;
SHOW log_rotation_size;
"

echo "===== POSTGRESQL CONFIG FILES ====="
ls -lh /etc/postgresql/17/main/postgresql.conf \
       /etc/postgresql/17/main/pg_hba.conf \
       /etc/postgresql/17/main/pg_ident.conf

echo "===== POSTGRESQL LOG DIRECTORIES ====="
ls -ld /var/log/postgresql /var/lib/postgresql/17/main/log 2>/dev/null || true
'
```

構築時の設定は次のとおりでした。

| 項目 | 設定 |
|---|---|
| log_destination | `stderr` |
| logging_collector | `off` |
| log_directory | `log` |
| log_filename | `postgresql-%Y-%m-%d_%H%M%S.log` |
| ローテーション | 1日 / 10MB |

`logging_collector=off` のため、PostgreSQL自身はログファイルを作っていません。Debianのサービスが標準エラー出力をどこに記録しているかを、次の手順で確認します。

## 1.2　ログファイルとログ出力パラメーターの確認

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
echo "===== POSTGRESQL LOG FILES ====="
ls -lah /var/log/postgresql/

echo "===== POSTGRESQL LOG FILE TYPES ====="
file /var/log/postgresql/* 2>/dev/null || true

echo "===== RECENT POSTGRESQL JOURNAL ====="
journalctl -u postgresql@17-main --no-pager -n 30

echo "===== POSTGRESQL LOGGING PARAMETERS ====="
runuser -u postgres -- psql -X -At -c "
SHOW log_line_prefix;
SHOW log_connections;
SHOW log_disconnections;
SHOW log_min_messages;
SHOW data_directory;
SHOW config_file;
"
'
```

確認の結果、次のことがわかりました。

- 監視対象のログファイルは `/var/log/postgresql/postgresql-17-main.log` です。
- 日次ローテーションが動いています。
- `log_line_prefix` は `%m [%p] %q%u@%d ` です。
- `log_connections=off`、`log_disconnections=off`、`log_min_messages=warning` です。接続・切断は記録されていないため、認証失敗や接続異常の監視には制約があります。

## 1.3　ログの内容とWazuhの既存設定の確認

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
echo "===== POSTGRESQL LOG SAMPLE ====="
tail -n 15 /var/log/postgresql/postgresql-17-main.log

echo "===== WAZUH LOCALFILE CONFIGURATION ====="
grep -n -A 8 -B 2 "<localfile>" /var/ossec/etc/ossec.conf

echo "===== WAZUH POSTGRESQL DECODERS ====="
grep -Ril "postgresql" /var/ossec/ruleset/decoders 2>/dev/null || true
'
```

PostgreSQLのログには、次の種類の行が記録されています。

| 種類 | 内容 |
|---|---|
| `ERROR` | SQLの実行エラー |
| `FATAL` | 認証失敗などの重大なエラー |
| `LOG` | 接続・切断やデータベース内部のイベント |
| `STATEMENT` | 実行されたSQL文 |

Wazuhには、PostgreSQL専用のデコーダーやログ収集設定はありませんでした。

> **重要：** 現在のログには、実際のSQL文やアプリケーションのデータ内容まで記録されています。このログをそのままWazuh Managerに転送すると、データベースの情報がSIEM側にも複製されてしまいます。

## 1.4　監視方式の決定

次の方式で構築することにしました。

**SQL文やパラメーター値をWazuh Managerへ転送しない方式**

1. 生のログはLXC 109の中だけに保持する。
2. LXC 109の中で動く独立したフィルターがログを読み、許可したイベントだけを別のファイルに書き出す。
3. Wazuh Agentは、フィルターが書き出したファイルだけを監視する。

フィルターがWazuhに渡すのは、発生時刻・重大度・あらかじめ決めたイベント分類だけです。SQL文、`STATEMENT`・`DETAIL`・`CONTEXT` 行、ユーザー名、エラーの生メッセージは転送しません。

## 1.5　ローテーション方式とログ出力方式の確認

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
echo "===== POSTGRESQL LOGROTATE ====="
cat /etc/logrotate.d/postgresql-common 2>/dev/null

echo "===== POSTGRESQL LOGGING CONFIG ====="
grep -nE "^[[:space:]]*#?[[:space:]]*(logging_collector|log_destination|log_statement|log_min_messages|log_line_prefix|log_connections|log_disconnections|syslog_facility|syslog_ident)" \
  /etc/postgresql/17/main/postgresql.conf

echo "===== RSYSLOG STATUS ====="
systemctl is-active rsyslog 2>/dev/null || true

echo "===== LOG FILE OWNERSHIP ====="
stat -c "%U:%G %a %n" /var/log/postgresql/postgresql-17-main.log
'
```

| 項目 | 結果 | 判断 |
|---|---|---|
| ローテーション方式 | `copytruncate` | フィルターはファイルの切り詰めに追従する必要がある |
| rsyslog | `inactive` | rsyslogの転送ルールを使う方式は採らない |
| ログファイルの権限 | `postgres:adm 640` | Wazuhから元ログは直接読ませない |

## 1.6　実効設定の確認

PostgreSQLが実際に使っているログ設定を確認します。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- sudo -u postgres psql -X -At -c "
SELECT name || '=' || setting
FROM pg_settings
WHERE name IN (
  'logging_collector',
  'log_destination',
  'log_statement',
  'log_min_messages',
  'log_min_error_statement',
  'log_line_prefix',
  'log_connections',
  'log_disconnections',
  'log_directory',
  'log_filename'
)
ORDER BY name;
"
```

`log_min_error_statement=error` のため、SQLの実行でエラーが起きると、そのSQL文が別の `STATEMENT:` 行として記録されます。フィルターでは、この行を確実に除外する必要があります。

## 1.7　重大度別の件数の確認

ログ本文やSQL文は表示せず、重大度ごとの件数だけを集計します。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
LOG=/var/log/postgresql/postgresql-17-main.log

echo "===== LOG EVENT COUNTS ====="
for level in PANIC FATAL ERROR WARNING LOG STATEMENT; do
    count=$(grep -cE " ${level}:" "$LOG" 2>/dev/null || true)
    printf "%-12s %s\n" "$level" "$count"
done
'
```

実行結果（例）：

```text
===== LOG EVENT COUNTS =====
PANIC        0
FATAL        20
ERROR        88
WARNING      3
LOG          2280
STATEMENT    88
```

`ERROR` と `STATEMENT` が同じ件数（88件）であることから、エラーのたびにSQL文が記録されていることがわかります。

## 1.8　FATALの種類の確認

認証失敗とその他の接続失敗を区別するため、`FATAL` 行だけを対象に、キーワードごとの件数を集計します。ログ本文は表示しません。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
LOG=/var/log/postgresql/postgresql-17-main.log

echo "===== FATAL EVENT CLASSIFICATION COUNTS ====="
for pattern in \
  "password authentication failed" \
  "authentication failed" \
  "no pg_hba.conf entry" \
  "role .* does not exist" \
  "database .* does not exist" \
  "too many connections" \
  "SSL"
do
    count=$(grep " FATAL:" "$LOG" | grep -ciE "$pattern" || true)
    printf "%-38s %s\n" "$pattern" "$count"
done
'
```

構築時は、`FATAL` 20件のうち、パスワード認証失敗が8件でした。それ以外のパターンは0件です。

この結果から、Wazuhへ送るイベントを次のように決めました。

| 検出対象 | Wazuhへ送るイベント名 |
|---|---|
| パスワード認証失敗 | `POSTGRESQL_AUTH_FAILURE` |
| その他のFATAL | `POSTGRESQL_FATAL` |
| ERROR | `POSTGRESQL_ERROR` |
| WARNING | `POSTGRESQL_WARNING` |
| PANIC | `POSTGRESQL_PANIC` |

分類できないログは転送しません。

# 第2章　フィルターの準備

## 2.1　既存設定と出力先の確認

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
echo "===== EXISTING POSTGRESQL LOCALFILE REFERENCES ====="
grep -n -i -B 3 -A 5 "postgresql" /var/ossec/etc/ossec.conf || true

echo "===== FILTER OUTPUT DIRECTORY ====="
if [ -e /var/log/postgresql-wazuh ]; then
    stat -c "%U:%G %a %n" /var/log/postgresql-wazuh
else
    echo "Not created"
fi

echo "===== WAZUH LOGCOLLECTOR STATUS ====="
systemctl is-active wazuh-agent
'
```

PostgreSQL用のWazuh監視設定はまだなく、フィルターの出力先も `Not created`（未作成）であることを確認します。

## 2.2　Wazuh Agentの実行ユーザーの確認

出力ファイルの所有者と権限を決めるため、Wazuhの実行ユーザーを確認します。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
echo "===== WAZUH SERVICE USER ====="
systemctl show wazuh-agent -p User -p Group

echo "===== WAZUH ACCOUNT ====="
getent passwd wazuh || true
id wazuh 2>/dev/null || true

echo "===== AGENT PROCESS ====="
ps -eo user,group,pid,comm | grep -E "wazuh-logcollector|wazuh-agentd" | grep -v grep
'
```

```bash
pct exec 109 -- bash -c '
echo "===== WAZUH AGENT STATUS ====="
systemctl status wazuh-agent --no-pager -l

echo "===== WAZUH PROCESSES ====="
pgrep -a -f "wazuh|ossec" || true

echo "===== WAZUH GROUP MEMBERSHIP ====="
getent group wazuh
'
```

ログ収集プロセス（`wazuh-logcollector`）の実行ユーザーと、元ログへのアクセス可否を確認します。

> `pgrep -x wazuh-logcollector` は使えません。`pgrep -x` は15文字を超えるプロセス名を検索できないためです。実行ファイルのパスでPIDを取得します。

```bash
pct exec 109 -- bash -c '
PID=$(ps -eo pid,args | awk '\''$2=="/var/ossec/bin/wazuh-logcollector" {print $1; exit}'\'')
echo "===== WAZUH LOGCOLLECTOR IDENTITY ====="
if [ -n "$PID" ]; then
    ps -o pid,ppid,user,group,comm,args -p "$PID"
else
    echo "wazuh-logcollector process not found"
fi

echo "===== WAZUH ORIGINAL LOG ACCESS ====="
runuser -u wazuh -- test -r /var/log/postgresql/postgresql-17-main.log \
  && echo "Readable" || echo "Not readable (expected)"
'
```

実行結果（例）：

```text
    PID    PPID USER     GROUP    COMMAND         COMMAND
  10336       1 root     wazuh    wazuh-logcollec /var/ossec/bin/wazuh-logcollector
===== WAZUH ORIGINAL LOG ACCESS =====
Not readable (expected)
```

| 項目 | 結果 |
|---|---|
| Wazuhユーザー | `wazuh`（UID 103、GID 107） |
| `wazuh-logcollector` | rootで実行、グループは `wazuh` |
| 元のPostgreSQLログ | `wazuh` ユーザーからは読めない（望ましい状態） |

元ログの権限は変更しません。元ログの読み取りはroot権限のフィルターサービスだけが担当し、Wazuhにはフィルターの出力ファイルだけを読ませます。

## 2.3　フィルター出力先の作成

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
install -d -o root -g wazuh -m 0750 /var/log/postgresql-wazuh
install -o root -g wazuh -m 0640 /dev/null /var/log/postgresql-wazuh/events.log

echo "===== FILTER DIRECTORY ====="
stat -c "%U:%G %a %n" /var/log/postgresql-wazuh

echo "===== FILTER OUTPUT FILE ====="
stat -c "%U:%G %a %n" /var/log/postgresql-wazuh/events.log

echo "===== WAZUH READ TEST ====="
runuser -u wazuh -- test -r /var/log/postgresql-wazuh/events.log \
  && echo "PASS: Wazuh can read filtered log" \
  || echo "FAIL: Wazuh cannot read filtered log"
'
```

実行結果（例）：

```text
===== FILTER DIRECTORY =====
root:wazuh 750 /var/log/postgresql-wazuh
===== FILTER OUTPUT FILE =====
root:wazuh 640 /var/log/postgresql-wazuh/events.log
===== WAZUH READ TEST =====
PASS: Wazuh can read filtered log
```

## 2.4　Python実行環境の確認

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
echo "===== PYTHON ====="
python3 --version

echo "===== SYSTEMD ====="
systemctl --version | head -n 1

echo "===== FILTER OUTPUT ====="
ls -l /var/log/postgresql-wazuh/
'
```

構築時はPython 3.13.5とsystemd 257で、追加のパッケージなしで実装できました。

# 第3章　フィルターの作成とサービス化

## 3.1　フィルターの処理方針

1. PostgreSQLのログを読み取る。
2. 行の先頭にあるPostgreSQL標準のログ形式（日時・PID・重大度）だけを解析して、`FATAL`・`ERROR`・`WARNING`・`PANIC` を判定する。本文中の「ERROR」という文字列は判定に使わないため、SQL文や複数行の `STATEMENT` を誤ってイベントとして扱うことはない。
3. 認証失敗は専用のイベントに分類する。
4. SQL文、`STATEMENT`・`DETAIL`・`CONTEXT`、ユーザー名、エラー本文は出力しない。
5. 起動時点より前の過去ログは転送せず、新しいログだけを処理する。
6. ファイルの交換と、`copytruncate` によるファイルの切り詰めに追従する。

## 3.2　フィルター本体の作成

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c 'cat > /usr/local/sbin/postgresql-wazuh-filter.py <<'"'"'PY'"'"'
#!/usr/bin/env python3

import os
import re
import time

SOURCE = "/var/log/postgresql/postgresql-17-main.log"
OUTPUT = "/var/log/postgresql-wazuh/events.log"

# PostgreSQL標準ログの先頭部分だけを解析する。
PREFIX = re.compile(
    r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}(?:\.\d+)?(?: [A-Z]{2,5})?)"
    r" \[\d+\] (?:\S+ )?"
    r"(PANIC|FATAL|ERROR|WARNING):"
)

AUTH_FAILURE = re.compile(
    r"\bpassword authentication failed\b",
    re.IGNORECASE
)

EVENTS = {
    "PANIC": "POSTGRESQL_PANIC",
    "FATAL": "POSTGRESQL_FATAL",
    "ERROR": "POSTGRESQL_ERROR",
    "WARNING": "POSTGRESQL_WARNING",
}

def classify(line):
    match = PREFIX.match(line)
    if not match:
        return None

    timestamp, severity = match.groups()

    if severity == "FATAL" and AUTH_FAILURE.search(line):
        event = "POSTGRESQL_AUTH_FAILURE"
    else:
        event = EVENTS[severity]

    # 元ログのメッセージ・SQL・ユーザー名などは出力しない。
    return f"{timestamp} {event}\n"


def main():
    os.umask(0o027)

    with open(SOURCE, "r", encoding="utf-8", errors="replace") as source:
        # 起動前の過去ログは転送しない。
        source.seek(0, os.SEEK_END)

        with open(OUTPUT, "a", encoding="utf-8") as output:
            current_inode = os.stat(SOURCE).st_ino

            while True:
                line = source.readline()

                if line:
                    event = classify(line)
                    if event:
                        output.write(event)
                        output.flush()
                    continue

                time.sleep(1)

                try:
                    info = os.stat(SOURCE)
                except FileNotFoundError:
                    continue

                # ログファイルの交換・ローテーションに追従。
                if info.st_ino != current_inode:
                    source.close()
                    source = open(
                        SOURCE, "r",
                        encoding="utf-8",
                        errors="replace"
                    )
                    source.seek(0, os.SEEK_END)
                    current_inode = info.st_ino

                # copytruncateによる切り詰めに追従。
                elif info.st_size < source.tell():
                    source.seek(0)


if __name__ == "__main__":
    main()
PY

chmod 0750 /usr/local/sbin/postgresql-wazuh-filter.py
chown root:root /usr/local/sbin/postgresql-wazuh-filter.py

echo "===== SCRIPT PERMISSIONS ====="
stat -c "%U:%G %a %n" /usr/local/sbin/postgresql-wazuh-filter.py

echo "===== PYTHON SYNTAX CHECK ====="
python3 -m py_compile /usr/local/sbin/postgresql-wazuh-filter.py
echo "Python syntax OK"
'
```

最後に `root:root 750 /usr/local/sbin/postgresql-wazuh-filter.py` と `Python syntax OK` が表示されれば成功です。

## 3.3　ファイルが最後まで作成されたことの確認

長いコマンドを貼り付けると、端末の表示が途中で崩れることがあります。構文チェックだけでなく、ファイルの末尾まで作成されたことを確認します。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
echo "===== SCRIPT LINE COUNT ====="
wc -l /usr/local/sbin/postgresql-wazuh-filter.py

echo "===== SCRIPT END ====="
tail -n 50 /usr/local/sbin/postgresql-wazuh-filter.py

echo "===== MAIN FUNCTION CHECK ====="
grep -nE "^def main|^if __name__|output.write|source.readline|source.seek" \
  /usr/local/sbin/postgresql-wazuh-filter.py || true
'
```

ファイルが89行あり、末尾に `if __name__ == "__main__":` があれば正常です。

## 3.4　実際のログ形式との照合テスト

現在のPostgreSQLログの書式に、フィルターの判定パターンが一致するかを確認します。ログ本文やSQL文は表示せず、判定件数だけを調べます。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- python3 - <<'PY'
import importlib.util
from collections import Counter

path = "/usr/local/sbin/postgresql-wazuh-filter.py"
spec = importlib.util.spec_from_file_location("pgfilter", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

counts = Counter()
unmatched = Counter()

with open(module.SOURCE, encoding="utf-8", errors="replace") as f:
    for line in f:
        event = module.classify(line)
        if event:
            name = event.strip().split()[-1]
            counts[name] += 1
        else:
            for level in ("PANIC", "FATAL", "ERROR", "WARNING"):
                if f" {level}:" in line:
                    unmatched[level] += 1

print("===== FILTER MATCH COUNTS =====")
for name, count in sorted(counts.items()):
    print(f"{name}: {count}")

print("===== UNMATCHED SEVERITY COUNTS =====")
for name, count in sorted(unmatched.items()):
    print(f"{name}: {count}")

print("===== RESULT =====")
print("PASS" if not unmatched else "REVIEW REQUIRED")
PY
```

`PASS` と表示されれば、実際のログ書式に対応できています。`REVIEW REQUIRED` の場合は、判定パターンを修正してから進めてください。構築時の判定件数は次のとおりでした。

| イベント | 件数 |
|---|---:|
| 認証失敗 | 8 |
| その他のFATAL | 12 |
| ERROR | 88 |
| WARNING | 3 |

## 3.5　SQL文が出力されないことのテスト

実際のPostgreSQLログには書き込まず、ダミーのデータでPythonの関数だけをテストします。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- python3 - <<'PY'
import importlib.util

path = "/usr/local/sbin/postgresql-wazuh-filter.py"
spec = importlib.util.spec_from_file_location("pgfilter", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

tests = [
    (
        "2026-11-18 14:00:00 JST [1234] app@db ERROR: test error "
        "STATEMENT: UPDATE secret_table SET password='SECRET_SQL_VALUE'",
        "POSTGRESQL_ERROR"
    ),
    (
        "2026-11-18 14:01:00 JST [1235] app@db FATAL: password authentication failed for user SECRET_USER",
        "POSTGRESQL_AUTH_FAILURE"
    ),
    (
        "2026-11-18 14:02:00 JST [1236] app@db WARNING: test warning",
        "POSTGRESQL_WARNING"
    ),
]

for raw, expected in tests:
    result = module.classify(raw)
    assert result is not None and expected in result, "Classification failed"
    assert "SECRET_SQL_VALUE" not in result
    assert "SECRET_USER" not in result
    assert "UPDATE" not in result
    assert "password authentication failed" not in result

print("PASS: SQL text excluded")
print("PASS: User information excluded")
print("PASS: Raw error messages excluded")
print("PASS: Only fixed event names are emitted")
PY
```

実行結果（例）：

```text
PASS: SQL text excluded
PASS: User information excluded
PASS: Raw error messages excluded
PASS: Only fixed event names are emitted
```

## 3.6　systemdサービスの登録

フィルターを常駐させるsystemdサービスを登録します。読み取り専用・書き込み先の限定など、セキュリティ上の制限を設定しています。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c 'cat > /etc/systemd/system/postgresql-wazuh-filter.service <<'"'"'EOF'"'"'
[Unit]
Description=PostgreSQL sanitized event filter for Wazuh
After=local-fs.target
Wants=local-fs.target

[Service]
Type=simple
User=root
Group=root
ExecStart=/usr/bin/python3 /usr/local/sbin/postgresql-wazuh-filter.py
Restart=always
RestartSec=5
UMask=0027

# Security restrictions
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
ProtectHostname=true
ProtectClock=true
PrivateDevices=true
RestrictSUIDSGID=true
LockPersonality=true
MemoryDenyWriteExecute=true
ReadOnlyPaths=/var/log/postgresql
ReadWritePaths=/var/log/postgresql-wazuh

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload

echo "===== SYSTEMD UNIT VALIDATION ====="
systemd-analyze verify /etc/systemd/system/postgresql-wazuh-filter.service

echo "===== SERVICE DEFINITION ====="
systemctl cat postgresql-wazuh-filter.service
'
```

`systemd-analyze verify` でエラーが表示されないことを確認します。

## 3.7　サービスの起動

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
systemctl enable --now postgresql-wazuh-filter.service

echo "===== SERVICE STATUS ====="
systemctl status postgresql-wazuh-filter.service --no-pager -l

echo "===== FILTER OUTPUT ====="
ls -l /var/log/postgresql-wazuh/events.log

echo "===== RECENT SERVICE LOG ====="
journalctl -u postgresql-wazuh-filter.service -n 10 --no-pager
'
```

`active (running)` になり、`Started postgresql-wazuh-filter.service - PostgreSQL sanitized event filter for Wazuh.` が記録されていれば成功です。構築時のメモリ使用量は約1.6MBでした。

## 3.8　出力形式のJSONへの変更

WazuhのJSONログ収集機能を使うため、出力形式をJSONに統一します。出力ファイルが空のうちに変更するので、既存のイベントには影響しません。

サービスを停止し、出力部分を書き換えてから、JSONの出力をテストします。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
systemctl stop postgresql-wazuh-filter.service

python3 - <<'"'"'PY'"'"'
from pathlib import Path

p = Path("/usr/local/sbin/postgresql-wazuh-filter.py")
s = p.read_text()

s = s.replace("import os\nimport re\nimport time", "import json\nimport os\nimport re\nimport time")

s = s.replace(
    "return f\"{timestamp} {event}\\n\"",
    "return json.dumps({\"timestamp\": timestamp, \"event\": event}, ensure_ascii=True) + \"\\n\""
)

p.write_text(s)
PY

python3 -m py_compile /usr/local/sbin/postgresql-wazuh-filter.py

echo "===== JSON OUTPUT TEST ====="
python3 - <<'"'"'PY'"'"'
import importlib.util
import json

path = "/usr/local/sbin/postgresql-wazuh-filter.py"
spec = importlib.util.spec_from_file_location("pgfilter", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

sample = "2026-11-18 15:10:00 JST [1234] app@db FATAL: password authentication failed for user SECRET_USER"
result = module.classify(sample)
obj = json.loads(result)

assert obj["event"] == "POSTGRESQL_AUTH_FAILURE"
assert "SECRET_USER" not in result
assert "password authentication failed" not in result

print(json.dumps(obj, ensure_ascii=False))
print("PASS: valid JSON; sensitive message excluded")
PY
'
```

実行結果（例）：

```text
===== JSON OUTPUT TEST =====
{"timestamp": "2026-11-18 15:10:00 JST", "event": "POSTGRESQL_AUTH_FAILURE"}
PASS: valid JSON; sensitive message excluded
```

## 3.9　サービスの再起動

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
systemctl restart postgresql-wazuh-filter.service

echo "===== SERVICE STATUS ====="
systemctl is-active postgresql-wazuh-filter.service

echo "===== SERVICE DETAILS ====="
systemctl status postgresql-wazuh-filter.service --no-pager -l

echo "===== OUTPUT FILE ====="
ls -l /var/log/postgresql-wazuh/events.log
'
```

`active` と表示されれば、フィルターの準備は完了です。次章で、このファイルをWazuh Agentに監視させます。

# 第4章　Wazuh Agentへの監視設定

LXC 109のWazuh Agentに、フィルターが書き出すJSONファイルだけを監視させます。元のPostgreSQLログは監視させません。

## 4.1　設定ファイルのバックアップ

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
BACKUP="/var/ossec/etc/ossec.conf.backup-$(date +%Y%m%d-%H%M%S)"
cp -a /var/ossec/etc/ossec.conf "$BACKUP"
echo "Backup created: $BACKUP"
'
```

## 4.2　監視設定の追加

既存の設定ブロックには手を加えず、設定ファイルの末尾に新しい `<ossec_config>` ブロックとして追加します。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
cat >> /var/ossec/etc/ossec.conf <<'"'"'EOF'"'"'

<ossec_config>
  <localfile>
    <location>/var/log/postgresql-wazuh/events.log</location>
    <log_format>json</log_format>
  </localfile>
</ossec_config>
EOF

echo "===== ADDED CONFIGURATION ====="
tail -n 12 /var/ossec/etc/ossec.conf
'
```

## 4.3　設定の検証

Wazuhの `ossec.conf` は、複数の `<ossec_config>` ブロックを持てる形式です。そのため、通常のXML文書としてそのまま解析すると `junk after document element` というエラーになります。これは設定の誤りではありません。全体を仮のルート要素で囲んでから検証します。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
echo "===== WAZUH CONFIG STRUCTURE VALIDATION ====="
python3 - <<'"'"'PY'"'"'
from pathlib import Path
import xml.etree.ElementTree as ET

content = Path("/var/ossec/etc/ossec.conf").read_text()
ET.fromstring("<config_root>\n" + content + "\n</config_root>")
print("PASS: all ossec_config blocks are well-formed")

root = ET.fromstring("<config_root>\n" + content + "\n</config_root>")
for localfile in root.findall(".//localfile"):
    location = localfile.findtext("location")
    if location == "/var/log/postgresql-wazuh/events.log":
        print("PASS: PostgreSQL JSON localfile configuration found")
        print("log_format:", localfile.findtext("log_format"))
        break
else:
    raise SystemExit("FAIL: PostgreSQL localfile configuration not found")
PY

echo
echo "===== WAZUH AGENT CONFIG TEST ====="
/var/ossec/bin/wazuh-agentd -t
RESULT=$?
echo "Exit code: $RESULT"
exit "$RESULT"
'
```

実行結果（例）：

```text
===== WAZUH CONFIG STRUCTURE VALIDATION =====
PASS: all ossec_config blocks are well-formed
PASS: PostgreSQL JSON localfile configuration found
log_format: json

===== WAZUH AGENT CONFIG TEST =====
Exit code: 0
```

## 4.4　Wazuh Agentの再起動

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
systemctl restart wazuh-agent

echo "===== SERVICE STATUS ====="
systemctl is-active wazuh-agent

echo
echo "===== RECENT AGENT LOG ====="
journalctl -u wazuh-agent -n 20 --no-pager
'
```

`active` と表示され、`Started wazuh-agent.service - Wazuh agent.` が記録されていれば成功です。

## 4.5　監視の開始の確認

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
echo "===== LOGCOLLECTOR PROCESS ====="
pgrep -af wazuh-logcollector

echo
echo "===== POSTGRESQL LOG MONITOR REFERENCES ====="
grep -Ei "postgresql-wazuh/events.log|events.log" /var/ossec/logs/ossec.log | tail -n 20

echo
echo "===== FILTER OUTPUT PERMISSIONS ====="
stat -c "%U:%G %a %n" /var/log/postgresql-wazuh/events.log

echo
echo "===== WAZUH USER READ TEST ====="
runuser -u wazuh -- test -r /var/log/postgresql-wazuh/events.log \
  && echo "PASS: wazuh can read sanitized events"
'
```

| 確認項目 | 期待値 |
|---|---|
| ログ収集 | `Analyzing file: '/var/log/postgresql-wazuh/events.log'.` が記録されている |
| ファイルの権限 | `root:wazuh 640` |
| Wazuhユーザーの読み取り | `PASS: wazuh can read sanitized events` |

# 第5章　Manager側の検知ルール

VM 220のWazuh Managerに、PostgreSQL専用の検知ルールを追加します。この章のVM 220への操作は、Proxmoxホストから `qm guest exec 220` で実行します（QEMU Guest Agentを使ってVM内のコマンドを実行する方法です）。結果はJSON形式で返り、コマンドの出力は `out-data` に入ります。

## 5.1　QEMU Guest Agentの応答確認

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest cmd 220 get-osinfo
```

`"pretty-name" : "Ubuntu 24.04.5 LTS"` が返れば、Guest Agent経由でVM 220を操作できます。

## 5.2　既存ルールの確認

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
echo "===== WAZUH MANAGER STATUS ====="
systemctl is-active wazuh-manager

echo
echo "===== LOCAL RULE FILE ====="
ls -lh /var/ossec/etc/rules/local_rules.xml

echo
echo "===== EXISTING LOCAL RULES ====="
sed -n "1,220p" /var/ossec/etc/rules/local_rules.xml
'
```

構築時の `local_rules.xml` には、SSH認証失敗のサンプルルール `100001` が1件だけありました。PostgreSQL用には、既存ルールと分けて `100100`〜`100105` を使います。

## 5.3　ルールIDの重複確認

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
echo "===== CHECK RULE ID COLLISIONS ====="
grep -RhnE "<rule[[:space:]]+id=\"10010[0-4]\"" \
  /var/ossec/etc/rules /var/ossec/ruleset/rules 2>/dev/null \
  || echo "PASS: IDs 100100-100104 are not in use"
'
```

`PASS: IDs 100100-100104 are not in use` が返ることを確認します。

## 5.4　ルールファイルのバックアップ

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
BACKUP="/var/ossec/etc/rules/local_rules.xml.backup-$(date +%Y%m%d-%H%M%S)"
cp -a /var/ossec/etc/rules/local_rules.xml "$BACKUP"
echo "Backup created: $BACKUP"
ls -l "$BACKUP"
'
```

## 5.5　検知ルールの追加

JSONデコーダーを親ルールにして、`event` フィールドが完全に一致したときだけ検知するルールを追加します。

| ルールID | イベント | レベル |
|---|---|---:|
| 100100 | 親ルール（JSONイベント共通） | 0 |
| 100101 | 認証失敗 | 8 |
| 100102 | FATAL | 10 |
| 100103 | ERROR | 7 |
| 100104 | WARNING | 4 |
| 100105 | PANIC | 12 |

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
cat >> /var/ossec/etc/rules/local_rules.xml <<'"'"'EOF'"'"'

<group name="local,postgresql,">

  <rule id="100100" level="0">
    <decoded_as>json</decoded_as>
    <description>PostgreSQL sanitized JSON event base rule</description>
  </rule>

  <rule id="100101" level="8">
    <if_sid>100100</if_sid>
    <field name="event">^POSTGRESQL_AUTH_FAILURE$</field>
    <description>PostgreSQL authentication failure detected</description>
    <group>authentication_failed,postgresql,</group>
  </rule>

  <rule id="100102" level="10">
    <if_sid>100100</if_sid>
    <field name="event">^POSTGRESQL_FATAL$</field>
    <description>PostgreSQL FATAL event detected</description>
    <group>postgresql,fatal,</group>
  </rule>

  <rule id="100103" level="7">
    <if_sid>100100</if_sid>
    <field name="event">^POSTGRESQL_ERROR$</field>
    <description>PostgreSQL ERROR event detected</description>
    <group>postgresql,error,</group>
  </rule>

  <rule id="100104" level="4">
    <if_sid>100100</if_sid>
    <field name="event">^POSTGRESQL_WARNING$</field>
    <description>PostgreSQL WARNING event detected</description>
    <group>postgresql,warning,</group>
  </rule>

  <rule id="100105" level="12">
    <if_sid>100100</if_sid>
    <field name="event">^POSTGRESQL_PANIC$</field>
    <description>PostgreSQL PANIC event detected</description>
    <group>postgresql,critical,</group>
  </rule>

</group>
EOF

echo "===== POSTGRESQL RULES ADDED ====="
tail -n 65 /var/ossec/etc/rules/local_rules.xml
'
```

この段階では、まだManagerを再起動しません。

## 5.6　ルールの検証

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
echo "===== XML STRUCTURE VALIDATION ====="
python3 - <<'"'"'PY'"'"'
from pathlib import Path
import xml.etree.ElementTree as ET

content = Path("/var/ossec/etc/rules/local_rules.xml").read_text()
root = ET.fromstring("<config_root>\n" + content + "\n</config_root>")

rules = {
    rule.get("id"): rule
    for rule in root.findall(".//rule")
}

expected = ["100100", "100101", "100102", "100103", "100104", "100105"]

for rule_id in expected:
    if rule_id not in rules:
        raise SystemExit(f"FAIL: missing rule {rule_id}")
    print(f"PASS: rule {rule_id}")

print("PASS: XML structure is valid")
PY

echo
echo "===== WAZUH MANAGER CONFIGURATION TEST ====="
/var/ossec/bin/wazuh-analysisd -t
RESULT=$?
echo "Exit code: $RESULT"
exit "$RESULT"
'
```

6つのルールすべてに `PASS` が出て、`Exit code: 0` であれば正常です。`Rule tree threshold` に関するメッセージはメモリ使用量についてのINFOで、エラーではありません。

## 5.7　wazuh-logtestによる判定テスト

Managerを再起動する前に、Wazuhのルールテスト機能で5種類のイベントが想定どおりのルールに一致するかを確認します。本番のログにテストデータは入りません。

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
printf "%s\n" \
  "{\"timestamp\":\"2026-11-18 15:20:00 JST\",\"event\":\"POSTGRESQL_AUTH_FAILURE\"}" \
  "{\"timestamp\":\"2026-11-18 15:20:01 JST\",\"event\":\"POSTGRESQL_FATAL\"}" \
  "{\"timestamp\":\"2026-11-18 15:20:02 JST\",\"event\":\"POSTGRESQL_ERROR\"}" \
  "{\"timestamp\":\"2026-11-18 15:20:03 JST\",\"event\":\"POSTGRESQL_WARNING\"}" \
  "{\"timestamp\":\"2026-11-18 15:20:04 JST\",\"event\":\"POSTGRESQL_PANIC\"}" \
  | /var/ossec/bin/wazuh-logtest
'
```

| イベント | ルールID | レベル | 結果 |
|---|---:|---:|---|
| 認証失敗 | 100101 | 8 | 一致 |
| FATAL | 100102 | 10 | 一致 |
| ERROR | 100103 | 7 | 一致 |
| WARNING | 100104 | 4 | 一致 |
| PANIC | 100105 | 12 | 一致 |

PANICはレベル12のため `mail: True` と表示されます。これは、メール通知が設定されていれば通知の対象になるという意味で、メールが送信されたわけではありません。

## 5.8　Managerの再起動

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
systemctl restart wazuh-manager

echo "===== MANAGER STATUS ====="
systemctl is-active wazuh-manager

echo
echo "===== RECENT MANAGER LOG ====="
journalctl -u wazuh-manager -n 25 --no-pager
'
```

`active` と表示され、`Started wazuh-manager.service - Wazuh manager.` が記録されていれば成功です。

## 5.9　Agentの接続確認

**実行先：Proxmoxホスト（root@pve）**

```bash
echo "===== POSTGRESQL AGENT LOG ====="
pct exec 109 -- bash -c '
tail -n 35 /var/ossec/logs/ossec.log
'

echo
echo "===== MANAGER AGENT STATUS ====="
qm guest exec 220 -- /var/ossec/bin/agent_control -lc
```

LXC 109のAgentログに `Connected to the server ([192.168.0.220]:1514/tcp)` があり、Manager側の一覧で `ID: 004, Name: postgresql, IP: any, Active` となっていれば正常です。Manager再起動の直後は一時的に切断されますが、自動的に再接続します。

## 5.10　実転送テスト

PostgreSQLにテスト用のSQLや認証失敗を発生させるのではなく、フィルターの出力ファイルに固定のJSONを1件だけ追加して、転送から検知までを確認します。

> **注意：** このテストで、Wazuhにテスト用のWARNINGアラートが1件記録されます。実際の障害と混同しないよう、テストイベントとして扱ってください。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
printf "%s\n" \
  "{\"timestamp\":\"2026-11-18 15:25:00 JST\",\"event\":\"POSTGRESQL_WARNING\"}" \
  >> /var/log/postgresql-wazuh/events.log

echo "===== TEST EVENT ====="
tail -n 1 /var/log/postgresql-wazuh/events.log

echo
echo "===== FILE PERMISSIONS ====="
stat -c "%U:%G %a %n" /var/log/postgresql-wazuh/events.log
'
```

VM 220の `alerts.json` に、Agent ID `004`・ルールID `100104` のアラートが記録されたかを確認します。

```bash
qm guest exec 220 -- bash -c '
python3 - <<'"'"'PY'"'"'
import json
from pathlib import Path

path = Path("/var/ossec/logs/alerts/alerts.json")

if not path.exists():
    raise SystemExit("FAIL: alerts.json not found")

matches = []

with path.open() as f:
    for line in f:
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue

        rule = obj.get("rule", {})
        agent = obj.get("agent", {})

        if (
            str(rule.get("id")) == "100104"
            and str(agent.get("id")) == "004"
            and "POSTGRESQL_WARNING" in obj.get("full_log", "")
        ):
            matches.append(obj)

if matches:
    print("PASS: PostgreSQL test alert received")
    for obj in matches[-3:]:
        print(json.dumps({
            "timestamp": obj.get("timestamp"),
            "agent": obj.get("agent", {}).get("name"),
            "agent_id": obj.get("agent", {}).get("id"),
            "rule_id": obj.get("rule", {}).get("id"),
            "level": obj.get("rule", {}).get("level"),
            "description": obj.get("rule", {}).get("description")
        }, ensure_ascii=False, indent=2))
else:
    print("NOT FOUND: alert has not appeared yet")
PY
'
```

`PASS: PostgreSQL test alert received` と、`"rule_id": "100104"`・`"agent": "postgresql"` が表示されれば、LXC 109からVM 220までの転送と検知が成立しています。

この章までで、次の仕組みが完成しました。

- PostgreSQLの元ログからSQL文を転送しないフィルター
- ユーザー名・SQL文・エラーメッセージを含まないJSONイベント
- Wazuh Agentによるイベントの収集
- Wazuh Managerによる5種類のイベントの分類と、アラートの生成

# 第6章　認証失敗の相関検知

単発の認証失敗だけでなく、短時間に繰り返される認証失敗を「ブルートフォース攻撃の疑い」として検知します。今のフィルターはSQL文・ユーザー名・接続元IPを出力していないため、この章では **同じAgent（LXC 109）で60秒間に認証失敗が5回以上起きたら検知する** 方式にします。接続元IPごとの相関は第7章で扱います。

| 項目 | 設定 |
|---|---|
| 対象イベント | ルール `100101`（`POSTGRESQL_AUTH_FAILURE`） |
| 集計単位 | 同一Agent |
| 時間枠 | 60秒 |
| 発生回数 | 5回 |
| 相関ルールID | `100106` |
| レベル | 12 |

PostgreSQLの設定変更、元ログの転送、ファイアウォールの変更は行いません。

## 6.1　既存ルールの確認

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
echo "===== EXISTING POSTGRESQL RULES ====="
grep -n -A 65 -B 3 "PostgreSQL sanitized JSON event base rule" \
  /var/ossec/etc/rules/local_rules.xml

echo
echo "===== RULE ID COLLISION CHECK ====="
grep -nE "id=\"10010[6-9]\"|id=\"10011[0-9]\"" \
  /var/ossec/etc/rules/local_rules.xml || true

echo
echo "===== EXISTING FREQUENCY RULES ====="
grep -R -nE "frequency=|timeframe=|same_agent|same_source_ip" \
  /var/ossec/etc/rules/local_rules.xml
'
```

既存のPostgreSQLルール `100100`〜`100105` があり、`100106`〜`100119` とのID重複や、既存の相関ルールがないことを確認します。

## 6.2　ルールファイルのバックアップ

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
BACKUP="/var/ossec/etc/rules/local_rules.xml.backup-auth-correlation-$(date +%Y%m%d-%H%M%S)"
cp -a /var/ossec/etc/rules/local_rules.xml "$BACKUP"
echo "===== BACKUP CREATED ====="
ls -l "$BACKUP"
'
```

## 6.3　相関ルールの書き方の確認

Wazuh標準ルールで、`frequency`（回数）と `timeframe`（時間枠）を使った相関ルールの書き方を確認します。

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
echo "===== WAZUH CORRELATION RULE EXAMPLES ====="
grep -R -n -B 3 -A 8 \
  "frequency=.*timeframe=" \
  /var/ossec/ruleset/rules \
  --include="*.xml" | head -n 100
'
```

## 6.4　相関ルールの追加

ルール `100106` を、既存の `100102` の直前に挿入します。

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
python3 - <<'"'"'PY'"'"'
from pathlib import Path

p = Path("/var/ossec/etc/rules/local_rules.xml")
s = p.read_text()

if "<rule id=\"100106\"" in s:
    raise SystemExit("STOP: Rule 100106 already exists")

anchor = """  <rule id="100102" level="10">"""

rule = """  <rule id="100106" level="12" frequency="5" timeframe="60">
    <if_matched_sid>100101</if_matched_sid>
    <same_agent />
    <description>PostgreSQL: Multiple authentication failures from the same agent within 60 seconds.</description>
    <mitre>
      <id>T1110</id>
    </mitre>
    <group>postgresql,authentication_failures,brute_force,</group>
  </rule>

"""

if s.count(anchor) != 1:
    raise SystemExit("STOP: Expected insertion point not found uniquely")

p.write_text(s.replace(anchor, rule + anchor, 1))
print("PASS: Rule 100106 added")
PY

echo
echo "===== NEW RULE ====="
grep -n -A 10 -B 2 "id=\"100106\"" \
  /var/ossec/etc/rules/local_rules.xml
'
```

この段階では、まだManagerを再起動しません。

## 6.5　ルールの検証

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
echo "===== XML STRUCTURE CHECK ====="
python3 - <<'"'"'PY'"'"'
from pathlib import Path
import xml.etree.ElementTree as ET

p = Path("/var/ossec/etc/rules/local_rules.xml")
content = p.read_text()

ET.fromstring("<config_root>" + content + "</config_root>")
print("PASS: XML structure")

root = ET.fromstring("<config_root>" + content + "</config_root>")
rules = [
    r for r in root.iter("rule")
    if r.get("id") == "100106"
]

if len(rules) != 1:
    raise SystemExit("FAIL: Rule 100106 count is not 1")

r = rules[0]
print("Rule ID:", r.get("id"))
print("Level:", r.get("level"))
print("Frequency:", r.get("frequency"))
print("Timeframe:", r.get("timeframe"))
PY

echo
echo "===== WAZUH RULE VALIDATION ====="
/var/ossec/bin/wazuh-analysisd -t
'
```

XMLの構造とルールIDは正常ですが、`wazuh-analysisd -t` で次の警告が出ます。

```text
WARNING: Detected a deprecated field option for rule,
same_agent is not longer available.
```

Wazuh 4.14.10では `same_agent` は非推奨です。Wazuh 4.xの相関ルールは、もともと **同じAgentのイベントだけを集計する** のが既定の動作です（すべてのAgentを集計したいときだけ `<global_frequency />` を指定します）。そのため、`same_agent` の行を削除しても集計の条件は変わりません。

> **注意：** 警告が出たままManagerを再起動しないでください。次の手順で修正してから反映します。

## 6.6　非推奨設定の削除

`same_agent` の行だけを削除します。5回・60秒の条件はそのままです。

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
python3 - <<'"'"'PY'"'"'
from pathlib import Path

p = Path("/var/ossec/etc/rules/local_rules.xml")
s = p.read_text()

old = """    <if_matched_sid>100101</if_matched_sid>
    <same_agent />
"""

new = """    <if_matched_sid>100101</if_matched_sid>
"""

if s.count(old) != 1:
    raise SystemExit("STOP: Expected rule block not found exactly once")

p.write_text(s.replace(old, new, 1))
print("PASS: Deprecated same_agent removed")
PY

echo
echo "===== CORRELATION RULE ====="
grep -n -A 9 -B 2 "id=\"100106\"" \
  /var/ossec/etc/rules/local_rules.xml

echo
echo "===== WAZUH RULE VALIDATION ====="
/var/ossec/bin/wazuh-analysisd -t
'
```

`PASS: Deprecated same_agent removed` と表示され、`wazuh-analysisd -t` で警告が出なくなれば修正完了です。

## 6.7　wazuh-logtestによる相関テスト

`wazuh-logtest` の中だけで、認証失敗を5回続けて送ります。PostgreSQLやAgentの実際のログには書き込みません。

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
printf "%s\n" \
  "{\"timestamp\":\"2026-11-18 15:31:01 JST\",\"event\":\"POSTGRESQL_AUTH_FAILURE\"}" \
  "{\"timestamp\":\"2026-11-18 15:31:02 JST\",\"event\":\"POSTGRESQL_AUTH_FAILURE\"}" \
  "{\"timestamp\":\"2026-11-18 15:31:03 JST\",\"event\":\"POSTGRESQL_AUTH_FAILURE\"}" \
  "{\"timestamp\":\"2026-11-18 15:31:04 JST\",\"event\":\"POSTGRESQL_AUTH_FAILURE\"}" \
  "{\"timestamp\":\"2026-11-18 15:31:05 JST\",\"event\":\"POSTGRESQL_AUTH_FAILURE\"}" \
  | /var/ossec/bin/wazuh-logtest
'
```

| 回数 | 一致したルール | レベル |
|---:|---|---:|
| 1〜4回目 | 100101 | 8 |
| 5回目 | 100106 | 12 |

5回目で `100106` が発火し、MITRE ATT&CKの `T1110`（Credential Access / Brute Force）が付いていれば成功です。

## 6.8　反映前の確認

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
echo "===== WAZUH MANAGER STATUS ====="
systemctl is-active wazuh-manager

echo
echo "===== CORRELATION RULE ====="
grep -n -A 8 "id=\"100106\"" \
  /var/ossec/etc/rules/local_rules.xml

echo
echo "===== RULE VALIDATION ====="
/var/ossec/bin/wazuh-analysisd -t
'
```

## 6.9　Managerの再起動

再起動中は、Wazuh Managerの検知処理が一時的に止まります。Agent側の設定やPostgreSQL本体は変更しません。

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
systemctl restart wazuh-manager

echo "===== MANAGER STATUS ====="
systemctl is-active wazuh-manager

echo
echo "===== MANAGER START TIME ====="
systemctl show wazuh-manager -p ActiveEnterTimestamp
'
```

## 6.10　Agentの再接続の確認

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
echo "===== WAZUH AGENTS ====="
/var/ossec/bin/agent_control -lc

echo
echo "===== MANAGER ERRORS ====="
journalctl -u wazuh-manager --since "2026-11-18 06:32:20" --no-pager \
  | grep -Ei "error|critical|failed|started|running" \
  | tail -n 30
'
```

`--since` の日時は、6.9で表示された起動時刻（UTC）の少し前に合わせてください。

> **Agentが一覧に出ない、または Pending になる場合：** Managerの再起動直後は、一部のAgentが一時的に `Pending`（接続待ち）になることがあります。構築時もProxmoxホストのAgent（001）が一時的にPendingになりましたが、約1分半後に自動で再接続しました。Agentを再登録したり削除したりせず、次の手順で状態を確認してください。

全Agentの登録状態を確認します。

```bash
qm guest exec 220 -- /var/ossec/bin/agent_control -l
```

Pendingになっている場合は、そのAgent側で接続の状況を確認します（Proxmoxホストの例）。

**実行先：Proxmoxホスト（root@pve）**

```bash
echo "===== WAZUH AGENT CONNECTION LOG ====="
grep -Ei "connect|disconnect|error|critical|server|duplicate|key" \
  /var/ossec/logs/ossec.log | tail -n 50

echo
echo "===== MANAGER CONFIGURATION ====="
grep -n -A 8 '<server>' /var/ossec/etc/ossec.conf

echo
echo "===== TCP 1514 CONNECTIVITY ====="
timeout 5 bash -c '</dev/tcp/192.168.0.220/1514' \
  && echo "TCP 1514 CONNECT OK" \
  || echo "TCP 1514 CONNECT FAILED"
```

ログに再接続の記録があり、`TCP 1514 CONNECT OK` であれば、少し待ってからもう一度一覧を確認します。

```bash
qm guest exec 220 -- /var/ossec/bin/agent_control -lc
```

Agent 001〜004がすべて `Active` になれば正常です。

## 6.11　実際の転送経路での相関テスト

フィルターの出力ファイルにテスト用の認証失敗イベントを5件追加し、LXC 109からManagerまでの実際の経路で `100106` が発火するかを確認します。

> **注意：** テストイベントはWazuhの本番アラートに記録されます。運用記録には「合成テスト」と明記し、実際の攻撃として扱わないでください。PostgreSQLのログやデータベースは変更しません。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
for i in 1 2 3 4 5; do
  printf "{\"timestamp\":\"2026-11-18 15:34:%02d JST\",\"event\":\"POSTGRESQL_AUTH_FAILURE\"}\n" "$i" \
    >> /var/log/postgresql-wazuh/events.log
done

echo "===== SYNTHETIC TEST EVENTS ====="
tail -n 5 /var/log/postgresql-wazuh/events.log
'
```

Managerのアラートを確認します。

```bash
qm guest exec 220 -- bash -c '
python3 - <<'"'"'PY'"'"'
import json
from collections import deque
from pathlib import Path

path = Path("/var/ossec/logs/alerts/alerts.json")
matches = deque(maxlen=20)

with path.open(encoding="utf-8") as f:
    for line in f:
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue

        agent = event.get("agent", {})
        rule = event.get("rule", {})

        if agent.get("id") == "004" and rule.get("id") in ("100101", "100106"):
            matches.append({
                "timestamp": event.get("timestamp"),
                "agent": agent.get("name"),
                "rule_id": rule.get("id"),
                "level": rule.get("level"),
                "description": rule.get("description")
            })

print("===== POSTGRESQL AUTHENTICATION ALERTS =====")
for item in matches:
    print(json.dumps(item, ensure_ascii=False))

print("===== CORRELATION RESULT =====")
if any(item["rule_id"] == "100106" for item in matches):
    print("SUCCESS: Rule 100106 detected")
else:
    print("NOT YET DETECTED: Rule 100106 not found")
PY
'
```

`SUCCESS: Rule 100106 detected` と表示されれば、実際の転送経路でもブルートフォースの相関検知が成立しています。構築時は、単発検知（100101）が4件、相関検知（100106、レベル12）が1件記録されました。

この章までで、次の検知ができるようになりました。

| ルールID | 検知内容 |
|---|---|
| 100101 | PostgreSQLの認証失敗（単発） |
| 100106 | 同じAgentで60秒間に5回以上の認証失敗（ブルートフォースの疑い、MITRE T1110） |

ただし、この方式では攻撃元のIPアドレスまではわかりません。次章で、接続元IPを安全にイベントへ加えます。

# 第7章　接続元IPの取得とIP対応フィルターの試作

第6章の相関検知は同じAgent単位のため、攻撃元のIPアドレスまではわかりません。この章では、「SQL文・ユーザー名をWazuhへ送らない」方針を保ったまま、認証失敗イベントに接続元IPを加える準備をします。

| 項目 | 方針 |
|---|---|
| 転送する情報 | 発生時刻、イベント種別、接続元IP |
| 転送しない情報 | SQL文、ユーザー名、パスワード、DB名、接続元ポート、PID、元のログ本文 |
| 相関の単位 | 接続元IPアドレス |
| 検知条件 | 同じIPから60秒間に5回以上 |
| IPv4・IPv6 | 両方に対応 |
| 既存ルール | 100101・100106を維持 |

## 7.1　認証失敗ログにIPアドレスがあるかの調査

まず、現在のログで、認証失敗の行や接続受付の行にIPアドレスが含まれているかを調べます。ログの本文やSQL文は表示しません。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- python3 - <<'PY'
import ipaddress
import re
from collections import deque
from pathlib import Path

path = Path("/var/log/postgresql/postgresql-17-main.log")

prefix = re.compile(
    r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}(?:\.\d+)?)"
    r" \[(\d+)\]"
)

auth_re = re.compile(r"password authentication failed", re.I)
received_re = re.compile(r"connection received:", re.I)
host_re = re.compile(r'\bhost[= ]+"?([^\s",]+)"?', re.I)

def extract_ips(line):
    result = []
    for candidate in re.findall(
        r'(?<![0-9A-Fa-f:.])(?:[0-9]{1,3}\.){3}[0-9]{1,3}'
        r'|(?<![0-9A-Fa-f:])[0-9A-Fa-f:]{2,}(?:%[0-9A-Za-z_.-]+)?',
        line
    ):
        try:
            ip = ipaddress.ip_address(candidate.split("%")[0])
            if str(ip) not in result:
                result.append(str(ip))
        except ValueError:
            pass
    return result

recent_connection = {}
matches = deque(maxlen=10)

with path.open(encoding="utf-8", errors="replace") as f:
    for line in f:
        m = prefix.match(line)
        if not m:
            continue

        timestamp, pid = m.groups()

        if received_re.search(line):
            ips = extract_ips(line)
            if ips:
                recent_connection[pid] = ips

        if auth_re.search(line):
            matches.append({
                "timestamp": timestamp,
                "pid": pid,
                "ip_in_auth_line": extract_ips(line),
                "ip_from_connection_received": recent_connection.get(pid, [])
            })

print("===== SANITIZED AUTHENTICATION LOG ANALYSIS =====")
print("auth_failure_count_in_file:", len(matches))
for item in matches:
    print(item)

print("===== RESULT =====")
if not matches:
    print("No matching authentication failure lines found.")
elif any(
    x["ip_in_auth_line"] or x["ip_from_connection_received"]
    for x in matches
):
    print("IP candidate found. Review PID association before implementation.")
else:
    print("No IP found in inspected authentication/connection lines.")
PY
```

構築時は、現在のログファイルに認証失敗が0件でした（以前の認証失敗はローテーションで過去のファイルに移っていました）。そこで、ローテーション済みのログも含めて集計します。

```bash
pct exec 109 -- python3 - <<'PY'
import gzip
import ipaddress
import re
from pathlib import Path

base = Path("/var/log/postgresql")
files = sorted(base.glob("postgresql-17-main.log*"))

auth_re = re.compile(r"password authentication failed", re.I)
prefix_re = re.compile(r"^(\S+)\s+\[(\d+)\]")
ip_re = re.compile(
    r'(?<![0-9A-Fa-f:.])(?:[0-9]{1,3}\.){3}[0-9]{1,3}'
    r'|(?<![0-9A-Fa-f:])[0-9A-Fa-f:]{2,}'
)

def lines(path):
    if path.suffix == ".gz":
        with gzip.open(path, "rt", encoding="utf-8", errors="replace") as f:
            yield from f
    else:
        with path.open(encoding="utf-8", errors="replace") as f:
            yield from f

def valid_ips(line):
    found = []
    for value in ip_re.findall(line):
        try:
            ip = str(ipaddress.ip_address(value))
            if ip not in found:
                found.append(ip)
        except ValueError:
            pass
    return found

total_auth = 0
total_connection = 0
auth_with_ip = 0

print("===== LOG FILE SUMMARY =====")

for path in files:
    count_auth = 0
    count_connection = 0
    count_auth_ip = 0

    for line in lines(path):
        if auth_re.search(line):
            count_auth += 1
            total_auth += 1
            if valid_ips(line):
                count_auth_ip += 1
                auth_with_ip += 1

        if "connection received:" in line.lower():
            count_connection += 1
            total_connection += 1

    print({
        "file": path.name,
        "auth_failures": count_auth,
        "auth_lines_with_ip": count_auth_ip,
        "connection_received": count_connection
    })

print("===== TOTAL =====")
print({
    "auth_failures": total_auth,
    "auth_lines_with_ip": auth_with_ip,
    "connection_received": total_connection
})
PY
```

実行結果（例）の合計：

```text
===== TOTAL =====
{'auth_failures': 28, 'auth_lines_with_ip': 0, 'connection_received': 0}
```

過去の認証失敗28件のどれにもIPアドレスはなく、接続受付のログも0件でした。`log_connections=off` のため、接続受付のログが記録されていないからです。

## 7.2　採用する方式

PostgreSQLの `log_connections` を有効にし、次の仕組みでIPを取得します。

1. PostgreSQLは、接続を受け付けたときに「PID」と「接続元IP」を含む行（`LOG: connection received`）を記録する。
2. 同じ接続で認証に失敗すると、同じPIDで認証失敗の行が記録される。
3. フィルターはPIDとIPの対応をメモリー上だけに一時的に持ち、認証失敗のイベントに接続元IPを付ける。

IPが取得できなかった認証失敗は、IPごとの相関には使わず、これまでどおり単発の検知だけを行います。

## 7.3　PostgreSQL設定の確認

設定を変える前に、現在の値と、設定が反映される条件（`context`）を確認します。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- runuser -u postgres -- \
  psql -X -d postgres -P pager=off -c "
SELECT
  name,
  setting,
  context,
  source
FROM pg_settings
WHERE name IN (
  'log_connections',
  'log_line_prefix',
  'log_hostname',
  'logging_collector',
  'log_destination'
)
ORDER BY name;
"
```

| 設定 | 現在値 | 対応 |
|---|---|---|
| `log_connections` | off | 有効にする（第8章） |
| `log_line_prefix` | `%m [%p] %q%u@%d ` | `%p`（PID）があるので、接続受付と認証失敗をPIDで対応付けられる |
| `log_hostname` | off | 変更しない（DNS名ではなくIPを記録させる） |
| `logging_collector` | off | 変更しない |
| `log_destination` | stderr | 変更しない |

## 7.4　既存フィルターの確認とバックアップ

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
echo "===== FILTER SCRIPT ====="
sed -n "1,240p" /usr/local/sbin/postgresql-wazuh-filter.py

echo
echo "===== FILTER SERVICE ====="
systemctl is-active postgresql-wazuh-filter.service

echo
echo "===== FILTER OUTPUT PERMISSIONS ====="
stat -c "%U:%G %a %n" \
  /var/log/postgresql-wazuh \
  /var/log/postgresql-wazuh/events.log
'
```

改修前のスクリプトを保存します。サービスの停止や設定の変更はありません。

```bash
pct exec 109 -- bash -c '
set -e

BACKUP="/usr/local/sbin/postgresql-wazuh-filter.py.backup-ip-$(date +%Y%m%d-%H%M%S)"

cp -a /usr/local/sbin/postgresql-wazuh-filter.py "$BACKUP"

echo "===== BACKUP CREATED ====="
stat -c "%U:%G %a %n" "$BACKUP"

echo
echo "===== ORIGINAL SCRIPT CHECKSUM ====="
sha256sum /usr/local/sbin/postgresql-wazuh-filter.py "$BACKUP"
'
```

元のスクリプトとバックアップのSHA-256が一致していれば、復旧できる状態です。

## 7.5　IP対応フィルターの試作

稼働中のスクリプトは書き換えず、IP対応版を一時ファイル（`/tmp/postgresql-wazuh-filter-ip.py`）として作ってテストします。テストに失敗しても、今のログ収集は止まりません。

試作版の仕様は次のとおりです。

- `LOG: connection received` の行から、PIDとIPアドレスを取得する。
- `FATAL: password authentication failed` の行のPIDと照合する。
- IPv4・IPv6を `ipaddress` モジュールで検証する。
- PIDとIPの対応はメモリー上で最大300秒だけ保持する。
- SQL文、ユーザー名、DB名、ポート番号、元のログ本文は出力しない。
- IPを取得できない場合は、IPの項目を出力しない。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c 'cat > /tmp/postgresql-wazuh-filter-ip.py <<'"'"'PY'"'"'
#!/usr/bin/env python3

import ipaddress
import json
import re
import time

PREFIX = re.compile(
    r"^(?P<timestamp>\d{4}-\d{2}-\d{2} "
    r"\d{2}:\d{2}:\d{2}(?:\.\d+)?(?: [A-Z]{2,5})?)"
    r" \[(?P<pid>\d+)\] "
    r"(?:\S+ )?"
    r"(?P<severity>PANIC|FATAL|ERROR|WARNING|LOG):"
)

HOST = re.compile(
    r"\bhost=(?:\"([^\"]+)\"|([^\s,]+))",
    re.IGNORECASE
)

AUTH_FAILURE = re.compile(
    r"\bpassword authentication failed\b",
    re.IGNORECASE
)

EVENTS = {
    "PANIC": "POSTGRESQL_PANIC",
    "FATAL": "POSTGRESQL_FATAL",
    "ERROR": "POSTGRESQL_ERROR",
    "WARNING": "POSTGRESQL_WARNING",
}

IP_TTL = 300
MAX_CONNECTIONS = 10000

connections = {}

def extract_ip(line):
    match = HOST.search(line)
    if not match:
        return None

    value = (match.group(1) or match.group(2) or "").strip()
    value = value.strip("[]")

    if "%" in value:
        value = value.split("%", 1)[0]

    try:
        return str(ipaddress.ip_address(value))
    except ValueError:
        return None


def classify(line, now=None):
    if now is None:
        now = time.monotonic()

    match = PREFIX.match(line)
    if not match:
        return None

    timestamp = match.group("timestamp")
    pid = match.group("pid")
    severity = match.group("severity")

    # 古いPID/IP対応情報を破棄する。
    expired = [
        key for key, (_, created) in connections.items()
        if now - created > IP_TTL
    ]
    for key in expired:
        connections.pop(key, None)

    # 接続受付ログからPIDと送信元IPを記録する。
    if severity == "LOG" and "connection received:" in line.lower():
        ip = extract_ip(line)

        # PID再利用時に古いIPを残さない。
        connections.pop(pid, None)

        if ip:
            connections[pid] = (ip, now)

            while len(connections) > MAX_CONNECTIONS:
                oldest = next(iter(connections))
                connections.pop(oldest, None)

        return None

    # 切断時に対応情報を破棄する。
    if severity == "LOG" and "disconnection:" in line.lower():
        connections.pop(pid, None)
        return None

    if severity == "FATAL" and AUTH_FAILURE.search(line):
        event = {
            "timestamp": timestamp,
            "event": "POSTGRESQL_AUTH_FAILURE",
        }

        connection = connections.get(pid)
        if connection:
            event["source_ip"] = connection[0]

        return json.dumps(event, ensure_ascii=True) + "\n"

    if severity in EVENTS:
        event = {
            "timestamp": timestamp,
            "event": EVENTS[severity],
        }
        return json.dumps(event, ensure_ascii=True) + "\n"

    return None
PY

python3 -m py_compile /tmp/postgresql-wazuh-filter-ip.py &&
echo "Temporary filter syntax: PASS"
'
```

`Temporary filter syntax: PASS` と表示されれば成功です。

## 7.6　一時ファイルが最後まで作成されたことの確認

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
echo "===== TEMPORARY SCRIPT: LINE COUNT ====="
wc -l /tmp/postgresql-wazuh-filter-ip.py

echo
echo "===== TEMPORARY SCRIPT: LAST 100 LINES ====="
tail -n 100 /tmp/postgresql-wazuh-filter-ip.py

echo
echo "===== PYTHON SYNTAX CHECK ====="
python3 -m py_compile /tmp/postgresql-wazuh-filter-ip.py
echo "EXIT CODE: $?"
'
```

115行あり、`classify()` 関数の最後（`return None`）まで存在し、`EXIT CODE: 0` であれば正常です。

## 7.7　PIDとIPの対応情報を使用後すぐに破棄する修正

OSがPIDを再利用したときに、古いIPを誤って別の接続に紐付けないよう、認証失敗を処理した直後にPIDとIPの対応情報を破棄します（`connections.get` を `connections.pop` に変更）。

> 文字列全体を置き換える方法では、改行文字の扱いの違いで置換に失敗することがあります。ここでは該当する1行を直接書き換えます。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
set -e

python3 - <<'"'"'PY'"'"'
from pathlib import Path

p = Path("/tmp/postgresql-wazuh-filter-ip.py")
lines = p.read_text().splitlines()

start = next(
    i for i, line in enumerate(lines)
    if line.strip() == "connection = connections.get(pid)"
)

if lines[start + 1].strip() != "if connection:":
    raise SystemExit("Unexpected filter structure; aborted")

lines[start] = "        connection = connections.pop(pid, None)"

p.write_text("\n".join(lines) + "\n")
PY

python3 -m py_compile /tmp/postgresql-wazuh-filter-ip.py

echo "===== UPDATED AUTH BLOCK ====="
grep -n -A 12 -B 2 "AUTH_FAILURE.search" \
  /tmp/postgresql-wazuh-filter-ip.py

echo
echo "===== SYNTAX CHECK ====="
echo "PASS"
'
```

更新後のブロックに `connection = connections.pop(pid, None)` があれば成功です。

## 7.8　IPv4・IPv6・情報漏えい防止のテスト

模擬ログを使って、次の点を確認します。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
set -e

python3 - <<'"'"'PY'"'"'
import importlib.util
import json

path = "/tmp/postgresql-wazuh-filter-ip.py"
spec = importlib.util.spec_from_file_location("pgfilter", path)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

def check(condition, message):
    if not condition:
        raise SystemExit("FAIL: " + message)
    print("PASS:", message)

# IPv4
m.connections.clear()
m.classify(
    "2026-11-18 15:40:00 JST [12345] postgres@postgres LOG: connection received: host=192.0.2.10 port=54321",
    now=100
)
result = m.classify(
    "2026-11-18 15:40:01 JST [12345] attacker@postgres FATAL: password authentication failed for user SECRET_USER",
    now=101
)
obj = json.loads(result)
check(obj.get("source_ip") == "192.0.2.10", "IPv4 PID correlation")
check(set(obj) == {"timestamp", "event", "source_ip"}, "Only approved JSON fields emitted")
check("SECRET_USER" not in result and "password authentication failed" not in result, "No username or raw authentication message")
check("54321" not in result and "12345" not in result, "No port or PID emitted")
check("12345" not in m.connections, "PID mapping cleared after authentication failure")

# IPv6
m.connections.clear()
m.classify(
    "2026-11-18 15:41:00 JST [23456] postgres@postgres LOG: connection received: host=2001:0db8:0000:0000:0000:0000:0000:0001 port=54322",
    now=200
)
result6 = m.classify(
    "2026-11-18 15:41:01 JST [23456] attacker@postgres FATAL: password authentication failed for user SECRET_USER",
    now=201
)
obj6 = json.loads(result6)
check(obj6.get("source_ip") == "2001:db8::1", "IPv6 extraction and canonicalization")

# Expired mapping
m.connections.clear()
m.classify(
    "2026-11-18 15:42:00 JST [34567] postgres@postgres LOG: connection received: host=198.51.100.20 port=54323",
    now=10
)
expired = m.classify(
    "2026-11-18 15:47:01 JST [34567] attacker@postgres FATAL: password authentication failed for user SECRET_USER",
    now=311
)
check("source_ip" not in json.loads(expired), "Expired PID mapping rejected")

# Hostname is not accepted as an IP
m.connections.clear()
m.classify(
    "2026-11-18 15:48:00 JST [45678] postgres@postgres LOG: connection received: host=attacker.example port=54324",
    now=400
)
invalid = m.classify(
    "2026-11-18 15:48:01 JST [45678] attacker@postgres FATAL: password authentication failed for user SECRET_USER",
    now=401
)
check("source_ip" not in json.loads(invalid), "Non-IP hostname rejected")

print("ALL FILTER TESTS PASSED")
PY
'
```

| テスト項目 | 期待する結果 |
|---|---|
| IPv4のPID照合 | `192.0.2.10` が付く |
| 出力項目の制限 | `timestamp`・`event`・`source_ip` の3つだけ |
| ユーザー名・本文の非出力 | `SECRET_USER` などが含まれない |
| ポート・PIDの非出力 | `54321`・`12345` が含まれない |
| 使用後の破棄 | 認証失敗の処理後、PIDの対応情報が消えている |
| IPv6の正規化 | `2001:db8::1` に正規化される |
| 期限切れ | 300秒を過ぎた対応情報は使われない |
| ホスト名の拒否 | IPではないホスト名は出力されない |

最後に `ALL FILTER TESTS PASSED` と表示されれば成功です。なお、これは模擬ログによるテストです。実際のPostgreSQLのログとの照合は次の手順で行います。

## 7.9　Wazuh側の確認

Wazuhで送信元IPごとに相関するため、Manager側の現在のルールとバージョンを確認します。

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
echo "===== POSTGRESQL CORRELATION RULE ====="
grep -n -A 15 -B 3 -E "100101|100106" \
  /var/ossec/etc/rules/local_rules.xml

echo
echo "===== WAZUH VERSION ====="
/var/ossec/bin/wazuh-control info
'
```

ルールファイルをバックアップします。

```bash
qm guest exec 220 -- bash -c '
set -e

BACKUP="/var/ossec/etc/rules/local_rules.xml.backup-ip-$(date +%Y%m%d-%H%M%S)"

cp -a /var/ossec/etc/rules/local_rules.xml "$BACKUP"

echo "===== BACKUP ====="
stat -c "%U:%G %a %n" "$BACKUP"

echo
echo "===== CHECKSUM ====="
sha256sum \
  /var/ossec/etc/rules/local_rules.xml \
  "$BACKUP"
'
```

Wazuhの標準ルールで、送信元IPごとの相関（`same_source_ip`）が使われていることを確認します。

```bash
qm guest exec 220 -- bash -c '
echo "===== SAME SOURCE IP RULE EXAMPLES ====="
grep -R -n -B 4 -A 8 "<same_source_ip" \
  /var/ossec/ruleset/rules \
  /var/ossec/etc/rules 2>/dev/null \
  | head -n 100

echo
echo "===== WAZUH LOGTEST AVAILABLE ====="
ls -l /var/ossec/bin/wazuh-logtest
'
```

ApacheやMicrosoft SQL Serverなどの標準ルールで `same_source_ip` が使われていれば、PostgreSQLの送信元IPの相関にも同じ方式を使えます。

> **フィールド名の決定：** Wazuh標準の送信元IPの相関と互換性を持たせるため、イベントのIPフィールド名は `source_ip` ではなく **`srcip`** に統一します（第8章で変更します）。

## 7.10　実際のログ形式との照合

既存ログの `LOG`・`FATAL` 行の先頭部分を確認します。認証失敗の行は、本文を `[REDACTED]` に置き換えて表示します。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
echo "===== EXISTING LOG PREFIX SAMPLES ====="

grep -h -E " LOG:| FATAL:" \
  /var/log/postgresql/postgresql-17-main.log \
  | tail -n 15 \
  | sed -E "s/(password authentication failed).*/\1 [REDACTED]/"

echo
echo "===== LOG LINE PREFIX SETTING ====="

runuser -u postgres -- psql -X -d postgres -Atc \
  "SHOW log_line_prefix;"
'
```

実際のログは、次のような形式でした。

```text
2026-11-18 06:07:47.992 UTC [198] LOG:  checkpoint complete: ...
```

一時フィルターの正規表現で、既存ログのタイムスタンプ・PID・重大度を取り出せるかを確認します。

```bash
pct exec 109 -- bash -c '
python3 - <<'"'"'PY'"'"'
import importlib.util

path = "/tmp/postgresql-wazuh-filter-ip.py"
spec = importlib.util.spec_from_file_location("pgfilter", path)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

count = 0

with open(
    "/var/log/postgresql/postgresql-17-main.log",
    encoding="utf-8",
    errors="replace"
) as f:
    for line in f:
        if " LOG:" not in line and " FATAL:" not in line:
            continue

        match = m.PREFIX.match(line)
        if not match:
            print("UNMATCHED:", line.rstrip()[:160])
            continue

        print(
            "MATCH:",
            "timestamp=", match.group("timestamp"),
            "pid=", match.group("pid"),
            "severity=", match.group("severity")
        )
        count += 1

        if count >= 10:
            break

print("MATCHED_LINES:", count)
PY
'
```

`MATCHED_LINES: 10` と表示され、10件すべてでタイムスタンプ・PID・`LOG` が取り出せれば、実際のログ形式に対応できています。

> **`log_connections` の反映条件：** `log_connections` の `context` は `superuser-backend` です。PostgreSQL 17では、この種類の設定は `postgresql.conf` で変更でき、設定の再読み込み（SIGHUP）で反映されます。反映されるのは新しく始まる接続からで、既存の接続には適用されません。**PostgreSQLの再起動は必要ありません。**

この章では、IP対応フィルターの試作版を作り、模擬ログと実際のログ形式の両方で動作を確認しました。次章では、試作版のフィールド名を `srcip` に変えて本番に反映し、`log_connections` を有効にして、送信元IPごとの相関ルールを追加します。

# 第8章　送信元IPごとの相関検知の本番化

第7章の試作版をもとに、次の順で本番に反映します。

1. 試作版の正規表現とフィールド名（`srcip`）の修正と、テスト
2. Wazuhの相関ルール `100106` を「同じ送信元IP」単位に変更し、テスト
3. PostgreSQLの `log_connections` の有効化（再起動なし）
4. 統合版フィルター（IP対応＋既存の監視ループ）の作成、テスト、本番への切り替え
5. Wazuh Managerへのルールの反映と、実際の認証失敗による最終確認

## 8.1　試作版の修正

PIDの直後に空白が複数入る形式に対応し、出力するIPのフィールド名を `srcip` に変えます。

> 長いPythonスクリプトをターミナルに貼り付けると、途中で崩れて実行されないことがあります（構築時もヒアドキュメントが途中で切れて `SyntaxError` になりました）。ここでは対象の2行だけを `sed` で書き換えます。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
set -e

FILE=/tmp/postgresql-wazuh-filter-ip.py

sed -i "/(?P<pid>/c\\    r\" \\\\[(?P<pid>\\\\d+)\\\\]\\\\s+\"" "$FILE"
sed -i "s/event\\[\"source_ip\"\\]/event[\"srcip\"]/" "$FILE"

python3 -m py_compile "$FILE"

echo "===== PREFIX ====="
sed -n "11,16p" "$FILE"

echo
echo "===== IP FIELD ====="
grep -nE "srcip|source_ip" "$FILE"

echo
echo "===== SYNTAX ====="
echo PASS
'
```

実行結果（例）：

```text
===== PREFIX =====
    r" \[(?P<pid>\d+)\]\s+"
    r"(?:\S+ )?"
    r"(?P<severity>PANIC|FATAL|ERROR|WARNING|LOG):"
)

HOST = re.compile(

===== IP FIELD =====
104:            event["srcip"] = connection[0]

===== SYNTAX =====
PASS
```

## 8.2　正規表現のテスト

次の3つの形式を認識できるかを確認します。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
python3 - <<'"'"'PY'"'"'
import importlib.util

path = "/tmp/postgresql-wazuh-filter-ip.py"
spec = importlib.util.spec_from_file_location("pgfilter", path)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

samples = [
    "2026-11-18 06:07:47.992 UTC [198]  LOG: connection received: host=192.0.2.10",
    "2026-11-18 06:07:47.992 UTC [198] postgres@postgres LOG: connection authenticated",
    "2026-11-18 06:07:47.992 UTC [198]  FATAL: password authentication failed for user \"test\"",
]

for line in samples:
    match = m.PREFIX.match(line)
    if not match:
        print("FAIL:", line)
        raise SystemExit(1)

    print(
        "PASS:",
        "PID=", match.group("pid"),
        "SEVERITY=", match.group("severity")
    )

print("ALL PREFIX TESTS PASSED")
PY
'
```

| 形式 | 期待する結果 |
|---|---|
| PIDの直後に空白が複数ある `LOG` | `PID= 198 SEVERITY= LOG` |
| ユーザー・DB名が付いた `LOG` | `PID= 198 SEVERITY= LOG` |
| 認証失敗の `FATAL` | `PID= 198 SEVERITY= FATAL` |

最後に `ALL PREFIX TESTS PASSED` と表示されれば成功です。

## 8.3　IP相関処理のテスト

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
python3 - <<'"'"'PY'"'"'
import importlib.util
import json
import time

path = "/tmp/postgresql-wazuh-filter-ip.py"
spec = importlib.util.spec_from_file_location("pgfilter", path)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

now = time.monotonic()
m.connections.clear()

def check(name, condition):
    if not condition:
        raise SystemExit("FAIL: " + name)
    print("PASS:", name)

# IPv4: 接続受付から認証失敗まで
m.classify(
    "2026-11-18 06:07:47.992 UTC [198]  LOG: connection received: host=192.0.2.10",
    now
)
event = m.classify(
    "2026-11-18 06:07:48.100 UTC [198]  FATAL: password authentication failed for user \"secret-user\"",
    now + 1
)
data = json.loads(event)
check("IPv4 PID correlation", data.get("srcip") == "192.0.2.10")
check("Sensitive text excluded", "secret-user" not in event and "password" not in event)
check("PID mapping cleared", "198" not in m.connections)

# IPv6
m.classify(
    "2026-11-18 06:08:00.000 UTC [199]  LOG: connection received: host=2001:db8::10",
    now + 2
)
event = m.classify(
    "2026-11-18 06:08:01.000 UTC [199]  FATAL: password authentication failed",
    now + 3
)
data = json.loads(event)
check("IPv6 PID correlation", data.get("srcip") == "2001:db8::10")

# TTL expiration
m.classify(
    "2026-11-18 06:09:00.000 UTC [200]  LOG: connection received: host=192.0.2.20",
    now + 4
)
event = m.classify(
    "2026-11-18 06:15:00.000 UTC [200]  FATAL: password authentication failed",
    now + 305
)
data = json.loads(event)
check("Expired IP is not attached", "srcip" not in data)

# Invalid hostname
m.classify(
    "2026-11-18 06:16:00.000 UTC [201]  LOG: connection received: host=invalid.example",
    now + 306
)
check("Invalid host rejected", "201" not in m.connections)

print("ALL IP CORRELATION TESTS PASSED")
PY
'
```

6項目すべてに `PASS` が出て、`ALL IP CORRELATION TESTS PASSED` と表示されれば成功です。

## 8.4　相関ルールを送信元IP単位に変更

ルール `100106` に `<same_source_ip />` を加え、「同じ送信元IPから60秒間に5回以上」の条件にします。

現在のルールを確認します。

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
echo "===== POSTGRESQL CORRELATION RULE ====="

grep -n -A 14 -B 3 "100106" \
  /var/ossec/etc/rules/local_rules.xml

echo
echo "===== WAZUH LOGTEST ====="

ls -l /var/ossec/bin/wazuh-logtest

echo
echo "===== RULE FILE CHECKSUM ====="

sha256sum /var/ossec/etc/rules/local_rules.xml
'
```

バックアップを取ってから、ルールを変更して構文を検証します。

```bash
qm guest exec 220 -- bash -c '
set -e

RULE=/var/ossec/etc/rules/local_rules.xml
BACKUP="${RULE}.backup-sameip-$(date +%Y%m%d-%H%M%S)"

cp -a "$RULE" "$BACKUP"

python3 - <<'"'"'PY'"'"'
from pathlib import Path

p = Path("/var/ossec/etc/rules/local_rules.xml")
s = p.read_text()

old = """    <if_matched_sid>100101</if_matched_sid>
    <description>PostgreSQL: Multiple authentication failures from the same agent within 60 seconds.</description>"""

new = """    <if_matched_sid>100101</if_matched_sid>
    <same_source_ip />
    <description>PostgreSQL: 5 authentication failures from the same source IP within 60 seconds.</description>"""

if s.count(old) != 1:
    raise SystemExit("FAIL: Expected rule block not found exactly once")

p.write_text(s.replace(old, new, 1))
PY

echo "===== UPDATED RULE ====="
grep -n -A 10 -B 2 "100106" "$RULE"

echo
echo "===== BACKUP ====="
echo "$BACKUP"

echo
echo "===== RULE VALIDATION ====="
/var/ossec/bin/wazuh-analysisd -t
'
```

変更後のルールは次のとおりです。

```xml
<rule id="100106" level="12" frequency="5" timeframe="60">
  <if_matched_sid>100101</if_matched_sid>
  <same_source_ip />
  <description>PostgreSQL: 5 authentication failures from the same source IP within 60 seconds.</description>
```

> この時点ではルールファイルを変更しただけで、稼働中のManagerにはまだ反映されていません。Managerの再起動は8.8で行います。

## 8.5　相関ルールのテスト

`wazuh-logtest` は、その時点のルールファイルを読み込んでテストします。次の3つのケースを確認します。

**同じIPから5回（5回目で100106が発火する）**

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
printf "%s\n" \
"{\"timestamp\":\"2026-11-18 07:00:01 UTC\",\"event\":\"POSTGRESQL_AUTH_FAILURE\",\"srcip\":\"192.0.2.10\"}" \
"{\"timestamp\":\"2026-11-18 07:00:02 UTC\",\"event\":\"POSTGRESQL_AUTH_FAILURE\",\"srcip\":\"192.0.2.10\"}" \
"{\"timestamp\":\"2026-11-18 07:00:03 UTC\",\"event\":\"POSTGRESQL_AUTH_FAILURE\",\"srcip\":\"192.0.2.10\"}" \
"{\"timestamp\":\"2026-11-18 07:00:04 UTC\",\"event\":\"POSTGRESQL_AUTH_FAILURE\",\"srcip\":\"192.0.2.10\"}" \
"{\"timestamp\":\"2026-11-18 07:00:05 UTC\",\"event\":\"POSTGRESQL_AUTH_FAILURE\",\"srcip\":\"192.0.2.10\"}" \
| /var/ossec/bin/wazuh-logtest
'
```

1〜4回目が `100101`（レベル8）、5回目が `100106`（レベル12、MITRE `T1110`）になれば成功です。

**異なるIPが混ざる場合（100106は発火しない）**

```bash
qm guest exec 220 -- bash -c '
printf "%s\n" \
"{\"timestamp\":\"2026-11-18 07:01:01 UTC\",\"event\":\"POSTGRESQL_AUTH_FAILURE\",\"srcip\":\"192.0.2.10\"}" \
"{\"timestamp\":\"2026-11-18 07:01:02 UTC\",\"event\":\"POSTGRESQL_AUTH_FAILURE\",\"srcip\":\"192.0.2.10\"}" \
"{\"timestamp\":\"2026-11-18 07:01:03 UTC\",\"event\":\"POSTGRESQL_AUTH_FAILURE\",\"srcip\":\"192.0.2.10\"}" \
"{\"timestamp\":\"2026-11-18 07:01:04 UTC\",\"event\":\"POSTGRESQL_AUTH_FAILURE\",\"srcip\":\"192.0.2.10\"}" \
"{\"timestamp\":\"2026-11-18 07:01:05 UTC\",\"event\":\"POSTGRESQL_AUTH_FAILURE\",\"srcip\":\"192.0.2.20\"}" \
| /var/ossec/bin/wazuh-logtest \
| grep -E "id:|level:|description:|firedtimes:"
'
```

`192.0.2.10` が4回、`192.0.2.20` が1回なので、5件すべてが `100101` になり、`100106` が出なければ成功です。

**送信元IPがない場合（100106は発火しない）**

```bash
qm guest exec 220 -- bash -c '
printf "%s\n" \
"{\"timestamp\":\"2026-11-18 07:02:01 UTC\",\"event\":\"POSTGRESQL_AUTH_FAILURE\"}" \
"{\"timestamp\":\"2026-11-18 07:02:02 UTC\",\"event\":\"POSTGRESQL_AUTH_FAILURE\"}" \
"{\"timestamp\":\"2026-11-18 07:02:03 UTC\",\"event\":\"POSTGRESQL_AUTH_FAILURE\"}" \
"{\"timestamp\":\"2026-11-18 07:02:04 UTC\",\"event\":\"POSTGRESQL_AUTH_FAILURE\"}" \
"{\"timestamp\":\"2026-11-18 07:02:05 UTC\",\"event\":\"POSTGRESQL_AUTH_FAILURE\"}" \
| /var/ossec/bin/wazuh-logtest
'
```

5件とも `100101` で、`100106` が出なければ成功です。送信元IPがわからないイベントを、同じ攻撃元として誤って集計しないことを確認できます。

最後にManagerの設定を検証します。

```bash
qm guest exec 220 -- /var/ossec/bin/wazuh-analysisd -t
```

`"exitcode" : 0` であれば正常です（`err-data` の `Rule tree threshold` はINFOで、エラーではありません）。

> `qm guest exec` の結果に表示される `"exited" : 1` は「コマンドの実行が終わった」という意味です。コマンドの成否は `"exitcode"` で判断してください。また、結果として表示されたJSONをそのままシェルに貼り付けると `command not found` になりますが、システムには影響ありません。

## 8.6　log_connectionsの有効化

PostgreSQLの再起動をせず、接続受付のログ（`connection received`）を記録させます。

### 現在の設定と設定ファイルの構成を確認

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
echo "===== POSTGRESQL CONNECTION LOG SETTINGS ====="
runuser -u postgres -- psql -X -d postgres -P pager=off -c "
SELECT name, setting, context, source, pending_restart
FROM pg_settings
WHERE name IN (
  '\''log_connections'\'',
  '\''log_disconnections'\'',
  '\''log_line_prefix'\'',
  '\''logging_collector'\''
)
ORDER BY name;
"
'
```

```bash
pct exec 109 -- bash -c '
runuser -u postgres -- psql -X -d postgres -P pager=off -c "
SHOW config_file;
SELECT name, setting, applied, error, sourcefile, sourceline
FROM pg_file_settings
WHERE name IN ('\''log_connections'\'', '\''log_disconnections'\'')
ORDER BY name, sourceline;
"
'
```

`pg_file_settings` に該当する行がなければ、どの設定ファイルにも明記されておらず、既定値の `off` が使われています。

```bash
pct exec 109 -- bash -c '
CONF=/etc/postgresql/17/main/postgresql.conf
AUTO=/var/lib/postgresql/17/main/postgresql.auto.conf

echo "===== MAIN CONFIG ====="
grep -nEi "^[[:space:]]*(include|include_dir|include_if_exists|log_connections|log_disconnections)" "$CONF" || true

echo
echo "===== AUTO CONFIG ====="
if [ -f "$AUTO" ]; then
    grep -nEi "^[[:space:]]*(log_connections|log_disconnections)" "$AUTO" || true
else
    echo "postgresql.auto.conf not found"
fi

echo
echo "===== CONFIG DIRECTORY ====="
ls -la /etc/postgresql/17/main/conf.d 2>/dev/null || true
'
```

`include_dir = 'conf.d'` があり、`conf.d` が空であることを確認します。既存の `postgresql.conf` を直接書き換えるのではなく、`conf.d` に専用の設定ファイルを置く方式にします。

### バックアップと専用設定ファイルの作成

```bash
pct exec 109 -- bash -c '
set -e
CONF=/etc/postgresql/17/main/postgresql.conf
BACKUP="${CONF}.backup-before-log-connections-$(date +%Y%m%d-%H%M%S)"

cp -a "$CONF" "$BACKUP"

echo "===== BACKUP ====="
stat -c "%U:%G %a %s %n" "$BACKUP"

echo
echo "===== CONFIG DIRECTORY PERMISSIONS ====="
stat -c "%U:%G %a %n" /etc/postgresql/17/main/conf.d
'
```

```bash
pct exec 109 -- bash -c '
set -e

CONF=/etc/postgresql/17/main/conf.d/99-wazuh-connection-logging.conf

printf "%s\n" \
  "# Wazuh PostgreSQL connection source IP collection" \
  "log_connections = on" \
  > "$CONF"

chown postgres:postgres "$CONF"
chmod 640 "$CONF"

echo "===== CREATED CONFIG ====="
stat -c "%U:%G %a %s bytes %n" "$CONF"
cat "$CONF"
'
```

### 反映前の検証

```bash
pct exec 109 -- bash -c '
runuser -u postgres -- psql -X -d postgres -P pager=off -c "
SELECT sourcefile, sourceline, name, setting, applied, error
FROM pg_file_settings
WHERE name = '\''log_connections'\''
   OR error IS NOT NULL
ORDER BY sourcefile, sourceline;
"
'
```

`99-wazuh-connection-logging.conf` の `log_connections` が `on`、`applied` が `t`、`error` が空であれば正常です。

### 設定の再読み込み（再起動なし）

```bash
pct exec 109 -- bash -c '
set -e
runuser -u postgres -- psql -X -d postgres -v ON_ERROR_STOP=1 -c "SELECT pg_reload_conf();"
'
```

`t` が返れば再読み込みは成功です。既存の接続は切断されず、新しく始まる接続から有効になります。

```bash
pct exec 109 -- bash -c '
runuser -u postgres -- psql -X -d postgres -P pager=off -c "
SELECT name, setting, context, source, pending_restart
FROM pg_settings
WHERE name = '\''log_connections'\'';
"
'
```

| 項目 | 期待値 |
|---|---|
| setting | `on` |
| source | `configuration file` |
| pending_restart | `f` |

### 接続受付ログの確認

```bash
pct exec 109 -- bash -c '
set -e

echo "===== CREATE TEST CONNECTION ====="
runuser -u postgres -- psql -X -d postgres -v ON_ERROR_STOP=1 -c "SELECT 1;"

echo
echo "===== RECENT CONNECTION LOG ====="
grep -E "connection received:|connection authenticated:" \
  /var/log/postgresql/postgresql-17-main.log \
  | tail -n 10
'
```

構築時は、次のようにPIDと接続元IPが記録されました。

```text
[15614] [unknown]@[unknown] LOG: connection received: host=192.168.0.211 port=54188
[15614] agent@agent_memory LOG: connection authenticated: ...
```

ローカルソケットからの接続は `host=[local]` と記録されます。これはIPアドレスではないため、フィルターはIPとして扱いません。

## 8.7　統合版フィルターの作成と本番への切り替え

試作版には、ログを読み続ける `main()`（監視ループ）がありません。そこで、本番版の監視ループ（過去ログの読み飛ばし、ファイル交換・`copytruncate` への追従）をそのまま残し、IP対応の処理だけを組み込んだ統合版を作ります。

### 本番フィルターのバックアップ

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
BACKUP="/usr/local/sbin/postgresql-wazuh-filter.py.backup-before-ip-$(date +%Y%m%d-%H%M%S)"
cp -a /usr/local/sbin/postgresql-wazuh-filter.py "$BACKUP"
echo "===== BACKUP CREATED ====="
stat -c "%U:%G %a %n" "$BACKUP"
echo
echo "===== CURRENT PRODUCTION FILTER ====="
stat -c "%U:%G %a %s bytes %n" /usr/local/sbin/postgresql-wazuh-filter.py
'
```

### 統合版フィルター（最終版の全文）

LXC 109の中に、次の内容で `/tmp/postgresql-wazuh-filter-integrated.py` を作成します（160行、3,785バイト、SHA-256 `98481b5042866fde348a03b909a19faef54f3f24da661488481bd6c5b2bf9bf4`）。

> 長いファイルをターミナルに貼り付けると崩れることがあります。エディターで作成するか、ファイルを転送して配置してください。作成後、次の手順でSHA-256が上の値と一致することを必ず確認してください。

```python
#!/usr/bin/env python3

import ipaddress
import json
import os
import re
import time

SOURCE = "/var/log/postgresql/postgresql-17-main.log"
OUTPUT = "/var/log/postgresql-wazuh/events.log"

PREFIX = re.compile(
    r"^(?P<timestamp>\d{4}-\d{2}-\d{2} "
    r"\d{2}:\d{2}:\d{2}(?:\.\d+)?(?: [A-Z]{2,5})?)"
    r" \[(?P<pid>\d+)\]\s+"
    r"(?:\S+ )?"
    r"(?P<severity>PANIC|FATAL|ERROR|WARNING|LOG):"
)

HOST = re.compile(
    r"\bhost=(?:\"([^\"]+)\"|([^\s,]+))",
    re.IGNORECASE
)

AUTH_FAILURE = re.compile(
    r"\bpassword authentication failed\b",
    re.IGNORECASE
)

EVENTS = {
    "PANIC": "POSTGRESQL_PANIC",
    "FATAL": "POSTGRESQL_FATAL",
    "ERROR": "POSTGRESQL_ERROR",
    "WARNING": "POSTGRESQL_WARNING",
}

IP_TTL = 300
MAX_CONNECTIONS = 10000

connections = {}


def extract_ip(line):
    match = HOST.search(line)
    if not match:
        return None

    value = (match.group(1) or match.group(2) or "").strip()
    value = value.strip("[]")

    if "%" in value:
        value = value.split("%", 1)[0]

    try:
        return str(ipaddress.ip_address(value))
    except ValueError:
        return None


def classify(line, now=None):
    if now is None:
        now = time.monotonic()

    match = PREFIX.match(line)
    if not match:
        return None

    timestamp = match.group("timestamp")
    pid = match.group("pid")
    severity = match.group("severity")

    expired = [
        key for key, (_, created) in connections.items()
        if now - created > IP_TTL
    ]
    for key in expired:
        connections.pop(key, None)

    if severity == "LOG" and "connection received:" in line.lower():
        ip = extract_ip(line)

        connections.pop(pid, None)

        if ip:
            connections[pid] = (ip, now)

            while len(connections) > MAX_CONNECTIONS:
                oldest = next(iter(connections))
                connections.pop(oldest, None)

        return None

    if severity == "LOG" and "disconnection:" in line.lower():
        connections.pop(pid, None)
        return None

    if severity == "FATAL" and AUTH_FAILURE.search(line):
        event = {
            "timestamp": timestamp,
            "event": "POSTGRESQL_AUTH_FAILURE",
        }

        connection = connections.pop(pid, None)
        if connection:
            event["srcip"] = connection[0]

        return json.dumps(event, ensure_ascii=True) + "\n"

    if severity in EVENTS:
        event = {
            "timestamp": timestamp,
            "event": EVENTS[severity],
        }
        return json.dumps(event, ensure_ascii=True) + "\n"

    return None


def main():
    os.umask(0o027)

    with open(SOURCE, "r", encoding="utf-8", errors="replace") as source:
        source.seek(0, os.SEEK_END)

        with open(OUTPUT, "a", encoding="utf-8") as output:
            current_inode = os.stat(SOURCE).st_ino

            while True:
                line = source.readline()

                if line:
                    event = classify(line)
                    if event:
                        output.write(event)
                        output.flush()
                    continue

                time.sleep(1)

                try:
                    info = os.stat(SOURCE)
                except FileNotFoundError:
                    continue

                if info.st_ino != current_inode:
                    source.close()
                    source = open(
                        SOURCE, "r",
                        encoding="utf-8",
                        errors="replace"
                    )
                    source.seek(0, os.SEEK_END)
                    current_inode = info.st_ino

                elif info.st_size < source.tell():
                    source.seek(0)


if __name__ == "__main__":
    main()
```

### 所有者・権限の設定と構文の検証

```bash
pct exec 109 -- bash -c '
set -e

FILE=/tmp/postgresql-wazuh-filter-integrated.py

chown root:root "$FILE"
chmod 750 "$FILE"

python3 -m py_compile "$FILE"

echo "===== INTEGRATED FILTER ====="
stat -c "%U:%G %a %s bytes %n" "$FILE"
sha256sum "$FILE"

echo
echo "===== MAIN FUNCTION ====="
grep -nE "^def (classify|main)|^if __name__" "$FILE"

echo
echo "===== SYNTAX ====="
echo "PYTHON SYNTAX OK"
'
```

| 項目 | 期待値 |
|---|---|
| 所有者・権限・サイズ | `root:root 750 3785 bytes` |
| SHA-256 | `98481b5042866fde348a03b909a19faef54f3f24da661488481bd6c5b2bf9bf4` |
| 関数 | 60行目 `def classify`、119行目 `def main`、159行目 `if __name__` |

### 本番版との差分の確認

```bash
pct exec 109 -- bash -c '
diff -u \
  /usr/local/sbin/postgresql-wazuh-filter.py \
  /tmp/postgresql-wazuh-filter-integrated.py || true
'
```

既存の監視ループ（過去ログの読み飛ばし、inodeの変化の検知、`copytruncate` への追従、JSONの出力）が維持され、IP対応の処理だけが追加されていることを確認します。

### 機能テスト

```bash
pct exec 109 -- python3 - <<'PY'
import importlib.util
import json

path = "/tmp/postgresql-wazuh-filter-integrated.py"
spec = importlib.util.spec_from_file_location("pgfilter", path)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

def check(condition, message):
    if not condition:
        raise AssertionError(message)
    print("PASS:", message)

# IPv4
mod.connections.clear()
mod.classify(
    "2026-11-18 07:14:03.621 UTC [15614] [unknown]@[unknown] "
    "LOG:  connection received: host=192.168.0.211 port=54188",
    now=100
)
result = mod.classify(
    "2026-11-18 07:14:04.000 UTC [15614] FATAL: "
    "password authentication failed for user \"secret_user\" "
    "STATEMENT: SELECT 'secret_password';",
    now=101
)
event = json.loads(result)
check(event.get("srcip") == "192.168.0.211", "IPv4 PID correlation")
check(set(event) == {"timestamp", "event", "srcip"}, "No SQL or credentials in output")
check("secret" not in result, "Sensitive text excluded")

# IPv6
mod.connections.clear()
mod.classify(
    "2026-11-18 07:15:00 UTC [20001] [unknown]@[unknown] "
    "LOG:  connection received: host=2001:db8::10 port=54321",
    now=200
)
result = mod.classify(
    "2026-11-18 07:15:01 UTC [20001] FATAL: "
    "password authentication failed for user \"test\"",
    now=201
)
check(json.loads(result).get("srcip") == "2001:db8::10", "IPv6 PID correlation")

# Local connection
mod.connections.clear()
mod.classify(
    "2026-11-18 07:16:00 UTC [20002] [unknown]@[unknown] "
    "LOG:  connection received: host=[local]",
    now=300
)
check("20002" not in mod.connections, "Local socket is not treated as an IP")

# Missing IP
result = mod.classify(
    "2026-11-18 07:16:01 UTC [20002] FATAL: "
    "password authentication failed for user \"test\"",
    now=301
)
check("srcip" not in json.loads(result), "Missing IP does not create a false source")

# Normal warning
result = mod.classify(
    "2026-11-18 07:17:00 UTC [20003] postgres@postgres WARNING: "
    "synthetic warning with private details",
    now=400
)
event = json.loads(result)
check(event["event"] == "POSTGRESQL_WARNING", "WARNING event preserved")
check(set(event) == {"timestamp", "event"}, "WARNING details are sanitized")

print("ALL TESTS PASSED")
PY
```

8項目すべてに `PASS` が出て、`ALL TESTS PASSED` と表示されれば成功です。

### 境界条件のテスト

PIDの再利用、期限切れ、不正なIP、対応情報の上限（10,000件）を確認します。

```bash
pct exec 109 -- python3 - <<'PY'
import importlib.util
import json

path = "/tmp/postgresql-wazuh-filter-integrated.py"
spec = importlib.util.spec_from_file_location("pgfilter", path)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

def check(condition, message):
    if not condition:
        raise AssertionError("FAIL: " + message)
    print("PASS:", message)

def received(pid, host, now):
    return mod.classify(
        f"2026-11-18 07:14:03 UTC [{pid}] "
        f"[unknown]@[unknown] LOG: connection received: host={host} port=54321",
        now=now
    )

def auth_failure(pid, now):
    result = mod.classify(
        f"2026-11-18 07:14:04 UTC [{pid}] FATAL: "
        "password authentication failed for user test",
        now=now
    )
    return json.loads(result)

# PID reuse
mod.connections.clear()
received(30001, "192.0.2.10", 100)
received(30001, "192.0.2.20", 101)
event = auth_failure(30001, 102)
check(event.get("srcip") == "192.0.2.20", "PID reuse uses latest IP")

# TTL expiration
mod.connections.clear()
received(30002, "192.0.2.30", 100)
event = auth_failure(30002, 401)
check("srcip" not in event, "Expired IP is not attached")

# Invalid host
mod.connections.clear()
received(30003, "not-an-ip", 100)
check("30003" not in mod.connections, "Invalid IP is rejected")

# Maximum connection count
mod.connections.clear()
for i in range(mod.MAX_CONNECTIONS):
    mod.connections[str(i)] = ("192.0.2.1", 100)

received(40000, "192.0.2.40", 101)
check(len(mod.connections) == mod.MAX_CONNECTIONS, "Connection map stays within limit")
check("40000" in mod.connections, "Newest connection is retained")

print("ALL EDGE TESTS PASSED")
PY
```

`ALL EDGE TESTS PASSED` と表示されれば成功です。

### 本番サービスの状態の確認

```bash
pct exec 109 -- bash -c '
echo "===== SERVICE STATUS ====="
systemctl status postgresql-wazuh-filter.service --no-pager

echo
echo "===== SERVICE DEFINITION ====="
systemctl cat postgresql-wazuh-filter.service

echo
echo "===== OUTPUT FILE ====="
stat -c "%U:%G %a %s bytes %n" /var/log/postgresql-wazuh/events.log
'
```

systemdのサービス定義（セキュリティ制限、読み取り・書き込みパスの制限）は変更しません。

### 本番への配置準備

本番ファイルの横に候補ファイル（`.new`）を置きます。現行のサービスは動いたままです。

```bash
pct exec 109 -- bash -c '
set -e

PROD=/usr/local/sbin/postgresql-wazuh-filter.py
NEW=/usr/local/sbin/postgresql-wazuh-filter.py.new
BACKUP="${PROD}.backup-before-ip-deploy-$(date +%Y%m%d-%H%M%S)"

echo "===== CREATE BACKUP ====="
cp -a "$PROD" "$BACKUP"
stat -c "%U:%G %a %s %n" "$BACKUP"

echo
echo "===== STAGE INTEGRATED FILTER ====="
install -o root -g root -m 750 \
  /tmp/postgresql-wazuh-filter-integrated.py "$NEW"

python3 -m py_compile "$NEW"

echo
echo "===== VERIFY CHECKSUMS ====="
sha256sum /tmp/postgresql-wazuh-filter-integrated.py "$NEW"

echo
echo "===== VERIFY STAGED FILE ====="
stat -c "%U:%G %a %s %n" "$NEW"

echo
echo "===== SERVICE STILL RUNNING ====="
systemctl is-active postgresql-wazuh-filter.service
'
```

2つのファイルのSHA-256が一致することを確認します。表示されたバックアップのファイル名（`postgresql-wazuh-filter.py.backup-before-ip-deploy-日時`）は、次の手順で使うので控えておいてください。

### 本番への切り替え

本番ファイルを一度に置き換え（`mv`）、フィルターサービスだけを再起動します。再起動に失敗した場合は、自動でバックアップに戻します。

> **注意1：** 次のコマンドの `BACKUP=` には、構築時のバックアップのファイル名が書かれています。必ず、前の手順で表示された **ご自身の環境のファイル名** に置き換えてから実行してください。
>
> **注意2：** フィルターは起動時にログの末尾から読み始めるため、再起動中（数秒）に発生したPostgreSQLのイベントは転送されない場合があります。PostgreSQL本体・Wazuh Manager・Wazuh Agentは再起動しません。

```bash
pct exec 109 -- bash -c '
set -e

PROD=/usr/local/sbin/postgresql-wazuh-filter.py
NEW=/usr/local/sbin/postgresql-wazuh-filter.py.new
BACKUP=/usr/local/sbin/postgresql-wazuh-filter.py.backup-before-ip-deploy-20261118-162149

echo "===== FINAL CHECK ====="
test -f "$NEW"
test -f "$BACKUP"
python3 -m py_compile "$NEW"

echo
echo "===== ATOMIC DEPLOYMENT ====="
mv -f "$NEW" "$PROD"

echo
echo "===== RESTART FILTER SERVICE ====="
if ! systemctl restart postgresql-wazuh-filter.service; then
    echo "RESTART FAILED - ROLLING BACK"
    cp -a "$BACKUP" "$PROD"
    systemctl restart postgresql-wazuh-filter.service || true
    exit 1
fi

echo
echo "===== SERVICE STATUS ====="
systemctl is-active postgresql-wazuh-filter.service
systemctl status postgresql-wazuh-filter.service --no-pager -l

echo
echo "===== DEPLOYED FILE ====="
stat -c "%U:%G %a %s bytes %n" "$PROD"
sha256sum "$PROD"

echo
echo "===== RECENT SERVICE LOG ====="
journalctl -u postgresql-wazuh-filter.service -n 15 --no-pager

echo
echo "DEPLOYMENT CHECK COMPLETE"
'
```

`active (running)` になり、本番ファイルのSHA-256が統合版と同じで、最後に `DEPLOYMENT CHECK COMPLETE` と表示されれば切り替えは完了です。

```bash
pct exec 109 -- bash -c '
echo "===== FILTER SERVICE ====="
systemctl is-active postgresql-wazuh-filter.service

echo
echo "===== FILTER PROCESS ====="
ps -eo pid,etime,rss,args | grep "[p]ostgresql-wazuh-filter.py"

echo
echo "===== SANITIZED EVENTS ====="
tail -n 15 /var/log/postgresql-wazuh/events.log

echo
echo "===== OUTPUT PERMISSIONS ====="
stat -c "%U:%G %a %s bytes %n" /var/log/postgresql-wazuh/events.log
'
```

## 8.8　実際の認証失敗による確認

### 認証失敗を1回発生させる

既存のユーザー `agent` に対して、誤ったパスワードでローカルのTCP接続を試みます。データベースのデータは変更しません。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
set +e

echo "===== BEFORE ====="
date -u
wc -l /var/log/postgresql-wazuh/events.log

echo
echo "===== CONTROLLED AUTH FAILURE ====="
PGPASSWORD="Wazuh-Invalid-Test-Only-2026" \
psql -h 127.0.0.1 -p 5432 -U agent -d agent_memory \
  -c "SELECT 1;" 2>&1

echo
echo "===== RECENT POSTGRESQL LOG ====="
tail -n 12 /var/log/postgresql/postgresql-17-main.log

echo
echo "===== RECENT SANITIZED EVENTS ====="
sleep 2
tail -n 8 /var/log/postgresql-wazuh/events.log
'
```

ユーザー名・データベース名は、ご自身の環境に存在するものに置き換えてください。出力ファイルに、次のように `srcip` 付きのイベントが記録されれば成功です。

```text
{"timestamp": "2026-11-18 07:27:22.703 UTC", "event": "POSTGRESQL_AUTH_FAILURE", "srcip": "127.0.0.1"}
{"timestamp": "2026-11-18 07:27:22.716 UTC", "event": "POSTGRESQL_AUTH_FAILURE", "srcip": "127.0.0.1"}
```

> **1回の試行で2件記録される理由：** 構築時は、`psql` を1回実行するごとに認証失敗が2件記録されました。いずれも同じ送信元IPが付いており、SQL文・ユーザー名・パスワードは含まれていません。

### Managerへの到達の確認

```bash
qm guest exec 220 -- bash -c '
python3 -c "
import json
from pathlib import Path

p = Path(\"/var/ossec/logs/alerts/alerts.json\")
if not p.exists():
    raise SystemExit(\"FAIL: alerts.json not found\")

count = 0
with p.open() as f:
    for line in f:
        try:
            e = json.loads(line)
        except Exception:
            continue

        rule = e.get(\"rule\", {})
        data = e.get(\"data\", {})

        if rule.get(\"id\") in (\"100101\", \"100106\") and data.get(\"event\") == \"POSTGRESQL_AUTH_FAILURE\":
            print(json.dumps({
                \"timestamp\": e.get(\"timestamp\"),
                \"rule_id\": rule.get(\"id\"),
                \"level\": rule.get(\"level\"),
                \"srcip\": data.get(\"srcip\"),
                \"agent\": e.get(\"agent\", {}).get(\"name\")
            }, ensure_ascii=False))
            count += 1

print(\"MATCH_COUNT:\", count)
"
'
```

今回の認証失敗が `"rule_id": "100101"`・`"srcip": "127.0.0.1"`・`"agent": "postgresql"` として記録されていれば、Managerまで届いています。

## 8.9　Managerへのルールの反映

8.4でルールファイルを変更しましたが、Managerを再起動するまで、稼働中のプロセスは古いルールのままです。`wazuh-logtest` はその時点のファイルを読むため、テストでは新しいルールが使われる点に注意してください。

> `wazuh-control reload` は、ルールだけを読み直す機能ではありません。内部でManagerのサービス群を停止・再起動します。ここではsystemdでManagerを再起動します。

### 再起動前のバックアップ

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
echo "===== RULE BACKUPS ====="
ls -lht /var/ossec/etc/rules/local_rules.xml.backup* 2>/dev/null | head -n 10

echo
echo "===== CURRENT RULE FILE ====="
stat -c "%U:%G %a %s bytes %y %n" \
  /var/ossec/etc/rules/local_rules.xml
'
```

```bash
qm guest exec 220 -- bash -c '
set -e

BACKUP="/var/ossec/etc/rules/local_rules.xml.backup-pre-reload-$(date +%Y%m%d-%H%M%S)"

cp -a /var/ossec/etc/rules/local_rules.xml "$BACKUP"

echo "===== BACKUP CREATED ====="
stat -c "%U:%G %a %s bytes %n" "$BACKUP"

echo
echo "===== CHECKSUM ====="
sha256sum \
  /var/ossec/etc/rules/local_rules.xml \
  "$BACKUP"
'
```

元のファイルとバックアップのSHA-256が一致することを確認します。

### Managerの再起動

再起動中は、Agentからのイベントの受信・分析・アラートの生成が一時的に止まります。

```bash
qm guest exec 220 -- bash -c '
set -e

echo "===== RESTART WAZUH MANAGER ====="
systemctl restart wazuh-manager

echo
echo "===== SERVICE STATUS ====="
systemctl is-active wazuh-manager

echo
echo "===== ANALYSISD PROCESS ====="
pgrep -a wazuh-analysisd
'
```

`active` と、新しい `wazuh-analysisd` のプロセスが表示されれば成功です。

```bash
qm guest exec 220 -- bash -c '
echo "===== WAZUH AGENT STATUS ====="
/var/ossec/bin/agent_control -lc

echo
echo "===== MANAGER RECENT ERRORS ====="
journalctl -u wazuh-manager --since "5 minutes ago" --no-pager \
  | grep -Ei "error|critical|failed" \
  | tail -n 30 || true
'
```

Agent 001〜004がすべて `Active` で、直近5分間に `error`・`critical`・`failed` がなければ正常です。

## 8.10　送信元IPの相関の最終確認

同じ送信元IPから認証失敗を5回発生させます。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
for i in 1 2 3 4 5; do
    echo "===== FINAL AUTH FAILURE TEST $i ====="
    PGPASSWORD="Wazuh-Invalid-Test-Only-2026" \
    psql -h 127.0.0.1 -p 5432 -U agent -d agent_memory \
      -c "SELECT 1;" >/dev/null 2>&1 || true
    sleep 1
done

echo "===== TEST COMPLETED ====="
'
```

Managerで相関アラートを確認します。

```bash
qm guest exec 220 -- bash -c '
python3 - <<'"'"'PY'"'"'
import json
from pathlib import Path

path = Path("/var/ossec/logs/alerts/alerts.json")
matches = []

with path.open() as f:
    for line in f:
        try:
            e = json.loads(line)
        except json.JSONDecodeError:
            continue

        rule = e.get("rule", {})
        data = e.get("data", {})

        if rule.get("id") == "100106" and data.get("event") == "POSTGRESQL_AUTH_FAILURE":
            matches.append({
                "timestamp": e.get("timestamp"),
                "rule_id": rule.get("id"),
                "level": rule.get("level"),
                "srcip": data.get("srcip"),
                "agent": e.get("agent", {}).get("name"),
                "description": rule.get("description")
            })

print("===== LATEST CORRELATION ALERTS =====")
for item in matches[-5:]:
    print(json.dumps(item, ensure_ascii=False))

print("TOTAL_CORRELATION_ALERTS:", len(matches))
PY
'
```

次のように、説明文が「same source IP」の `100106` が記録されていれば完成です。

```json
{
  "timestamp": "2026-11-18T07:39:03.945+0000",
  "rule_id": "100106",
  "level": 12,
  "srcip": "127.0.0.1",
  "agent": "postgresql",
  "description": "PostgreSQL: 5 authentication failures from the same source IP within 60 seconds."
}
```

> 結果として表示されたJSONは、確認用の出力です。シェルに貼り付けて実行するものではありません。

## 第2部の完了状態

PostgreSQLの監視は、次の構成で完成しました。

| 段階 | 処理 |
|---|---|
| PostgreSQL 17（LXC 109） | 認証失敗と、接続受付（PID・接続元IP）を記録 |
| サニタイズフィルター | PIDと接続元IPを対応付け、SQL文・ユーザー名・パスワードなどを取り除いてJSON化 |
| Wazuh Agent（ID 004） | JSONイベントをManagerへ転送 |
| Wazuh Manager（VM 220） | 単発の検知と、送信元IPごとの相関検知 |

| ルールID | レベル | 検知内容 |
|---|---:|---|
| 100101 | 8 | PostgreSQLの認証失敗（単発） |
| 100102 | 10 | その他のFATAL |
| 100103 | 7 | ERROR |
| 100104 | 4 | WARNING |
| 100105 | 12 | PANIC |
| 100106 | 12 | 同じ送信元IPから60秒間に5回以上の認証失敗（MITRE T1110） |

自動遮断はまだ有効にしていません。第3部では、Wazuhが出したアラートをPostgreSQLに保存し、インシデントとして管理するCollectorを構築します。
