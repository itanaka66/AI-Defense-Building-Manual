import re,hashlib,json,sys
s=open(sys.argv[1],encoding='utf-8').read()
bl=re.findall(r'```(\w*)\n(.*?)\n```',s,re.S)
print(len(bl), json.dumps([[hashlib.sha256(b.encode()).hexdigest()[:16],len(b.split('\n'))] for _,b in bl],separators=(',',':')))
