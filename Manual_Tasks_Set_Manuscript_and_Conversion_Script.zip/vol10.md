---
title: "AI自律型サイバー防御システム 構築マニュアル 前編"
subtitle: "第10部　ディスク障害の対処とAI Defense Managerの準備"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」前編の第10部です。第9部の点検の中で、Wazuhのルール5138（`General SATA disk failure`）が Proxmoxホストから出ていることが分かりました。第10部の前半では、その原因を調べ、故障したバックアップ用のHDDを安全に切り離して取り外し、Proxmoxの設定を整理するまでを扱います。後半では、構築を再開し、AIによる分析と判断を受け持つ新しいVM「AI Defense Manager」（VM 230）を作って、初期の設定と確認を行います。

防御システムが、自分を動かしている基盤の故障を見つけた事例です。

## 本書の表記

- コマンドは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 各手順の冒頭に「実行先」を示します。
- ディスクの型番・シリアル番号・容量などは構築時のものです。お使いの環境では異なります。デバイス名（`/dev/sdg`）やSATAのポート（`ata11`）は、自分の環境で確認したものに置き換えてください。

## 結論（先に）

| 項目 | 内容 |
|---|---|
| 故障したもの | バックアップ用のHDD（Hitachi HDS722020ALA330、2TB、`/dev/sdg`、Proxmoxのストレージ `backup`） |
| 症状 | 容量が0バイトとして認識され、読み込みが `I/O error` になる。SATAの通信エラー（`BadCRC` など）がくり返し、リンクの速度が1.5Gbpsに落ちる |
| 対処 | 書き込みを止めて読み取り専用にし、アンマウントし、ホストを止めてHDDを取り外し、ストレージの定義を削除 |
| データ | 読み出せなかったため、HDDの中のバックアップは破棄した |

# 第1章　Wazuhが検知したディスクの異常

## 1.1　ルール5138のメッセージ

Wazuhが記録したカーネルのメッセージを、同じものをまとめて表示します。シリアル番号のような長い英数字は伏せます。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import json
from pathlib import Path
from collections import Counter

p = Path("/var/ossec/logs/alerts/2026/Nov/ossec-alerts-20.json")
messages = Counter()
first = {}
last = {}

with p.open() as f:
    for line in f:
        try:
            e = json.loads(line)
        except json.JSONDecodeError:
            continue

        if str((e.get("rule") or {}).get("id")) != "5138":
            continue

        ts = e.get("timestamp", "")
        msg = e.get("full_log") or ""

        # シリアル番号らしき長い英数字列を伏せる
        import re
        msg = re.sub(r'\b[A-Fa-f0-9]{12,}\b', '[REDACTED_ID]', msg)

        messages[msg] += 1
        first[msg] = min(first.get(msg, ts), ts)
        last[msg] = max(last.get(msg, ts), ts)

print("=== UNIQUE KERNEL MESSAGES ===")
for msg, count in messages.most_common():
    print(f"count={count} first={first[msg]} last={last[msg]}")
    print(msg[:1000])
    print("---")
PY
```

構築時は、`READ FPDMA QUEUED`・`WRITE FPDMA QUEUED` の失敗など、SATAのディスクの読み書きのエラーでした。誤検知として扱わず、Proxmoxホストで確かめます。

## 1.2　Proxmoxホストのカーネルのログ

**実行先：Proxmoxホスト pve（root）**

```bash
echo "=== JOURNAL BOOTS ==="
journalctl --list-boots --no-pager

echo
echo "=== RETAINED SATA ERROR LOGS ==="
journalctl -k --no-pager \
  | grep -Ei 'ata7|ata11|I/O error|blk_update|Buffer I/O|reset|failed command|exception|SError|Emask|EH complete' \
  | tail -n 100
```

```bash
echo "=== BLOCK DEVICE INVENTORY ==="
lsblk -o NAME,MAJ:MIN,SIZE,TYPE,FSTYPE,MOUNTPOINTS,MODEL,TRAN,RO

echo
echo "=== SDG DEVICE LINKS ==="
find -L /dev/disk/by-id -maxdepth 1 -type b -samefile /dev/sdg -printf '%p\n' 2>/dev/null

echo
echo "=== SDG SYSFS DETAILS ==="
for f in vendor model rev state; do
  p="/sys/block/sdg/device/$f"
  [ -r "$p" ] && printf '%s=' "$f" && cat "$p"
done
```

構築時は、`/dev/sdg` で実際のI/Oエラーが起きていました。

# 第2章　ディスクの状態の診断

## 2.1　SMART

**実行先：Proxmoxホスト pve（root）**

```bash
smartctl -x /dev/sdg
```

構築時は、次のように表示されてSMARTの情報を取れませんでした。

```text
Short INQUIRY response, skip product id
A mandatory SMART command failed
```

確認の条件をゆるめ、ATAとしても問い合わせます。

```bash
smartctl -x -T permissive /dev/sdg
```

```bash
smartctl -x -d sat -T permissive /dev/sdg
```

```text
Read Device Identity failed: empty IDENTIFY data
Device Model: [No Information Found]
```

OSから見て、ディスクが自分の情報を返せない状態でした。

## 2.2　容量の不一致

**実行先：Proxmoxホスト pve（root）**

```bash
journalctl -k -b --no-pager | grep -Ei 'sdg|ata[0-9]+.*(error|failed|reset|exception|link)'
```

```text
[sdg] access beyond end of device
I/O error, dev sdg, sector 2048
```

```bash
echo "=== BACKUP MOUNT ==="
findmnt -T /mnt/pve/backup -o SOURCE,TARGET,FSTYPE,OPTIONS

echo
echo "=== DEVICE CAPACITY ==="
printf 'sdg sectors: '
cat /sys/block/sdg/size
printf 'sdg1 sectors: '
cat /sys/block/sdg/sdg1/size
printf 'sdg bytes: '
blockdev --getsize64 /dev/sdg
printf 'sdg1 bytes: '
blockdev --getsize64 /dev/sdg1

echo
echo "=== DEVICE TREE ==="
lsblk -o NAME,MAJ:MIN,SIZE,TYPE,FSTYPE,MOUNTPOINTS /dev/sdg
```

構築時は、`/dev/sdg` が0バイト（0セクター）として扱われていて、その上のパーティション（`/dev/sdg1`、約2TB）が `/mnt/pve/backup` にマウントされたままでした。ディスク全体の容量が0のため、パーティションの先頭（セクター2048）を読むだけで「デバイスの末尾を超えた」というエラーになります。

## 2.3　接続の経路

**実行先：Proxmoxホスト pve（root）**

```bash
echo "=== SCSI DEVICE PATH ==="
readlink -f /sys/block/sdg/device

echo
echo "=== UDEV DEVICE ATTRIBUTES ==="
udevadm info --query=property --name=/dev/sdg \
  | grep -E '^(DEVNAME|DEVPATH|ID_BUS|ID_MODEL|ID_SERIAL|ID_VENDOR|ID_WWN|ID_PATH|ID_TYPE)='

echo
echo "=== SCSI HOST INFORMATION ==="
for f in /sys/class/scsi_host/host10/proc_name \
         /sys/class/scsi_host/host10/unique_id; do
  if [ -r "$f" ]; then
    printf '%s=' "$f"
    cat "$f"
  fi
done
```

```bash
echo "=== ATA11 SYSFS ==="
for f in /sys/class/ata_link/link*/device; do
  [ "$(readlink -f "$f")" = "$(readlink -f /sys/class/ata_port/ata11)" ] && echo "$f"
done

echo
echo "=== ATA11 LINK ATTRIBUTES ==="
find /sys/class/ata_port/ata11 -maxdepth 3 -type f \
  \( -name 'sata_spd' -o -name 'sata_spd_limit' -o -name 'hw_sata_spd_limit' -o -name 'enabled' \) \
  -print -exec cat {} \; 2>/dev/null

echo
echo "=== ATA11 KERNEL LOG ==="
journalctl -k -b --no-pager | grep -Ei 'ata11|52:00.2|sdg' | tail -80
```

構築時は、マザーボード（Supermicro H12SSL-i）のAMD FCHのSATAコントローラの `ata11`（SCSIのホスト10）に、Hitachi HDS722020ALA330（約2TB）がつながっていました。

# 第3章　バックアップの領域の保全

## 3.1　Proxmoxでの使われ方

**実行先：Proxmoxホスト pve（root）**

```bash
fuser -vm /mnt/pve/backup
```

使っているのはカーネルのマウントだけで、ユーザーのプロセスはありませんでした。

```bash
echo "=== PVE STORAGE CONFIGURATION ==="
grep -n -B 3 -A 8 -E 'backup|/mnt/pve/backup' /etc/pve/storage.cfg

echo
echo "=== BACKUP DIRECTORY METADATA ==="
stat /mnt/pve/backup
```

```bash
pvesm status --storage backup
```

`backup` は、Proxmoxに登録されたディレクトリ形式のストレージ（`dir: backup`、`path /mnt/pve/backup`）で、状態は `active`、容量は約1.92TBでした。

## 3.2　ファイルシステムの状態

**実行先：Proxmoxホスト pve（root）**

```bash
journalctl -k -b --no-pager | grep -Ei 'EXT4-fs.*(error|warning|abort)|sdg'
```

```bash
echo "=== DIRECTORY ENTRIES ==="
ls -la /mnt/pve/backup

echo
echo "=== MOUNT SUPERBLOCK ==="
findmnt -T /mnt/pve/backup -o SOURCE,FSTYPE,OPTIONS,FSROOT
```

構築時は、ディレクトリの中身を読むだけで次のエラーになりました。

```text
ls: cannot access '/mnt/pve/backup/lost+found': Input/output error

d????????? ? ? ? ? lost+found
```

```bash
echo "=== EXT4 MOUNT STATUS ==="
grep -F '/mnt/pve/backup' /proc/mounts

echo
echo "=== EXT4 SUPERBLOCK PARAMETERS ==="
tune2fs -l /dev/sdg1 2>&1 \
  | grep -Ei 'Filesystem state|Errors behavior|Filesystem features|Block count|Block size|Last checked'
```

## 3.3　読み取り専用への切り替え

これ以上書き込まないよう、読み取り専用（`ro`）でマウントし直します。修復（`fsck`）や削除は行いません。

**実行先：Proxmoxホスト pve（root）**

```bash
mount -o remount,ro /mnt/pve/backup && \
findmnt -T /mnt/pve/backup -o SOURCE,TARGET,FSTYPE,OPTIONS
```

```text
/dev/sdg1 /mnt/pve/backup ext4 ro,relatime
```

```bash
echo "=== BLOCK DEVICES ==="
lsblk -e 7 -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS,MODEL,RO

echo
echo "=== FILESYSTEM CAPACITY ==="
df -hT
```

## 3.4　救出先の準備（TrueNASのディスクの切り離し）

ホストには、2TBを受け取れる空きのあるファイルシステムがありませんでした。救出先として、TrueNAS（VM 100）のデータ用の仮想ディスク RAID_A（約2.17TB）を使う方針にしました。

**実行先：Proxmoxホスト pve（root）**

```bash
qm config 100
```

```bash
qm status 100
```

TrueNASを正常に停止します。

```bash
qm shutdown 100 --timeout 120
```

```bash
qm status 100
```

`status: stopped` を確認します。RAID_A・RAID_Bの中身を確認します。

```bash
pvesm list RAID_A --vmid 100
```

```bash
pvesm list RAID_B --vmid 100
```

RAID_A（`scsi1`）をVM 100から切り離します。仮想ディスク自体は削除されず、`unused0` として残ります。

```bash
qm set 100 --delete scsi1
```

```bash
qm config 100
```

```bash
pvesm path RAID_A:vm-100-disk-0
```

構築時の実体は `/dev/RAID_A/vm-100-disk-0` でした。

> 救出はこの後、元のディスクが読み出せないことが分かったため行っていません（第4章）。RAID_A は VM 100 から切り離したまま（`unused0`）です。TrueNAS（VM 100）の扱いは別途検討することにし、RAID_A・RAID_B は今後ほかの用途に自由に使ってよいことにしました（後の部で使います）。

# 第4章　原因の切り分け

## 4.1　救出の対象の大きさ

**実行先：Proxmoxホスト pve（root）**

```bash
echo "=== TARGET DEVICE SIZE ==="
blockdev --getsize64 /dev/RAID_A/vm-100-disk-0

echo
echo "=== TARGET LOGICAL VOLUME ==="
lvs -a -o lv_name,vg_name,lv_size,lv_attr,pool_lv,data_percent,metadata_percent RAID_A
```

```bash
echo "=== BACKUP DIRECTORY SIZES ==="
du -x -h -d 2 /mnt/pve/backup 2>&1

echo
echo "=== FILESYSTEM USAGE ==="
df -hT /mnt/pve/backup
```

```bash
ls -lah /mnt/pve/backup/dump
```

`df` では使用量は約123GBでしたが、`du` も `dump` ディレクトリの一覧も `Input/output error` になり、ファイルとして読み出すことはできませんでした。ケーブルの抜き差しはせず、ソフトウェアの側から状態を調べます。

## 4.2　デバイスとリンクの状態

**実行先：Proxmoxホスト pve（root）**

```bash
echo "=== SDG DEVICE STATE ==="
for f in size ro device/state device/model device/rev; do
  p="/sys/block/sdg/$f"
  if [ -r "$p" ]; then
    printf '%s=' "$f"
    cat "$p"
  fi
done

echo
echo "=== SATA LINK STATE ==="
for f in /sys/class/ata_link/link*/{sata_spd,sata_spd_limit}; do
  [ -r "$f" ] && printf '%s=' "$f" && cat "$f"
done
```

```bash
journalctl -k -b --no-pager | grep -Ei 'ata11|sdg|hard resetting link|SATA link down|failed command|IDENTIFY' | tail -n 100
```

## 4.3　アンマウント

これ以上ファイルシステムからディスクにアクセスしないよう、アンマウントします。

**実行先：Proxmoxホスト pve（root）**

```bash
umount /mnt/pve/backup
```

## 4.4　起動からのリンクの記録

**実行先：Proxmoxホスト pve（root）**

```bash
journalctl -k -b --no-pager | grep -Ei 'ata11|scsi 10:|sdg:|sd 10:0:0:0' | head -n 80
```

起動したときは、正しく認識されていました。

```text
ata11: SATA link up 3.0 Gbps
ata11.00: ATA-8: Hitachi HDS722020ALA330
ata11.00: 3907029168 sectors
```

その後、通信のエラーがくり返されていました。

```text
interface fatal error
SError: { UnrecovData CommWake 10B8B BadCRC }
failed command: READ FPDMA QUEUED
hard resetting link
```

`BadCRC`・`10B8B` は、SATAの通信の途中でデータが壊れたことを表します。

```bash
echo "=== SCSI HOST 10 DEVICES ==="
ls -la /sys/class/scsi_host/host10/device/

echo
echo "=== CURRENT SDG DEVICE ==="
ls -la /sys/block/sdg/device/
```

## 4.5　容量の再読み込み

容量を読み直させて、戻るかどうかを試します。

**実行先：Proxmoxホスト pve（root）**

```bash
echo 1 > /sys/block/sdg/device/rescan
```

```bash
echo "=== DEVICE CAPACITY ==="
blockdev --getsize64 /dev/sdg

echo
echo "=== KERNEL SECTOR COUNT ==="
cat /sys/block/sdg/size

echo
echo "=== PARTITION CAPACITY ==="
blockdev --getsize64 /dev/sdg1 2>&1
```

構築時は、0バイトのままでした。

```bash
journalctl -k --since "2026-11-20 15:20:00" --no-pager | grep -Ei 'ata11|sdg|I/O error|reset|failed command|hard resetting|BadCRC|CommWake' | tail -80
```

```text
Read Capacity(16) failed
```

## 4.6　SATAのリンクの速度とポート

**実行先：Proxmoxホスト pve（root）**

```bash
echo "=== ATA LINK 11 ERROR COUNTERS ==="
for f in /sys/class/ata_link/link11/{hw_sata_spd_limit,sata_spd,sata_spd_limit}; do
  if [ -r "$f" ]; then
    printf '%s: ' "$f"
    cat "$f"
  fi
done

echo
echo "=== ATA PORT ERROR HISTORY ==="
journalctl -k --no-pager | grep -E 'ata11.*(SError|BadCRC|CommWake|hard resetting|SATA link up)' | tail -30
```

起動したときは3.0Gbpsだったリンクが、1.5Gbpsに下がっていました。

```bash
echo "=== SCSI DEVICE STATE ==="
cat /sys/block/sdg/device/state

echo
echo "=== DEVICE INQUIRY ==="
cat /sys/block/sdg/device/inquiry | od -An -tx1

echo
echo "=== DEVICE IDENTITY ==="
for f in vendor model rev; do
  printf '%s: ' "$f"
  cat "/sys/block/sdg/device/$f"
done
```

SCSIとしての識別の情報は取れますが、容量の取得には失敗する状態でした。

```bash
lspci -nnk -s 52:00.2
```

```bash
echo "=== ATA PORT NUMBER ==="
cat /sys/class/ata_port/ata11/port_no

echo
echo "=== PMP LINKS ==="
cat /sys/class/ata_port/ata11/nr_pmp_links

echo
echo "=== ATA LINK DIRECTORY ==="
ls -la /sys/class/ata_link/link11/
```

ほかのポートの速度と比べます。

```bash
for n in 11 12 13 14 15 16 17 18; do
  printf 'ata%s: ' "$n"
  if [ -r "/sys/class/ata_link/link$n/sata_spd" ]; then
    cat "/sys/class/ata_link/link$n/sata_spd"
  else
    echo "no link"
  fi
done
```

構築時は、AMD FCHのSATAコントローラに `ata11`〜`ata18` の8ポートがあり、1.5Gbpsに下がっていたのは `ata11`（このHDD）だけでした。

## 4.7　判断

容量が0のまま戻らず、SATAの通信のエラーがくり返し、リンクの速度も落ちていました。HDDの中のバックアップを読み出すことはできないと判断し、**HDDと、その中のバックアップの両方を破棄する**ことにしました。

> HDDの中のデータはソフトウェアで消去できない状態です。情報の漏えいを防ぐため、取り外したHDDは、プラッタを物理的に壊すか、物理破壊に対応した専門の業者に処分を依頼してください。

# 第5章　HDDの取り外しとストレージの整理

## 5.1　取り外し

SATAにつながったまま抜かず、稼働中のVM・コンテナを止めてから、Proxmoxホストを正常に停止して取り外します。取り外した後、ホストを起動します。

## 5.2　取り外し後の確認

**実行先：Proxmoxホスト pve（root）**

```bash
echo "=== REMOVED HDD DEVICE CHECK ==="
if [ -e /sys/block/sdg ]; then
  echo "WARNING: sdg still exists"
else
  echo "OK: sdg is no longer detected"
fi

echo
echo "=== BACKUP MOUNT CHECK ==="
if findmnt /mnt/pve/backup; then
  echo "WARNING: backup is still mounted"
else
  echo "OK: backup is not mounted"
fi
```

起動し直した後は、デバイス名が付け直されることがあります（構築時は、別のディスクが `sdg` になりました）。型番とシリアル番号で、故障したHDDがないことを確かめます。

```bash
lsblk -d -o NAME,SIZE,MODEL,SERIAL,WWN,TRAN
```

構築時は、Hitachi製の2TBのHDDが一覧にないことを確認しました。

## 5.3　ストレージの定義の削除

**実行先：Proxmoxホスト pve（root）**

```bash
cat /etc/pve/storage.cfg
```

取り外したHDDの `backup` の定義が残っています。

```text
dir: backup
        path /mnt/pve/backup
        content snippets,images,iso,backup,vztmpl,rootdir
        is_mountpoint 1
        nodes pve
```

```bash
pvesm status
```

`backup` のストレージの定義だけを削除します。ほかのディスク・ファイル・ストレージの設定には触れません。

```bash
pvesm remove backup
```

```bash
pvesm status
```

`backup` が一覧からなくなり、ほかのストレージが `active` のままであることを確認します。

# 第6章　AI Defense Manager（VM 230）の作成

AIによる分析・判断・対処を受け持つ部分は、既存のVMに入れず、独立した新しいVMとして作ります。

## 6.1　置き場所と空きの確認

**実行先：Proxmoxホスト pve（root）**

```bash
lvs -a -o vg_name,lv_name,lv_size,data_percent,metadata_percent
```

```bash
pvs -o pv_name,vg_name,pv_size,pv_free
```

`local-lvm`（ボリュームグループ `pve`）は NVMe SSD（`/dev/nvme0n1p3`）の上にあります。構築時のThin Poolは約794GiBで、使用率は60.86%でした。

```bash
qm config 230
```

VMID 230 が使われていないこと（設定が存在しないこと）を確認します。

```bash
pvesm list local --content iso
```

```bash
free -h
```

構築時は、`ubuntu-24.04.5-live-server-amd64.iso` があり、ホストのメモリは約283GiBのうち約124GiBが空いていました。

## 6.2　VMの作成と起動

| 項目 | 設定 |
|---|---|
| VMID / 名前 | 230 / `ai-defense-manager` |
| CPU / メモリ | 4コア（`host`） / 8GB |
| ディスク | `local-lvm` に100GB（`discard=on`、`iothread=1`） |
| ネットワーク | `vmbr0`（virtio） |
| QEMU Guest Agent | 有効 |

**実行先：Proxmoxホスト pve（root）**

```bash
qm create 230 --name ai-defense-manager --ostype l26 --memory 8192 --cores 4 --cpu host --machine q35 --scsihw virtio-scsi-single --scsi0 local-lvm:100,discard=on,iothread=1 --ide2 local:iso/ubuntu-24.04.5-live-server-amd64.iso,media=cdrom --boot 'order=scsi0;ide2' --net0 virtio,bridge=vmbr0 --agent enabled=1
```

Thin Poolの空きが足りなくなったときの保護が無効だという警告が出ますが、作成はされます。

```text
You have not turned on protection against thin pools running out of space.
```

```bash
qm config 230
```

```bash
qm start 230
```

```bash
qm status 230
```

## 6.3　Ubuntu Serverのインストール

Proxmox の Web画面で VM 230 の「コンソール」を開き、`Try or Install Ubuntu Server` を選んで、次の設定でインストールします。

| 項目 | 設定 |
|---|---|
| 言語 | English |
| キーボード | Japanese |
| ネットワーク | DHCP |
| Proxy | 空欄 |
| Mirror | デフォルト |
| ストレージ | Use an entire disk（100GBの仮想ディスクだけを対象にする）、LVM 有効 |
| ユーザー名 | `aidefense` |
| ホスト名 | `ai-defense-manager` |
| OpenSSH Server | インストールする |
| Featured snaps | 何も選ばない |

ストレージの画面では、100GBの仮想ディスク以外（ホストのディスクや RAID_A・RAID_B）を選ばないよう注意します。

# 第7章　ネットワークと周辺のサーバーへの到達

## 7.1　アドレスと経路

**実行先：VM 230 ai-defense-manager（root）**

```bash
ip -br addr
```

```bash
ip route
```

構築時は、DHCPで `192.168.0.33/24` が割り当てられ、デフォルトゲートウェイは `192.168.0.1` でした。

## 7.2　security-core と Ollama への到達

**実行先：VM 230 ai-defense-manager（root）**

```bash
ping -c 3 192.168.0.220
```

```bash
ping -c 3 192.168.0.180
```

既存のOllama（GPUサーバー、`192.168.0.180`）のAPIに接続し、使えるモデルの一覧を取得します。

```bash
curl -sS --max-time 5 http://192.168.0.180:11434/api/tags
```

# 第8章　OSの更新と初期の確認

## 8.1　パッケージの更新

**実行先：VM 230 ai-defense-manager（root）**

```bash
cat /etc/os-release
```

```bash
apt list --upgradable
```

まず、何が変わるかを試すだけの実行（シミュレーション）で確かめます。

```bash
apt-get -s upgrade
```

構築時は、更新29件・新規インストール0件・削除0件で、systemd 関連の11件は保留（対象外）でした。

```bash
apt-get upgrade
```

```bash
if [ -f /var/run/reboot-required ]; then cat /var/run/reboot-required; else echo "REBOOT_NOT_REQUIRED"; fi
```

構築時は `REBOOT_NOT_REQUIRED` で、再起動は不要でした。

## 8.2　SSHの状態

**実行先：VM 230 ai-defense-manager（root）**

```bash
systemctl status ssh --no-pager
```

```bash
sshd -T | grep -E '^(permitrootlogin|passwordauthentication|pubkeyauthentication|kbdinteractiveauthentication|permitemptyPasswords|allowtcpforwarding|maxauthtries)'
```

```bash
if [ -s /root/.ssh/authorized_keys ]; then echo "AUTHORIZED_KEYS_PRESENT"; wc -l < /root/.ssh/authorized_keys; else echo "NO_ROOT_AUTHORIZED_KEYS"; fi
```

```bash
who
```

```bash
if [ -s /home/aidefense/.ssh/authorized_keys ]; then echo "AUTHORIZED_KEYS_PRESENT"; wc -l < /home/aidefense/.ssh/authorized_keys; else echo "NO_USER_AUTHORIZED_KEYS"; fi
```

構築時は、Windows PC（`192.168.0.251`）から `aidefense` でパスワード認証によりSSH接続していて、root・`aidefense` のどちらにも公開鍵は登録されていませんでした。今の接続を保つため、公開鍵認証への切り替えなどSSHの設定は変更していません。

## 8.3　資源の確認

**実行先：VM 230 ai-defense-manager（root）**

```bash
df -h /
```

```bash
free -h
```

```bash
lscpu
```

```bash
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS
```

```bash
vgs
```

構築時は、ルートの割り当てが48GBで、ボリュームグループ `ubuntu-vg`（約98GB）には空きが残っていました（インストーラーの既定の動きです）。メモリは7.8GiB、CPUは AMD EPYC の4コアでした。

## 8.4　ネットワーク・時刻・ホスト名

**実行先：VM 230 ai-defense-manager（root）**

```bash
networkctl status enp6s18 --no-pager
```

```bash
netplan get
```

構築時の設定は、シンプルなDHCPでした（変更不要）。

```bash
timedatectl status
```

```bash
hostnamectl
```

## 8.5　WazuhのAPIとOllamaのAPIへの到達

**実行先：VM 230 ai-defense-manager（root）**

```bash
nc -zv -w 3 192.168.0.220 55000
```

```bash
nc -zv -w 3 192.168.0.180 11434
```

どちらも `succeeded` と表示されれば到達できます。

## 8.6　Python

**実行先：VM 230 ai-defense-manager（root）**

```bash
python3 --version
```

```bash
python3 -m pip --version
```

構築時は Python 3.12.3 でした。

# 第10部のまとめ

## 行ったこと

| 順番 | 内容 |
|---|---|
| 1 | Wazuhのルール5138から、Proxmoxホストのバックアップ用HDDの異常を見つけた |
| 2 | SMART・容量・SATAのリンクを調べ、HDDの故障（容量0、通信エラー、速度の低下）と判断した |
| 3 | 読み取り専用にしてからアンマウントし、書き込みを止めた |
| 4 | ホストを止めてHDDを取り外し、Proxmoxの `backup` の定義を削除した |
| 5 | AI Defense Manager（VM 230、`192.168.0.33`）を作り、Ubuntu Server 24.04.5 を入れて、更新・確認を行った |

## 残った課題

- HDDの中にあったバックアップは失われました。代わりの保存先は、本書とは別に用意します（なくても運用上の問題はない判断です）。
- TrueNAS（VM 100）の扱いは別途検討します。RAID_A（`unused0`）・RAID_B は、今後ほかの用途に使ってよいことにしました。
- 取り外したHDDは、物理的に破壊して処分してください。
- **【リスク・未対応】** VM 230 のSSHは、パスワード認証のままです。公開鍵認証への切り替えは行っていません。
