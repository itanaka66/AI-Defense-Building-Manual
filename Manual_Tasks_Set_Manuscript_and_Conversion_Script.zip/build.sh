#!/bin/bash
# build.sh part.md outbase mode
set -e
MD=$1; OUT=$2; MODE=$3
rm -f $OUT.docx.toc.json
node build_docx.js $MD $OUT.docx $MODE
python3 fix_toc.py $MD $OUT.docx $MODE
node build_docx.js $MD $OUT.docx $MODE
python3 fix_toc.py $MD $OUT.docx $MODE check
