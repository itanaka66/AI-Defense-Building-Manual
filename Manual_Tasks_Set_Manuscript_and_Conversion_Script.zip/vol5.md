---
title: "AI自律型サイバー防御システム 構築マニュアル 前編"
subtitle: "第5部　強化版Collectorの本番反映"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」前編の第5部です。第4部でテスト用のコピーに加えた強化を仕上げ、本番のCollectorに反映して、実際の運用で正しく動くことを確認します。

## 本書の表記

- コマンドやファイル内容は、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 各手順の冒頭に「実行先」を示します。
- 「実行結果（例）」は構築時の実際の出力です。お使いの環境では、inode・サイズ・日時・ハッシュなどが異なります。
- 認証情報や状態ファイルの中身は表示しません。

## 第4部終了時点の状態

| 項目 | 状態 |
|---|---|
| 本番のCollector | `/usr/local/lib/wazuh-collector/collector.py`（9,626バイト、SHA-256 `931ee3cb...`） |
| 本番のサービス | `wazuh-collector.service`（active、再起動0回） |
| テスト版 | `/tmp/wazuh-collector-hardening-test.py`（第4部の強化をすべて適用済み） |
| 改善前のバックアップ | `/usr/local/lib/wazuh-collector/collector.py.backup-pre-hardening-20261118` |

> テスト版は `/tmp` にあります。第4部から続けて、security-coreを再起動せずに作業してください。

# 第1章　終了処理の改善

## 1.1　問題点

`run()` の最後の `finally` は、ファイルを閉じてから、DBの接続を閉じます。このままでは、ファイルを閉じるときに例外が起きると、DBの接続が閉じられません。どちらかが失敗しても、もう一方は必ず閉じるように直します。

修正の前にバックアップします。

**実行先：security-core VM 220（root）**

```bash
cp -a \
  /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.backup-before-cleanup-fix-20261118
```

```bash
grep -n -A35 -B10 'finally:' \
  /tmp/wazuh-collector-hardening-test.py
```

```bash
sed -n '435,485p' \
  /tmp/wazuh-collector-hardening-test.py
```

`handle` は `try` の前に開かれ、`connection` は `None` で初期化されているので、`finally` ではどちらも参照できます。修正する箇所が1か所だけであることを確認します。

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")

old = """    finally:
        handle.close()

        if connection is not None:
            connection.close()
"""

print("TARGET_COUNT:", source.count(old))
PY
```

`TARGET_COUNT: 1` であれば次に進みます。

## 1.2　終了処理の修正

ファイルとDB接続のクローズを、それぞれ独立した `try` で囲みます。ログには例外の種類だけを書き、機密情報は出しません。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")

old = """    finally:
        handle.close()

        if connection is not None:
            connection.close()
"""

new = """    finally:
        try:
            handle.close()
        except Exception as error:
            logging.error(
                "Alert file close failed: %s",
                type(error).__name__,
            )

        if connection is not None:
            try:
                connection.close()
            except Exception as error:
                logging.error(
                    "PostgreSQL connection close failed: %s",
                    type(error).__name__,
                )
"""

if source.count(old) != 1:
    raise SystemExit("ABORT: target count is not 1")

path.write_text(source.replace(old, new), encoding="utf-8")
print("TEST COPY CLEANUP UPDATED: PASS")
PY
```

```bash
python3 -m py_compile \
  /tmp/wazuh-collector-hardening-test.py \
  && echo "PY_COMPILE: PASS"
```

## 1.3　終了処理の確認

構文木から `finally` の部分を取り出し、両方のクローズが保護されていることを確認します。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import ast
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")
tree = ast.parse(source)

run_func = next(
    node for node in tree.body
    if isinstance(node, ast.FunctionDef) and node.name == "run"
)

finally_node = next(
    node for node in ast.walk(run_func)
    if isinstance(node, ast.Try) and node.finalbody
)

finally_source = ast.get_source_segment(source, finally_node)

assert finally_source is not None
assert "handle.close()" in finally_source
assert "connection.close()" in finally_source
assert "Alert file close failed" in finally_source
assert "PostgreSQL connection close failed" in finally_source

print("HANDLE CLOSE PROTECTED: PASS")
print("CONNECTION CLOSE PROTECTED: PASS")
print("BOTH CLEANUP PATHS PRESENT: PASS")
PY
```

ファイルのクローズが失敗しても、DB接続のクローズが実行されるという順序を、偽のオブジェクトで確かめます。

```bash
python3 - <<'PY'
import logging

logging.disable(logging.CRITICAL)

events = []

class FakeHandle:
    def close(self):
        events.append("handle.close")
        raise OSError("simulated")

class FakeConnection:
    def close(self):
        events.append("connection.close")

handle = FakeHandle()
connection = FakeConnection()

try:
    try:
        handle.close()
    except Exception as error:
        events.append(f"handle.error:{type(error).__name__}")

    if connection is not None:
        try:
            connection.close()
        except Exception as error:
            events.append(f"connection.error:{type(error).__name__}")

    assert events == [
        "handle.close",
        "handle.error:OSError",
        "connection.close",
    ]

    print("HANDLE CLOSE FAILURE: PASS")
    print("CONNECTION CLOSE STILL EXECUTED: PASS")
finally:
    logging.disable(logging.NOTSET)
PY
```

> 長いコードを端末に貼り付けると、途中が崩れて `SyntaxError` になることがあります。その場合はファイルや本番には影響がないので、もう一度貼り付け直してください。

## 1.4　本番との差分の確認

**実行先：security-core VM 220（root）**

```bash
echo "=== PRODUCTION SHA256 ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== TEST SHA256 ==="
sha256sum /tmp/wazuh-collector-hardening-test.py

echo
echo "=== DIFF SUMMARY ==="
diff -u \
  /usr/local/lib/wazuh-collector/collector.py \
  /tmp/wazuh-collector-hardening-test.py \
  | diffstat 2>/dev/null || true

echo
echo "=== PRODUCTION SERVICE ==="
systemctl is-active wazuh-collector.service
systemctl show wazuh-collector.service -p NRestarts
```

`diffstat` が入っていなければ要約は表示されませんが、問題ありません。差分の前半と後半を確認します。

```bash
diff -u \
  /usr/local/lib/wazuh-collector/collector.py \
  /tmp/wazuh-collector-hardening-test.py \
  | grep -E '^(---|\+\+\+|@@|[+-][^+-])' \
  | head -120
```

```bash
diff -u \
  /usr/local/lib/wazuh-collector/collector.py \
  /tmp/wazuh-collector-hardening-test.py \
  | tail -180
```

# 第2章　ローテーション時のファイルオープンの保護

## 2.1　問題点

ローテーションを検知したときの次の2行は、未完了の行のとき（第4部5.3）とEOFのとき（第4部5.2）の2か所にあります。

```python
new_handle = ALERT_FILE.open("rb")
new_stat = os.fstat(new_handle.fileno())
```

どちらも例外処理がないため、新しいファイルを開けなかった場合にCollectorが終了します。また、開いた後に `fstat()` が失敗すると、ファイルが開いたまま残ります。この処理を1つの関数にまとめ、失敗したら現在のファイルのまま再試行するようにします。

**実行先：security-core VM 220（root）**

```bash
grep -n -B8 -A28 \
  'new_handle = ALERT_FILE.open' \
  /tmp/wazuh-collector-hardening-test.py
```

追加する関数の名前が、まだ使われていないことを確認します。何も表示されなければ問題ありません。

```bash
grep -n '^def safe_open_current_alert_file' \
  /tmp/wazuh-collector-hardening-test.py || true
```

修正の前にバックアップします。

```bash
cp -a \
  /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.backup-before-rotation-open-fix-20261118

sha256sum \
  /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.backup-before-rotation-open-fix-20261118
```

## 2.2　安全にファイルを開く関数の追加

`open_initial_file()` の後、`read_alert_line()` の前に追加します。`open()` か `fstat()` が失敗したら、例外の種類だけをログに書き、開いたファイルを閉じて `(None, None)` を返します。

**実行先：security-core VM 220（root）**

```bash
sed -n '350,430p' \
  /tmp/wazuh-collector-hardening-test.py
```

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")

marker = "\ndef read_alert_line(handle, discarding=False):\n"

addition = '''

def safe_open_current_alert_file():
    handle = None

    try:
        handle = ALERT_FILE.open("rb")
        actual_stat = os.fstat(handle.fileno())
        return handle, actual_stat

    except OSError as error:
        if handle is not None:
            try:
                handle.close()
            except OSError as close_error:
                logging.error(
                    "Failed to close alert file after open error: %s",
                    type(close_error).__name__,
                )

        logging.error(
            "Failed to open current alert file: %s",
            type(error).__name__,
        )
        return None, None

'''

if source.count(marker) != 1:
    raise SystemExit("ABORT: insertion marker count is not 1")

if "def safe_open_current_alert_file(" in source:
    raise SystemExit("ABORT: function already exists")

path.write_text(
    source.replace(marker, addition + marker),
    encoding="utf-8",
)

print("SAFE OPEN FUNCTION ADDED: PASS")
PY
```

追加された関数を確認します。

```bash
grep -n -A35 -B3 \
  '^def safe_open_current_alert_file' \
  /tmp/wazuh-collector-hardening-test.py
```

> 構築時は、このコマンドが `ABORT: function already exists` と表示しましたが、続く確認で関数は正しく追加済みでした（384〜406行目）。二重に追加しない安全チェックが働いただけなので、`grep` で関数が1つだけあることを確認できれば問題ありません。

```bash
python3 -m py_compile \
  /tmp/wazuh-collector-hardening-test.py \
  && echo "PY_COMPILE: PASS"
```

## 2.3　未完了の行のときの呼び出しの置き換え

関数を追加しただけでは、呼び出し側は古いままです。まず2か所の前後を確認します。

**実行先：security-core VM 220（root）**

```bash
sed -n '495,555p' \
  /tmp/wazuh-collector-hardening-test.py

echo
echo "=== EOF ROTATION ==="

sed -n '580,635p' \
  /tmp/wazuh-collector-hardening-test.py
```

2か所を一度に変えると問題の切り分けが難しくなるため、1か所ずつ直します。1か所目（未完了の行）では、オープンに失敗したら `handle.seek(line_start)` で読み取り位置を戻し、未完了の行を失わずに次の待機で再確認します。

```bash
sed -n '525,575p' \
  /tmp/wazuh-collector-hardening-test.py
```

```bash
python3 - <<'PY'
from pathlib import Path

p = Path("/tmp/wazuh-collector-hardening-test.py")
s = p.read_text()

old = '''                    new_handle = ALERT_FILE.open("rb")
                    new_stat = os.fstat(new_handle.fileno())

                    if new_stat.st_ino == active_inode:
                        new_handle.close()
                        handle.seek(line_start)
                        time.sleep(POLL_INTERVAL)
                        continue

                    try:
                        save_state(new_stat.st_ino, 0)
                    except Exception as error:
                        new_handle.close()
                        handle.seek(line_start)
'''

new = '''                    new_handle, new_stat = safe_open_current_alert_file()

                    if new_handle is None:
                        handle.seek(line_start)
                        time.sleep(POLL_INTERVAL)
                        continue

                    if new_stat.st_ino == active_inode:
                        new_handle.close()
                        handle.seek(line_start)
                        time.sleep(POLL_INTERVAL)
                        continue

                    try:
                        save_state(new_stat.st_ino, 0)
                    except Exception as error:
                        new_handle.close()
                        handle.seek(line_start)
'''

if s.count(old) != 1:
    raise SystemExit("ABORT: target block count is not 1")

p.write_text(s.replace(old, new))
print("INCOMPLETE ROTATION OPEN FIX: PASS")
PY
```

```bash
sed -n '535,575p' \
  /tmp/wazuh-collector-hardening-test.py
```

オープンに失敗した場合に、行の先頭へ戻して再試行する形になっていることを確認します。

## 2.4　EOFのときの呼び出しの置き換え

EOFのときは、未完了の行のときと違い、読み取り位置を戻す必要はありません。オープンに失敗したら、旧ファイルを開いたまま次の待機に進みます。

**実行先：security-core VM 220（root）**

```bash
sed -n '585,650p' \
  /tmp/wazuh-collector-hardening-test.py
```

```bash
python3 - <<'PY'
from pathlib import Path

p = Path("/tmp/wazuh-collector-hardening-test.py")
s = p.read_text()

old = '''                    new_handle = ALERT_FILE.open("rb")
                    new_stat = os.fstat(new_handle.fileno())

                    if new_stat.st_ino == active_inode:
                        new_handle.close()
                        time.sleep(POLL_INTERVAL)
                        continue

                    try:
                        save_state(new_stat.st_ino, 0)
'''

new = '''                    new_handle, new_stat = safe_open_current_alert_file()

                    if new_handle is None:
                        time.sleep(POLL_INTERVAL)
                        continue

                    if new_stat.st_ino == active_inode:
                        new_handle.close()
                        time.sleep(POLL_INTERVAL)
                        continue

                    try:
                        save_state(new_stat.st_ino, 0)
'''

if s.count(old) != 1:
    raise SystemExit("ABORT: target block count is not 1")

p.write_text(s.replace(old, new))
print("EOF ROTATION OPEN FIX: PASS")
PY
```

置き換えた箇所を確認します。

```bash
sed -n '605,635p' /tmp/wazuh-collector-hardening-test.py
```

> 構築時は、このコマンドが `ABORT: target block count is not 1` と表示しましたが、確認するとEOF側はすでに `safe_open_current_alert_file()` を使う形に置き換わっていました。`ABORT` の場合はファイルは変更されないので、必ずこの `sed` で実際の内容を確認してください。

```bash
python3 -m py_compile \
  /tmp/wazuh-collector-hardening-test.py \
  && echo "PY_COMPILE: PASS"
```

## 2.5　置き換えの確認

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import ast
from pathlib import Path

p = Path("/tmp/wazuh-collector-hardening-test.py")
source = p.read_text()
tree = ast.parse(source)

run = next(
    n for n in tree.body
    if isinstance(n, ast.FunctionDef) and n.name == "run"
)

calls = [
    n for n in ast.walk(run)
    if isinstance(n, ast.Call)
    and isinstance(n.func, ast.Name)
    and n.func.id == "safe_open_current_alert_file"
]

checks = {
    "two_rotation_calls": len(calls) == 2,
    "no_direct_rotation_open": (
        source.count('new_handle = ALERT_FILE.open("rb")') == 0
    ),
    "helper_defined_once": source.count(
        "def safe_open_current_alert_file():"
    ) == 1,
}

for name, passed in checks.items():
    print(f"{name}: {'PASS' if passed else 'FAIL'}")

if not all(checks.values()):
    raise SystemExit(1)
PY
```

| 確認項目 | 意味 |
|---|---|
| `two_rotation_calls` | `run()` の中で関数を2か所から呼んでいる |
| `no_direct_rotation_open` | 直接 `ALERT_FILE.open()` を呼ぶ古い処理が残っていない |
| `helper_defined_once` | 関数の定義が1つだけ |

## 2.6　関数の単体テスト

`ALERT_FILE` は `Path` のインスタンスなので、`open` をモックするときはインスタンスではなく `Path` クラス側を差し替えます（インスタンスの属性は読み取り専用です）。

**実行先：security-core VM 220（root）**

開けない場合：

```bash
python3 - <<'PY'
import importlib.util
from unittest.mock import patch
from pathlib import Path

spec = importlib.util.spec_from_file_location(
    "collector_test",
    "/tmp/wazuh-collector-hardening-test.py",
)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

with patch.object(
    Path,
    "open",
    side_effect=PermissionError("test"),
):
    handle, stat = module.safe_open_current_alert_file()

assert handle is None
assert stat is None

print("OPEN FAILURE HANDLING: PASS")
PY
```

開いた後に `fstat()` が失敗する場合：

```bash
python3 - <<'PY'
import importlib.util
from pathlib import Path
from unittest.mock import patch, MagicMock

spec = importlib.util.spec_from_file_location(
    "collector_test",
    "/tmp/wazuh-collector-hardening-test.py",
)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

fake_handle = MagicMock()
fake_handle.fileno.return_value = 99

with patch.object(Path, "open", return_value=fake_handle), \
     patch.object(module.os, "fstat", side_effect=OSError("test")):

    handle, stat = module.safe_open_current_alert_file()

assert handle is None
assert stat is None
fake_handle.close.assert_called_once()

print("FSTAT FAILURE HANDLING: PASS")
print("HANDLE CLOSED: PASS")
PY
```

正常に開ける場合（本番の `alerts.json` を読み取り専用で開いて、すぐ閉じます）：

```bash
python3 - <<'PY'
import importlib.util

spec = importlib.util.spec_from_file_location(
    "collector_test",
    "/tmp/wazuh-collector-hardening-test.py",
)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

handle, stat = module.safe_open_current_alert_file()

assert handle is not None
assert stat is not None
assert stat.st_ino > 0
assert not handle.closed

print("NORMAL OPEN: PASS")
print("INODE VALID: PASS")

handle.close()
assert handle.closed
print("HANDLE CLOSE: PASS")
PY
```

```bash
sed -n '530,575p' /tmp/wazuh-collector-hardening-test.py

echo
echo "=== EOF ROTATION ==="

sed -n '610,655p' /tmp/wazuh-collector-hardening-test.py
```

| 分岐 | オープン失敗時 | 成功時 |
|---|---|---|
| 未完了の行 | `handle.seek(line_start)` で位置を戻して再試行 | 状態の保存に成功してから切り替える |
| EOF | 旧ファイルを開いたまま再試行 | 状態の保存に成功してから切り替える |

# 第3章　stat()の例外処理

## 3.1　問題点

ローテーションの検知に使う `ALERT_FILE.stat()` は、`FileNotFoundError` しか捕まえていません。`PermissionError` や一時的なI/Oエラーが起きると、Collectorが終了します。`OSError` 全体を捕まえて、ログに記録して再試行するように直します。

**実行先：security-core VM 220（root）**

```bash
echo "=== PRODUCTION SHA256 ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== TEST SHA256 ==="
sha256sum /tmp/wazuh-collector-hardening-test.py

echo
echo "=== PRODUCTION SERVICE ==="
systemctl is-active wazuh-collector.service
systemctl show wazuh-collector.service -p NRestarts
```

```bash
grep -n -B 3 -A 8 'ALERT_FILE.stat()' \
  /tmp/wazuh-collector-hardening-test.py
```

修正の前にバックアップします。

```bash
cp -a \
  /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.backup-before-stat-hardening-20261118 \
&& sha256sum \
  /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.backup-before-stat-hardening-20261118
```

## 3.2　stat()の例外処理の修正

未完了の行のときは行の先頭に戻し、EOFのときは旧ファイルのまま、どちらもエラーの種類をログに書いて再試行します。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
from pathlib import Path

p = Path("/tmp/wazuh-collector-hardening-test.py")
s = p.read_text()

old1 = '''                except FileNotFoundError:
                    handle.seek(line_start)
                    time.sleep(POLL_INTERVAL)
                    continue
'''

new1 = '''                except OSError as error:
                    handle.seek(line_start)
                    logging.error(
                        "Failed to stat alerts.json: %s",
                        type(error).__name__,
                    )
                    time.sleep(POLL_INTERVAL)
                    continue
'''

old2 = '''                except FileNotFoundError:
                    time.sleep(POLL_INTERVAL)
                    continue
'''

new2 = '''                except OSError as error:
                    logging.error(
                        "Failed to stat alerts.json: %s",
                        type(error).__name__,
                    )
                    time.sleep(POLL_INTERVAL)
                    continue
'''

if s.count(old1) != 1 or s.count(old2) != 1:
    raise SystemExit("ABORT: target block count mismatch")

s = s.replace(old1, new1, 1)
s = s.replace(old2, new2, 1)
p.write_text(s)

print("STAT ERROR HANDLING FIX: PASS")
PY
```

```bash
sed -n '527,550p' /tmp/wazuh-collector-hardening-test.py

echo
sed -n '610,632p' /tmp/wazuh-collector-hardening-test.py
```

```bash
python3 -m py_compile \
  /tmp/wazuh-collector-hardening-test.py \
  && echo "PY_COMPILE: PASS"
```

## 3.3　修正の確認

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import ast
from pathlib import Path

source = Path(
    "/tmp/wazuh-collector-hardening-test.py"
).read_text()

tree = ast.parse(source)
run = next(
    n for n in tree.body
    if isinstance(n, ast.FunctionDef) and n.name == "run"
)

checks = {
    "stat_calls": source.count("current_stat = ALERT_FILE.stat()") == 2,
    "oserror_handlers": source.count("except OSError as error:") >= 3,
    "stat_error_log": source.count(
        '"Failed to stat alerts.json: %s"'
    ) == 2,
}

for name, passed in checks.items():
    print(f"{name}: {'PASS' if passed else 'FAIL'}")

if not all(checks.values()):
    raise SystemExit(1)
PY
```

これで、`stat()`・`open()`・`fstat()` のどれが失敗しても、Collectorは終了せずに再試行します。

```bash
sed -n '440,500p' /tmp/wazuh-collector-hardening-test.py

echo
echo "=== RUN END ==="

sed -n '650,690p' /tmp/wazuh-collector-hardening-test.py
```

# 第4章　run()を使った異常系テスト

第2章・第3章の修正が、実際の `run()` の中で意図どおり動くかを確認します。ファイル・ファイルの位置・状態の保存・待機はすべて偽のオブジェクトに差し替えるので、本番のログ・DB・状態ファイルには触れません。`time.sleep` を差し替えて例外を投げることで、無限ループを安全に止めます。

**実行先：security-core VM 220（root）**

```bash
sed -n '480,670p' /tmp/wazuh-collector-hardening-test.py
```

## 4.1　stat()が失敗した場合

`ALERT_FILE.stat()` が `PermissionError` になった場合に、状態を保存せず、未完了の行のときは行の先頭に戻し、EOFのときは位置を変えないことを確認します。

```bash
python3 - <<'PY'
import importlib.util

spec = importlib.util.spec_from_file_location(
    "collector_test",
    "/tmp/wazuh-collector-hardening-test.py",
)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class StopTest(Exception):
    pass


class FakeHandle:
    def __init__(self, position):
        self.position = position
        self.seek_calls = []
        self.closed = False

    def tell(self):
        return self.position

    def seek(self, position):
        self.seek_calls.append(position)
        self.position = position

    def close(self):
        self.closed = True


class FakeAlertPath:
    def stat(self):
        raise PermissionError("simulated stat failure")


def test_branch(status, initial_position):
    handle = FakeHandle(initial_position)
    module.ALERT_FILE = FakeAlertPath()

    module.load_state = lambda: None
    module.open_initial_file = lambda state: (handle, 12345)
    module.read_alert_line = lambda *args, **kwargs: (
        status, None, False
    )
    module.save_state = lambda *args: (_ for _ in ()).throw(
        AssertionError("save_state must not be called")
    )

    def stop_sleep(_):
        raise StopTest()

    module.time.sleep = stop_sleep

    try:
        module.run()
    except StopTest:
        pass

    assert handle.closed
    assert handle.position == initial_position

    if status == "incomplete":
        assert handle.seek_calls == [initial_position]
    else:
        assert handle.seek_calls == []

    print(f"{status}: PASS")


test_branch("incomplete", 17)
test_branch("eof", 23)
PY
```

`Failed to stat alerts.json: PermissionError` のログに続いて、`incomplete: PASS` と `eof: PASS` が表示されれば成功です。本番に影響がないことも確認します。

```bash
echo "=== PRODUCTION COLLECTOR SHA256 ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== PRODUCTION SERVICE ==="
systemctl is-active wazuh-collector.service

echo
echo "=== RESTART COUNT ==="
systemctl show wazuh-collector.service -p NRestarts --value
```

## 4.2　stat()の失敗から回復した場合

1回目の `stat()` が失敗し、2回目で成功してinodeの変化（11111 → 22222）を検知したときに、ローテーションの処理まで進むことを確認します（未完了の行の場合）。

**実行先：security-core VM 220（root）**

```bash
grep -n -A45 -B8 \
    'current_stat = ALERT_FILE.stat()' \
    /tmp/wazuh-collector-hardening-test.py
```

```bash
python3 - <<'PY'
import importlib.util

spec = importlib.util.spec_from_file_location(
    "collector_test",
    "/tmp/wazuh-collector-hardening-test.py",
)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class StopTest(Exception):
    pass


class FakeStat:
    def __init__(self, inode):
        self.st_ino = inode


class FakePath:
    def __init__(self):
        self.calls = 0

    def stat(self):
        self.calls += 1
        if self.calls == 1:
            raise PermissionError("temporary failure")
        return FakeStat(22222)


class FakeHandle:
    def __init__(self):
        self.position = 37
        self.seek_calls = []
        self.closed = False

    def tell(self):
        return self.position

    def seek(self, position):
        self.seek_calls.append(position)
        self.position = position

    def close(self):
        self.closed = True


path = FakePath()
old_handle = FakeHandle()
new_handle = FakeHandle()
saved_states = []
statuses = iter(["incomplete", "incomplete"])

module.ALERT_FILE = path
module.load_state = lambda: None
module.open_initial_file = lambda state: (old_handle, 11111)
module.read_alert_line = lambda *args, **kwargs: (
    next(statuses), None, False
)
module.safe_open_current_alert_file = lambda: (
    new_handle,
    FakeStat(22222),
)
module.save_state = lambda inode, offset: saved_states.append(
    (inode, offset)
)


def stop_sleep(_):
    if path.calls == 2:
        raise StopTest()


module.time.sleep = stop_sleep

try:
    module.run()
except StopTest:
    pass

checks = {
    "stat retry": path.calls == 2,
    "old offset restored": old_handle.seek_calls == [37],
    "old handle closed": old_handle.closed,
    "new handle closed": new_handle.closed,
    "new state saved": saved_states == [(22222, 0)],
}

for name, passed in checks.items():
    print(f"{name}: {'PASS' if passed else 'FAIL'}")

if not all(checks.values()):
    raise SystemExit(1)
PY
```

| 確認項目 | 意味 |
|---|---|
| `stat retry` | `stat()` が2回呼ばれた（1回目失敗、2回目成功） |
| `old offset restored` | 1回目の失敗で、旧ファイルの位置を37に戻した |
| `old handle closed` | 切り替えで旧ファイルを閉じた |
| `new handle closed` | テストの終了処理で新しいファイルも閉じた |
| `new state saved` | 新しいinode（22222）と位置0を保存した |

```bash
python3 -m py_compile /tmp/wazuh-collector-hardening-test.py \
&& echo "PY_COMPILE: PASS"
```

## 4.3　新しいファイルを開けなかった場合

`stat()` でinodeの変化を検知したのに、新しい `alerts.json` を開けなかった場合を確認します。旧ファイルを開いたまま、位置を保ち、状態は保存しないことが期待です。

> `run()` は終わるときに `finally` で必ずファイルを閉じます。そのため「旧ファイルが開いたままか」は、テストの最後ではなく、再試行の待機（`time.sleep`）の時点で記録して判定します。

**実行先：security-core VM 220（root）**

未完了の行の場合：

```bash
python3 - <<'PY'
import importlib.util

spec = importlib.util.spec_from_file_location(
    "collector_test",
    "/tmp/wazuh-collector-hardening-test.py",
)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class StopTest(Exception):
    pass


class FakeStat:
    st_ino = 22222


class FakePath:
    def stat(self):
        return FakeStat()


class FakeHandle:
    def __init__(self):
        self.position = 41
        self.seek_calls = []
        self.closed = False

    def tell(self):
        return self.position

    def seek(self, position):
        self.seek_calls.append(position)
        self.position = position

    def close(self):
        self.closed = True


path = FakePath()
old_handle = FakeHandle()
saved_states = []
open_calls = 0
retry_state = {}


def fake_open():
    global open_calls
    open_calls += 1
    return None, None


module.ALERT_FILE = path
module.load_state = lambda: None
module.open_initial_file = lambda state: (old_handle, 11111)
module.read_alert_line = lambda *args, **kwargs: (
    "incomplete", None, False
)
module.safe_open_current_alert_file = fake_open
module.save_state = lambda *args: saved_states.append(args)


def stop_sleep(_):
    retry_state["handle_open"] = not old_handle.closed
    retry_state["position"] = old_handle.position
    raise StopTest()


module.time.sleep = stop_sleep

try:
    module.run()
except StopTest:
    pass

checks = {
    "open attempted": open_calls == 1,
    "old handle open during retry": retry_state.get("handle_open") is True,
    "old offset restored during retry": retry_state.get("position") == 41,
    "state not modified": saved_states == [],
    "handle closed during final cleanup": old_handle.closed,
}

for name, passed in checks.items():
    print(f"{name}: {'PASS' if passed else 'FAIL'}")

if not all(checks.values()):
    raise SystemExit(1)
PY
```

EOFの場合：

```bash
python3 - <<'PY'
import importlib.util

spec = importlib.util.spec_from_file_location(
    "collector_test",
    "/tmp/wazuh-collector-hardening-test.py",
)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class StopTest(Exception):
    pass


class FakeStat:
    st_ino = 22222


class FakePath:
    def stat(self):
        return FakeStat()


class FakeHandle:
    def __init__(self):
        self.position = 41
        self.closed = False

    def tell(self):
        return self.position

    def close(self):
        self.closed = True


old_handle = FakeHandle()
saved_states = []
open_calls = 0
retry_state = {}


def fake_open():
    global open_calls
    open_calls += 1
    return None, None


module.ALERT_FILE = FakePath()
module.load_state = lambda: None
module.open_initial_file = lambda state: (old_handle, 11111)
module.read_alert_line = lambda *args, **kwargs: (
    "eof", None, False
)
module.safe_open_current_alert_file = fake_open
module.save_state = lambda *args: saved_states.append(args)


def stop_sleep(_):
    retry_state["handle_open"] = not old_handle.closed
    retry_state["position"] = old_handle.position
    raise StopTest()


module.time.sleep = stop_sleep

try:
    module.run()
except StopTest:
    pass

checks = {
    "open attempted": open_calls == 1,
    "old handle open during retry": retry_state.get("handle_open") is True,
    "old position preserved": retry_state.get("position") == 41,
    "state not modified": saved_states == [],
    "handle closed during final cleanup": old_handle.closed,
}

for name, passed in checks.items():
    print(f"{name}: {'PASS' if passed else 'FAIL'}")

if not all(checks.values()):
    raise SystemExit(1)
PY
```

どちらも5項目が `PASS` になれば、新しいファイルを開けなくても、旧ファイルのまま安全に再試行できます。

```bash
echo "=== TEST SCRIPT ==="
python3 -m py_compile /tmp/wazuh-collector-hardening-test.py \
  && echo "TEST PY_COMPILE: PASS"

echo
echo "=== PRODUCTION SCRIPT SHA256 ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== PRODUCTION SERVICE ==="
systemctl is-active wazuh-collector.service

echo
echo "=== PRODUCTION RESTART COUNT ==="
systemctl show wazuh-collector.service -p NRestarts --value
```

# 第5章　Unicodeの書式制御文字と日時の長さ

## 5.1　テスト版全体の構造

本番に反映する前に、テスト版を全体として見直します。まず関数と定数の一覧を出します。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import ast
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")
tree = ast.parse(source)

print("=== FUNCTIONS ===")
for node in tree.body:
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        print(
            f"{node.lineno:4}-{node.end_lineno:4} "
            f"{node.name}"
        )

print()
print("=== GLOBAL CONSTANTS ===")
for node in tree.body:
    if isinstance(node, ast.Assign):
        names = [
            target.id
            for target in node.targets
            if isinstance(target, ast.Name)
        ]
        if names:
            print(f"{node.lineno:4} {', '.join(names)}")
PY
```

構築時は15個の関数で、入力検証・DB保存・状態管理・ローテーション・メインループに分かれていました。入力検証の部分と、importと定数を確認します。

```bash
sed -n '80,245p' /tmp/wazuh-collector-hardening-test.py
```

```bash
sed -n '1,80p' /tmp/wazuh-collector-hardening-test.py
```

## 5.2　現在の動作の確認

日時・文字列・IPアドレスの検証が、境界的な入力をどう扱うかを確認します。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import importlib.util

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

print("=== TIMESTAMP ===")
for value in (
    "2026-11-18T12:00:00+09:00",
    "2026-11-18T03:00:00Z",
    "invalid",
    "9" * 10000,
):
    try:
        result = module.parse_timestamp(value)
        print(f"accepted: length={len(value)}")
    except Exception as error:
        print(f"rejected: length={len(value)}, error={type(error).__name__}")

print()
print("=== TEXT ===")
for value in (
    "normal text",
    "line1\nline2",
    "日本語テスト",
    "zero\u200bwidth",
    "bidi\u202econtrol",
):
    result = module.safe_text(value)
    print(f"input={value!r} output={result!r}")

print()
print("=== IP ===")
for value in ("192.0.2.1", " 192.0.2.1 ", "2001:db8::1"):
    print(f"{value!r} -> {module.safe_ip(value)!r}")
PY
```

構築時の結果：

```text
=== TEXT ===
input='normal text' output='normal text'
input='line1\nline2' output='line1line2'
input='日本語テスト' output='日本語テスト'
input='zero\u200bwidth' output='zero\u200bwidth'
input='bidi\u202econtrol' output='bidi\u202econtrol'

=== IP ===
'192.0.2.1' -> '192.0.2.1'
' 192.0.2.1 ' -> None
'2001:db8::1' -> '2001:db8::1'
```

| 項目 | 現状 | 判断 |
|---|---|---|
| 日時 | 不正な値と10,000文字の値は拒否される | 長さの上限を明示的に設ける |
| 改行 | 除去される | 問題なし |
| 日本語 | そのまま残る | 問題なし |
| ゼロ幅スペース（U+200B）・双方向制御文字（U+202E） | 残る | ログの表示を偽装できるため除去する |
| 前後に空白のあるIPアドレス | 拒否される | セキュリティ上は厳格なままでよい |

## 5.3　書式制御文字の除去

Unicodeの分類が「Cf」（書式制御文字）の文字を、`safe_text()` で除去します。日本語や絵文字は残ります。修正の前にバックアップします。

**実行先：security-core VM 220（root）**

```bash
cp -a /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.backup-before-unicode-fix-20261118

sha256sum \
  /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.backup-before-unicode-fix-20261118
```

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")

old = '''def safe_text(value, limit=4096):
    if not isinstance(value, str):
        return None

    value = "".join(
        char for char in value
        if char >= " " and not 0x7f <= ord(char) <= 0x9f
    )

    value = value.strip()

    if not value:
        return None

    return value[:limit]
'''

new = '''def safe_text(value, limit=4096):
    if not isinstance(value, str):
        return None

    value = "".join(
        char for char in value
        if (
            char >= " "
            and not 0x7f <= ord(char) <= 0x9f
            and __import__("unicodedata").category(char) != "Cf"
        )
    )

    value = value.strip()

    if not value:
        return None

    return value[:limit]
'''

if source.count(old) != 1:
    raise SystemExit("ERROR: safe_text target not unique; no changes made")

path.write_text(source.replace(old, new), encoding="utf-8")
print("safe_text updated in test copy only")
PY
```

```bash
sed -n '1,18p' /tmp/wazuh-collector-hardening-test.py
sed -n '125,155p' /tmp/wazuh-collector-hardening-test.py
python3 -m py_compile /tmp/wazuh-collector-hardening-test.py
```

`__import__("unicodedata")` でも動きますが、読みやすさと保守のため、通常の `import` に整理します。

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")

old_import = "import ipaddress\n"
new_import = "import ipaddress\nimport unicodedata\n"

old_call = '__import__("unicodedata").category(char)'
new_call = 'unicodedata.category(char)'

if source.count(old_import) != 1:
    raise SystemExit("ERROR: import target not unique")

if source.count(old_call) != 1:
    raise SystemExit("ERROR: Unicode call target not unique")

source = source.replace(old_import, new_import, 1)
source = source.replace(old_call, new_call, 1)

path.write_text(source, encoding="utf-8")
print("unicodedata import normalized")
PY
```

## 5.4　日時の長さの上限

日時の文字列は64文字までに制限し、空の文字列も拒否します。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")

old = '''def parse_timestamp(value):
    if not isinstance(value, str):
        raise ValueError("invalid timestamp")

    result = datetime.fromisoformat(
'''

new = '''def parse_timestamp(value):
    if not isinstance(value, str) or not value or len(value) > 64:
        raise ValueError("invalid timestamp")

    result = datetime.fromisoformat(
'''

if source.count(old) != 1:
    raise SystemExit("ERROR: timestamp target not unique; no changes made")

path.write_text(source.replace(old, new, 1), encoding="utf-8")
print("Timestamp length limit added: 64 characters")
PY
```

## 5.5　回帰テスト

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import importlib.util

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

print("=== TIMESTAMP TEST ===")
timestamp_cases = [
    ("valid JST", "2026-11-18T12:00:00+09:00", True),
    ("valid UTC", "2026-11-18T03:00:00Z", True),
    ("empty", "", False),
    ("invalid", "invalid", False),
    ("over limit", "9" * 65, False),
]

for name, value, expected in timestamp_cases:
    try:
        module.parse_timestamp(value)
        actual = True
    except (ValueError, TypeError):
        actual = False

    print(f"{name}: {'PASS' if actual == expected else 'FAIL'}")

print()
print("=== SAFE TEXT TEST ===")
text_cases = [
    ("Japanese", "日本語テスト", "日本語テスト"),
    ("newline", "line1\nline2", "line1line2"),
    ("zero width", "zero\u200bwidth", "zerowidth"),
    ("bidi control", "bidi\u202econtrol", "bidicontrol"),
    ("emoji", "安全🔐テスト", "安全🔐テスト"),
]

for name, value, expected in text_cases:
    actual = module.safe_text(value)
    print(f"{name}: {'PASS' if actual == expected else 'FAIL'}")
    if actual != expected:
        print(f"  expected={expected!r}")
        print(f"  actual  ={actual!r}")
PY
```

| 区分 | 確認した内容 |
|---|---|
| 日時 | JST・UTCは受け入れ、空・不正・65文字以上は拒否 |
| 文字列 | 日本語・絵文字は保持、改行・ゼロ幅スペース・双方向制御文字は除去 |

10項目すべてが `PASS` になれば完了です。

# 第6章　巨大な行とローテーションの総合試験

## 6.1　読み飛ばしの位置の計測

1 MiBを超える行が、どの位置で読み飛ばされるかを実測します。最初の読み込みでは、上限（1 MiB＋1バイト）に続けて64 KiBを追加で読むため、残りは想定より少なくなります。

**実行先：security-core VM 220（root）**

```bash
nl -ba /tmp/wazuh-collector-hardening-test.py | sed -n '390,490p'
```

```bash
python3 - <<'PY'
import importlib.util
import io

spec = importlib.util.spec_from_file_location(
    "collector_test",
    "/tmp/wazuh-collector-hardening-test.py",
)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

payload = b"A" * (
    m.MAX_ALERT_LINE_BYTES + m.READ_CHUNK_BYTES * 3
) + b"\n"

h = io.BytesIO(payload)

for i in range(6):
    status, _, discarding = m.read_alert_line(
        h,
        discarding=(i > 0),
    )
    print(
        f"step={i + 1}",
        f"status={status}",
        f"discarding={discarding}",
        f"position={h.tell()}",
        f"remaining={len(payload) - h.tell()}",
    )
    if status in ("oversized", "eof"):
        break
PY
```

| 段階 | 状態 | 読み込み位置 | 残り |
|---|---|---:|---:|
| 1 | `discarding` | 1,114,113 | 131,072 |
| 2 | `discarding` | 1,179,649 | 65,536 |
| 3 | `oversized` | 1,245,185 | 0 |

64 KiBずつ捨て、改行に届いたところで `oversized` になって終わります。

## 6.2　テスト環境の準備

`run()` 全体を、一時ディレクトリの疑似ログで動かします。状態の保存とDBへの接続はモックにし、本番の状態ファイル（`/var/lib/wazuh-collector/state.json`）とDBには触れません。

**実行先：security-core VM 220（root）**

```bash
grep -n -A65 '^def save_state' /tmp/wazuh-collector-hardening-test.py
```

```bash
sed -n '1,65p' /tmp/wazuh-collector-hardening-test.py
```

一時ディレクトリでのローテーション（名前を変えて新しいファイルを作る）で、inodeが変わることを確認します。

```bash
python3 - <<'PY'
import tempfile
from pathlib import Path

with tempfile.TemporaryDirectory(prefix="wazuh-rotation-test-") as tmp:
    root = Path(tmp)
    alert_dir = root / "alerts"
    alert_dir.mkdir()

    active = alert_dir / "alerts.json"
    rotated = alert_dir / "alerts.json.1"

    active.write_bytes(b"A" * 1024)
    active.rename(rotated)
    active.write_bytes(b'{"test":"new"}\n')

    assert rotated.exists()
    assert active.exists()
    assert rotated.stat().st_ino != active.stat().st_ino

    print("PASS: temporary log rotation")
    print("PASS: old inode =", rotated.stat().st_ino)
    print("PASS: new inode =", active.stat().st_ino)
    print("PASS: no production files accessed")
PY
```

```bash
grep -nE '^(def run|def save_state|def open_initial_file|def safe_open_current_alert_file|def read_alert_line|def process_line)' /tmp/wazuh-collector-hardening-test.py
```

## 6.3　読み飛ばし中のローテーション

旧ログに1 MiBを超える未完了の行を置き、`run()` が読み飛ばしを始めた後（1回目の待機）でログをローテーションさせます。新しいinodeと位置0が保存されることを確認します。DBへの接続が起きたらテストは失敗します。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import importlib.util
import tempfile
from pathlib import Path
from unittest.mock import patch
import os

spec = importlib.util.spec_from_file_location(
    "collector_test",
    "/tmp/wazuh-collector-hardening-test.py",
)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

saved_states = []
sleep_count = 0
rotation_info = {}

class StopTest(Exception):
    pass

def fake_save_state(inode, offset):
    saved_states.append((inode, offset))

def forbidden_connect(*args, **kwargs):
    raise AssertionError("DB connection must not occur")

with tempfile.TemporaryDirectory(prefix="wazuh-rotation-run-") as tmp:
    root = Path(tmp)
    alert_dir = root / "alerts"
    alert_dir.mkdir()

    alert_file = alert_dir / "alerts.json"
    rotated_file = alert_dir / "alerts.json.1"

    # 巨大な未完了行。最初の読み込み後にEOFとなる長さ。
    alert_file.write_bytes(
        b"A" * (m.MAX_ALERT_LINE_BYTES + 1 + m.READ_CHUNK_BYTES)
    )

    def fake_open_initial_file(state):
        handle = alert_file.open("rb")
        inode = os.fstat(handle.fileno()).st_ino
        return handle, inode

    def fake_sleep(seconds):
        global sleep_count
        sleep_count += 1

        if sleep_count == 1:
            old_inode = alert_file.stat().st_ino
            alert_file.rename(rotated_file)
            alert_file.write_bytes(b"")
            rotation_info["old_inode"] = old_inode
            rotation_info["new_inode"] = alert_file.stat().st_ino
            print("TEST: log rotated during oversized-line discard")

        elif sleep_count == 2:
            raise StopTest()

    with (
        patch.object(m, "ALERT_FILE", alert_file),
        patch.object(m, "ALERT_DIR", alert_dir),
        patch.object(m, "STATE_FILE", root / "state.json"),
        patch.object(m, "load_state", lambda: None),
        patch.object(m, "open_initial_file", fake_open_initial_file),
        patch.object(m, "save_state", fake_save_state),
        patch.object(m.psycopg, "connect", forbidden_connect),
        patch.object(m.time, "sleep", fake_sleep),
    ):
        try:
            m.run()
        except StopTest:
            pass

    assert rotation_info["old_inode"] != rotation_info["new_inode"]
    assert saved_states == [(rotation_info["new_inode"], 0)]
    assert not (root / "state.json").exists()

    print("PASS: oversized line entered discard mode")
    print("PASS: rotation detected during discard")
    print("PASS: new inode saved with offset 0")
    print("PASS: production DB was not accessed")
    print("PASS: production state file was not modified")
    print("ALL ROTATION TESTS PASSED")
PY
```

ログには次の3行が出力されます。

```text
Oversized alert line detected; discarding
Incomplete oversized line discarded at rotation
Switched to new alerts.json inode
```

## 6.4　ローテーション時に状態の保存に失敗した場合

新しいinodeの保存を意図的に失敗させ、旧ファイルを閉じずに保ち、新しいファイルに切り替えないことを確認します。旧ファイルが開いているかどうかは、2回目の待機（再試行）の時点で記録します。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import importlib.util
import tempfile
from pathlib import Path
from unittest.mock import patch
import os

spec = importlib.util.spec_from_file_location(
    "collector_test",
    "/tmp/wazuh-collector-hardening-test.py",
)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

saved_attempts = []
rotation_info = {}
sleep_count = 0
old_handle_info = {}

class StopTest(Exception):
    pass

def fake_save_state(inode, offset):
    saved_attempts.append((inode, offset))
    if rotation_info and inode == rotation_info["new_inode"]:
        raise OSError("simulated state-save failure")

def forbidden_connect(*args, **kwargs):
    raise AssertionError("DB connection must not occur")

with tempfile.TemporaryDirectory(prefix="wazuh-rotation-fail-") as tmp:
    root = Path(tmp)
    alert_dir = root / "alerts"
    alert_dir.mkdir()

    alert_file = alert_dir / "alerts.json"
    rotated_file = alert_dir / "alerts.json.1"

    alert_file.write_bytes(
        b"A" * (m.MAX_ALERT_LINE_BYTES + 1 + m.READ_CHUNK_BYTES)
    )

    def fake_open_initial_file(state):
        handle = alert_file.open("rb")
        old_handle_info["handle"] = handle
        old_handle_info["inode"] = os.fstat(handle.fileno()).st_ino
        return handle, old_handle_info["inode"]

    def fake_sleep(seconds):
        global sleep_count
        sleep_count += 1

        if sleep_count == 1:
            alert_file.rename(rotated_file)
            alert_file.write_bytes(b"")
            rotation_info["new_inode"] = alert_file.stat().st_ino
            rotation_info["old_inode"] = rotated_file.stat().st_ino
            print("TEST: rotation completed")

        elif sleep_count == 2:
            old_handle_info["open_during_retry"] = (
                not old_handle_info["handle"].closed
            )
            old_handle_info["position_during_retry"] = (
                old_handle_info["handle"].tell()
            )
            raise StopTest()

    with (
        patch.object(m, "ALERT_FILE", alert_file),
        patch.object(m, "ALERT_DIR", alert_dir),
        patch.object(m, "STATE_FILE", root / "state.json"),
        patch.object(m, "load_state", lambda: None),
        patch.object(m, "open_initial_file", fake_open_initial_file),
        patch.object(m, "save_state", fake_save_state),
        patch.object(m.psycopg, "connect", forbidden_connect),
        patch.object(m.time, "sleep", fake_sleep),
    ):
        try:
            m.run()
        except StopTest:
            pass

    assert rotation_info["old_inode"] != rotation_info["new_inode"]
    assert saved_attempts == [(rotation_info["new_inode"], 0)]
    assert old_handle_info["open_during_retry"] is True
    assert old_handle_info["position_during_retry"] > 0
    assert old_handle_info["handle"].closed is True
    assert not (root / "state.json").exists()

    print("PASS: state-save failure detected")
    print("PASS: old file handle retained during retry")
    print("PASS: old file position preserved")
    print("PASS: old handle closed only during final cleanup")
    print("PASS: production DB untouched")
    print("PASS: production state untouched")
    print("ALL TESTS PASSED")
PY
```

`ERROR State save failed during rotation: OSError` のログに続いて `ALL TESTS PASSED` と表示されれば、状態を保存できない間は旧ファイルのまま待ち、誤って新しいファイルに切り替えないことを確認できます。

# 第7章　DB障害と再処理の総合試験

## 7.1　DB接続が切れた場合の再接続

1回目のDB処理を意図的に失敗させ、接続を捨てて作り直し、同じアラートを元の位置からもう一度処理することを確認します。状態は、処理が成功してから1回だけ保存されるはずです。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import importlib.util
import tempfile
from pathlib import Path
from unittest.mock import patch
import os

spec = importlib.util.spec_from_file_location(
    "collector_test",
    "/tmp/wazuh-collector-hardening-test.py",
)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

saved_states = []
processed_lines = []
connections = []
sleep_count = 0
connection_attempts = 0

class StopTest(Exception):
    pass

class FakeConnection:
    def __init__(self, number):
        self.number = number
        self.closed = False
        self.close_count = 0

    def close(self):
        self.close_count += 1
        self.closed = True

def fake_connect(*args, **kwargs):
    global connection_attempts
    connection_attempts += 1
    connection = FakeConnection(connection_attempts)
    connections.append(connection)
    return connection

def fake_process_line(connection, line):
    processed_lines.append((connection.number, line))

    if len(processed_lines) == 1:
        raise OSError("simulated database connection failure")

def fake_save_state(inode, offset):
    saved_states.append((inode, offset))

def fake_sleep(seconds):
    global sleep_count
    sleep_count += 1

    if sleep_count == 2:
        raise StopTest()

with tempfile.TemporaryDirectory(prefix="wazuh-db-reconnect-") as tmp:
    root = Path(tmp)
    alert_dir = root / "alerts"
    alert_dir.mkdir()

    alert_file = alert_dir / "alerts.json"
    line = b'{"id":"retry-event","rule":{"id":"200003","level":7}}\n'
    alert_file.write_bytes(line)

    def fake_open_initial_file(state):
        handle = alert_file.open("rb")
        inode = os.fstat(handle.fileno()).st_ino
        return handle, inode

    with (
        patch.object(m, "ALERT_FILE", alert_file),
        patch.object(m, "ALERT_DIR", alert_dir),
        patch.object(m, "STATE_FILE", root / "state.json"),
        patch.object(m, "load_state", lambda: None),
        patch.object(m, "open_initial_file", fake_open_initial_file),
        patch.object(m, "save_state", fake_save_state),
        patch.object(m.psycopg, "connect", fake_connect),
        patch.object(m, "process_line", fake_process_line),
        patch.object(m.time, "sleep", fake_sleep),
    ):
        try:
            m.run()
        except StopTest:
            pass

    print("Connection attempts:", connection_attempts)
    print("Processed attempts:", len(processed_lines))
    print("Saved states:", saved_states)

    assert connection_attempts == 2
    assert len(processed_lines) == 2
    assert processed_lines[0][1] == line
    assert processed_lines[1][1] == line
    assert processed_lines[0][0] == 1
    assert processed_lines[1][0] == 2
    assert connections[0].closed is True
    assert connections[0].close_count >= 1
    assert connections[1].closed is True
    assert saved_states == [
        (os.stat(alert_file).st_ino, len(line))
    ]
    assert not (root / "state.json").exists()

    print("PASS: first DB processing attempt failed")
    print("PASS: failed connection was closed")
    print("PASS: new DB connection established")
    print("PASS: same event retried from original position")
    print("PASS: state saved only after successful processing")
    print("PASS: all test connections closed")
    print("PASS: production state file untouched")
    print("ALL TESTS PASSED")
PY
```

> テスト用の接続オブジェクトには、本番のコードが参照する `closed` 属性が必要です。属性がないと `AttributeError` になります。

## 7.2　状態の保存失敗後の再処理と重複の防止

DBへの登録は成功したのに状態の保存に失敗した場合、`run()` が同じアラートを再処理し、2回目は一意制約で拒否されて、登録が1件だけになることを、実際の `run()` で確認します（第4部8.6の確認を、ループ全体で行うものです）。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import importlib.util
import tempfile
from pathlib import Path
from unittest.mock import patch
import os
import json

spec = importlib.util.spec_from_file_location(
    "collector_test",
    "/tmp/wazuh-collector-hardening-test.py",
)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

inserted_ids = set()
insert_attempts = []
successful_inserts = []
duplicate_count = 0
save_attempts = []
sleep_count = 0
connections = []

class StopTest(Exception):
    pass

class FakeTransaction:
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        return False

class FakeConnection:
    def __init__(self):
        self.closed = False

    def transaction(self):
        return FakeTransaction()

    def execute(self, sql, event):
        global duplicate_count
        event_id = event["event_id"]
        insert_attempts.append(event_id)

        if event_id in inserted_ids:
            duplicate_count += 1
            raise m.psycopg.errors.UniqueViolation(
                "duplicate event"
            )

        inserted_ids.add(event_id)
        successful_inserts.append(event_id)

    def close(self):
        self.closed = True

def fake_connect(*args, **kwargs):
    connection = FakeConnection()
    connections.append(connection)
    return connection

def fake_save_state(inode, offset):
    save_attempts.append((inode, offset))
    if len(save_attempts) == 1:
        raise OSError("simulated state save failure")

def fake_sleep(seconds):
    global sleep_count
    sleep_count += 1
    if sleep_count == 2:
        raise StopTest()

with tempfile.TemporaryDirectory(prefix="wazuh-state-retry-") as tmp:
    root = Path(tmp)
    alert_dir = root / "alerts"
    alert_dir.mkdir()

    alert_file = alert_dir / "alerts.json"
    line = (
        b'{"id":"step315-run-event",'
        b'"timestamp":"2026-11-18T15:00:00+09:00",'
        b'"rule":{"id":"100001","level":5,"description":"test"},'
        b'"agent":{"id":"001","name":"test-agent"},'
        b'"manager":{"name":"test-manager"},'
        b'"decoder":{"name":"test-decoder"}}\n'
    )
    alert_file.write_bytes(line)
    inode = alert_file.stat().st_ino

    def fake_open_initial_file(state):
        handle = alert_file.open("rb")
        return handle, os.fstat(handle.fileno()).st_ino

    with (
        patch.object(m, "ALERT_FILE", alert_file),
        patch.object(m, "ALERT_DIR", alert_dir),
        patch.object(m, "STATE_FILE", root / "state.json"),
        patch.object(m, "load_state", lambda: None),
        patch.object(m, "open_initial_file", fake_open_initial_file),
        patch.object(m, "save_state", fake_save_state),
        patch.object(m.psycopg, "connect", fake_connect),
        patch.object(m.time, "sleep", fake_sleep),
    ):
        try:
            m.run()
        except StopTest:
            pass

    print("Insert attempts:", insert_attempts)
    print("Successful inserts:", successful_inserts)
    print("Duplicate count:", duplicate_count)
    print("State save attempts:", save_attempts)

    assert insert_attempts == [
        "step315-run-event",
        "step315-run-event",
    ]
    assert successful_inserts == ["step315-run-event"]
    assert duplicate_count == 1
    assert len(save_attempts) == 2
    assert save_attempts[0] == (inode, len(line))
    assert save_attempts[1] == (inode, len(line))
    assert not (root / "state.json").exists()
    assert all(c.closed for c in connections)

    print("PASS: DB insert succeeded once")
    print("PASS: failed state save caused event retry")
    print("PASS: duplicate was rejected")
    print("PASS: second state save succeeded")
    print("PASS: production state untouched")
    print("ALL TESTS PASSED")
PY
```

構築時の結果：

```text
Insert attempts: ['step315-run-event', 'step315-run-event']
Successful inserts: ['step315-run-event']
Duplicate count: 1
State save attempts: [(5778632, 230), (5778632, 230)]
ALL TESTS PASSED
```

## 7.3　禁止した要素が含まれていないことの確認

構文を確認し、`ON CONFLICT`・`SELECT`・`UPDATE`・`DELETE` や、`full_log`・`password`・`command` がコードに現れないことを確認します。何も表示されなければ問題ありません。

**実行先：security-core VM 220（root）**

```bash
python3 -m py_compile /tmp/wazuh-collector-hardening-test.py &&
echo "PASS: Python syntax" &&
grep -nE 'ON CONFLICT|SELECT |UPDATE |DELETE |full_log|password|command' \
  /tmp/wazuh-collector-hardening-test.py || true
```

# 第8章　本番への反映と起動時の問題

## 8.1　本番との差分の最終確認

**実行先：security-core VM 220（root）**

```bash
diff -u \
  /usr/local/lib/wazuh-collector/collector.py \
  /tmp/wazuh-collector-hardening-test.py \
  | less
```

`less` で見にくい場合は、範囲を分けて表示します。

```bash
diff -u \
  /usr/local/lib/wazuh-collector/collector.py \
  /tmp/wazuh-collector-hardening-test.py \
  | sed -n '80,260p'
```

```bash
diff -u \
  /usr/local/lib/wazuh-collector/collector.py \
  /tmp/wazuh-collector-hardening-test.py \
  | sed -n '260,480p'
```

| 領域 | 変更内容 |
|---|---|
| 入力検証 | 整数・文字列・日時・Unicodeの制限 |
| 配列・MITRE | 件数・文字数・キーの制限 |
| 状態ファイル | inodeと位置の厳格な検証、実際に開いたファイルのinode |
| 行サイズ | 1 MiBの上限、64 KiB単位の読み飛ばし |
| ローテーション | 未完了の行・EOF・読み飛ばし中の切り替え、open・fstat・statの失敗時の再試行 |
| DB・終了処理 | 接続失敗時の巻き戻し、重複の処理、クローズの独立 |

## 8.2　本番の健全性とテスト版の保全

**実行先：security-core VM 220（root）**

```bash
systemctl is-active wazuh-collector &&
systemctl show wazuh-collector \
  -p MainPID -p NRestarts -p ActiveEnterTimestamp &&
sha256sum /usr/local/lib/wazuh-collector/collector.py &&
stat -c '%U:%G %a %s %y' \
  /var/lib/wazuh-collector/state.json
```

検証の終わったテスト版を、`/tmp` の中で別名で保全します。

```bash
cp -a \
  /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.verified-20261119 &&
sha256sum \
  /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.verified-20261119
```

```bash
stat -c '%n | %U:%G | %a | %s bytes' \
  /usr/local/lib/wazuh-collector/collector.py \
  /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.verified-20261119
```

| ファイル | 所有者・権限 | サイズ（構築時） |
|---|---|---:|
| 本番 `collector.py` | `root:root 755` | 9,626バイト |
| テスト版 | `root:root 600` | 18,510バイト |

## 8.3　候補ファイルの配置と本番のバックアップ

テスト版を、本番と同じ所有者・権限で `collector.py.candidate` として配置し、構文とハッシュを確認します。

**実行先：security-core VM 220（root）**

```bash
install -o root -g root -m 755 \
  /tmp/wazuh-collector-hardening-test.py \
  /usr/local/lib/wazuh-collector/collector.py.candidate &&
python3 -m py_compile \
  /usr/local/lib/wazuh-collector/collector.py.candidate &&
stat -c '%n | %U:%G | %a | %s bytes' \
  /usr/local/lib/wazuh-collector/collector.py.candidate &&
sha256sum \
  /tmp/wazuh-collector-hardening-test.py \
  /usr/local/lib/wazuh-collector/collector.py.candidate
```

現在の本番のコードをバックアップします。

```bash
cp -a \
  /usr/local/lib/wazuh-collector/collector.py \
  /usr/local/lib/wazuh-collector/collector.py.backup-20261119 &&
sha256sum \
  /usr/local/lib/wazuh-collector/collector.py \
  /usr/local/lib/wazuh-collector/collector.py.backup-20261119
```

```text
本番:
931ee3cb381be2dd059ad76669bf00e19f2da2c949cf264abb235061f88c95a8

バックアップ:
931ee3cb381be2dd059ad76669bf00e19f2da2c949cf264abb235061f88c95a8
```

## 8.4　本番のコードの置き換え

候補ファイルを一度 `collector.py.new` としてコピーし、`cmp` で一致を確かめてから、`mv` で一度に置き換えます（途中の状態のファイルが本番の名前で存在する時間をなくすためです）。この時点ではサービスは再起動しないので、動いているプロセスは古いコードのままです。

**実行先：security-core VM 220（root）**

```bash
set -e

install -o root -g root -m 755 \
  /usr/local/lib/wazuh-collector/collector.py.candidate \
  /usr/local/lib/wazuh-collector/collector.py.new

cmp \
  /usr/local/lib/wazuh-collector/collector.py.candidate \
  /usr/local/lib/wazuh-collector/collector.py.new

mv -f \
  /usr/local/lib/wazuh-collector/collector.py.new \
  /usr/local/lib/wazuh-collector/collector.py

echo "=== FILE ==="
stat -c '%n | %U:%G | %a | %s bytes' \
  /usr/local/lib/wazuh-collector/collector.py

echo "=== SHA256 ==="
sha256sum \
  /usr/local/lib/wazuh-collector/collector.py \
  /usr/local/lib/wazuh-collector/collector.py.backup-20261119
```

> `set -e` を対話シェルで実行すると、途中のコマンドが失敗した時点でシェル自体が終了します。その場合はログインし直して、状態を確認してください。

本番の `collector.py` のSHA-256は、テスト版と同じ `d404f10a...`（18,510バイト）になります。

## 8.5　再起動と起動の失敗

**実行先：security-core VM 220（root）**

```bash
systemctl restart wazuh-collector &&
sleep 2 &&
echo "=== SERVICE ===" &&
systemctl is-active wazuh-collector &&
systemctl show wazuh-collector \
  -p MainPID \
  -p NRestarts \
  -p ActiveEnterTimestamp &&
echo "=== JOURNAL ===" &&
journalctl -u wazuh-collector -n 30 --no-pager
```

構築時は、ここで `activating` と表示され、正常に動きませんでした。状態とログを確認します。

```bash
echo "=== SYSTEMD STATUS ==="
systemctl status wazuh-collector --no-pager -l

echo
echo "=== SERVICE PROPERTIES ==="
systemctl show wazuh-collector \
  -p ActiveState \
  -p SubState \
  -p Result \
  -p MainPID \
  -p NRestarts \
  -p ExecMainStatus

echo
echo "=== RECENT JOURNAL ==="
journalctl -u wazuh-collector -n 60 --no-pager -o short-iso
```

```bash
journalctl -u wazuh-collector \
  --since "2026-11-18 15:14:00" \
  --no-pager -o cat
```

`--since` の時刻は、再起動した時刻に合わせます。構築時のログは次のとおりです（抜粋）。

```text
  File "/usr/local/lib/wazuh-collector/collector.py", line 316, in find_inode_file
    for entry in os.scandir(ALERT_DIR):
                 ^^^^^^^^^^^^^^^^^^^^^
PermissionError: [Errno 13] Permission denied: '/var/ossec/logs/alerts'
```

**原因：** 新しいコードの `open_initial_file()` は、起動時に `find_inode_file()` で `/var/ossec/logs/alerts` の中身を `os.scandir()` で一覧しています。しかし第3部第7章のACLでは、`wazuh-collector` にはこのディレクトリの通過権限（`x`）しか与えておらず、一覧を取る読み取り権限（`r`）がありません。新しい処理の前提と、最小権限の設計が食い違っていました。

> テストでは `find_inode_file()` をモックにしたり、root で実行したりしていたため、この問題は本番のユーザーで動かすまで見つかりませんでした。

## 8.6　自動再起動の停止

systemdが5秒ごとに再起動を繰り返すため、Collectorだけを止めます。Wazuh Manager・Indexer・PostgreSQLには影響しません。

**実行先：security-core VM 220（root）**

```bash
systemctl stop wazuh-collector &&
systemctl is-active wazuh-collector
```

> 一般ユーザーで実行すると、systemdが管理者の認証を求めます。その場合はそのユーザーのパスワードを入力します（パスワードは記録に残さないでください）。

`inactive` と表示されれば停止しています。

安易にディレクトリへの読み取り権限を追加するのではなく、最小権限を保ったままコードで対処します。まず権限とコードを確認します。

```bash
sudo bash -c '
echo "=== ALERT DIRECTORY PERMISSIONS ==="
namei -l /var/ossec/logs/alerts
getfacl -p /var/ossec/logs/alerts
echo
echo "=== ALERT FILE PERMISSIONS ==="
stat -c "%n | %U:%G | %a | %s bytes" /var/ossec/logs/alerts/alerts.json
getfacl -p /var/ossec/logs/alerts/alerts.json
echo
echo "=== INODE SEARCH FUNCTION ==="
sed -n "290,375p" /usr/local/lib/wazuh-collector/collector.py
echo
echo "=== SYSTEMD ACCESS RULES ==="
systemctl cat wazuh-collector
'
```

```bash
echo "=== ALERT FILES (NAME / INODE / SIZE) ==="
find /var/ossec/logs/alerts \
  -maxdepth 1 -type f \
  -printf '%f | inode=%i | size=%s bytes\n' |
  sort

echo
echo "=== COLLECTOR STATE ==="
stat -c '%U:%G | %a | %s bytes' \
  /var/lib/wazuh-collector/state.json

python3 - <<'PY'
import json
from pathlib import Path

p = Path("/var/lib/wazuh-collector/state.json")
state = json.loads(p.read_text())
print("state inode:", state.get("inode"))
print("state offset:", state.get("offset"))
PY

echo
echo "=== CURRENT ALERT FILE ==="
stat -c 'inode=%i | size=%s bytes' \
  /var/ossec/logs/alerts/alerts.json
```

保存されているinode（`5409146`）は、現在の `alerts.json` と同じでした。つまり、ディレクトリを一覧しなくても、現在のファイルを直接開けば再開できる状態です。

```bash
echo "=== STARTUP FILE HANDLING ==="
sed -n '300,390p' /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== INODE SEARCH REFERENCES ==="
grep -n -C 4 'find_inode_file\|open_initial_file' \
  /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== ROTATION HANDLING ==="
sed -n '500,680p' /usr/local/lib/wazuh-collector/collector.py
```

# 第9章　起動処理の修正

修正は、ここでもテスト版に対して行い、検証してから本番に反映します。

## 9.1　現在のファイルを優先する起動処理

方針は次の2つです。

1. 保存されているinodeが現在の `alerts.json` と同じなら、ディレクトリを一覧せずに、現在のファイルを直接開いて再開する。
2. ディレクトリを一覧できない場合でも、`find_inode_file()` は例外で落ちずに、警告を出して `None` を返す。

修正の前にテスト版をバックアップします。

**実行先：security-core VM 220（root）**

```bash
set -e

cp -a \
  /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.backup-before-startup-permission-fix-20261119

sha256sum \
  /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.backup-before-startup-permission-fix-20261119
```

`find_inode_file()` と `open_initial_file()` をまとめて置き換えます。

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text()

start = source.index("def find_inode_file(inode):")
end = source.index("def safe_open_current_alert_file():", start)

replacement = '''def find_inode_file(inode):
    try:
        entries = os.scandir(ALERT_DIR)
    except OSError as error:
        logging.warning(
            "Cannot scan alert directory for previous inode: %s",
            type(error).__name__,
        )
        return None

    with entries:
        for entry in entries:
            try:
                if entry.is_file(follow_symlinks=False):
                    if entry.inode() == inode:
                        return Path(entry.path)
            except OSError:
                continue

    return None


def open_initial_file(state):
    if state is None:
        handle = ALERT_FILE.open("rb")
        try:
            actual_stat = os.fstat(handle.fileno())
            handle.seek(0, os.SEEK_END)
            offset = handle.tell()
            save_state(actual_stat.st_ino, offset)
            logging.info("Initial start at current end of alerts.json")
            return handle, actual_stat.st_ino
        except Exception:
            handle.close()
            raise

    old_inode, old_offset = state

    # Prefer the current alerts.json. This avoids directory enumeration
    # when the saved inode is still the active file.
    handle = ALERT_FILE.open("rb")
    try:
        actual_stat = os.fstat(handle.fileno())
        if actual_stat.st_ino == old_inode:
            handle.seek(min(old_offset, actual_stat.st_size))
            logging.info("Resuming current alert file")
            return handle, actual_stat.st_ino
        handle.close()
        handle = None
    except Exception:
        if handle is not None:
            handle.close()
        raise

    # The active file changed. Try to resume the previous rotated file.
    old_path = find_inode_file(old_inode)

    if old_path is not None:
        handle = None
        try:
            handle = old_path.open("rb")
            actual_stat = os.fstat(handle.fileno())

            if actual_stat.st_ino == old_inode:
                handle.seek(min(old_offset, actual_stat.st_size))
                logging.info("Resuming previous rotated alert file")
                return handle, actual_stat.st_ino

            handle.close()
            handle = None
            logging.warning(
                "Previous rotated file changed while opening; using current file"
            )
        except Exception:
            if handle is not None:
                try:
                    handle.close()
                except OSError:
                    pass
            raise

    handle = ALERT_FILE.open("rb")
    try:
        actual_stat = os.fstat(handle.fileno())

        if actual_stat.st_ino == old_inode:
            handle.seek(min(old_offset, actual_stat.st_size))
        else:
            handle.seek(0)
            logging.warning(
                "Previous rotated alert file unavailable; replaying current file"
            )

        return handle, actual_stat.st_ino
    except Exception:
        handle.close()
        raise


'''

path.write_text(source[:start] + replacement + source[end:])
print("Patched test copy only:", path)
PY

python3 -m py_compile /tmp/wazuh-collector-hardening-test.py &&
sha256sum /tmp/wazuh-collector-hardening-test.py &&
sed -n '310,420p' /tmp/wazuh-collector-hardening-test.py
```

## 9.2　ローテーション済みファイルの置き場所

旧ファイルを探すときの前提を確認します。日付ごとのアーカイブは、`alerts` の直下ではなく `年/月` のサブディレクトリにあります。

**実行先：security-core VM 220（root）**

```bash
find /var/ossec/logs/alerts/2026/Nov \
  -maxdepth 1 -type f \
  -printf '%f | inode=%i | size=%s bytes\n' \
  | sort
```

現在の `alerts.json` は、日付ごとのアーカイブ `ossec-alerts-18.json` と同じinodeです。日付が変わると、`alerts` の直下には新しい `alerts.json` だけが残り、前日分は `年/月` の下に移ります。つまり、`alerts` の直下だけを探す `find_inode_file()` では、ローテーションされた旧ファイルは見つかりません。

9.1の最後の処理のように、旧ファイルが見つからないときに現在のファイルの先頭から黙って読み直すと、旧ファイルの読み残しを取りこぼしたことに気づけません。そこで、**旧ファイルを確認できない場合は、安全側に倒して起動を拒否する（fail-closed）** ように変更します。

## 9.3　安全側に倒す起動処理

**実行先：security-core VM 220（root）**

```bash
sed -n '300,430p' \
  /tmp/wazuh-collector-hardening-test.py
```

```bash
set -e

cp -a \
  /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.backup-before-fail-closed-20261119

sha256sum \
  /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.backup-before-fail-closed-20261119

cmp \
  /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.backup-before-fail-closed-20261119

echo "PASS: backup verified"
```

`open_initial_file()` だけを置き換えます（9.1の `find_inode_file()` はそのまま使います）。

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")

start = source.index("def open_initial_file(state):\n")
end = source.index("\ndef safe_open_current_alert_file():\n", start)

replacement = '''def open_initial_file(state):
    if state is None:
        handle = ALERT_FILE.open("rb")
        try:
            actual_stat = os.fstat(handle.fileno())
            handle.seek(0, os.SEEK_END)
            offset = handle.tell()
            save_state(actual_stat.st_ino, offset)
            logging.info("Initial start at current end of alerts.json")
            return handle, actual_stat.st_ino
        except Exception:
            handle.close()
            raise

    old_inode, old_offset = state

    # First check whether the saved inode is still the current file.
    handle = ALERT_FILE.open("rb")
    try:
        actual_stat = os.fstat(handle.fileno())
        if actual_stat.st_ino == old_inode:
            handle.seek(min(old_offset, actual_stat.st_size))
            logging.info("Resuming current alert file")
            return handle, actual_stat.st_ino
    except Exception:
        handle.close()
        raise

    handle.close()

    # The current file changed. Resume only if the previous inode
    # can be located and verified. Never silently skip its remaining data.
    old_path = find_inode_file(old_inode)

    if old_path is None:
        raise RuntimeError(
            "Previous alert file cannot be located; refusing unsafe resume"
        )

    handle = None
    try:
        handle = old_path.open("rb")
        actual_stat = os.fstat(handle.fileno())

        if actual_stat.st_ino != old_inode:
            raise RuntimeError(
                "Previous alert file inode changed; refusing unsafe resume"
            )

        handle.seek(min(old_offset, actual_stat.st_size))
        logging.info("Resuming previous rotated alert file")
        return handle, actual_stat.st_ino

    except Exception:
        if handle is not None:
            try:
                handle.close()
            except OSError:
                pass
        raise

'''
path.write_text(source[:start] + replacement + source[end:], encoding="utf-8")
print("PASS: open_initial_file replaced")
PY

python3 -m py_compile /tmp/wazuh-collector-hardening-test.py

sha256sum /tmp/wazuh-collector-hardening-test.py
```

## 9.4　起動処理の回帰テスト

3つの条件を一時ディレクトリで確認します。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import importlib.util
import tempfile
from pathlib import Path
from unittest.mock import patch

spec = importlib.util.spec_from_file_location(
    "collector_test",
    "/tmp/wazuh-collector-hardening-test.py",
)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

with tempfile.TemporaryDirectory() as tmp:
    directory = Path(tmp)
    current = directory / "alerts.json"
    current.write_bytes(b"current-event\n")

    rotated = directory / "ossec-alerts-18.json"
    rotated.write_bytes(b"old-event\n")

    m.ALERT_DIR = directory
    m.ALERT_FILE = current
    m.save_state = lambda inode, offset: None

    current_inode = current.stat().st_ino
    rotated_inode = rotated.stat().st_ino

    # Test 1: same inode resumes without directory enumeration.
    with patch.object(
        m.os,
        "scandir",
        side_effect=AssertionError("unexpected directory scan"),
    ):
        handle, inode = m.open_initial_file((current_inode, 3))
        try:
            assert inode == current_inode
            assert handle.tell() == 3
        finally:
            handle.close()
    print("PASS: same inode resumes without directory scan")

    # Test 2: previous rotated inode is located and resumed.
    handle, inode = m.open_initial_file((rotated_inode, 4))
    try:
        assert inode == rotated_inode
        assert Path(handle.name) == rotated
        assert handle.tell() == 4
    finally:
        handle.close()
    print("PASS: previous rotated file resumes at saved offset")

    # Test 3: denied directory scan must fail closed.
    with patch.object(
        m.os,
        "scandir",
        side_effect=PermissionError("test permission denial"),
    ):
        try:
            m.open_initial_file((999999999, 7))
        except RuntimeError as error:
            assert "refusing unsafe resume" in str(error)
        else:
            raise AssertionError("unsafe fallback was not rejected")
    print("PASS: inaccessible previous inode is rejected")

print("ALL STEP324-22 TESTS PASSED")
PY
```

| テスト | 確認内容 |
|---|---|
| 1 | inodeが同じなら、ディレクトリを一覧せずに保存位置から再開する |
| 2 | 旧ファイルが見つかれば、保存位置から再開する |
| 3 | 旧ファイルを確認できなければ、起動を拒否する |

> テスト3のとおり、旧ファイルを確認できない状態で起動すると、Collectorはエラーで停止し、systemdが再起動を繰り返します。これは、アラートの取りこぼしを黙って起こさないための意図した動作です。その場合は、状態ファイルとアラートファイルを確認して、原因を取り除いてから起動してください。

## 9.5　候補ファイルの配置とサービスのユーザーでの確認

**実行先：security-core VM 220（root）**

```bash
set -e

install -o root -g root -m 755 \
  /tmp/wazuh-collector-hardening-test.py \
  /usr/local/lib/wazuh-collector/collector.py.candidate

python3 -m py_compile \
  /usr/local/lib/wazuh-collector/collector.py.candidate

echo "=== HASH VERIFICATION ==="
sha256sum \
  /tmp/wazuh-collector-hardening-test.py \
  /usr/local/lib/wazuh-collector/collector.py.candidate

echo "=== FILE PERMISSIONS ==="
stat -c '%n | %U:%G | %a | %s bytes' \
  /usr/local/lib/wazuh-collector/collector.py.candidate
```

構築時の候補ファイルは18,898バイト、SHA-256は `7a816056...` でした。

本番と同じ `wazuh-collector` ユーザーで、本番の状態ファイルを読み、現在の `alerts.json` を正しい位置で開けるかを確認します（読み取りだけで、状態ファイルは変更しません）。拡張子が `.py` ではないため、ローダーを明示して読み込みます。

```bash
sudo -u wazuh-collector /usr/bin/python3 - <<'PY'
import importlib.util
import importlib.machinery

path = "/usr/local/lib/wazuh-collector/collector.py.candidate"

loader = importlib.machinery.SourceFileLoader(
    "collector_candidate",
    path,
)
spec = importlib.util.spec_from_loader(loader.name, loader)

m = importlib.util.module_from_spec(spec)
loader.exec_module(m)

state = m.load_state()
assert state is not None, "collector state is missing"

saved_inode, saved_offset = state
handle, active_inode = m.open_initial_file(state)

try:
    actual_offset = handle.tell()

    assert active_inode == saved_inode, "inode mismatch"
    assert actual_offset == saved_offset, "offset mismatch"

    print("PASS: service user loaded state")
    print("PASS: service user opened alerts.json")
    print("PASS: saved inode matched current inode")
    print("PASS: saved offset restored")
    print("inode:", active_inode)
    print("offset:", actual_offset)
finally:
    handle.close()

print("ALL STEP324-24 TESTS PASSED")
PY
```

構築時は inode `5409146`、位置 `2178712` で、保存されていた値と一致しました。

# 第10章　再反映と運用の確認

## 10.1　修正版の本番への反映

Collectorが止まっている（`inactive`）こと、本番のコードが8.4で反映した版（`d404f10a...`）であることを確かめてから、その版を別名で保全し、修正版に置き換えます。どれか1つでも条件を満たさなければ、`set -e` によりそこで止まります。サービスはまだ起動しません。

**実行先：security-core VM 220（root）**

```bash
set -e

PROD=/usr/local/lib/wazuh-collector/collector.py
CANDIDATE=/usr/local/lib/wazuh-collector/collector.py.candidate
NEW=/usr/local/lib/wazuh-collector/collector.py.new
BACKUP=/usr/local/lib/wazuh-collector/collector.py.backup-before-fail-closed-20261119

echo "=== PRECHECK ==="

test "$(sha256sum "$PROD" | awk '{print $1}')" = \
  "d404f10ac8aea659a227665e617b2cb9c996b7b989f42dc4a3b8abd648a0796b"

test "$(systemctl is-active wazuh-collector.service)" = "inactive"

test ! -e "$BACKUP"

echo "PASS: production hash verified"
echo "PASS: collector service is inactive"

echo
echo "=== PRESERVE CURRENT PRODUCTION ==="

cp -a "$PROD" "$BACKUP"

echo "=== INSTALL NEW VERSION ==="

install -o root -g root -m 755 "$CANDIDATE" "$NEW"
cmp "$CANDIDATE" "$NEW"
mv -f "$NEW" "$PROD"

echo
echo "=== VERIFY DEPLOYMENT ==="

sha256sum "$PROD" "$BACKUP"

stat -c '%n | %U:%G | %a | %s bytes' "$PROD" "$BACKUP"

echo "PASS: atomic deployment completed"
```

> ハッシュの値 `d404f10a...` は、構築時に8.4で反映した版のものです。お使いの環境では、8.4の後に表示された自分の値に置き換えてください。

| ファイル | 内容 |
|---|---|
| `collector.py` | 修正版（`7a816056...`、18,898バイト） |
| `collector.py.backup-before-fail-closed-20261119` | 8.4で反映した版（`d404f10a...`） |
| `collector.py.backup-20261119` | 第4部より前の本番版（`931ee3cb...`） |
| `collector.py.backup-pre-hardening-20261118` | 同上（第4部1.5で作成） |

## 10.2　起動前の確認と起動

**実行先：security-core VM 220（root）**

```bash
set -e

echo "=== PYTHON SYNTAX ==="
python3 -m py_compile \
  /usr/local/lib/wazuh-collector/collector.py

echo "PASS: Python syntax"

echo
echo "=== PRODUCTION HASH ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== SERVICE STATUS ==="
systemctl is-active wazuh-collector.service || true
systemctl show wazuh-collector.service \
  -p User -p Group -p ExecStart -p Restart -p RestartSec

echo
echo "=== STATE FILE PERMISSIONS ==="
stat -c '%n | %U:%G | %a | %s bytes' \
  /var/lib/wazuh-collector/state.json
```

```bash
systemctl start wazuh-collector.service

sleep 3

echo "=== SERVICE STATUS ==="
systemctl is-active wazuh-collector.service

echo
echo "=== SERVICE DETAILS ==="
systemctl show wazuh-collector.service \
  -p ActiveState \
  -p SubState \
  -p MainPID \
  -p NRestarts \
  -p ExecMainStatus

echo
echo "=== RECENT JOURNAL ==="
journalctl -u wazuh-collector.service -n 20 --no-pager
```

ログに次の3つが出ていれば、修正した起動処理で正常に再開しています（構築時の出力）。

```text
Nov 18 15:31:53 security-core python3[87457]: 2026-11-18 15:31:53,441 INFO Wazuh alert collector starting
Nov 18 15:31:53 security-core python3[87457]: 2026-11-18 15:31:53,441 INFO Resuming current alert file
Nov 18 15:31:53 security-core python3[87457]: 2026-11-18 15:31:53,463 INFO PostgreSQL connection established
```

## 10.3　起動後の安定性と読み取りの追従

**実行先：security-core VM 220（root）**

```bash
echo "=== SERVICE RUNTIME ==="
systemctl show wazuh-collector.service \
  -p ActiveState \
  -p SubState \
  -p MainPID \
  -p NRestarts \
  -p ActiveEnterTimestamp \
  -p ExecMainStartTimestamp

echo
echo "=== PROCESS ==="
ps -p "$(systemctl show -p MainPID --value wazuh-collector.service)" \
  -o pid,etime,%cpu,%mem,stat,cmd

echo
echo "=== LATEST COLLECTOR LOGS ==="
journalctl -u wazuh-collector.service -n 15 --no-pager
```

読み取り位置が `alerts.json` に追いついているかを、サービスのユーザーで確認します（状態ファイルは読むだけです）。

```bash
echo "=== COLLECTOR READ POSITION ==="

sudo -u wazuh-collector /usr/bin/python3 - <<'PY'
import importlib.util
import importlib.machinery
import os

path = "/usr/local/lib/wazuh-collector/collector.py"
loader = importlib.machinery.SourceFileLoader("collector_check", path)
spec = importlib.util.spec_from_loader(loader.name, loader)
m = importlib.util.module_from_spec(spec)
loader.exec_module(m)

state = m.load_state()
assert state is not None, "state missing"

saved_inode, saved_offset = state
current = os.stat(m.ALERT_FILE)

print("saved_inode:", saved_inode)
print("current_inode:", current.st_ino)
print("saved_offset:", saved_offset)
print("current_file_size:", current.st_size)

if saved_inode == current.st_ino:
    print("unread_bytes:", max(0, current.st_size - saved_offset))
    print("PASS: state refers to current alerts.json")
else:
    print("NOTICE: state refers to a rotated file")
PY

echo
echo "=== LOGS SINCE CURRENT START ==="
journalctl -u wazuh-collector.service \
  --since "2026-11-18 15:31:53 UTC" \
  --no-pager
```

`--since` の時刻は、起動した時刻に合わせます。30秒後にもう一度、稼働状態と警告の有無を確認します。

```bash
sleep 30

echo "=== SERVICE HEALTH ==="
systemctl show wazuh-collector.service \
  -p ActiveState -p SubState -p MainPID -p NRestarts

echo
echo "=== READ POSITION ==="
sudo -u wazuh-collector /usr/bin/python3 - <<'PY'
import json
import os

state_path = "/var/lib/wazuh-collector/state.json"
alert_path = "/var/ossec/logs/alerts/alerts.json"

with open(state_path, "r", encoding="utf-8") as f:
    state = json.load(f)

st = os.stat(alert_path)

print("saved_inode:", state["inode"])
print("current_inode:", st.st_ino)
print("saved_offset:", state["offset"])
print("current_file_size:", st.st_size)

if state["inode"] == st.st_ino:
    print("unread_bytes:", max(0, st.st_size - state["offset"]))
else:
    print("NOTICE: rotation detected")
PY

echo
echo "=== RECENT ERRORS ==="
journalctl -u wazuh-collector.service \
  --since "1 minute ago" \
  -p warning --no-pager
```

`unread_bytes` が0か小さい値で、`RECENT ERRORS` が `-- No entries --` であれば、新しいアラートに追従して正常に動いています。

## 10.4　WazuhとPostgreSQLの件数の照合

DB側の確認は、LXC 109の中で、DB管理者（`postgres`）で行います（プロンプトが `root@postgresql` になります）。

**実行先：LXC 109 postgresql（root）**

```bash
sudo -u postgres psql -X -d security_workbench -c "
SELECT
    COUNT(*) AS total_events,
    MAX(event_timestamp) AS latest_event_timestamp,
    MAX(ingested_at) AS latest_ingested_at,
    COUNT(*) FILTER (
        WHERE ingested_at >= NOW() - INTERVAL '15 minutes'
    ) AS ingested_last_15m
FROM incident.alert_events;
"
```

```bash
sudo -u postgres psql -X -d security_workbench -c "
SELECT
    COUNT(*) AS total_events,
    MIN(event_timestamp) AS earliest_event,
    MAX(event_timestamp) AS latest_event,
    MIN(ingested_at) AS earliest_ingested,
    MAX(ingested_at) AS latest_ingested
FROM incident.alert_events;
"
```

DBに入っている最も古いアラートの時刻（構築時は `2026-11-18 11:00:59 UTC`、第3部でCollectorを初めて起動した直後）を基準に、Wazuh側の同じ期間の件数を数えます。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import json

path = "/var/ossec/logs/alerts/alerts.json"
count = 0
invalid = 0

with open(path, "rb") as f:
    for line in f:
        if not line.strip():
            continue
        try:
            json.loads(line)
            count += 1
        except (json.JSONDecodeError, UnicodeDecodeError):
            invalid += 1

print("valid_json_records:", count)
print("invalid_records:", invalid)
PY
```

```bash
python3 - <<'PY'
import json
from datetime import datetime, timezone

path = "/var/ossec/logs/alerts/alerts.json"
start = datetime(2026, 11, 18, 11, 0, 59, tzinfo=timezone.utc)

total = 0
matched = 0
invalid = 0
missing_timestamp = 0

with open(path, "rb") as f:
    for line in f:
        if not line.strip():
            continue

        try:
            obj = json.loads(line)
            total += 1
            value = obj.get("timestamp")

            if not isinstance(value, str):
                missing_timestamp += 1
                continue

            ts = datetime.fromisoformat(value.replace("Z", "+00:00"))

            if ts.tzinfo is None:
                continue

            if ts.astimezone(timezone.utc) >= start:
                matched += 1

        except (json.JSONDecodeError, UnicodeDecodeError, ValueError):
            invalid += 1

print("total_records:", total)
print("records_since_2026-11-18_11:00:59_UTC:", matched)
print("missing_timestamp:", missing_timestamp)
print("invalid_records:", invalid)
PY
```

`start` の日時は、自分の環境のDBの最も古いアラートの時刻に置き換えます。続けて、DB側も同じ期間で数え直します。

**実行先：LXC 109 postgresql（root）**

```bash
sudo -u postgres psql -X -d security_workbench -c "
SELECT
    COUNT(*) AS total_events,
    COUNT(*) FILTER (
        WHERE event_timestamp >= TIMESTAMPTZ '2026-11-18 11:00:59+00'
    ) AS events_in_comparison_period,
    MAX(event_timestamp) AS latest_event_timestamp,
    MAX(ingested_at) AS latest_ingested_at,
    COUNT(*) FILTER (
        WHERE ingested_at >= NOW() - INTERVAL '5 minutes'
    ) AS ingested_last_5m
FROM incident.alert_events;
"
```

> ファイルとDBを別々の時刻に数えると、その間に増えたアラートの分だけ差が出ます。差がある場合は、続けてもう一度両方を数えてください。

構築時の照合結果：

| 項目 | 件数 |
|---|---:|
| Wazuh `alerts.json`（同じ期間） | 230 |
| PostgreSQL `incident.alert_events`（同じ期間） | 230 |
| 差 | 0 |

# 第5部のまとめ

第5部で、強化版のCollectorが本番で動き始めました。

| 項目 | 状態 |
|---|---|
| 本番のCollector | `/usr/local/lib/wazuh-collector/collector.py`（強化版、18,898バイト） |
| サービス | `wazuh-collector.service`（active、自動起動） |
| 起動時の処理 | 現在のファイルを優先して再開し、旧ファイルを確認できない場合は起動を拒否（fail-closed） |
| 照合結果 | 同じ期間のWazuhのアラートとDBの件数が一致（230件） |

第4部・第5部を通じて、Collectorに加えた強化は次のとおりです。

| 領域 | 内容 |
|---|---|
| 入力 | 型・範囲・長さの検証、制御文字（C0・DEL・C1・Unicodeの書式制御文字）の除去、日時の長さの上限 |
| 行サイズ | 1行1 MiBの上限、64 KiB単位の読み飛ばし |
| ローテーション | 未完了の行・EOF・読み飛ばし中の切り替え、実際に開いたファイルのinode、`stat`・`open`・`fstat` の失敗時の再試行 |
| 状態ファイル | 値の厳格な検証、DB登録の成功後にだけ保存 |
| DB | 接続失敗時の巻き戻しと再接続、一意制約による重複の拒否（SELECT権限は不要） |
| 起動と終了 | 最小権限のままの起動、fail-closed、ファイルとDB接続の独立したクローズ |

> **運用上の注意：** 9.2のとおり、日付ごとのアーカイブは `alerts/年/月` に移るため、Collectorが止まっている間に日付が変わると、起動時に旧ファイルを確認できず、起動を拒否します。長時間止めたあとに起動できない場合は、状態ファイルと `alerts` 以下を確認してから対処してください。

次の段階では、DBに蓄積したアラートの重複防止とデータの整合性をさらに確かめ（STEP 325以降）、監視の仕組みを広げていきます。
