---
title: "AI自律型サイバー防御システム 構築マニュアル 前編"
subtitle: "第3部　アラート保存Collectorの構築"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」前編の第3部です。Wazuhが検知したアラートをPostgreSQLに保存し、インシデントとして管理するための仕組み（Incident Collector）を構築します。

| 構成要素 | 役割 |
|---|---|
| Wazuh Manager（VM 220） | 検知・相関分析を行い、アラートを `alerts.json` に記録する |
| Incident Collector（VM 220） | アラートを読み取り、検証し、重複を除いてDBへ登録する |
| PostgreSQL（LXC 109） | インシデントDB・イベント履歴を保存する |
| AI分析エージェント（今後） | 脅威の評価、優先順位付け、対応の提案を行う |

## 本書の表記

- コマンドやファイル内容は、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 各手順の冒頭に「実行先」を示します。LXC 109への操作はProxmoxホストから `pct exec 109 --` で、VM 220への操作はProxmoxホストから `qm guest exec 220 --` で実行します（VM 220に直接ログインして実行する手順もあります）。
- 「実行結果（例）」は構築時の実際の出力です。お使いの環境では、IDや日時などが異なります。
- パスワードは画面やチャット、コマンド履歴に残さない方法で設定します。

## 第2部終了時点の状態

| 項目 | 状態 |
|---|---|
| Wazuh Manager | VM 220（`192.168.0.220`）、4.14.10 |
| PostgreSQL | LXC 109（`192.168.0.151`）、17.11 |
| PostgreSQL監視 | サニタイズフィルター、ルール100100〜100106 |

# 第1章　保存先データベースの準備

既存のPostgreSQLやWazuhの設定を壊さないよう、まずデータベースの構成を調べてから、インシデント管理用のスキーマとロールを作ります。

## 1.1　既存データベースの確認

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
echo "===== POSTGRESQL DATABASE INVENTORY ====="

runuser -u postgres -- psql -X -P pager=off -c "
SELECT
    datname AS database,
    pg_catalog.pg_get_userbyid(datdba) AS owner,
    pg_size_pretty(pg_database_size(datname)) AS size,
    datallowconn AS allow_connections
FROM pg_database
WHERE datistemplate = false
ORDER BY datname;
"

echo
echo "===== POSTGRESQL VERSION ====="
runuser -u postgres -- psql -X -Atc "SELECT version();"
'
```

構築時は17個のデータベースがあり、その中にセキュリティ用途の `security_workbench`（所有者 `security_workbench`）がありました。

## 1.2　security_workbenchの中身の確認

新しいデータベースを作る前に、`security_workbench` がすでに使われていないかを確認します。この節の操作はすべて読み取り専用です。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
runuser -u postgres -- psql -X -d security_workbench -P pager=off -c "
SELECT
    schemaname AS schema,
    tablename AS table,
    tableowner AS owner
FROM pg_tables
WHERE schemaname NOT IN (
    '\''pg_catalog'\'',
    '\''information_schema'\''
)
ORDER BY schemaname, tablename;
"
'
```

ユーザーテーブルが `(0 rows)` であることを確認します。

スキーマとロールを確認します。

```bash
pct exec 109 -- bash -c '
runuser -u postgres -- psql -X -d security_workbench -P pager=off -c "
SELECT schema_name, schema_owner
FROM information_schema.schemata
WHERE schema_name NOT IN (
    '\''pg_catalog'\'',
    '\''information_schema'\''
)
ORDER BY schema_name;
"

echo "===== ROLES ====="

runuser -u postgres -- psql -X -d security_workbench -P pager=off -c "
SELECT rolname, rolsuper, rolcreatedb, rolcreaterole, rolcanlogin
FROM pg_roles
WHERE rolname IN (
    '\''security_workbench'\'',
    '\''postgres'\''
)
ORDER BY rolname;
"
'
```

`public` スキーマに対する権限を確認します。

```bash
pct exec 109 -- bash -c '
runuser -u postgres -- psql -X -d security_workbench -P pager=off -c "
SELECT
    '\''security_workbench'\'' AS role,
    has_schema_privilege(
        '\''security_workbench'\'',
        '\''public'\'',
        '\''USAGE'\''
    ) AS public_usage,
    has_schema_privilege(
        '\''security_workbench'\'',
        '\''public'\'',
        '\''CREATE'\''
    ) AS public_create,
    '\''postgres'\'' AS admin_role,
    has_schema_privilege(
        '\''postgres'\'',
        '\''public'\'',
        '\''CREATE'\''
    ) AS postgres_create;
"
'
```

| 項目 | 構築時の状態 |
|---|---|
| ユーザーテーブル | 0件 |
| ユーザースキーマ | `public` のみ |
| `security_workbench` ロール | 一般ユーザー（SUPERUSER・CREATEDB・CREATEROLEなし、LOGINあり） |
| `public` スキーマの権限 | `security_workbench` に USAGE・CREATE あり |

> `information_schema.schema_privileges` というビューはPostgreSQL 17には存在しません。スキーマの権限は、上のように `has_schema_privilege()` 関数で確認します。

**決定事項：** 既存の `security_workbench` データベースを使います。ただし既存の `public` スキーマには手を加えず、インシデント管理専用の `incident` スキーマを新しく作ります。また、Wazuhからイベントを書き込む「収集用ロール」と、スキーマ・テーブルを管理するロール（`postgres`）を分けます。既存の `security_workbench` ロールの権限は変更しません。

## 1.3　専用スキーマの作成

ここからデータベースへの変更が始まります。この操作は専用スキーマを1つ作るだけで、既存のテーブルやデータには触れません。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
set -e

runuser -u postgres -- psql -X -v ON_ERROR_STOP=1 \
  -d security_workbench \
  -c "CREATE SCHEMA incident AUTHORIZATION postgres;"

echo
echo "===== VERIFY INCIDENT SCHEMA ====="

runuser -u postgres -- psql -X -d security_workbench -c "
SELECT
    schema_name,
    schema_owner
FROM information_schema.schemata
WHERE schema_name = '\''incident'\'';
"
'
```

実行結果（例）：

```text
CREATE SCHEMA

===== VERIFY INCIDENT SCHEMA =====
 schema_name | schema_owner 
-------------+--------------
 incident    | postgres
(1 row)
```

## 1.4　収集用ロールの作成

ロール名 `wazuh_collector` がまだ使われていないことを確認します。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
runuser -u postgres -- psql -X -P pager=off -c "
SELECT
    rolname,
    rolsuper,
    rolcreatedb,
    rolcreaterole,
    rolcanlogin
FROM pg_roles
WHERE rolname = '\''wazuh_collector'\'';
"
'
```

`(0 rows)` であれば、名前の衝突はありません。

まず、ログインできない状態で、管理者権限を一切持たないロールを作ります。

```bash
pct exec 109 -- bash -c '
set -e

runuser -u postgres -- psql -X -v ON_ERROR_STOP=1 \
  -d security_workbench \
  -c "CREATE ROLE wazuh_collector
      NOLOGIN
      NOSUPERUSER
      NOCREATEDB
      NOCREATEROLE
      NOREPLICATION
      NOBYPASSRLS
      NOINHERIT;"

echo
echo "===== VERIFY COLLECTOR ROLE ====="

runuser -u postgres -- psql -X -P pager=off -c "
SELECT
    rolname,
    rolsuper,
    rolcreatedb,
    rolcreaterole,
    rolreplication,
    rolbypassrls,
    rolinherit,
    rolcanlogin
FROM pg_roles
WHERE rolname = '\''wazuh_collector'\'';
"
'
```

すべての列が `f`（無効）になっていれば、安全な初期状態です。

## 1.5　パスワードの設定

パスワードをシェルの履歴やSQLに残さないため、PostgreSQLの対話型のパスワード設定機能を使います。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- runuser -u postgres -- psql -X -d security_workbench
```

`security_workbench=#` のプロンプトが表示されたら、次を入力します。

```text
\password wazuh_collector
```

新しいパスワードを2回入力します（入力中の文字は表示されません）。

- 十分に長いランダムなパスワード（32文字以上を推奨）にしてください。
- パスワードマネージャーなどに安全に保管し、チャットや資料には貼らないでください。

設定が終わったら、次を入力して終了します。

```text
\q
```

この段階では、まだログインは許可しません。

## 1.6　接続とスキーマ利用の権限の付与

データベースへの接続と、`incident` スキーマの利用だけを許可します。オブジェクトの作成権限や管理者権限は付与しません。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
set -e

runuser -u postgres -- psql -X -v ON_ERROR_STOP=1 \
  -d security_workbench <<'"'"'SQL'"'"'
GRANT CONNECT ON DATABASE security_workbench TO wazuh_collector;
GRANT USAGE ON SCHEMA incident TO wazuh_collector;
SQL

echo
echo "===== VERIFY PRIVILEGES ====="

runuser -u postgres -- psql -X -d security_workbench -P pager=off -c "
SELECT
    has_database_privilege(
        '\''wazuh_collector'\'',
        '\''security_workbench'\'',
        '\''CONNECT'\''
    ) AS can_connect,
    has_schema_privilege(
        '\''wazuh_collector'\'',
        '\''incident'\'',
        '\''USAGE'\''
    ) AS can_use_incident_schema,
    has_schema_privilege(
        '\''wazuh_collector'\'',
        '\''incident'\'',
        '\''CREATE'\''
    ) AS can_create_objects;
"
'
```

| 権限 | 期待値 |
|---|---|
| DBへの接続（CONNECT） | `t` |
| `incident` スキーマの利用（USAGE） | `t` |
| `incident` スキーマでの作成（CREATE） | `f` |

# 第2章　ネットワークとTLSの確認

Wazuh Manager（`192.168.0.220`）からPostgreSQL（`192.168.0.151`）へ、安全に接続できるようにします。ログインを許可する前に、待ち受けの設定・接続許可の設定・TLS証明書を確認します。この章の操作はすべて読み取り専用です。

## 2.1　待ち受けと接続許可の設定の確認

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
echo "===== POSTGRESQL NETWORK SETTINGS ====="

runuser -u postgres -- psql -X -P pager=off -c "
SELECT
    name,
    setting,
    source,
    pending_restart
FROM pg_settings
WHERE name IN (
    '\''listen_addresses'\'',
    '\''port'\'',
    '\''ssl'\'',
    '\''password_encryption'\'',
    '\''hba_file'\''
)
ORDER BY name;
"

echo
echo "===== LISTENING SOCKETS ====="
ss -lntp | grep ":5432" || true

echo
echo "===== PG_HBA CONFIGURATION ====="
runuser -u postgres -- psql -X -P pager=off -c "
SELECT
    line_number,
    type,
    database,
    user_name,
    address,
    auth_method,
    error
FROM pg_hba_file_rules
ORDER BY line_number;
"
'
```

`pg_hba.conf` の実際の内容と、解析された規則（ネットマスクを含む）を確認します。

```bash
pct exec 109 -- bash -c '
echo "===== PG_HBA FILE ====="
nl -ba /etc/postgresql/17/main/pg_hba.conf

echo
echo "===== PARSED HBA RULES ====="
runuser -u postgres -- psql -X -P pager=off -c "
SELECT
    line_number,
    type,
    database,
    user_name,
    address,
    netmask,
    auth_method,
    error
FROM pg_hba_file_rules
ORDER BY line_number;
"
'
```

構築時は、PostgreSQLがIPv4・IPv6のすべてのインターフェースで5432番を待ち受けており、`pg_hba.conf` の11行目に次の広い接続許可がありました。

```text
host    all    all    0.0.0.0/0    md5
```

これは、IPv4の任意の接続元に、すべてのデータベース・すべてのユーザーへの接続を許可する規則です（認証は必要です）。既存のアプリケーションの接続を壊さないよう、この規則はここでは変更しません。Wazuh用の接続許可は、別の専用規則として追加します（第3章）。

> **メモ：** この広い許可ルールは、既存の運用に合わせてそのまま使います。セキュリティ上の問題になる場合は、後で接続元を限定するよう修正します。

## 2.2　Wazuh ManagerからのTCP接続の確認

データベースへのログインはせず、TCPの接続だけを確認します。

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
echo "===== POSTGRESQL TCP CONNECTIVITY ====="
nc -vz -w 3 192.168.0.151 5432
'
```

`err-data` に `Connection to 192.168.0.151 5432 port [tcp/postgresql] succeeded!` と表示されれば、通信経路は確保できています。

## 2.3　TLS証明書の確認

認証情報を含む通信を暗号化するため、PostgreSQLのTLS設定を確認します。秘密鍵の中身は表示しません。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
set -e

echo "===== TLS CONFIGURATION ====="

runuser -u postgres -- psql -X -P pager=off -c "
SELECT name, setting
FROM pg_settings
WHERE name IN (
    '\''ssl'\'',
    '\''ssl_cert_file'\'',
    '\''ssl_key_file'\'',
    '\''ssl_ca_file'\'',
    '\''data_directory'\''
)
ORDER BY name;
"

echo
echo "===== SERVER CERTIFICATE ====="

CERT=$(runuser -u postgres -- psql -X -Atc "SHOW ssl_cert_file;")
DATA=$(runuser -u postgres -- psql -X -Atc "SHOW data_directory;")

case "$CERT" in
    /*) CERT_PATH="$CERT" ;;
    *) CERT_PATH="$DATA/$CERT" ;;
esac

if [ -f "$CERT_PATH" ]; then
    stat -c "%U:%G %a %n" "$CERT_PATH"
    openssl x509 -in "$CERT_PATH" -noout -subject -issuer -dates
else
    echo "Certificate file not found: $CERT_PATH"
fi
'
```

```bash
pct exec 109 -- bash -c '
echo "===== CERTIFICATE SAN ====="
openssl x509 \
  -in /etc/ssl/certs/ssl-cert-snakeoil.pem \
  -noout -ext subjectAltName

echo
echo "===== CERTIFICATE FINGERPRINT ====="
openssl x509 \
  -in /etc/ssl/certs/ssl-cert-snakeoil.pem \
  -noout -fingerprint -sha256

echo
echo "===== PRIVATE KEY PERMISSIONS ====="
stat -c "%U:%G %a %n" \
  /etc/ssl/private/ssl-cert-snakeoil.key

echo
echo "===== POSTGRESQL SSL GROUP ====="
id postgres
'
```

| 項目 | 構築時の状態 |
|---|---|
| PostgreSQLのSSL | `on` |
| サーバー証明書 | `/etc/ssl/certs/ssl-cert-snakeoil.pem`（自己署名） |
| CN・SAN | `postgresql.neomedia.mydns.jp`（IPアドレスのSANはなし） |
| 有効期限 | 2036年8月11日 |
| CA証明書 | 未設定 |
| 秘密鍵 | `root:ssl-cert 640`（`postgres` は `ssl-cert` グループに所属） |

TLSによる暗号化は有効ですが、自己署名証明書のため、そのままではWazuh側でサーバーが本物かどうかを検証できません。

## 2.4　証明書と秘密鍵の整合性の確認

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
CERT=/etc/ssl/certs/ssl-cert-snakeoil.pem
KEY=/etc/ssl/private/ssl-cert-snakeoil.key

echo "===== SELF-SIGNED CERTIFICATE VALIDATION ====="
openssl verify -CAfile "$CERT" "$CERT"

echo
echo "===== DNS NAME VALIDATION ====="
openssl x509 -in "$CERT" \
  -noout -checkhost postgresql.neomedia.mydns.jp

echo
echo "===== CERTIFICATE PUBLIC KEY HASH ====="
openssl x509 -in "$CERT" -pubkey -noout \
  | openssl pkey -pubin -outform DER \
  | sha256sum

echo
echo "===== PRIVATE KEY PUBLIC KEY HASH ====="
openssl pkey -in "$KEY" -pubout -outform DER \
  | sha256sum
'
```

| 検証 | 期待する結果 |
|---|---|
| 自己署名証明書の検証 | OK |
| DNS名との一致 | `postgresql.neomedia.mydns.jp` と一致 |
| 証明書と秘密鍵の公開鍵のハッシュ | 2つが一致 |

**決定事項：** 証明書はすぐには交換しません。この証明書をWazuh Manager側で「信頼できる証明書」として登録し、接続先の名前まで検証する `verify-full` で接続します。接続先の名前には証明書のDNS名を使い、IPアドレスは `192.168.0.151` に固定します。

# 第3章　Wazuh Manager側の接続準備

## 3.1　TLSハンドシェイクの確認

VM 220からPostgreSQLへのTLS接続を確認します。DBへのログインはしません。

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
echo "===== POSTGRESQL TLS HANDSHAKE ====="

timeout 10 openssl s_client \
  -starttls postgres \
  -connect 192.168.0.151:5432 \
  -servername postgresql.neomedia.mydns.jp \
  -showcerts </dev/null 2>&1 \
  | grep -E "CONNECTED|subject=|issuer=|Protocol|Cipher|Verify return code|BEGIN CERTIFICATE|END CERTIFICATE"
'
```

構築時は `TLSv1.3`・`TLS_AES_256_GCM_SHA384` で接続できました。`Verify return code: 18 (self-signed certificate)` は接続の失敗ではなく、VM 220がまだこの自己署名証明書を信頼していないという意味です。

## 3.2　受け取った証明書の指紋の照合

VM 220が受け取った証明書を一時ファイルに保存し、SHA-256の指紋を表示します。

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
set -e

CERT=/tmp/postgresql-server-ca.pem

timeout 10 openssl s_client \
  -starttls postgres \
  -connect 192.168.0.151:5432 \
  -servername postgresql.neomedia.mydns.jp \
  -showcerts </dev/null 2>/dev/null \
  | sed -n "/-----BEGIN CERTIFICATE-----/,/-----END CERTIFICATE-----/p" \
  > "$CERT"

echo "===== RECEIVED CERTIFICATE ====="
openssl x509 -in "$CERT" -noout -subject -issuer

echo
echo "===== SHA256 FINGERPRINT ====="
openssl x509 -in "$CERT" -noout -fingerprint -sha256
'
```

表示された指紋が、2.3でLXC 109の中で確認した指紋と完全に一致することを確認します。構築時の指紋は次のとおりでした。

```text
3D:69:26:B8:3B:D0:2B:BE:00:BA:E0:53:2E:B7:9F:BE:9B:3A:36:D8:09:5C:59:73:76:52:7A:3D:F1:33:45:81
```

一致すれば、ネットワーク経由で受け取った証明書が、PostgreSQLサーバーの本物の証明書であると確認できます。

## 3.3　専用の信頼済み証明書として配置

OS全体のCAストアには登録せず、PostgreSQL接続専用のファイルとして配置します。

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
set -e

install -o root -g root -m 0644 \
  /tmp/postgresql-server-ca.pem \
  /etc/ssl/certs/postgresql-server-ca.pem

echo "===== CERTIFICATE FILE ====="
stat -c "%U:%G %a %s %n" \
  /etc/ssl/certs/postgresql-server-ca.pem

echo
echo "===== TRUST VALIDATION ====="
openssl verify \
  -CAfile /etc/ssl/certs/postgresql-server-ca.pem \
  /etc/ssl/certs/postgresql-server-ca.pem

echo
echo "===== HOSTNAME VALIDATION ====="
openssl x509 \
  -in /etc/ssl/certs/postgresql-server-ca.pem \
  -noout -checkhost postgresql.neomedia.mydns.jp
'
```

`/etc/ssl/certs/postgresql-server-ca.pem: OK` と `Hostname postgresql.neomedia.mydns.jp does match certificate` が表示されれば成功です。

## 3.4　PostgreSQLクライアントの導入

VM 220にPostgreSQLのクライアント（`psql`）があるかを確認します。

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
echo "===== PSQL CLIENT ====="
command -v psql || true

echo
echo "===== PSQL VERSION ====="
psql --version 2>/dev/null || true

echo
echo "===== CERTIFICATE READ ACCESS ====="
test -r /etc/ssl/certs/postgresql-server-ca.pem \
  && echo "OK: certificate is readable" \
  || echo "ERROR: certificate is not readable"
'
```

`psql` がなければ、Ubuntu標準のパッケージを確認してインストールします。PostgreSQLサーバー本体はインストールしません。

```bash
qm guest exec 220 -- bash -c '
echo "===== POSTGRESQL CLIENT PACKAGE ====="
apt-cache policy postgresql-client
'
```

```bash
qm guest exec 220 -- bash -c '
apt-get update &&
DEBIAN_FRONTEND=noninteractive apt-get install -y postgresql-client
'
```

Ubuntu 24.04標準の `postgresql-client`（バージョン16）が入ります。PostgreSQL 17のサーバーへの接続にも使えます。

## 3.5　接続パラメーターの確認

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
echo "===== PSQL VERSION ====="
psql --version

echo
echo "===== HOSTNAME RESOLUTION ====="
getent hosts postgresql.neomedia.mydns.jp || true

echo
echo "===== DATABASE PORT ====="
nc -vz -w 3 192.168.0.151 5432
'
```

構築時は、証明書のDNS名 `postgresql.neomedia.mydns.jp` は名前解決できませんでした。DNSに登録する必要はありません。`PGHOSTADDR`（または `hostaddr`）で接続先のIPアドレスを指定し、`PGHOST`（`host`）で証明書のDNS名を指定すれば、IPで接続しながらホスト名の検証もできます。

この組み合わせで、パラメーターと証明書を確認します。パスワードは設定せず、ログインもしません。

```bash
qm guest exec 220 -- bash -c '
export PGHOST=postgresql.neomedia.mydns.jp
export PGHOSTADDR=192.168.0.151
export PGPORT=5432
export PGDATABASE=security_workbench
export PGUSER=wazuh_collector
export PGSSLMODE=verify-full
export PGSSLROOTCERT=/etc/ssl/certs/postgresql-server-ca.pem

echo "===== CONNECTION PARAMETERS ====="
printf "PGHOST=%s\n" "$PGHOST"
printf "PGHOSTADDR=%s\n" "$PGHOSTADDR"
printf "PGPORT=%s\n" "$PGPORT"
printf "PGDATABASE=%s\n" "$PGDATABASE"
printf "PGUSER=%s\n" "$PGUSER"
printf "PGSSLMODE=%s\n" "$PGSSLMODE"
printf "PGSSLROOTCERT=%s\n" "$PGSSLROOTCERT"

echo
echo "===== CERTIFICATE VALIDATION ====="
openssl verify \
  -CAfile "$PGSSLROOTCERT" \
  "$PGSSLROOTCERT"
'
```

| パラメーター | 値 | 意味 |
|---|---|---|
| PGHOSTADDR | `192.168.0.151` | 実際の接続先IP |
| PGHOST | `postgresql.neomedia.mydns.jp` | 証明書で検証する名前 |
| PGSSLMODE | `verify-full` | 暗号化に加え、証明書とホスト名を検証する |
| PGSSLROOTCERT | `/etc/ssl/certs/postgresql-server-ca.pem` | 信頼する証明書 |

# 第4章　専用の接続許可ルールとログインの有効化

`pg_hba.conf` には全IPv4を対象にした広い規則が残っています。そのまま `wazuh_collector` をログイン可能にせず、専用の規則で接続元を限定してから有効にします。

## 4.1　現在の規則と適用範囲の確認

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
runuser -u postgres -- psql -X -d postgres -P pager=off -c "
SELECT
    line_number,
    type,
    database,
    user_name,
    address,
    auth_method,
    error
FROM pg_hba_file_rules
ORDER BY line_number;
"
'
```

```bash
pct exec 109 -- bash -c '
echo "===== HBA NETWORK MASKS ====="
runuser -u postgres -- psql -X -d postgres -P pager=off -c "
SELECT
    line_number,
    type,
    database,
    user_name,
    address,
    netmask,
    auth_method,
    error
FROM pg_hba_file_rules
WHERE type = '\''host'\''
ORDER BY line_number;
"

echo
echo "===== CURRENT HBA FILE ====="
nl -ba /etc/postgresql/17/main/pg_hba.conf
'
```

| 行 | 規則 | 適用範囲 |
|---:|---|---|
| 8 | `0.0.0.0/24`（md5） | `0.0.0.0`〜`0.0.0.255` |
| 11 | `0.0.0.0/0`（md5） | すべてのIPv4アドレス |

既存のアプリケーションを守るため、これらの規則はここでは変更しません。代わりに、`wazuh_collector` 専用の規則を既存の規則より前（ファイルの先頭）に追加します。`pg_hba.conf` は上から順に評価され、最初に一致した規則が使われます。

ファイルの権限と、関連する設定を確認します。

```bash
pct exec 109 -- bash -c '
echo "===== HBA FILE ====="
stat -c "%U:%G %a %n" /etc/postgresql/17/main/pg_hba.conf

echo
echo "===== POSTGRESQL CONFIGURATION ====="
runuser -u postgres -- psql -X -d postgres -P pager=off -c "
SHOW hba_file;
SHOW config_file;
SHOW ssl;
SHOW password_encryption;
"

echo
echo "===== INCLUDE DIRECTIVES ====="
grep -nE "^[[:space:]]*include" \
  /etc/postgresql/17/main/pg_hba.conf || true
'
```

| 項目 | 構築時の状態 |
|---|---|
| `pg_hba.conf` | `postgres:postgres 640` |
| SSL | `on` |
| パスワードの暗号化 | `scram-sha-256` |
| include指定 | なし |

## 4.2　pg_hba.confのバックアップ

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
set -e

FILE=/etc/postgresql/17/main/pg_hba.conf
BACKUP="${FILE}.backup-wazuh-$(date +%Y%m%d-%H%M%S)"

cp -a "$FILE" "$BACKUP"

echo "===== BACKUP CREATED ====="
stat -c "%U:%G %a %s %n" "$BACKUP"

echo
echo "===== SHA256 ====="
sha256sum "$FILE" "$BACKUP"
'
```

元のファイルとバックアップのSHA-256が一致することを確認します。

## 4.3　専用ルールの追加

`pg_hba.conf` の先頭に、`wazuh_collector` 専用の規則を追加します。

| 規則 | 内容 |
|---|---|
| `local ... reject` | Unixソケットからの接続を拒否 |
| `hostssl ... 192.168.0.220/32 scram-sha-256` | Wazuh ManagerからのTLS接続だけを、SCRAM認証で許可 |
| `host ... 0.0.0.0/0 reject` | それ以外のIPv4からの接続を拒否 |
| `host ... ::/0 reject` | IPv6からの接続を拒否 |

他のユーザー向けの規則は変更しません。この段階ではまだ再読み込みしません。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
set -e

python3 - <<'"'"'PY'"'"'
from pathlib import Path

p = Path("/etc/postgresql/17/main/pg_hba.conf")
s = p.read_text()

marker = "# BEGIN WAZUH COLLECTOR ACCESS"

if marker in s:
    raise SystemExit("ERROR: Wazuh rules already exist; no changes made.")

rules = """# BEGIN WAZUH COLLECTOR ACCESS
local   all                 wazuh_collector                         reject
hostssl security_workbench  wazuh_collector  192.168.0.220/32        scram-sha-256
host    all                 wazuh_collector  0.0.0.0/0               reject
host    all                 wazuh_collector  ::/0                    reject
# END WAZUH COLLECTOR ACCESS

"""

p.write_text(rules + s)
PY

echo "===== NEW HBA RULES ====="
sed -n "1,12p" /etc/postgresql/17/main/pg_hba.conf

echo
echo "===== FILE PERMISSIONS ====="
stat -c "%U:%G %a %n" /etc/postgresql/17/main/pg_hba.conf
'
```

ファイルの所有者と権限が `postgres:postgres 640` のまま維持されていることも確認します。

## 4.4　構文の検証と再読み込み

PostgreSQL自身のパーサーで、追加した規則を検証します。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
runuser -u postgres -- psql -X -d postgres -P pager=off -c "
SELECT
    line_number,
    type,
    database,
    user_name,
    address,
    auth_method,
    error
FROM pg_hba_file_rules
WHERE line_number <= 10
ORDER BY line_number;
"

echo
echo "===== HBA PARSER ERRORS ====="
runuser -u postgres -- psql -X -d postgres -Atc "
SELECT count(*)
FROM pg_hba_file_rules
WHERE error IS NOT NULL;
"
'
```

追加した4つの規則が認識され、構文エラーが `0` であれば、設定を再読み込みします。再起動ではないため、既存の接続は切断されません。

```bash
pct exec 109 -- bash -c '
runuser -u postgres -- psql -X -d postgres -c "
SELECT pg_reload_conf();
"

echo
echo "===== POSTGRESQL SERVICE STATUS ====="
systemctl is-active postgresql
'
```

`pg_reload_conf` が `t`、サービスが `active` であれば、接続元を限定する規則が有効になりました。

## 4.5　ログインの有効化

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
set -e

runuser -u postgres -- psql -X -d security_workbench -c "
ALTER ROLE wazuh_collector LOGIN;
"

echo
echo "===== ROLE SECURITY CHECK ====="

runuser -u postgres -- psql -X -d security_workbench -P pager=off -c "
SELECT
    rolname,
    rolcanlogin,
    rolsuper,
    rolcreatedb,
    rolcreaterole,
    rolreplication,
    rolbypassrls
FROM pg_roles
WHERE rolname = '\''wazuh_collector'\'';
"
'
```

`rolcanlogin` だけが `t` で、ほかはすべて `f` であれば、最小権限のまま有効になっています。

## 4.6　パスワードなしでの到達確認

パスワードを渡さずに接続し、TLSの検証と接続許可の規則を通過して、パスワード認証の段階まで進むかを確認します。

**実行先：Proxmoxホスト（root@pve）**

```bash
qm guest exec 220 -- bash -c '
export PGHOST=postgresql.neomedia.mydns.jp
export PGHOSTADDR=192.168.0.151
export PGPORT=5432
export PGDATABASE=security_workbench
export PGUSER=wazuh_collector
export PGSSLMODE=verify-full
export PGSSLROOTCERT=/etc/ssl/certs/postgresql-server-ca.pem

echo "===== TLS VERIFIED CONNECTION TEST ====="

psql -X -w -c "SELECT 1;" 2>&1 || true
'
```

次のように `no password supplied` と表示されれば、期待どおりです。

```text
connection to server at "192.168.0.151", port 5432 failed:
fe_sendauth: no password supplied
```

証明書のエラーや `no pg_hba.conf entry` が出ていないので、TLSの検証と接続元の制限が正しく働いています。

## 4.7　実際のパスワードによるTLS接続

パスワードをコマンドの引数や環境変数に書かずに、実際にログインします。

> このコマンドは **VM 220（`root@security-core`）に直接ログインして** 実行します。ProxmoxのVMコンソールまたはSSHを使ってください。`psql` はVM 220にだけ入っているため、Proxmoxホストで実行すると `psql: command not found` になります。

**実行先：security-core VM 220（root）**

```bash
export PGHOST=postgresql.neomedia.mydns.jp
export PGHOSTADDR=192.168.0.151
export PGPORT=5432
export PGDATABASE=security_workbench
export PGUSER=wazuh_collector
export PGSSLMODE=verify-full
export PGSSLROOTCERT=/etc/ssl/certs/postgresql-server-ca.pem

psql -X -W -v ON_ERROR_STOP=1 -c "
SELECT
    current_user,
    current_database(),
    s.ssl,
    s.version,
    s.cipher
FROM pg_stat_ssl s
WHERE s.pid = pg_backend_pid();
"
```

`Password:` と表示されたら、1.5で設定した `wazuh_collector` のパスワードを入力します（入力内容は表示されません）。

| 項目 | 期待値 |
|---|---|
| current_user | `wazuh_collector` |
| current_database | `security_workbench` |
| ssl | `t` |
| version | `TLSv1.3` |

実行結果（例）：

```text
 wazuh_collector | security_workbench | t   | TLSv1.3 | TLS_AES_256_GCM_SHA384
```

これで、VM 220からLXC 109へ、証明書と接続元を検証した暗号化接続が確立できました。

# 第5章　アラートの構造調査と保存テーブルの作成

## 5.1　アラートファイルの構造の確認

Wazuhのアラートファイル `alerts.json` が、どのような項目を持っているかを調べます。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import json
from pathlib import Path

p = Path("/var/ossec/logs/alerts/alerts.json")
print("FILE_EXISTS:", p.is_file())

if not p.is_file():
    raise SystemExit("alerts.json not found")

print("FILE_SIZE:", p.stat().st_size)

lines = p.read_text(errors="replace").splitlines()
valid = []

for line in lines[-100:]:
    try:
        obj = json.loads(line)
        valid.append(obj)
    except (json.JSONDecodeError, ValueError):
        continue

print("VALID_RECENT_ALERTS:", len(valid))

for i, obj in enumerate(valid[-3:], 1):
    print(f"\n===== ALERT {i} =====")
    print("TOP_LEVEL_KEYS:", sorted(obj.keys()))

    for key in ("rule", "agent", "manager", "data", "decoder", "location"):
        value = obj.get(key)
        if isinstance(value, dict):
            print(f"{key.upper()}_KEYS:", sorted(value.keys()))
        elif value is not None:
            print(f"{key.upper()}_TYPE:", type(value).__name__)

    print("ID:", obj.get("id"))
    print("TIMESTAMP:", obj.get("timestamp"))

    rule = obj.get("rule")
    if isinstance(rule, dict):
        print("RULE_ID:", rule.get("id"))
        print("RULE_LEVEL:", rule.get("level"))
        print("RULE_DESCRIPTION:", rule.get("description"))

    agent = obj.get("agent")
    if isinstance(agent, dict):
        print("AGENT_ID:", agent.get("id"))
        print("AGENT_NAME:", agent.get("name"))
PY
```

アラートの `data` には、`pwd`（作業ディレクトリ）や `command`（実行されたコマンド）など、DBに保存すべきでない情報が含まれることがあります。そのため、**`data` や `full_log` を丸ごとDBに保存することはしません。**

## 5.2　保存する項目の安全確認

すべてのアラートについて、`data` の中の項目名、ルールのグループ、MITREの項目名がどれくらい現れるかを集計します。値そのものは表示しません。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import json
from pathlib import Path
from collections import Counter

p = Path("/var/ossec/logs/alerts/alerts.json")
data_keys = Counter()
rule_groups = Counter()
mitre_keys = Counter()
count = 0

with p.open(errors="replace") as f:
    for line in f:
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue

        count += 1
        data = obj.get("data")
        if isinstance(data, dict):
            data_keys.update(data.keys())

        rule = obj.get("rule")
        if isinstance(rule, dict):
            groups = rule.get("groups", [])
            if isinstance(groups, list):
                rule_groups.update(str(x) for x in groups)

            mitre = rule.get("mitre")
            if isinstance(mitre, dict):
                mitre_keys.update(mitre.keys())

print("TOTAL_VALID_ALERTS:", count)
print("\nDATA FIELD NAMES (TOP 40):")
for key, n in data_keys.most_common(40):
    print(f"{key}: {n}")

print("\nRULE GROUPS (TOP 30):")
for key, n in rule_groups.most_common(30):
    print(f"{key}: {n}")

print("\nMITRE FIELD NAMES:")
for key, n in mitre_keys.most_common():
    print(f"{key}: {n}")
PY
```

構築時は1,271件のアラートに、認証失敗、ブルートフォース、PostgreSQL、SCA、Rootcheckなどのグループがあり、MITREの項目は `id`・`tactic`・`technique` でした。

この結果から、DBに保存する項目を次のように決めました。

| カラム | 用途 |
|---|---|
| `event_id` | Wazuhイベントの一意な識別子（主キー。重複登録を防ぐ） |
| `event_timestamp` | アラートの発生日時 |
| `ingested_at` | DBへの登録日時 |
| `rule_id`・`rule_level`・`rule_description` | 検知ルール、重要度、検知内容 |
| `agent_id`・`agent_name` | 検知元のAgent |
| `manager_name`・`decoder_name` | Wazuhの管理情報 |
| `rule_groups` | ルールのグループ |
| `srcip`・`srcport` | 送信元のIPとポート（ある場合のみ） |
| `mitre` | MITRE ATT&CKの情報 |

## 5.3　保存テーブルの作成

`wazuh_collector` には **INSERTだけ** を許可し、読み取り・変更・削除はできないようにします。

> **注意：** Proxmoxホストのシェルに、`PGHOST` や `PGSSLMODE` などの環境変数が残っていると、`pct exec` で実行する `psql` がそれを引き継ぎ、`root certificate file "/etc/ssl/certs/postgresql-server-ca.pem" does not exist` というエラーになります（証明書はVM 220にしかありません）。次のコマンドは `env -u` でこれらの環境変数を外して実行するため、どちらの状態でも動きます。SQLはトランザクションの中にあるため、エラーになった場合も途中まで作られることはありません。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- runuser -u postgres -- env -u PGHOST -u PGHOSTADDR -u PGPORT -u PGDATABASE -u PGUSER -u PGSSLMODE -u PGSSLROOTCERT psql -X -v ON_ERROR_STOP=1 -d security_workbench <<'SQL'
BEGIN;

CREATE TABLE incident.alert_events (
    event_id         text PRIMARY KEY,
    event_timestamp  timestamptz NOT NULL,
    ingested_at      timestamptz NOT NULL DEFAULT now(),
    rule_id          integer NOT NULL,
    rule_level       smallint NOT NULL CHECK (rule_level BETWEEN 0 AND 16),
    rule_description text,
    agent_id         text,
    agent_name       text,
    manager_name     text,
    decoder_name     text,
    rule_groups      text[] NOT NULL DEFAULT ARRAY[]::text[],
    srcip            inet,
    srcport          integer CHECK (srcport BETWEEN 0 AND 65535),
    mitre            jsonb NOT NULL DEFAULT '{}'::jsonb
                     CHECK (jsonb_typeof(mitre) = 'object')
);

CREATE INDEX idx_alert_events_timestamp
    ON incident.alert_events (event_timestamp DESC);

CREATE INDEX idx_alert_events_level
    ON incident.alert_events (rule_level DESC);

CREATE INDEX idx_alert_events_rule
    ON incident.alert_events (rule_id);

CREATE INDEX idx_alert_events_srcip
    ON incident.alert_events (srcip);

REVOKE ALL ON incident.alert_events FROM PUBLIC;
GRANT INSERT ON incident.alert_events TO wazuh_collector;

COMMIT;

SELECT
    has_table_privilege('wazuh_collector',
                        'incident.alert_events', 'INSERT') AS can_insert,
    has_table_privilege('wazuh_collector',
                        'incident.alert_events', 'SELECT') AS can_select,
    has_table_privilege('wazuh_collector',
                        'incident.alert_events', 'UPDATE') AS can_update,
    has_table_privilege('wazuh_collector',
                        'incident.alert_events', 'DELETE') AS can_delete;
SQL
```

実行結果（例）：

```text
 can_insert | can_select | can_update | can_delete 
------------+------------+------------+------------
 t          | f          | f          | f
(1 row)
```

`wazuh_collector` はアラートを追加することだけができ、既存のイベントの読み取り・変更・削除はできません。

# 第6章　Collectorの実行環境の確認

Collectorは、Wazuh Managerの動作に影響を与えないよう、`alerts.json` を読み取るだけのプログラムとして作ります。

> この章のコマンドは **VM 220（`root@security-core`）にログインして** 実行します。`alerts.json` はVM 220の中にあるため、Proxmoxホストで実行すると `No such file or directory` になります。なお、VM 220にはシリアルポートを設定していないため、`qm terminal 220` ではログインできません。SSHか、Proxmox Web UIの「コンソール」を使ってください。

## 6.1　アラートファイルの権限の確認

**実行先：security-core VM 220（root）**

```bash
echo "===== ALERT FILE ====="
stat -c 'Owner=%U Group=%G Mode=%a Size=%s Path=%n' \
  /var/ossec/logs/alerts/alerts.json

echo
echo "===== WAZUH USER ====="
id wazuh

echo
echo "===== ALERT DIRECTORY ====="
stat -c 'Owner=%U Group=%G Mode=%a Path=%n' \
  /var/ossec/logs \
  /var/ossec/logs/alerts

echo
echo "===== LOG ROTATION CONFIG ====="
grep -R -n -E 'alerts\.json|/var/ossec/logs' \
  /etc/logrotate.d 2>/dev/null || true
```

| 項目 | 構築時の状態 |
|---|---|
| `alerts.json` | 所有者 `wazuh`、権限 `640` |
| `/var/ossec/logs` | `770` |
| `/var/ossec/logs/alerts` | `750` |
| logrotateの設定 | なし（Wazuh自身がローテーションする） |

## 6.2　アラートの出力設定の確認

**実行先：security-core VM 220（root）**

```bash
echo "===== WAZUH ALERT CONFIG ====="
grep -n -A 12 -B 4 -E 'alerts_log|log_alert_level|jsonout_output' \
  /var/ossec/etc/ossec.conf

echo
echo "===== ALERT FILES ====="
find /var/ossec/logs/alerts -maxdepth 1 -type f \
  -printf '%f | %s bytes | %TY-%Tm-%Td %TH:%TM\n' \
  | sort

echo
echo "===== WAZUH MANAGER STATUS ====="
systemctl is-active wazuh-manager
```

| 設定 | 構築時の値 | 意味 |
|---|---|---|
| `jsonout_output` | `yes` | JSON形式のアラート出力が有効 |
| `alerts_log` | `yes` | テキスト形式のアラートログも出力 |
| `logall`・`logall_json` | `no` | すべてのイベントの保存は無効 |
| `log_alert_level` | `3` | レベル3以上をアラートとして記録 |

CollectorはWazuhの設定を変更せず、`alerts.json` だけを読み取ります。

## 6.3　ローテーション方式の確認

**実行先：security-core VM 220（root）**

```bash
echo "===== WAZUH LOG ROTATION SETTINGS ====="
grep -R -n -E 'max_output_size|rotate|alerts\.json|log_size' \
  /var/ossec/etc /etc/logrotate.conf /etc/logrotate.d \
  2>/dev/null | head -80

echo
echo "===== SYSTEMD VERSION ====="
systemd --version | head -1

echo
echo "===== ALERT FILE DETAILS ====="
ls -li /var/ossec/logs/alerts/alerts.json
```

Wazuh Managerは独自のローテーション機能（`analysisd.min_rotate_interval=600`、`monitord.rotate_log=1`）でアラートファイルを切り替えます。そのため、Collectorはファイル名だけでなく、**inode（ファイルの実体の番号）と読み取り位置** を管理する方式にします。ローテーション後の読み直しと、DB側の主キーによる重複の排除を組み合わせます。

## 6.4　PostgreSQLドライバーの導入

**実行先：security-core VM 220（root）**

```bash
echo "===== PYTHON VERSION ====="
python3 --version

echo
echo "===== POSTGRESQL PYTHON DRIVERS ====="
python3 - <<'PY'
for name in ("psycopg", "psycopg2"):
    try:
        mod = __import__(name)
        print(name, "INSTALLED", getattr(mod, "__version__", "version unknown"))
    except ImportError:
        print(name, "NOT INSTALLED")
PY

echo
echo "===== APT PACKAGE CANDIDATES ====="
apt-cache policy python3-psycopg python3-psycopg2
```

構築時はPython 3.12.3で、ドライバーは未導入でした。OS標準のパッケージで管理できる **psycopg 3** を使います。

```bash
apt-get install -y python3-psycopg
```

```bash
python3 -c 'import psycopg; print("psycopg:", psycopg.__version__)'
```

`psycopg: 3.1.17` のように表示されれば成功です。

## 6.5　ACLの利用可否の確認

Collectorは、Wazuhとは別の専用ユーザーで動かします。専用ユーザーを `wazuh` グループに加えると、ログディレクトリへの書き込みまでできてしまうため、**読み取りだけを許可するACL** を使えるかを確認します。この時点では、まだACLもユーザーも変更しません。

**実行先：security-core VM 220（root）**

```bash
echo "===== ACL UTILITIES ====="
command -v getfacl || true
command -v setfacl || true

echo
echo "===== FILESYSTEM ====="
findmnt -T /var/ossec/logs/alerts/alerts.json \
  -o TARGET,FSTYPE,OPTIONS

echo
echo "===== CURRENT ACL ====="
if command -v getfacl >/dev/null 2>&1; then
    getfacl -p /var/ossec/logs
    getfacl -p /var/ossec/logs/alerts
    getfacl -p /var/ossec/logs/alerts/alerts.json
fi
```

ファイルシステムは `ext4` で、ACLを使えます。構築時は `getfacl`・`setfacl` が未導入だったため、ツールだけを導入します。既存のファイルの権限は変更しません。

```bash
apt-get install -y acl
```

```bash
getfacl -p /var/ossec/logs/alerts/alerts.json
```

# 第7章　専用ユーザーと読み取り専用の権限

## 7.1　現在の権限の確認

**実行先：security-core VM 220（root）**

```bash
echo "===== ALERT FILE ACL ====="
getfacl -p /var/ossec/logs/alerts/alerts.json

echo
echo "===== PARENT DIRECTORY ACL ====="
getfacl -p /var/ossec/logs

echo
echo "===== ALERT DIRECTORY ACL ====="
getfacl -p /var/ossec/logs/alerts
```

既存のWazuhの所有者・グループ・権限は変更せず、専用ユーザーにACLで必要な権限だけを与えます。

## 7.2　専用サービスユーザーの作成

ログインシェルもホームディレクトリも持たない、システム用のユーザーを作ります。

**実行先：security-core VM 220（root）**

```bash
useradd --system \
  --no-create-home \
  --home-dir /nonexistent \
  --shell /usr/sbin/nologin \
  wazuh-collector
```

```bash
echo "===== USER ====="
getent passwd wazuh-collector

echo
echo "===== GROUPS ====="
id wazuh-collector
```

実行結果（例）：

```text
===== USER =====
wazuh-collector:x:996:987::/nonexistent:/usr/sbin/nologin

===== GROUPS =====
uid=996(wazuh-collector) gid=987(wazuh-collector) groups=987(wazuh-collector)
```

`wazuh` グループには入っていないことを確認します。

## 7.3　読み取り専用ACLの設定

**実行先：security-core VM 220（root）**

```bash
setfacl -m u:wazuh-collector:--x /var/ossec/logs
setfacl -m u:wazuh-collector:--x /var/ossec/logs/alerts
setfacl -m u:wazuh-collector:r-- /var/ossec/logs/alerts/alerts.json
setfacl -m d:u:wazuh-collector:r-x /var/ossec/logs/alerts
```

| 対象 | 専用ユーザーに与える権限 |
|---|---|
| `/var/ossec/logs` | 通過のみ（`--x`） |
| `/var/ossec/logs/alerts` | 通過のみ（`--x`） |
| `alerts.json` | 読み取りのみ（`r--`） |
| `alerts` 以下に今後作られるファイル | 読み取り（デフォルトACL。実際の権限はファイル作成時の通常の権限との共通範囲） |

さらに、その上の `/var/ossec`（`root:wazuh 750`）にも通過権限が必要です。これがないと、下のファイルに読み取りACLがあっても到達できず、`Permission denied` になります。

```bash
setfacl -m u:wazuh-collector:--x /var/ossec
```

## 7.4　読み取り専用であることの確認

**実行先：security-core VM 220（root）**

```bash
getfacl -p /var/ossec/logs/alerts/alerts.json
getfacl -p /var/ossec/logs/alerts
```

```bash
echo "===== READ TEST ====="
runuser -u wazuh-collector -- test -r /var/ossec/logs/alerts/alerts.json \
  && echo "PASS: readable" || echo "FAIL: not readable"

echo
echo "===== WRITE TEST ====="
runuser -u wazuh-collector -- test -w /var/ossec/logs/alerts/alerts.json \
  && echo "FAIL: writable" || echo "PASS: not writable"

echo
echo "===== ACTUAL READ TEST ====="
runuser -u wazuh-collector -- head -c 1 /var/ossec/logs/alerts/alerts.json >/dev/null \
  && echo "PASS: file content readable" || echo "FAIL: cannot read file"
```

3項目すべてが `PASS` になれば、専用ユーザーはアラートファイルを読めるが、変更はできない状態です。

経路上のすべての階層も確認しておきます。

```bash
echo "===== COLLECTOR ACCOUNT ====="
id wazuh-collector

echo
echo "===== DIRECTORY ACL ====="
getfacl -p /var/ossec
getfacl -p /var/ossec/logs
getfacl -p /var/ossec/logs/alerts

echo
echo "===== PATH ACCESS ====="
namei -l /var/ossec/logs/alerts/alerts.json
```

## 7.5　アラートファイルの構造の確認

Wazuhがアラートファイルを実際にどう管理しているかを確認します。

**実行先：security-core VM 220（root）**

```bash
echo "===== ALERTS CONFIGURATION ====="
grep -n -A25 -B5 '<alerts>' /var/ossec/etc/ossec.conf

echo
echo "===== ROTATION OPTIONS ====="
grep -nE 'rotate_interval|max_output_size' \
  /var/ossec/etc/ossec.conf
```

`<alerts>` には `log_alert_level`（3）と `email_alert_level`（12）だけがあり、`rotate_interval`・`max_output_size` は未設定（既定値は無効）でした。

> `internal_options.conf` の `monitord.rotate_log` や `monitord.size_rotate` は、Wazuh自身の内部ログ用の設定で、`alerts.json` のローテーションの設定ではありません。

```bash
echo "===== ALERT DIRECTORY TREE ====="
find /var/ossec/logs/alerts -maxdepth 5 \
  -printf '%y inode=%i links=%n size=%s %p\n' | sort

echo
echo "===== ALERTS.JSON LINK DETAILS ====="
stat -c 'inode=%i links=%h size=%s type=%F name=%n' \
  /var/ossec/logs/alerts/alerts.json

echo
echo "===== FILES SHARING ALERTS.JSON INODE ====="
find /var/ossec/logs/alerts -xdev -inum \
  "$(stat -c '%i' /var/ossec/logs/alerts/alerts.json)" \
  -printf '%i %n %s %p\n'
```

実行結果（例）：

```text
5409146 2 1984636 /var/ossec/logs/alerts/2026/Nov/ossec-alerts-18.json
5409146 2 1984636 /var/ossec/logs/alerts/alerts.json
```

`alerts.json` は、日付ごとのファイル（`年/月/ossec-alerts-日.json`）と **同じinodeを共有するハードリンク** です。日付が変わると、新しい日のファイルが作られ、前日のファイルは圧縮（`.json.gz`）されます。Collectorは `alerts.json` のinodeが変わったことで、日付の切り替わりを検知します。

# 第8章　Collectorの作成

## 8.1　認証情報の保存先の作成

**実行先：security-core VM 220（root）**

```bash
install -d \
  -o wazuh-collector \
  -g wazuh-collector \
  -m 700 \
  /etc/wazuh-collector

stat -c '%U:%G %a %n' /etc/wazuh-collector
```

`wazuh-collector:wazuh-collector 700 /etc/wazuh-collector` と表示されれば、ほかのユーザーやサービスからは参照できない状態です。

接続先の設定を確認します（パスワードは表示しません）。

```bash
echo "===== DATABASE CONNECTION SETTINGS ====="
printf '%s\n' \
  'Host name: postgresql.neomedia.mydns.jp' \
  'Host address: 192.168.0.151' \
  'Port: 5432' \
  'Database: security_workbench' \
  'User: wazuh_collector' \
  'SSL mode: verify-full' \
  'CA certificate: /etc/ssl/certs/postgresql-server-ca.pem'

echo
echo "===== CA CERTIFICATE ====="
stat -c '%U:%G %a %s bytes %n' \
  /etc/ssl/certs/postgresql-server-ca.pem

echo
echo "===== COLLECTOR DIRECTORY ====="
stat -c '%U:%G %a %n' /etc/wazuh-collector
```

## 8.2　パスワードファイル（.pgpass）の作成

パスワードを画面に表示せず、専用ユーザーだけが読める `.pgpass` に保存します。

**実行先：security-core VM 220（root）**

```bash
sudo -u wazuh-collector bash -c '
set -eu
umask 077
read -rsp "PostgreSQL wazuh_collector password: " PGPASS
echo
read -rsp "Confirm password: " PGPASS2
echo

if [ "$PGPASS" != "$PGPASS2" ]; then
    echo "ERROR: passwords do not match"
    exit 1
fi

case "$PGPASS" in
  *:*)
    echo "ERROR: password contains a colon; stop and use an escaped .pgpass entry"
    exit 1
    ;;
esac

printf "%s\n" "postgresql.neomedia.mydns.jp:5432:security_workbench:wazuh_collector:$PGPASS" \
  > /etc/wazuh-collector/.pgpass

unset PGPASS PGPASS2
chmod 600 /etc/wazuh-collector/.pgpass
'
```

1.5で設定したパスワードを2回入力します。パスワードにコロン（`:`）が含まれる場合は、安全のため作成を中止します。

```bash
stat -c '%U:%G %a %s bytes %n' \
  /etc/wazuh-collector/.pgpass
```

`wazuh-collector:wazuh-collector 600` であることを確認します。**ファイルの中身は表示しないでください。**

## 8.3　専用ユーザーでの接続テスト

`.pgpass` を使い、`verify-full` で接続します。パスワードの入力は求められません。

**実行先：security-core VM 220（root）**

```bash
sudo -u wazuh-collector env \
  PGHOST=postgresql.neomedia.mydns.jp \
  PGHOSTADDR=192.168.0.151 \
  PGPORT=5432 \
  PGDATABASE=security_workbench \
  PGUSER=wazuh_collector \
  PGSSLMODE=verify-full \
  PGSSLROOTCERT=/etc/ssl/certs/postgresql-server-ca.pem \
  PGPASSFILE=/etc/wazuh-collector/.pgpass \
  psql -X -w -c '\conninfo' \
        -c 'SELECT current_user, current_database();'
```

`192.168.0.151` の5432番にTLS 1.3で接続し、`current_user` が `wazuh_collector`、`current_database` が `security_workbench` と表示されれば成功です。

## 8.4　状態ファイルとプログラムの保存先の作成

アラートファイルのどこまで読んだか（inodeと読み取り位置）を保存する状態ディレクトリを作ります。

**実行先：security-core VM 220（root）**

```bash
echo "===== ALERT DIRECTORY FILES ====="
find /var/ossec/logs/alerts \
  -maxdepth 1 -type f \
  -printf '%f | inode=%i | size=%s | modified=%TY-%Tm-%Td %TH:%TM:%TS\n' \
  | sort

echo
echo "===== ALERT FILE STATUS ====="
stat -c 'inode=%i size=%s owner=%U:%G mode=%a modified=%y' \
  /var/ossec/logs/alerts/alerts.json

echo
echo "===== WAZUH ROTATION SETTINGS ====="
grep -E '^(analysisd\.min_rotate_interval|monitord\.rotate_log|monitord\.size_rotate)=' \
  /var/ossec/etc/internal_options.conf

echo
echo "===== ALERT OUTPUT SETTINGS ====="
grep -nE 'jsonout_output|alerts_log|logall_json|log_alert_level' \
  /var/ossec/etc/ossec.conf
```

```bash
install -d \
  -o wazuh-collector \
  -g wazuh-collector \
  -m 700 \
  /var/lib/wazuh-collector

stat -c '%U:%G %a %n' /var/lib/wazuh-collector
```

プログラムはroot所有にして、実行ユーザーからは変更できないようにします。

```bash
install -d \
  -o root \
  -g root \
  -m 755 \
  /usr/local/lib/wazuh-collector

stat -c '%U:%G %a %n' /usr/local/lib/wazuh-collector
```

| ディレクトリ | 所有者・権限 | 用途 |
|---|---|---|
| `/etc/wazuh-collector` | `wazuh-collector` 700 | 認証情報（`.pgpass`） |
| `/var/lib/wazuh-collector` | `wazuh-collector` 700 | 状態ファイル（`state.json`） |
| `/usr/local/lib/wazuh-collector` | `root` 755 | プログラム本体 |

## 8.5　Collector本体の作成

Collectorの設計上の要点は次のとおりです。

- Wazuhの `alerts.json` だけを監視する。
- DBに保存するのは、許可した項目だけ（`full_log`、任意の `data`、コマンド、パスワードなどは保存しない）。
- 値を検証してから保存する（イベントID・ルールID・レベル・日時・IPアドレス・ポート番号）。
- DBの主キー（`event_id`）で重複を排除する（`ON CONFLICT DO NOTHING`）。
- DBへの登録が成功してから、読み取り位置を保存する。
- inodeの変化でファイルの切り替わりを検知し、新しいファイルを先頭から読む。
- 初めて起動したときは、過去のアラートを登録せず、ファイルの末尾から読み始める。

**実行先：security-core VM 220（root）**

```bash
cat > /usr/local/lib/wazuh-collector/collector.py <<'PY'
#!/usr/bin/python3

import os
import sys
import json
import time
import stat
import logging
import tempfile
import ipaddress
from datetime import datetime
from pathlib import Path

import psycopg
from psycopg.types.json import Jsonb


ALERT_FILE = Path("/var/ossec/logs/alerts/alerts.json")
ALERT_DIR = ALERT_FILE.parent
STATE_FILE = Path("/var/lib/wazuh-collector/state.json")
PGPASS_FILE = "/etc/wazuh-collector/.pgpass"

POLL_INTERVAL = 1.0

DB_CONFIG = {
    "host": "postgresql.neomedia.mydns.jp",
    "hostaddr": "192.168.0.151",
    "port": 5432,
    "dbname": "security_workbench",
    "user": "wazuh_collector",
    "sslmode": "verify-full",
    "sslrootcert": "/etc/ssl/certs/postgresql-server-ca.pem",
    "passfile": PGPASS_FILE,
    "connect_timeout": 10,
    "application_name": "wazuh-alert-collector",
}

INSERT_SQL = """
INSERT INTO incident.alert_events (
    event_id,
    event_timestamp,
    rule_id,
    rule_level,
    rule_description,
    agent_id,
    agent_name,
    manager_name,
    decoder_name,
    rule_groups,
    srcip,
    srcport,
    mitre
)
VALUES (
    %(event_id)s,
    %(event_timestamp)s,
    %(rule_id)s,
    %(rule_level)s,
    %(rule_description)s,
    %(agent_id)s,
    %(agent_name)s,
    %(manager_name)s,
    %(decoder_name)s,
    %(rule_groups)s,
    %(srcip)s,
    %(srcport)s,
    %(mitre)s
)
ON CONFLICT (event_id) DO NOTHING
"""

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    stream=sys.stdout,
)


def parse_timestamp(value):
    if not isinstance(value, str):
        raise ValueError("invalid timestamp")

    result = datetime.fromisoformat(
        value.replace("Z", "+00:00")
    )

    if result.tzinfo is None:
        raise ValueError("timestamp has no timezone")

    return result


def safe_integer(value, minimum, maximum):
    try:
        number = int(value)
        if minimum <= number <= maximum:
            return number
    except (TypeError, ValueError):
        pass
    return None


def safe_ip(value):
    if not isinstance(value, str):
        return None

    try:
        return str(ipaddress.ip_address(value))
    except ValueError:
        return None


def safe_text(value, limit=4096):
    if isinstance(value, str):
        return value[:limit]
    return None


def extract_event(alert):
    if not isinstance(alert, dict):
        return None

    rule = alert.get("rule")
    agent = alert.get("agent")
    manager = alert.get("manager")
    decoder = alert.get("decoder")
    data = alert.get("data")

    if not all(isinstance(x, dict) for x in
               (rule, agent, manager, decoder)):
        return None

    event_id = safe_text(alert.get("id"), 128)
    rule_id = safe_integer(rule.get("id"), 0, 2147483647)
    rule_level = safe_integer(rule.get("level"), 0, 16)

    if not event_id or rule_id is None or rule_level is None:
        return None

    try:
        event_timestamp = parse_timestamp(alert.get("timestamp"))
    except (ValueError, TypeError):
        return None

    groups = rule.get("groups", [])
    if not isinstance(groups, list):
        groups = []

    groups = [
        item[:256]
        for item in groups
        if isinstance(item, str)
    ]

    mitre_source = rule.get("mitre", {})
    mitre = {}

    if isinstance(mitre_source, dict):
        for key in ("id", "tactic", "technique"):
            value = mitre_source.get(key)
            if isinstance(value, (str, int, list)):
                mitre[key] = value

    srcip = None
    srcport = None

    if isinstance(data, dict):
        srcip = safe_ip(data.get("srcip"))
        srcport = safe_integer(data.get("srcport"), 0, 65535)

    return {
        "event_id": event_id,
        "event_timestamp": event_timestamp,
        "rule_id": rule_id,
        "rule_level": rule_level,
        "rule_description": safe_text(rule.get("description")),
        "agent_id": safe_text(agent.get("id"), 128),
        "agent_name": safe_text(agent.get("name"), 256),
        "manager_name": safe_text(manager.get("name"), 256),
        "decoder_name": safe_text(decoder.get("name"), 256),
        "rule_groups": groups,
        "srcip": srcip,
        "srcport": srcport,
        "mitre": Jsonb(mitre),
    }


def save_state(inode, offset):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)

    fd, temporary = tempfile.mkstemp(
        prefix=".state-",
        dir=str(STATE_FILE.parent),
    )

    try:
        os.fchmod(fd, 0o600)

        with os.fdopen(fd, "w", encoding="utf-8") as output:
            json.dump(
                {"inode": inode, "offset": offset},
                output,
            )
            output.flush()
            os.fsync(output.fileno())

        os.replace(temporary, STATE_FILE)

        directory_fd = os.open(STATE_FILE.parent, os.O_DIRECTORY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)

    except Exception:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def load_state():
    try:
        with STATE_FILE.open("r", encoding="utf-8") as source:
            state = json.load(source)

        inode = int(state["inode"])
        offset = int(state["offset"])

        if inode <= 0 or offset < 0:
            raise ValueError("invalid state")

        return inode, offset

    except FileNotFoundError:
        return None

    except Exception as error:
        raise RuntimeError("collector state is invalid") from error


def find_inode_file(inode):
    for entry in os.scandir(ALERT_DIR):
        try:
            if entry.is_file(follow_symlinks=False):
                if entry.inode() == inode:
                    return Path(entry.path)
        except OSError:
            continue

    return None


def open_initial_file(state):
    current_stat = ALERT_FILE.stat()

    if state is None:
        handle = ALERT_FILE.open("rb")
        handle.seek(0, os.SEEK_END)
        offset = handle.tell()

        save_state(current_stat.st_ino, offset)

        logging.info("Initial start at current end of alerts.json")
        return handle, current_stat.st_ino

    old_inode, old_offset = state
    old_path = find_inode_file(old_inode)

    if old_path is not None:
        handle = old_path.open("rb")
        handle.seek(min(old_offset, os.fstat(handle.fileno()).st_size))
        logging.info("Resuming previous alert file")
        return handle, old_inode

    handle = ALERT_FILE.open("rb")

    if current_stat.st_ino == old_inode:
        handle.seek(min(old_offset, current_stat.st_size))
    else:
        handle.seek(0)
        logging.warning(
            "Previous rotated file not found; replaying current file"
        )

    return handle, current_stat.st_ino


def process_line(connection, line):
    try:
        alert = json.loads(line)
    except (json.JSONDecodeError, UnicodeDecodeError):
        logging.warning("Invalid JSON alert line skipped")
        return

    event = extract_event(alert)

    if event is None:
        logging.warning("Alert rejected by field validation")
        return

    with connection.transaction():
        connection.execute(INSERT_SQL, event)


def run():
    logging.info("Wazuh alert collector starting")

    state = load_state()
    handle, active_inode = open_initial_file(state)

    connection = None

    try:
        while True:
            if connection is None or connection.closed:
                try:
                    connection = psycopg.connect(**DB_CONFIG)
                    logging.info("PostgreSQL connection established")
                except Exception as error:
                    logging.error(
                        "PostgreSQL connection failed: %s",
                        type(error).__name__,
                    )
                    time.sleep(5)
                    continue

            line_start = handle.tell()
            line = handle.readline()

            if line:
                if not line.endswith(b"\n"):
                    handle.seek(line_start)
                    time.sleep(POLL_INTERVAL)
                    continue

                try:
                    process_line(connection, line)
                    save_state(active_inode, handle.tell())
                except Exception as error:
                    handle.seek(line_start)
                    logging.error(
                        "Alert processing failed: %s",
                        type(error).__name__,
                    )

                    try:
                        connection.close()
                    except Exception:
                        pass

                    connection = None
                    time.sleep(5)

                continue

            # At EOF: check whether Wazuh rotated alerts.json.
            try:
                current_stat = ALERT_FILE.stat()
            except FileNotFoundError:
                time.sleep(POLL_INTERVAL)
                continue

            if current_stat.st_ino != active_inode:
                handle.close()
                handle = ALERT_FILE.open("rb")
                active_inode = current_stat.st_ino

                save_state(active_inode, 0)
                logging.info("Switched to new alerts.json inode")

            time.sleep(POLL_INTERVAL)

    finally:
        handle.close()

        if connection is not None:
            connection.close()


if __name__ == "__main__":
    run()
PY

chown root:root /usr/local/lib/wazuh-collector/collector.py
chmod 755 /usr/local/lib/wazuh-collector/collector.py
```

> このプログラムは、第4部で入力検証やローテーションへの対応などを強化します。ここに掲載したのは、第3部の時点（初版）の全文です。

## 8.6　作成したファイルの確認

長いコマンドを貼り付けると、端末の表示が崩れることがあります。ファイルが最後まで正しく作られたかを確認します。

**実行先：security-core VM 220（root）**

```bash
echo "===== FILE STATUS ====="
stat -c '%U:%G %a %s bytes %n' \
  /usr/local/lib/wazuh-collector/collector.py

echo
echo "===== LINE COUNT ====="
wc -l /usr/local/lib/wazuh-collector/collector.py

echo
echo "===== LAST 25 LINES ====="
tail -n 25 /usr/local/lib/wazuh-collector/collector.py

echo
echo "===== PYTHON SYNTAX CHECK ====="
python3 -m py_compile \
  /usr/local/lib/wazuh-collector/collector.py
```

```bash
echo "===== FUNCTION DEFINITIONS ====="
grep -nE '^(def |if __name__)' \
  /usr/local/lib/wazuh-collector/collector.py

echo
echo "===== UNEXPECTED SHELL COMMAND CHECK ====="
if grep -nE '^(chmod|chown|apt-get|cat >|root@security-core)' \
  /usr/local/lib/wazuh-collector/collector.py; then
    echo "WARNING: unexpected shell text found"
else
    echo "PASS: no obvious shell command contamination"
fi

echo
echo "===== COMPILE CHECK ====="
python3 -m py_compile \
  /usr/local/lib/wazuh-collector/collector.py \
  && echo "PASS"
```

| 項目 | 期待値 |
|---|---|
| 所有者・権限 | `root:root 755` |
| サイズ・行数 | 9,487バイト、383行 |
| 末尾 | `if __name__ == "__main__":` と `run()` |
| シェルコマンドの混入 | `PASS: no obvious shell command contamination` |
| 構文 | `PASS` |

## 8.7　機密情報が保存されないことのテスト

`data` の中に `command`・`pwd`・`tty`・`dstuser` などがあっても、DBに登録するデータに入らないことを確認します。DBには接続しません。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import importlib.util

path = "/usr/local/lib/wazuh-collector/collector.py"
spec = importlib.util.spec_from_file_location("collector", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

sample = {
    "id": "1794989242.2755502",
    "timestamp": "2026-11-18T10:30:00.000+0000",
    "agent": {"id": "004", "name": "postgresql"},
    "manager": {"name": "security-core"},
    "decoder": {"name": "postgresql"},
    "rule": {
        "id": "100106",
        "level": 12,
        "description": "PostgreSQL authentication failure test",
        "groups": ["postgresql", "authentication_failed"],
        "mitre": {
            "id": ["T1110"],
            "tactic": ["Credential Access"],
            "technique": ["Brute Force"]
        }
    },
    "data": {
        "srcip": "192.0.2.10",
        "srcport": "54321",
        "command": "SENSITIVE_COMMAND",
        "pwd": "SENSITIVE_PASSWORD",
        "tty": "SENSITIVE_TTY",
        "dstuser": "SENSITIVE_USER"
    },
    "full_log": "SENSITIVE_FULL_LOG"
}

event = module.extract_event(sample)

assert event is not None
assert event["srcip"] == "192.0.2.10"
assert event["srcport"] == 54321

expected = {
    "event_id", "event_timestamp", "rule_id", "rule_level",
    "rule_description", "agent_id", "agent_name", "manager_name",
    "decoder_name", "rule_groups", "srcip", "srcport", "mitre"
}
assert set(event.keys()) == expected

serialized = repr(event)
for forbidden in (
    "SENSITIVE_COMMAND",
    "SENSITIVE_PASSWORD",
    "SENSITIVE_TTY",
    "SENSITIVE_USER",
    "SENSITIVE_FULL_LOG"
):
    assert forbidden not in serialized

assert event["mitre"].obj["id"] == ["T1110"]

print("PASS: allowed fields extracted")
print("PASS: sensitive data excluded")
print("PASS: source IP and port validated")
print("PASS: MITRE fields extracted")
print("PASS: exact database field whitelist")
PY
```

5項目すべてに `PASS` が表示されれば、許可した項目だけが取り出され、機密情報が除外されていることを確認できます。

# 第9章　DBへの登録処理の確認と修正

## 9.1　テーブル権限の確認

Collectorが実際にDBへ登録できるかを確認する前に、専用ユーザーで接続したときの権限を確認します。

**実行先：security-core VM 220（root）**

```bash
sudo -u wazuh-collector env \
  PGHOST=postgresql.neomedia.mydns.jp \
  PGHOSTADDR=192.168.0.151 \
  PGPORT=5432 \
  PGDATABASE=security_workbench \
  PGUSER=wazuh_collector \
  PGSSLMODE=verify-full \
  PGSSLROOTCERT=/etc/ssl/certs/postgresql-server-ca.pem \
  PGPASSFILE=/etc/wazuh-collector/.pgpass \
  psql -X -w -c "
SELECT
    current_user,
    current_database(),
    has_schema_privilege(current_user, 'incident', 'USAGE')
        AS schema_usage,
    has_table_privilege(
        current_user,
        'incident.alert_events',
        'INSERT'
    ) AS table_insert,
    has_table_privilege(
        current_user,
        'incident.alert_events',
        'SELECT'
    ) AS table_select;
"
```

実行結果（例）：

```text
 wazuh_collector | security_workbench | t            | t            | f
```

| 権限 | 結果 | 意味 |
|---|---|---|
| `incident` スキーマのUSAGE | `t` | 許可 |
| `alert_events` のINSERT | `t` | 許可 |
| `alert_events` のSELECT | `f` | 拒否（意図した最小権限） |

## 9.2　ON CONFLICTとSELECT権限の関係

8.5のプログラムのINSERT文は、末尾に `ON CONFLICT (event_id) DO NOTHING` を付けて重複を除外しています。しかしPostgreSQLでは、`ON CONFLICT` を使うと既存の行と照合するため、**テーブルのSELECT権限が必要** になります。`wazuh_collector` にはSELECT権限を与えていないので、このままでは `permission denied for table alert_events` で失敗します。

通常のINSERTと、`ON CONFLICT` 付きのINSERTを比べて確認します。どちらも最後に意図的に例外を発生させ、テストデータはコミットしません。

**実行先：security-core VM 220（root）**

通常のINSERT：

```bash
sudo -u wazuh-collector python3 - <<'PY'
import psycopg
import uuid
from datetime import datetime, timezone

import importlib.util

path = "/usr/local/lib/wazuh-collector/collector.py"
spec = importlib.util.spec_from_file_location("collector", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

event_id = "WAZUH-MINIMAL-ROLLBACK-" + uuid.uuid4().hex

try:
    with psycopg.connect(**module.DB_CONFIG) as conn:
        with conn.transaction():
            cursor = conn.execute("""
                INSERT INTO incident.alert_events (
                    event_id,
                    event_timestamp,
                    rule_id,
                    rule_level
                )
                VALUES (%s, %s, %s, %s)
            """, (
                event_id,
                datetime.now(timezone.utc),
                100106,
                12
            ))

            print("INSERT rowcount:", cursor.rowcount)
            raise RuntimeError("INTENTIONAL_ROLLBACK")

except RuntimeError as error:
    if str(error) != "INTENTIONAL_ROLLBACK":
        raise
    print("ROLLBACK: completed")
    print("Test INSERT was not committed")

except Exception as error:
    print("Exception type:", type(error).__name__)
    print("SQLSTATE:", getattr(error, "sqlstate", None))
    print("Message:", str(error))
    diag = getattr(error, "diag", None)
    if diag:
        print("Schema:", getattr(diag, "schema_name", None))
        print("Table:", getattr(diag, "table_name", None))
        print("Column:", getattr(diag, "column_name", None))
PY
```

```text
INSERT rowcount: 1
ROLLBACK: completed
Test INSERT was not committed
```

`ON CONFLICT` 付きのINSERT：

```bash
sudo -u wazuh-collector python3 - <<'PY'
import psycopg
import uuid
from datetime import datetime, timezone

event_id = "WAZUH-CONFLICT-ROLLBACK-" + uuid.uuid4().hex

try:
    with psycopg.connect(
        host="postgresql.neomedia.mydns.jp",
        hostaddr="192.168.0.151",
        port=5432,
        dbname="security_workbench",
        user="wazuh_collector",
        sslmode="verify-full",
        sslrootcert="/etc/ssl/certs/postgresql-server-ca.pem",
        passfile="/etc/wazuh-collector/.pgpass",
    ) as conn:
        with conn.transaction():
            cursor = conn.execute("""
                INSERT INTO incident.alert_events (
                    event_id,
                    event_timestamp,
                    rule_id,
                    rule_level
                )
                VALUES (%s, %s, %s, %s)
                ON CONFLICT (event_id) DO NOTHING
            """, (
                event_id,
                datetime.now(timezone.utc),
                100106,
                12
            ))

            print("INSERT rowcount:", cursor.rowcount)
            raise RuntimeError("INTENTIONAL_ROLLBACK")

except RuntimeError as error:
    if str(error) != "INTENTIONAL_ROLLBACK":
        raise
    print("ROLLBACK: completed")

except Exception as error:
    print("Exception type:", type(error).__name__)
    print("SQLSTATE:", getattr(error, "sqlstate", None))
    print("Message:", str(error))
    diag = getattr(error, "diag", None)
    if diag:
        print("Schema:", getattr(diag, "schema_name", None))
        print("Table:", getattr(diag, "table_name", None))
        print("Constraint:", getattr(diag, "constraint_name", None))
PY
```

```text
Exception type: InsufficientPrivilege
SQLSTATE: 42501
Message: permission denied for table alert_events
```

| SQL | 結果 |
|---|---|
| 通常のINSERT | 成功 |
| INSERT ＋ `ON CONFLICT DO NOTHING` | `InsufficientPrivilege` |

SELECT権限は与えずに、プログラム側の重複処理を変更します。

## 9.3　重複エラーで処理する方式の確認

`ON CONFLICT` を使わず、主キーの重複エラー（`UniqueViolation`、SQLSTATE `23505`）を捕まえて処理する方式が使えるかを確認します。全体を最後にロールバックします。

**実行先：security-core VM 220（root）**

```bash
sudo -u wazuh-collector python3 - <<'PY'
import psycopg
import uuid
from datetime import datetime, timezone

event_id = "WAZUH-DUPLICATE-ROLLBACK-" + uuid.uuid4().hex

try:
    with psycopg.connect(
        host="postgresql.neomedia.mydns.jp",
        hostaddr="192.168.0.151",
        port=5432,
        dbname="security_workbench",
        user="wazuh_collector",
        sslmode="verify-full",
        sslrootcert="/etc/ssl/certs/postgresql-server-ca.pem",
        passfile="/etc/wazuh-collector/.pgpass",
    ) as conn:
        with conn.transaction():
            values = (
                event_id,
                datetime.now(timezone.utc),
                100106,
                12
            )

            # 1回目：通常INSERT
            with conn.transaction():
                conn.execute("""
                    INSERT INTO incident.alert_events (
                        event_id,
                        event_timestamp,
                        rule_id,
                        rule_level
                    )
                    VALUES (%s, %s, %s, %s)
                """, values)

            print("FIRST INSERT: PASS")

            # 2回目：同じIDをINSERTして重複を発生させる
            try:
                with conn.transaction():
                    conn.execute("""
                        INSERT INTO incident.alert_events (
                            event_id,
                            event_timestamp,
                            rule_id,
                            rule_level
                        )
                        VALUES (%s, %s, %s, %s)
                    """, values)

            except psycopg.errors.UniqueViolation as error:
                if error.sqlstate != "23505":
                    raise
                print("DUPLICATE DETECTED: PASS")

            # 重複エラー後もトランザクションが使用可能か確認
            conn.execute("SELECT 1")
            print("CONNECTION RECOVERY: PASS")

            raise RuntimeError("INTENTIONAL_ROLLBACK")

except RuntimeError as error:
    if str(error) != "INTENTIONAL_ROLLBACK":
        raise
    print("ROLLBACK: completed")
    print("TEST DATA: NOT COMMITTED")
PY
```

```text
FIRST INSERT: PASS
DUPLICATE DETECTED: PASS
CONNECTION RECOVERY: PASS
ROLLBACK: completed
TEST DATA: NOT COMMITTED
```

重複は検出でき、その後も接続をそのまま使えることを確認できました。

## 9.4　修正前のバックアップ

修正する箇所を表示します（ファイルは変更しません）。

**実行先：security-core VM 220（root）**

```bash
sed -n '38,78p' /usr/local/lib/wazuh-collector/collector.py

echo
echo "===== process_line ====="

sed -n '280,310p' /usr/local/lib/wazuh-collector/collector.py
```

バックアップを作ります。同じ名前のバックアップがすでにある場合は中止します。

```bash
BACKUP=/usr/local/lib/wazuh-collector/collector.py.backup-before-duplicate-handling-20261118

if [ -e "$BACKUP" ]; then
    echo "ERROR: backup already exists; stopping"
    exit 1
fi

cp -a /usr/local/lib/wazuh-collector/collector.py "$BACKUP"

echo "===== BACKUP ====="
ls -l "$BACKUP"

echo
echo "===== SHA256 ====="
sha256sum \
  /usr/local/lib/wazuh-collector/collector.py \
  "$BACKUP"
```

2つのSHA256が一致することを確認します。

## 9.5　重複処理の修正

変更は次の2か所だけです。

1. `INSERT_SQL` から `ON CONFLICT (event_id) DO NOTHING` を削除する。
2. `process_line()` で `UniqueViolation` を捕まえ、重複したアラートはログに記録して読み飛ばす。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/usr/local/lib/wazuh-collector/collector.py")
source = path.read_text(encoding="utf-8")

old_sql = """    %(mitre)s
)
ON CONFLICT (event_id) DO NOTHING
"""

new_sql = """    %(mitre)s
)
"""

old_process = """    with connection.transaction():
        connection.execute(INSERT_SQL, event)
"""

new_process = """    try:
        with connection.transaction():
            connection.execute(INSERT_SQL, event)
    except psycopg.errors.UniqueViolation as error:
        if error.sqlstate != "23505":
            raise
        logging.info("Duplicate alert skipped")
"""

if source.count(old_sql) != 1:
    raise SystemExit("ERROR: SQL target mismatch; no changes made")

if source.count(old_process) != 1:
    raise SystemExit("ERROR: process_line target mismatch; no changes made")

updated = source.replace(old_sql, new_sql, 1)
updated = updated.replace(old_process, new_process, 1)

temporary = path.with_suffix(".py.new")
temporary.write_text(updated, encoding="utf-8")
temporary.chmod(path.stat().st_mode)

temporary.replace(path)

print("PATCH: applied")
PY
```

`PATCH: applied` と表示されれば適用されています。対象の文字列が1か所だけ見つからない場合は、何も変更せずに中止します。

## 9.6　修正内容の確認

**実行先：security-core VM 220（root）**

```bash
echo "===== PYTHON SYNTAX ====="
python3 -m py_compile /usr/local/lib/wazuh-collector/collector.py
echo "SYNTAX: PASS"

echo
echo "===== SQL CONFLICT CLAUSE ====="
grep -n -A 5 -B 5 'ON CONFLICT\|%(mitre)s' \
  /usr/local/lib/wazuh-collector/collector.py

echo
echo "===== process_line ====="
sed -n '290,315p' /usr/local/lib/wazuh-collector/collector.py

echo
echo "===== DIFF ====="
diff -u \
  /usr/local/lib/wazuh-collector/collector.py.backup-before-duplicate-handling-20261118 \
  /usr/local/lib/wazuh-collector/collector.py
```

構文エラーがないこと、`ON CONFLICT` が消えていること、差分が上の2か所だけであることを確認します。

## 9.7　本番コードでの登録テスト

修正したプログラムの `process_line()` を実際に呼び出し、同じアラートを2回処理します。最後にロールバックするので、テストデータは残りません。

**実行先：security-core VM 220（root）**

```bash
sudo -u wazuh-collector python3 - <<'PY'
import importlib.util
import json
import psycopg

path = "/usr/local/lib/wazuh-collector/collector.py"
spec = importlib.util.spec_from_file_location("collector", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

sample = {
    "id": "WAZUH-PROCESS-LINE-ROLLBACK-20261118-001",
    "timestamp": "2026-11-18T10:30:00.000+0000",
    "agent": {"id": "004", "name": "postgresql"},
    "manager": {"name": "security-core"},
    "decoder": {"name": "postgresql"},
    "rule": {
        "id": "100106",
        "level": 12,
        "description": "Collector process_line test",
        "groups": ["postgresql", "authentication_failed"],
        "mitre": {"id": ["T1110"]}
    },
    "data": {
        "srcip": "192.0.2.10",
        "srcport": "54321",
        "pwd": "MUST_NOT_BE_STORED"
    },
    "full_log": "MUST_NOT_BE_STORED"
}

line = (json.dumps(sample) + "\n").encode("utf-8")

try:
    with psycopg.connect(**module.DB_CONFIG) as conn:
        with conn.transaction():
            module.process_line(conn, line)
            print("FIRST PROCESS: PASS")

            module.process_line(conn, line)
            print("DUPLICATE PROCESS: PASS")

            conn.execute("SELECT 1")
            print("CONNECTION RECOVERY: PASS")

            raise RuntimeError("INTENTIONAL_ROLLBACK")

except RuntimeError as error:
    if str(error) != "INTENTIONAL_ROLLBACK":
        raise
    print("ROLLBACK: completed")
    print("TEST DATA: NOT COMMITTED")
PY
```

```text
FIRST PROCESS: PASS
Duplicate alert skipped
DUPLICATE PROCESS: PASS
CONNECTION RECOVERY: PASS
ROLLBACK: completed
TEST DATA: NOT COMMITTED
```

新しいアラートは登録され、重複したアラートは読み飛ばされ、接続はそのまま使えます。SELECT権限は不要です。

# 第10章　systemdサービス化

## 10.1　事前確認

**実行先：security-core VM 220（root）**

```bash
echo "===== EXISTING UNIT ====="
systemctl status wazuh-collector.service --no-pager || true

echo
echo "===== UNIT FILE ====="
if [ -e /etc/systemd/system/wazuh-collector.service ]; then
    ls -l /etc/systemd/system/wazuh-collector.service
    cat /etc/systemd/system/wazuh-collector.service
else
    echo "No existing unit file"
fi

echo
echo "===== EXECUTION USER ====="
id wazuh-collector

echo
echo "===== SCRIPT PERMISSIONS ====="
stat -c '%U:%G %a %n' \
  /usr/local/lib/wazuh-collector/collector.py \
  /var/lib/wazuh-collector \
  /etc/wazuh-collector \
  /etc/wazuh-collector/.pgpass
```

既存のユニットがないこと、各ファイルの所有者と権限が8.4の表のとおりであることを確認します。

## 10.2　サービス定義の作成

専用ユーザーで動かし、書き込めるのは状態ディレクトリだけに制限します。メモリ・CPU・タスク数の上限も設定します。

**実行先：security-core VM 220（root）**

```bash
cat > /etc/systemd/system/wazuh-collector.service <<'EOF'
[Unit]
Description=Wazuh Alert Collector to PostgreSQL
Documentation=local
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=wazuh-collector
Group=wazuh-collector

ExecStart=/usr/bin/python3 /usr/local/lib/wazuh-collector/collector.py

Restart=always
RestartSec=5
UMask=0077

# Process restrictions
NoNewPrivileges=true
PrivateTmp=true
PrivateDevices=true
ProtectSystem=strict
ProtectHome=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
ProtectHostname=true
ProtectClock=true
RestrictSUIDSGID=true
LockPersonality=true
MemoryDenyWriteExecute=true

# Filesystem access
ReadOnlyPaths=/var/ossec/logs/alerts
ReadOnlyPaths=/etc/ssl/certs/postgresql-server-ca.pem
ReadOnlyPaths=/usr/local/lib/wazuh-collector
ReadWritePaths=/var/lib/wazuh-collector

# Resource limits
MemoryMax=512M
CPUQuota=50%
TasksMax=32

[Install]
WantedBy=multi-user.target
EOF

echo "===== UNIT FILE CREATED ====="
stat -c '%U:%G %a %n' \
  /etc/systemd/system/wazuh-collector.service

echo
echo "===== UNIT CONTENT ====="
systemd-analyze verify /etc/systemd/system/wazuh-collector.service
```

`systemd-analyze verify` は次の警告を出します。

```text
/etc/systemd/system/wazuh-collector.service:3: Invalid URL, ignoring: local
```

`Documentation=` にはURLかマニュアルの参照を書く必要があります。この行は不要なので削除します。

```bash
echo "===== UNIT FILE ====="
cat -n /etc/systemd/system/wazuh-collector.service

echo
echo "===== SYSTEMD VERIFY ====="
systemd-analyze verify /etc/systemd/system/wazuh-collector.service
```

```bash
sed -i '/^Documentation=local$/d' \
  /etc/systemd/system/wazuh-collector.service

echo "===== UPDATED UNIT ====="
cat -n /etc/systemd/system/wazuh-collector.service

echo
echo "===== SYSTEMD VERIFY ====="
systemd-analyze verify /etc/systemd/system/wazuh-collector.service

echo
echo "===== VERIFY EXIT CODE ====="
echo $?
```

警告が消え、`VERIFY EXIT CODE` が `0` になれば完了です。

## 10.3　手動での起動

まだ自動起動（`enable`）は設定せず、一度だけ起動して動作を確認します。

**実行先：security-core VM 220（root）**

```bash
systemctl daemon-reload

systemctl start wazuh-collector.service

echo "===== SERVICE STATUS ====="
systemctl status wazuh-collector.service --no-pager -l

echo
echo "===== RECENT JOURNAL ====="
journalctl -u wazuh-collector.service -n 30 --no-pager
```

`active (running)` で、実行ユーザーが `wazuh-collector` であることを確認します。

```bash
sleep 5

echo "===== SERVICE STATUS ====="
systemctl is-active wazuh-collector.service

echo
echo "===== PROCESS ====="
systemctl show wazuh-collector.service \
  -p MainPID -p NRestarts -p ActiveState -p SubState

echo
echo "===== COLLECTOR STATE FILE ====="
if test -f /var/lib/wazuh-collector/state.json; then
    stat -c '%U:%G %a %s bytes %n' \
      /var/lib/wazuh-collector/state.json
else
    echo "STATE FILE NOT CREATED"
fi

echo
echo "===== JOURNAL ====="
journalctl -u wazuh-collector.service -n 30 --no-pager
```

状態ファイルの中身と認証情報は表示しません。

実行結果（例）：

```text
INFO Wazuh alert collector starting
INFO Initial start at current end of alerts.json
INFO PostgreSQL connection established
```

初めての起動なので、過去のアラートは登録せず、`alerts.json` の現在の末尾から読み始めます。状態ファイルは `wazuh-collector` 所有、権限 `600` で作られます。

# 第11章　実際のアラートでの動作確認

## 11.1　待機状態の確認

**実行先：security-core VM 220（root）**

```bash
echo "===== ALERT FILE ====="
stat -c 'size=%s bytes modified=%y' \
  /var/ossec/logs/alerts/alerts.json

echo
echo "===== COLLECTOR JOURNAL ====="
journalctl -u wazuh-collector.service \
  --since "5 minutes ago" --no-pager

echo
echo "===== STATE FILE METADATA ====="
stat -c '%U:%G %a %s bytes %n' \
  /var/lib/wazuh-collector/state.json
```

再起動やエラーのログがないことを確認します。

## 11.2　テストに使うルールの確認

第2部で作ったPostgreSQLのWARNING検知ルール（100104）を使って、テスト用のアラートを1件発生させます。

**実行先：security-core VM 220（root）**

```bash
echo "===== TEST RULE 100104 ====="
grep -n -A 12 -B 3 '100104' \
  /var/ossec/etc/rules/local_rules.xml
```

ルール100104は、親ルール100100に一致したイベントのうち、`event` が `POSTGRESQL_WARNING` のものを検知します（レベル4）。親ルールの条件とデコーダーを確認します。

```bash
echo "===== PARENT RULE 100100 ====="
grep -n -A 15 -B 5 'id="100100"' \
  /var/ossec/etc/rules/local_rules.xml

echo
echo "===== POSTGRESQL DECODER ====="
grep -R -n -A 12 -B 3 \
  'POSTGRESQL_WARNING\|POSTGRESQL_' \
  /var/ossec/etc/decoders /var/ossec/etc/rules
```

親ルール100100は次のとおりです。

```xml
<rule id="100100" level="0">
  <decoded_as>json</decoded_as>
  <description>PostgreSQL sanitized JSON event base rule</description>
</rule>
```

専用のデコーダーはなく、Wazuh標準のJSONデコーダーを使います。そのため、テストにはJSON形式のイベントが必要です（`POSTGRESQL_WARNING` という文字列だけでは、どのデコーダーにも一致しません）。

## 11.3　wazuh-logtestでのルール判定

**実行先：security-core VM 220（root）**

```bash
/var/ossec/bin/wazuh-logtest
```

起動したら、次のJSONを1行で入力します。

```json
{"event":"POSTGRESQL_WARNING","timestamp":"2026-11-18T11:05:00Z","srcip":"192.0.2.10"}
```

| 項目 | 期待する結果 |
|---|---|
| Decoder | `json` |
| Rule ID | `100104` |
| Level | `4` |
| Description | `PostgreSQL WARNING event detected` |
| 判定 | `**Alert to be generated.` |

`wazuh-logtest` の中だけのテストなので、`alerts.json` やDBには登録されません。終了したら、Collectorが動いていることを確認します。

```bash
systemctl is-active wazuh-collector.service
```

## 11.4　実際のアラートの発生

既存のログ入力経路を確認します。

**実行先：security-core VM 220（root）**

```bash
echo "===== WAZUH LOG INPUT CONFIG ====="
grep -n -A 8 -B 3 '<localfile>' /var/ossec/etc/ossec.conf
```

第2部で作った経路（LXC 109の `/var/log/postgresql-wazuh/events.log` → Wazuh Agent `postgresql`（ID 004））に、テスト用の合成イベントを1件追加します。`pct` はProxmoxホストのコマンドなので、**security-coreではなくProxmoxホストで実行します**。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- bash -c '
printf "%s\n" \
  "{\"timestamp\":\"2026-11-18 20:01:00 JST\",\"event\":\"POSTGRESQL_WARNING\"}" \
  >> /var/log/postgresql-wazuh/events.log
'
```

> このイベントはテスト用の合成データです。実際のPostgreSQLの障害を意味するものではありません。

Wazuhがアラートを生成したかを確認します。

**実行先：security-core VM 220（root）**

```bash
echo "===== LATEST POSTGRESQL WARNING ALERT ====="
grep '"rule"' /var/ossec/logs/alerts/alerts.json \
  | grep '"id":"100104"' \
  | tail -n 3
```

`agent.name` が `postgresql`、`rule.id` が `100104` のアラートが表示されます。アラートの先頭にある `"id"`（例：`1795000021.2810167`）を控えておきます。

## 11.5　DBへの登録の確認

Collectorにはテーブルを読む権限（SELECT）がないため、登録の確認はDB管理者（`postgres`）で行います。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- runuser -u postgres -- \
  psql -X -d security_workbench -c "
SELECT
    event_id,
    event_timestamp,
    rule_id,
    rule_level,
    rule_description,
    agent_id,
    agent_name,
    manager_name,
    rule_groups,
    srcip
FROM incident.alert_events
WHERE event_id = '1795000021.2810167';
"
```

`event_id` の値は、11.4で控えたアラートのIDに置き換えてください。1行が表示されれば、`alerts.json` → Collector → PostgreSQL の流れが動いています。

| 項目 | 登録された値（例） |
|---|---|
| event_id | `1795000021.2810167` |
| event_timestamp | `2026-11-18 11:07:01.074+00` |
| rule_id | `100104` |
| rule_level | `4` |
| rule_description | `PostgreSQL WARNING event detected` |
| agent_id / agent_name | `004` / `postgresql` |
| manager_name | `security-core` |
| rule_groups | `{local,postgresql,postgresql,warning}` |

## 11.6　保存項目と権限の最終確認

テーブルの列を確認します。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- runuser -u postgres -- \
  psql -X -d security_workbench -c "
SELECT
    column_name,
    data_type
FROM information_schema.columns
WHERE table_schema = 'incident'
  AND table_name = 'alert_events'
ORDER BY ordinal_position;
"
```

14列で、`full_log`・`data`・`command`・`password` などの列がないことを確認します。

Collectorのロールの権限を確認します。

```bash
pct exec 109 -- runuser -u postgres -- \
  psql -X -d security_workbench -c "
SELECT
    has_table_privilege(
        'wazuh_collector',
        'incident.alert_events',
        'INSERT'
    ) AS can_insert,
    has_table_privilege(
        'wazuh_collector',
        'incident.alert_events',
        'SELECT'
    ) AS can_select,
    has_table_privilege(
        'wazuh_collector',
        'incident.alert_events',
        'UPDATE'
    ) AS can_update,
    has_table_privilege(
        'wazuh_collector',
        'incident.alert_events',
        'DELETE'
    ) AS can_delete;
"
```

```text
 can_insert | can_select | can_update | can_delete 
------------+------------+------------+------------
 t          | f          | f          | f
(1 row)
```

Collectorはイベントを追加することだけができ、既存のデータを読む・変更する・削除することはできません。

# 第12章　自動起動と収集データの監査

## 12.1　自動起動の登録

**実行先：security-core VM 220（root）**

```bash
systemctl enable wazuh-collector.service
```

```bash
echo "===== SERVICE STATUS ====="
systemctl status wazuh-collector.service --no-pager -l

echo
echo "===== ENABLED STATUS ====="
systemctl is-enabled wazuh-collector.service

echo
echo "===== RESTART COUNT ====="
systemctl show wazuh-collector.service -p NRestarts
```

`Active: active (running)`、`enabled`、`NRestarts=0` を確認します。

## 12.2　収集件数と欠損の監査

しばらく稼働させてから、DBに蓄積されたデータを監査します。以降のSQLはすべて読み取りだけです。

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- runuser -u postgres -- \
  psql -X -d security_workbench -c "
SELECT
    COUNT(*) AS total_events,
    MIN(event_timestamp) AS first_event,
    MAX(event_timestamp) AS latest_event,
    MAX(ingested_at) AS latest_ingested_at,
    COUNT(*) FILTER (
        WHERE rule_level >= 12
    ) AS high_severity_events,
    COUNT(*) FILTER (
        WHERE srcip IS NOT NULL
    ) AS events_with_srcip,
    COUNT(*) FILTER (
        WHERE agent_id IS NULL OR agent_name IS NULL
    ) AS missing_agent,
    COUNT(*) FILTER (
        WHERE rule_description IS NULL
    ) AS missing_description
FROM incident.alert_events;
"
```

Agentごとの収集状況：

```bash
pct exec 109 -- runuser -u postgres -- \
  psql -X -d security_workbench -c "
SELECT
    agent_id,
    agent_name,
    COUNT(*) AS event_count,
    MIN(event_timestamp) AS first_event,
    MAX(event_timestamp) AS latest_event,
    COUNT(*) FILTER (
        WHERE srcip IS NOT NULL
    ) AS events_with_srcip,
    COUNT(DISTINCT rule_id) AS distinct_rules
FROM incident.alert_events
GROUP BY agent_id, agent_name
ORDER BY event_count DESC;
"
```

ルールIDとレベルごとの分布：

```bash
pct exec 109 -- runuser -u postgres -- \
  psql -X -d security_workbench -c "
SELECT
    rule_id,
    rule_level,
    rule_description,
    COUNT(*) AS event_count,
    COUNT(*) FILTER (
        WHERE srcip IS NOT NULL
    ) AS events_with_srcip,
    COUNT(DISTINCT agent_id) AS affected_agents
FROM incident.alert_events
GROUP BY
    rule_id,
    rule_level,
    rule_description
ORDER BY
    rule_level DESC,
    event_count DESC,
    rule_id;
"
```

| Rule ID | レベル | 検知内容（構築時の例） |
|---|---:|---|
| 5501 | 3 | PAM Login session opened |
| 5502 | 3 | PAM Login session closed |
| 100104 | 4 | PostgreSQL WARNING event detected |
| 87203 | 3 | Proxmox VE authentication succeeded. |

デコーダーごとの項目の品質：

```bash
pct exec 109 -- runuser -u postgres -- \
  psql -X -d security_workbench -c "
SELECT
    decoder_name,
    COUNT(*) AS total,
    COUNT(*) FILTER (
        WHERE cardinality(rule_groups) = 0
    ) AS empty_rule_groups,
    COUNT(*) FILTER (
        WHERE jsonb_typeof(mitre) = 'object'
          AND mitre <> '{}'::jsonb
    ) AS has_mitre,
    COUNT(*) FILTER (
        WHERE srcip IS NOT NULL
    ) AS has_srcip,
    COUNT(*) FILTER (
        WHERE srcport IS NOT NULL
    ) AS has_srcport
FROM incident.alert_events
GROUP BY decoder_name
ORDER BY total DESC;
"
```

## 12.3　整合性と異常値の監査

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- runuser -u postgres -- \
  psql -X -d security_workbench -c "
SELECT
    COUNT(*) AS total_events,
    COUNT(DISTINCT event_id) AS unique_event_ids,
    COUNT(*) FILTER (
        WHERE event_timestamp > now() + interval '5 minutes'
    ) AS future_timestamps,
    COUNT(*) FILTER (
        WHERE event_timestamp IS NULL
    ) AS null_timestamps,
    COUNT(*) FILTER (
        WHERE rule_id < 0 OR rule_level NOT BETWEEN 0 AND 16
    ) AS invalid_rule_values,
    COUNT(*) FILTER (
        WHERE srcport IS NOT NULL AND srcip IS NULL
    ) AS port_without_ip,
    COUNT(*) FILTER (
        WHERE ingested_at < event_timestamp - interval '1 day'
    ) AS ingestion_time_anomalies,
    COUNT(*) FILTER (
        WHERE agent_id IS NULL
           OR agent_name IS NULL
           OR rule_description IS NULL
    ) AS missing_required_fields
FROM incident.alert_events;
"
```

> 貼り付けるときは、行頭に `root@pve:~#` などのプロンプトの文字を含めないでください。

| 監査項目 | 期待値 |
|---|---|
| `total_events` と `unique_event_ids` | 同じ値（重複なし） |
| `future_timestamps` | 0 |
| `null_timestamps` | 0 |
| `invalid_rule_values` | 0 |
| `port_without_ip` | 0 |
| `ingestion_time_anomalies` | 0 |
| `missing_required_fields` | 0 |

## 12.4　Wazuh側との件数の照合

DBに送信元IPが少ない理由が、Collectorの取りこぼしなのか、元のアラートにIPがないのかを確かめます。

**実行先：security-core VM 220（root）**

`alerts.json` 全体のネットワーク項目の有無：

```bash
python3 - <<'PY'
import json
from collections import Counter

path = "/var/ossec/logs/alerts/alerts.json"
counts = Counter()
total = 0

with open(path, encoding="utf-8") as f:
    for line in f:
        try:
            alert = json.loads(line)
        except (json.JSONDecodeError, UnicodeDecodeError):
            continue

        total += 1
        data = alert.get("data")
        if not isinstance(data, dict):
            counts["no_data_object"] += 1
            continue

        for key in ("srcip", "srcport", "dstip", "dstport"):
            if data.get(key) not in (None, ""):
                counts[f"has_{key}"] += 1

        if not any(data.get(k) not in (None, "") for k in
                   ("srcip", "srcport", "dstip", "dstport")):
            counts["no_network_fields"] += 1

print("Total alerts:", total)
for key, value in sorted(counts.items()):
    print(f"{key}: {value}")
PY
```

Collectorが起動した時刻（10.3のジャーナルの時刻）以降の、Agentごとの件数：

```bash
python3 - <<'PY'
import json
from collections import defaultdict

path = "/var/ossec/logs/alerts/alerts.json"
start = "2026-11-18T11:00:48"

stats = defaultdict(lambda: {
    "total": 0,
    "srcip": 0,
    "srcport": 0,
    "first": None,
    "latest": None
})

with open(path, encoding="utf-8") as f:
    for line in f:
        try:
            a = json.loads(line)
        except (json.JSONDecodeError, UnicodeDecodeError):
            continue

        ts = a.get("timestamp", "")
        if ts < start:
            continue

        agent = a.get("agent", {})
        name = agent.get("name", "unknown") if isinstance(agent, dict) else "unknown"
        data = a.get("data", {})
        if not isinstance(data, dict):
            data = {}

        s = stats[name]
        s["total"] += 1

        if data.get("srcip") not in (None, ""):
            s["srcip"] += 1
        if data.get("srcport") not in (None, ""):
            s["srcport"] += 1

        if s["first"] is None or ts < s["first"]:
            s["first"] = ts
        if s["latest"] is None or ts > s["latest"]:
            s["latest"] = ts

print("Collector start:", start)
print("Agent | Alerts | srcip | srcport | First | Latest")
for name, s in sorted(stats.items()):
    print(
        f"{name} | {s['total']} | {s['srcip']} | "
        f"{s['srcport']} | {s['first']} | {s['latest']}"
    )
PY
```

`start` の値は、自分の環境のCollectorの起動時刻（UTC）に置き換えます。

DB側のAgentごとの件数：

**実行先：Proxmoxホスト（root@pve）**

```bash
pct exec 109 -- runuser -u postgres -- \
  psql -X -d security_workbench -c "
SELECT
    agent_id,
    agent_name,
    COUNT(*) AS db_events,
    MIN(event_timestamp) AS first_event,
    MAX(event_timestamp) AS latest_event,
    MAX(ingested_at) AS latest_ingested_at
FROM incident.alert_events
GROUP BY agent_id, agent_name
ORDER BY agent_id;
"
```

構築時の照合結果：

| Agent | Wazuh側 | DB側 | 差分 |
|---|---:|---:|---:|
| pve（001） | 2 | 2 | 0 |
| postgresql（004） | 23 | 23 | 0 |
| **合計** | **25** | **25** | **0** |

Collectorの起動後のアラートは、すべてDBに登録されていました。DBに送信元IPがないのは、この期間のアラート自体にIPが含まれていなかったためで、取りこぼしではありません。

## 12.5　Collectorのログの確認

**実行先：security-core VM 220（root）**

```bash
echo "===== COLLECTOR JOURNAL ====="
journalctl -u wazuh-collector.service \
  --since "2026-11-18 11:00:48 UTC" \
  --no-pager \
  -o short-iso

echo
echo "===== ERROR COUNTS ====="
journalctl -u wazuh-collector.service \
  --since "2026-11-18 11:00:48 UTC" \
  --no-pager \
  -p warning..emerg \
  | wc -l
```

`wc -l` は空行も数えるため、`1` と表示されることがあります。空行を除いて、警告・エラーの実際の行数を数えます。

```bash
journalctl -u wazuh-collector.service \
  --since "2026-11-18 11:00:48 UTC" \
  --no-pager \
  -p warning..emerg \
  -o cat \
  | awk 'NF { print; count++ }
         END { print "Non-empty warning/error lines:", count+0 }'
```

`Non-empty warning/error lines: 0` であれば、接続エラー・JSON解析エラー・項目検証エラーは起きていません。

## 12.6　状態ファイルとプログラムの確認

状態ファイルの中身（値）は表示せず、形式だけを確認します。

**実行先：security-core VM 220（root）**

```bash
echo "===== STATE FILE METADATA ====="
stat -c 'Owner=%U Group=%G Mode=%a Size=%s Modified=%y' \
  /var/lib/wazuh-collector/state.json

echo
echo "===== STATE FILE JSON STRUCTURE ====="
python3 - <<'PY'
import json

path = "/var/lib/wazuh-collector/state.json"

with open(path, encoding="utf-8") as f:
    state = json.load(f)

print("Valid JSON: True")
print("Top-level type:", type(state).__name__)

if isinstance(state, dict):
    print("Top-level keys:", sorted(state.keys()))
    print("Field types:", {
        k: type(v).__name__ for k, v in state.items()
    })
PY
```

```text
Valid JSON: True
Top-level type: dict
Top-level keys: ['inode', 'offset']
Field types: {'inode': 'int', 'offset': 'int'}
```

最後に、プログラム本体を確認します。

```bash
echo "===== COLLECTOR SOURCE METADATA ====="
stat -c 'Owner=%U Group=%G Mode=%a Size=%s Modified=%y' \
  /usr/local/lib/wazuh-collector/collector.py

echo
echo "===== FUNCTION DEFINITIONS ====="
grep -nE '^def |^class ' \
  /usr/local/lib/wazuh-collector/collector.py

echo
echo "===== SOURCE SYNTAX CHECK ====="
python3 -m py_compile \
  /usr/local/lib/wazuh-collector/collector.py \
  && echo "Python syntax: PASS"
```

| 項目 | 結果 |
|---|---|
| 所有者・権限 | `root` / `755` |
| サイズ | 9,626バイト（9.5の修正後） |
| 関数 | 9個 |
| 構文 | `Python syntax: PASS` |

# 第3部のまとめ

第3部で、Wazuhのアラートを安全にPostgreSQLへ保存する仕組みができあがりました。

| 構成要素 | 内容 |
|---|---|
| 保存先 | `security_workbench` DBの `incident.alert_events`（14列、機密情報の列なし） |
| DBロール | `wazuh_collector`（INSERTのみ。SELECT・UPDATE・DELETEは不可） |
| 接続 | `192.168.0.220/32` からの `hostssl` ＋ `scram-sha-256`、`verify-full` によるTLS 1.3 |
| 実行ユーザー | `wazuh-collector`（ログイン不可、アラートは読み取り専用のACL） |
| 認証情報 | `/etc/wazuh-collector/.pgpass`（600） |
| 状態ファイル | `/var/lib/wazuh-collector/state.json`（inodeと読み取り位置） |
| プログラム | `/usr/local/lib/wazuh-collector/collector.py`（root所有 755） |
| サービス | `wazuh-collector.service`（権限制限・資源制限付き、自動起動） |

> **メモ：** 第2章で確認した `pg_hba.conf` の11行目（`0.0.0.0/0 md5`）は、広い許可ルールのまま運用します。セキュリティ上の問題になる場合は、後で接続元を限定するよう修正します。

第4部では、STEP 100以降の監査で見つかった改善点（入力検証、ローテーションへの対応、DB接続断からの復旧など）をもとに、Collectorを強化していきます。
