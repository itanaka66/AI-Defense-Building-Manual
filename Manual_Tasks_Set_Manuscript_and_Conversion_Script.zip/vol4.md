---
title: "AI自律型サイバー防御システム 構築マニュアル 前編"
subtitle: "第4部　Collectorの監査と強化版の開発"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」前編の第4部です。第3部で稼働させたアラート保存Collectorを監査し、見つかった弱点を、本番を止めずにテスト用のコピーで改善していきます。

| 進め方 | 内容 |
|---|---|
| 監査 | 入力検証、読み取り位置、ローテーションの方式を、実際のファイルとコードで確認する |
| 保全 | 改善前のコードを完全にバックアップする |
| 開発 | `/tmp` のテスト用コピーだけを修正し、単体テストで確かめる |
| 本番 | 第4部では本番のCollectorは変更しない（反映は第5部） |

## 本書の表記

- コマンドやファイル内容は、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 各手順の冒頭に「実行先」を示します。
- 「実行結果（例）」は構築時の実際の出力です。お使いの環境では、inode・サイズ・日時などが異なります。
- 認証情報や状態ファイルの中身は表示しません。

## 第3部終了時点の状態

| 項目 | 状態 |
|---|---|
| Collector | `/usr/local/lib/wazuh-collector/collector.py`（9,626バイト） |
| サービス | `wazuh-collector.service`（active、enabled） |
| 保存先 | LXC 109 `security_workbench` DBの `incident.alert_events` |
| DBロール | `wazuh_collector`（INSERTのみ） |

# 第1章　稼働中Collectorの監査

この章では、ファイルの確認だけを行います。設定の変更やサービスの再起動はしません。

## 1.1　コードの後半の確認

入力検証（78〜186行目）に続いて、状態の保存・再開・ローテーションの処理を確認します。

**実行先：security-core VM 220（root）**

```bash
sed -n '187,383p' \
  /usr/local/lib/wazuh-collector/collector.py
```

監査の結果、基本設計は堅実でしたが、次の点に改善の余地がありました。

| 区分 | 項目 | 評価 |
|---|---|---|
| 良好 | 状態ファイルの保存 | 一時ファイル・fsync・アトミックな置き換えを使っている |
| 良好 | DB登録と状態保存の順序 | DBへの登録が成功してから読み取り位置を保存している |
| 良好 | 重複処理 | `UniqueViolation` だけを重複として扱っている |
| 要改善 | 入力行のサイズ | 1行の長さに上限がない |
| 要改善 | 数値・文字列の検証 | 真偽値を整数として受け入れる、制御文字を除去していない |
| 要改善 | ローテーション | 切り替わり後の旧ファイルの読み残しへの対応が不十分 |

## 1.2　ローテーションの方式の調査

**実行先：security-core VM 220（root）**

```bash
echo "===== ALERT LOG FILES ====="
ls -lah /var/ossec/logs/alerts/

echo
echo "===== LOGROTATE CONFIG REFERENCES ====="
grep -RniE 'alerts\.json|/var/ossec/logs' \
  /etc/logrotate.conf \
  /etc/logrotate.d/ \
  2>/dev/null

echo
echo "===== ALERT FILE INODE ====="
stat -c 'File=%n Inode=%i Size=%s Modified=%y' \
  /var/ossec/logs/alerts/alerts.json
```

logrotateには該当する設定がなく、`alerts.json` と `alerts.log` はどちらもリンク数が2でした。Wazuhの設定とリンク関係を確認します。

```bash
echo "===== WAZUH LOGGING CONFIG ====="
grep -nE '^(<global>|</global>|[[:space:]]*<logall>|[[:space:]]*<jsonout_output>|[[:space:]]*<alerts_log>|[[:space:]]*<log_alert_level>)' \
  /var/ossec/etc/ossec.conf

echo
echo "===== ALERT FILE LINK INFORMATION ====="
stat -c '%n device=%d inode=%i links=%h size=%s' \
  /var/ossec/logs/alerts/alerts.json \
  /var/ossec/logs/alerts/alerts.log

echo
echo "===== WAZUH LOG ROTATION REFERENCES ====="
grep -RniE 'alerts\.json|alerts\.log|rotate|compress|log.*size' \
  /var/ossec/etc \
  /var/ossec/bin \
  2>/dev/null | head -80
```

```bash
echo "===== JSON ALERT INODE LINKS ====="
find /var/ossec/logs/alerts -xdev -inum 5409146 \
  -printf '%i %n %s %p\n' 2>/dev/null

echo
echo "===== PLAIN ALERT INODE LINKS ====="
find /var/ossec/logs/alerts -xdev -inum 5398501 \
  -printf '%i %n %s %p\n' 2>/dev/null

echo
echo "===== ARCHIVE DIRECTORY STRUCTURE ====="
find /var/ossec/logs/alerts/2026 \
  -maxdepth 4 -type f \
  -printf '%TY-%Tm-%Td %TH:%TM %s bytes %p\n' \
  2>/dev/null | tail -30
```

`-inum` の値は、前のコマンドで表示された自分の環境のinodeに置き換えます。

| ファイル | inode | リンク数 |
|---|---:|---:|
| `alerts.json` | 5409146 | 2 |
| `2026/Nov/ossec-alerts-18.json` | 5409146 | 2 |
| `alerts.log` | 5398501 | 2 |

Wazuhは、現在のログと日付別のアーカイブを **ハードリンクで共有** しています。日付が変わると新しいファイルに切り替わり、前日のファイルは圧縮されます。

## 1.3　ローテーションの設定と圧縮アーカイブ

**実行先：security-core VM 220（root）**

```bash
echo "===== MONITORD ROTATION SETTINGS ====="
sed -n '270,305p' \
  /var/ossec/etc/internal_options.conf
```

| 設定 | 値 | 意味 |
|---|---:|---|
| `monitord.day_wait` | 10秒 | 日次ローテーション後の処理待ち |
| `monitord.compress` | 1 | 圧縮する |
| `monitord.sign` | 1 | 署名する |
| `monitord.rotate_log` | 1 | 日次でローテーションする |
| `monitord.keep_log_days` | 31 | 保持日数 |

```bash
echo "===== ARCHIVE FILE COUNTS ====="
find /var/ossec/logs/alerts/2026 \
  -type f \
  | awk '
    /\.json$/ { json_count++ }
    /\.json\.gz$/ { json_gz_count++ }
    /\.log$/ { plain_count++ }
    /\.log\.gz$/ { plain_gz_count++ }
    END {
      print "JSON active/archive:", json_count+0
      print "JSON compressed:", json_gz_count+0
      print "LOG active/archive:", plain_count+0
      print "LOG compressed:", plain_gz_count+0
    }'

echo
echo "===== WAZUH MANAGER SERVICE ====="
systemctl status wazuh-manager --no-pager -l

echo
echo "===== MONITORD PROCESS ====="
pgrep -af 'wazuh-monitord|ossec-monitord' || true
```

> ローテーションは独立したsystemdサービスではなく、Wazuh Managerの中の `wazuh-monitord` プロセスが行います。

圧縮されたアーカイブの形式と整合性を確認します。

```bash
echo "===== COMPRESSED JSON ARCHIVE ====="
file /var/ossec/logs/alerts/2026/Nov/ossec-alerts-17.json.gz

echo
echo "===== COMPRESSED ARCHIVE METADATA ====="
stat -c 'Owner=%U Group=%G Mode=%a Size=%s Modified=%y' \
  /var/ossec/logs/alerts/2026/Nov/ossec-alerts-17.json.gz
```

```bash
gzip -t /var/ossec/logs/alerts/2026/Nov/ossec-alerts-17.json.gz
echo "gzip exit code: $?"
```

`gzip exit code: 0` であれば、圧縮データは正常です。

## 1.4　読み取り位置と稼働状態の確認

**実行先：security-core VM 220（root）**

```bash
echo "===== CURRENT ALERT FILE INODE ====="
stat -c 'inode=%i size=%s' \
  /var/ossec/logs/alerts/alerts.json

echo
echo "===== COLLECTOR STATE ====="
python3 - <<'PY'
import json

path = "/var/lib/wazuh-collector/state.json"

with open(path, encoding="utf-8") as f:
    state = json.load(f)

print("State inode:", state["inode"])
print("State offset:", state["offset"])

import os
st = os.stat("/var/ossec/logs/alerts/alerts.json")
print("Current inode:", st.st_ino)
print("Current size:", st.st_size)
print("Offset within current file:", state["offset"] <= st.st_size)
PY
```

状態ファイルのinodeが現在の `alerts.json` と同じで、読み取り位置がファイルの末尾と一致していれば正常です。

```bash
echo "===== COLLECTOR SERVICE ====="
systemctl show wazuh-collector.service \
  -p ActiveState \
  -p SubState \
  -p MainPID \
  -p NRestarts \
  -p MemoryCurrent \
  -p CPUUsageNSec

echo
echo "===== RECENT COLLECTOR LOG ====="
journalctl -u wazuh-collector.service \
  -n 15 --no-pager -o cat
```

構築時は、再起動回数0、メモリ約18MiBで安定して動いていました。

## 1.5　改善前のバックアップ

第3部9.4のバックアップは、重複処理を修正する前のものです。現在のコードとはハッシュが異なるため、改善前の状態に戻すためのバックアップを新しく作ります。

**実行先：security-core VM 220（root）**

```bash
echo "===== COLLECTOR BACKUP ====="
stat -c 'Owner=%U Group=%G Mode=%a Size=%s Modified=%y' \
  /usr/local/lib/wazuh-collector/collector.py.backup-before-duplicate-handling-20261118

echo
echo "===== BACKUP SHA256 ====="
sha256sum \
  /usr/local/lib/wazuh-collector/collector.py.backup-before-duplicate-handling-20261118

echo
echo "===== CURRENT SOURCE SHA256 ====="
sha256sum \
  /usr/local/lib/wazuh-collector/collector.py
```

| ファイル | サイズ | SHA256（先頭） |
|---|---:|---|
| 既存のバックアップ（重複処理の修正前） | 9,487バイト | `132c9e33...` |
| 現在のコード | 9,626バイト | `931ee3cb...` |

```bash
BACKUP="/usr/local/lib/wazuh-collector/collector.py.backup-pre-hardening-20261118"

if [ -e "$BACKUP" ]; then
    echo "ERROR: Backup already exists. No changes made."
    exit 1
fi

cp -a /usr/local/lib/wazuh-collector/collector.py "$BACKUP"

echo "===== BACKUP VERIFICATION ====="
sha256sum \
  /usr/local/lib/wazuh-collector/collector.py \
  "$BACKUP"

echo
stat -c '%n Owner=%U Group=%G Mode=%a Size=%s' "$BACKUP"
```

2つのSHA256が一致すれば、改善前の状態にいつでも戻せます。

## 1.6　改善の方針

監査の結果から、次の順に改善します。

1. `safe_integer()`：真偽値（`true`/`false`）を整数として受け入れない。
2. `safe_text()`：制御文字を取り除き、文字数を制限する。
3. `rule_groups`：要素の数と文字列の長さを制限する。
4. `mitre`：許可したキーと値の型・要素の数を厳しく制限する。
5. 1行の長さに上限を設け、巨大な行を安全に読み飛ばす。
6. ローテーションの前後で、旧ファイルの読み残しがないようにする。

改善はすべてテスト用のコピーで行います。まず、現在のコードの先頭部分と末尾を確認します。

```bash
sed -n '1,77p' \
  /usr/local/lib/wazuh-collector/collector.py
```

```bash
tail -n 25 /usr/local/lib/wazuh-collector/collector.py
```

末尾が `if __name__ == "__main__":` で守られているため、テストでモジュールとして読み込んでも `run()` は起動しません。

# 第2章　テスト用コピーと入力検証の強化

## 2.1　テスト用コピーの作成

本番のコードには触らず、`/tmp` にテスト専用のコピーを作ります。

**実行先：security-core VM 220（root）**

```bash
TEST_FILE="/tmp/wazuh-collector-hardening-test.py"

if [ -e "$TEST_FILE" ]; then
    echo "ERROR: Test file already exists. No changes made."
    exit 1
fi

cp /usr/local/lib/wazuh-collector/collector.py "$TEST_FILE"
chmod 600 "$TEST_FILE"

echo "===== TEST COPY ====="
stat -c 'Owner=%U Group=%G Mode=%a Size=%s' "$TEST_FILE"

echo
sha256sum \
  /usr/local/lib/wazuh-collector/collector.py \
  "$TEST_FILE"
```

2つのSHA256が一致することを確認します。以降の第4部の修正は、すべてこのテスト用コピーに対して行います。

> `/tmp` のファイルはVMを再起動すると消えることがあります。第4部の作業は、再起動をはさまずに続けて行ってください。

## 2.2　入力検証の改善

改善する箇所を表示します。

```bash
sed -n '78,186p' \
  /tmp/wazuh-collector-hardening-test.py
```

| 関数・項目 | 現在の問題 | 改善 |
|---|---|---|
| `safe_integer` | `True` が整数1として受け入れられる | 真偽値を拒否し、10進数の文字列だけを受け入れる |
| `safe_text` | 改行・制御文字を許可している | 制御文字を除去し、空文字はNoneにする |
| `rule_groups` | 要素の数に上限がない | 64個・各256文字まで（`safe_string_list`） |
| `mitre` | 任意の型・数の値を受け入れる | `id`・`tactic`・`technique` だけを、型と数を制限して受け入れる（`safe_mitre`） |

`safe_integer()` から `extract_event()` の直前までを置き換え、`extract_event()` の中の `groups`・`mitre` の処理を新しい関数に差し替えます。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")

start = source.index("def safe_integer(")
end = source.index("\ndef extract_event(", start)

replacement = '''def safe_integer(value, minimum, maximum):
    if isinstance(value, bool):
        return None

    if isinstance(value, int):
        number = value
    elif isinstance(value, str):
        if not value or not value.isascii() or not value.isdecimal():
            return None
        if len(value) > 20:
            return None
        number = int(value)
    else:
        return None

    if minimum <= number <= maximum:
        return number

    return None


def safe_ip(value):
    if not isinstance(value, str):
        return None

    try:
        return str(ipaddress.ip_address(value))
    except ValueError:
        return None


def safe_text(value, limit=4096):
    if not isinstance(value, str):
        return None

    value = "".join(
        char for char in value
        if char >= " " and char != "\\\\x7f"
    )

    value = value.strip()

    if not value:
        return None

    return value[:limit]


def safe_string_list(value, max_items=64, item_limit=256):
    if not isinstance(value, list):
        return []

    result = []

    for item in value[:max_items]:
        text = safe_text(item, item_limit)
        if text is not None:
            result.append(text)

    return result


def safe_mitre(value):
    if not isinstance(value, dict):
        return {}

    result = {}

    for key, max_items in (
        ("id", 32),
        ("tactic", 16),
        ("technique", 32),
    ):
        item = value.get(key)

        if isinstance(item, str):
            text = safe_text(item, 256)
            if text is not None:
                result[key] = text

        elif isinstance(item, list):
            cleaned = safe_string_list(
                item,
                max_items=max_items,
                item_limit=256,
            )
            if cleaned:
                result[key] = cleaned

    return result

'''

updated = source[:start] + replacement + source[end:]

old_groups = '''    groups = rule.get("groups", [])
    if not isinstance(groups, list):
        groups = []

    groups = [
        item[:256]
        for item in groups
        if isinstance(item, str)
    ]

    mitre_source = rule.get("mitre", {})
    mitre = {}

    if isinstance(mitre_source, dict):
        for key in ("id", "tactic", "technique"):
            value = mitre_source.get(key)
            if isinstance(value, (str, int, list)):
                mitre[key] = value
'''

new_groups = '''    groups = safe_string_list(
        rule.get("groups", []),
        max_items=64,
        item_limit=256,
    )

    mitre = safe_mitre(rule.get("mitre", {}))
'''

if old_groups not in updated:
    raise SystemExit("ERROR: Expected extraction block not found")

updated = updated.replace(old_groups, new_groups, 1)

if updated == source:
    raise SystemExit("ERROR: No changes made")

path.write_text(updated, encoding="utf-8")
print("Test copy updated successfully")
PY

python3 -m py_compile /tmp/wazuh-collector-hardening-test.py \
  && echo "Python syntax: PASS"
```

`Test copy updated successfully` と `Python syntax: PASS` が表示されれば完了です。

## 2.3　入力検証の単体テスト

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import importlib.util

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

# 1. Integer validation
assert module.safe_integer(True, 0, 16) is None
assert module.safe_integer(False, 0, 16) is None
assert module.safe_integer("5", 0, 16) == 5
assert module.safe_integer("1.5", 0, 16) is None
assert module.safe_integer(-1, 0, 16) is None
print("Integer validation: PASS")

# 2. Text validation
assert module.safe_text("hello\nworld\t!") == "helloworld!"
assert module.safe_text("   ") is None
assert len(module.safe_text("A" * 5000)) == 4096
print("Text validation: PASS")

# 3. List limits
groups = module.safe_string_list(
    ["group"] * 100,
    max_items=64,
    item_limit=256,
)
assert len(groups) == 64
assert module.safe_string_list(["valid", 123]) == ["valid"]
print("List validation: PASS")

# 4. MITRE whitelist and limits
mitre = module.safe_mitre({
    "id": ["T1110"] * 50,
    "tactic": ["Credential Access"],
    "technique": ["Brute Force"],
    "unexpected": "must not survive",
})
assert len(mitre["id"]) == 32
assert "unexpected" not in mitre
assert "tactic" in mitre
print("MITRE validation: PASS")

# 5. Full event extraction
alert = {
    "id": "test-20261118-001",
    "timestamp": "2026-11-18T11:00:00.000+0000",
    "rule": {
        "id": "100106",
        "level": 12,
        "description": "Authentication failure",
        "groups": ["authentication_failed"],
        "mitre": {"id": ["T1110"]},
    },
    "agent": {"id": "004", "name": "postgresql"},
    "manager": {"name": "security-core"},
    "decoder": {"name": "json"},
    "data": {
        "srcip": "192.0.2.10",
        "srcport": "5432",
        "password": "must-not-be-stored",
        "command": "must-not-be-stored",
    },
    "full_log": "must-not-be-stored",
}

event = module.extract_event(alert)

assert event is not None
assert event["rule_id"] == 100106
assert event["rule_level"] == 12
assert event["srcip"] == "192.0.2.10"
assert event["srcport"] == 5432
assert "password" not in event
assert "command" not in event
assert "full_log" not in event
assert set(event.keys()) == {
    "event_id", "event_timestamp", "rule_id", "rule_level",
    "rule_description", "agent_id", "agent_name", "manager_name",
    "decoder_name", "rule_groups", "srcip", "srcport", "mitre",
}
print("Event extraction and sensitive-field exclusion: PASS")

print("ALL TESTS: PASS")
PY
```

```text
Integer validation: PASS
Text validation: PASS
List validation: PASS
MITRE validation: PASS
Event extraction and sensitive-field exclusion: PASS
ALL TESTS: PASS
```

## 2.4　実際のアラートとの互換性の確認

厳しくした検証で、実際のWazuhのアラートを誤って拒否しないかを確認します。本番の `alerts.json` を読み取るだけで、DBには接続しません。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import sys
import json
import importlib.util
from pathlib import Path

spec = importlib.util.spec_from_file_location(
    "collector_test",
    "/tmp/wazuh-collector-hardening-test.py",
)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

path = Path("/var/ossec/logs/alerts/alerts.json")

total = 0
accepted = 0
rejected = 0
invalid_json = 0

with path.open("rb") as f:
    for line in f:
        if not line.endswith(b"\n"):
            continue

        total += 1

        try:
            alert = json.loads(line)
        except (json.JSONDecodeError, UnicodeDecodeError):
            invalid_json += 1
            continue

        if module.extract_event(alert) is None:
            rejected += 1
        else:
            accepted += 1

print("Total complete lines:", total)
print("Accepted:", accepted)
print("Rejected:", rejected)
print("Invalid JSON:", invalid_json)
print("Accounting:", accepted + rejected + invalid_json)

if total != accepted + rejected + invalid_json:
    sys.exit("ACCOUNTING ERROR")

print("READ-ONLY COMPATIBILITY TEST: PASS")
PY
```

構築時は1,406件すべてが受け入れられ（拒否0件、JSONエラー0件）、`READ-ONLY COMPATIBILITY TEST: PASS` となりました。

# 第3章　1行のサイズ制限

## 3.1　読み取り処理の確認

**実行先：security-core VM 220（root）**

```bash
sed -n '280,390p' \
  /tmp/wazuh-collector-hardening-test.py
```

```bash
sed -n '380,450p' \
  /tmp/wazuh-collector-hardening-test.py
```

現在は `handle.readline()` で1行をまるごと読むため、非常に長い行があるとメモリの使用量を制限できません。サイズ制限を追加するときも、次の性質は保つ必要があります。

1. 改行がまだ書かれていない行は、読み取り位置を戻して次回に読む。
2. DBへの登録が成功してから状態ファイルを更新する。
3. DBの障害時には同じ行を再処理できる。
4. 上限を超えた行は、メモリにためずに次の改行まで読み飛ばす。

変更する場所の行番号を確認します。

```bash
grep -nE '^(POLL_INTERVAL|def process_line|def run)' \
  /tmp/wazuh-collector-hardening-test.py
```

## 3.2　上限の定数の追加

1行の上限を1 MiB、読み飛ばすときの単位を64 KiBにします。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")

old = "POLL_INTERVAL = 1.0\n"
new = """POLL_INTERVAL = 1.0
MAX_ALERT_LINE_BYTES = 1024 * 1024
READ_CHUNK_BYTES = 64 * 1024
"""

if source.count(old) != 1:
    raise SystemExit("ERROR: Expected constant not found exactly once")

path.write_text(source.replace(old, new, 1), encoding="utf-8")

print("Maximum alert line size: 1 MiB")
print("Read chunk size: 64 KiB")
PY

grep -nE '^(POLL_INTERVAL|MAX_ALERT_LINE_BYTES|READ_CHUNK_BYTES)' \
  /tmp/wazuh-collector-hardening-test.py
```

## 3.3　サイズ制限付きの読み取り関数

読み取り関数 `read_alert_line()` は、次の5つの状態を返します。

| 状態 | 意味 | Collectorの動作 |
|---|---|---|
| `line` | 正常な1行 | 処理してDBに登録する |
| `incomplete` | 改行がまだ書かれていない | 読み取り位置を戻して待つ |
| `oversized` | 上限を超えた行の終わりまで読み飛ばした | 読み飛ばした位置を保存する |
| `eof` | ファイルの末尾 | ローテーションを確認して待つ |
| `discarding` | 上限を超えた行を読み飛ばしている途中 | 次の読み取りでも読み飛ばしを続ける |

`process_line()` の直前に関数を追加します。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")

marker = "\ndef process_line(connection, line):\n"

if source.count(marker) != 1:
    raise SystemExit("ERROR: process_line insertion point not unique")

helper = '''

def read_alert_line(handle, discarding=False):
    """
    Read one bounded alert line.

    Returns:
        ("line", bytes, False)
        ("incomplete", None, False)
        ("oversized", None, False)
        ("eof", None, False)
        ("discarding", None, True)
    """
    if discarding:
        chunk = handle.readline(READ_CHUNK_BYTES)

        if not chunk:
            return "discarding", None, True

        if chunk.endswith(b"\\\\n"):
            return "oversized", None, False

        return "discarding", None, True

    line = handle.readline(MAX_ALERT_LINE_BYTES + 1)

    if not line:
        return "eof", None, False

    if line.endswith(b"\\\\n"):
        if len(line) > MAX_ALERT_LINE_BYTES:
            return "oversized", None, False
        return "line", line, False

    if len(line) <= MAX_ALERT_LINE_BYTES:
        return "incomplete", None, False

    chunk = handle.readline(READ_CHUNK_BYTES)

    if not chunk:
        return "discarding", None, True

    if chunk.endswith(b"\\\\n"):
        return "oversized", None, False

    return "discarding", None, True

'''

updated = source.replace(marker, helper + marker, 1)
path.write_text(updated, encoding="utf-8")

print("Bounded reader added to test copy")
PY

python3 -m py_compile /tmp/wazuh-collector-hardening-test.py \
  && echo "Python syntax: PASS"
```

## 3.4　改行判定の修正

追加した関数の内容を確認します。

```bash
sed -n '335,410p' \
  /tmp/wazuh-collector-hardening-test.py
```

`'''` で囲んだ文字列の中で `\\\\n` と書いたため、ファイルには `b"\\n"`（バックスラッシュと `n` の2文字）として書き込まれています。これでは実際の改行を判定できません。3か所を `b"\n"` に直します。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")

old = r'b"\\n"'
new = r'b"\n"'

count = source.count(old)

if count != 3:
    raise SystemExit(
        f"ERROR: Expected 3 escaped newline checks, found {count}"
    )

source = source.replace(old, new)
path.write_text(source, encoding="utf-8")

print("Corrected newline checks:", count)
PY

sed -n '355,390p' /tmp/wazuh-collector-hardening-test.py

python3 -m py_compile /tmp/wazuh-collector-hardening-test.py \
  && echo "Python syntax: PASS"
```

`Corrected newline checks: 3` と表示されれば修正できています。

## 3.5　読み取り関数の単体テスト

実際のログやDBは使わず、メモリ上のデータで確かめます。テストでは、上限を16バイト、読み飛ばしの単位を8バイトに小さくしています。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import importlib.util
import io

path = "/tmp/wazuh-collector-hardening-test.py"

spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

# テスト用に上限を小さく設定
module.MAX_ALERT_LINE_BYTES = 16
module.READ_CHUNK_BYTES = 8

read_line = module.read_alert_line

# 1. 正常な行
handle = io.BytesIO(b'{"a":1}\n')
status, line, discarding = read_line(handle)
assert status == "line"
assert line == b'{"a":1}\n'
assert discarding is False
print("NORMAL LINE: PASS")

# 2. 改行のない不完全な行
handle = io.BytesIO(b'{"a":1}')
status, line, discarding = read_line(handle)
assert status == "incomplete"
assert line is None
assert discarding is False
handle.seek(0)
assert handle.read() == b'{"a":1}'
print("INCOMPLETE LINE: PASS")

# 3. 上限を超える長い行を複数チャンクで破棄
handle = io.BytesIO(b"X" * 40 + b"\n" + b'{"ok":1}\n')
status, line, discarding = read_line(handle)

assert status == "discarding"
assert discarding is True

while status == "discarding":
    status, line, discarding = read_line(handle, discarding=True)

assert status == "oversized"
assert line is None
assert discarding is False
print("OVERSIZED LINE: PASS")

# 4. 超過行の直後にある正常行
status, line, discarding = read_line(handle)
assert status == "line"
assert line == b'{"ok":1}\n'
print("LINE AFTER OVERSIZED: PASS")

# 5. EOF
status, line, discarding = read_line(handle)
assert status == "eof"
print("EOF: PASS")

print("\nALL BOUNDED READER TESTS PASSED")
PY
```

5項目がすべて `PASS` になり、`ALL BOUNDED READER TESTS PASSED` と表示されれば成功です。

# 第4章　読み取りループの組み込み

## 4.1　ループの変更前の確認とバックアップ

読み取り関数を `run()` に組み込む前に、状態の保存・読み込み・初期ファイルの選び方を確認します。

**実行先：security-core VM 220（root）**

```bash
sed -n '390,510p' /tmp/wazuh-collector-hardening-test.py
```

```bash
sed -n '180,255p' /tmp/wazuh-collector-hardening-test.py
```

```bash
sed -n '245,345p' /tmp/wazuh-collector-hardening-test.py
```

inodeと読み取り位置を原子的に保存する `save_state()`、再起動時に位置を戻す `load_state()`、前回のファイルを探す `open_initial_file()` は、そのまま使えます。

```bash
grep -nE '^(def run|if __name__|POLL_INTERVAL|MAX_ALERT_LINE_BYTES|READ_CHUNK_BYTES)' \
  /tmp/wazuh-collector-hardening-test.py
```

テスト用コピー自体もバックアップします。

```bash
cp -a \
  /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.backup-before-loop-20261118

sha256sum \
  /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.backup-before-loop-20261118
```

## 4.2　新しい読み取りループ

`run()` を次の順序で動くように置き換えます。

1. まずログを1行読む（`read_alert_line()`）。
2. 上限を超えた行は、DBに接続せずに読み飛ばす。読み飛ばしが終わった位置を保存する。
3. 正常な行のときだけDBへの接続を確認する。接続に失敗したら、その行の先頭へ戻る。
4. DBへの登録が成功してから、読み取り位置を保存する。
5. 改行がまだない行は、行の先頭へ戻って待つ。

この順序にすると、DBが止まっていても巨大な行の読み飛ばしは進み、正常な行は取りこぼしません。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")

start = source.index("def run():")
end = source.index('\n\nif __name__ == "__main__":', start)

new_run = '''def run():
    logging.info("Wazuh alert collector starting")

    state = load_state()
    handle, active_inode = open_initial_file(state)

    connection = None
    discarding = False
    discard_start = None

    try:
        while True:
            line_start = handle.tell()

            status, line, _ = read_alert_line(
                handle,
                discarding=discarding,
            )

            if status == "line":
                if connection is None or connection.closed:
                    try:
                        connection = psycopg.connect(**DB_CONFIG)
                        logging.info("PostgreSQL connection established")
                    except Exception as error:
                        handle.seek(line_start)
                        logging.error(
                            "PostgreSQL connection failed: %s",
                            type(error).__name__,
                        )
                        time.sleep(5)
                        continue

                try:
                    process_line(connection, line)
                    save_state(active_inode, handle.tell())
                except Exception as error:
                    handle.seek(line_start)
                    logging.error(
                        "Alert processing failed: %s",
                        type(error).__name__,
                    )

                    try:
                        connection.close()
                    except Exception:
                        pass

                    connection = None
                    time.sleep(5)

                continue

            if status == "incomplete":
                handle.seek(line_start)
                time.sleep(POLL_INTERVAL)
                continue

            if status == "discarding":
                if not discarding:
                    discard_start = line_start
                    logging.warning(
                        "Oversized alert line detected; discarding"
                    )

                discarding = True
                time.sleep(POLL_INTERVAL)
                continue

            if status == "oversized":
                if discard_start is None:
                    discard_start = line_start

                try:
                    save_state(active_inode, handle.tell())
                    logging.warning("Oversized alert line skipped")
                    discarding = False
                    discard_start = None
                except Exception as error:
                    logging.error(
                        "State save failed after oversized line: %s",
                        type(error).__name__,
                    )
                    handle.seek(discard_start)
                    discarding = False
                    discard_start = None
                    time.sleep(POLL_INTERVAL)

                continue

            if status == "eof":
                if discarding:
                    time.sleep(POLL_INTERVAL)
                    continue

                try:
                    current_stat = ALERT_FILE.stat()
                except FileNotFoundError:
                    time.sleep(POLL_INTERVAL)
                    continue

                if current_stat.st_ino != active_inode:
                    handle.close()
                    handle = ALERT_FILE.open("rb")
                    active_inode = current_stat.st_ino

                    save_state(active_inode, 0)
                    logging.info("Switched to new alerts.json inode")

                time.sleep(POLL_INTERVAL)
                continue

    finally:
        handle.close()

        if connection is not None:
            connection.close()
'''

path.write_text(
    source[:start] + new_run + source[end:],
    encoding="utf-8",
)

print("DB-independent oversized-line handling applied")
PY

python3 -m py_compile \
  /tmp/wazuh-collector-hardening-test.py \
  && echo "Python syntax: PASS"
```

```bash
sed -n '415,535p' \
  /tmp/wazuh-collector-hardening-test.py
```

## 4.3　DB停止時のテスト

DBへの接続を必ず失敗させるモックを使い、実際の `run()` を動かします。`save_state` もモックに差し替えるため、本番の状態ファイルは変更されません。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import importlib.util
import io

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

module.MAX_ALERT_LINE_BYTES = 16
module.READ_CHUNK_BYTES = 8

payload = b"X" * 40 + b"\n" + b'{"ok":1}\n'

class TrackingBuffer(io.BytesIO):
    final_position = None

    def close(self):
        self.final_position = self.tell()
        super().close()

handle = TrackingBuffer(payload)
module.load_state = lambda: None
module.open_initial_file = lambda state: (handle, 123)

connect_attempts = []
saved_states = []

def fake_connect(**kwargs):
    connect_attempts.append(True)
    raise OSError("simulated database outage")

def fake_save_state(inode, offset):
    saved_states.append((inode, offset, len(connect_attempts)))

class StopTest(Exception):
    pass

def fake_sleep(seconds):
    if seconds == 5:
        raise StopTest()

original_connect = module.psycopg.connect
original_sleep = module.time.sleep
original_save_state = module.save_state

module.psycopg.connect = fake_connect
module.time.sleep = fake_sleep
module.save_state = fake_save_state

try:
    try:
        module.run()
    except StopTest:
        pass
finally:
    module.psycopg.connect = original_connect
    module.time.sleep = original_sleep
    module.save_state = original_save_state

assert saved_states == [(123, 41, 0)], saved_states
assert len(connect_attempts) == 1, connect_attempts
assert handle.final_position == 41, handle.final_position

print("OVERSIZED LINE PROCESSED WITHOUT DB: PASS")
print("OFFSET SAVED BEFORE DB CONNECTION: PASS")
print("NORMAL LINE POSITION RESTORED ON DB FAILURE: PASS")
print("PRODUCTION STATE FILE NOT MODIFIED BY TEST: PASS")
print("\nALL DB-OUTAGE TESTS PASSED")
PY
```

| 確認項目 | 意味 |
|---|---|
| `OVERSIZED LINE PROCESSED WITHOUT DB` | 41バイトの巨大な行を、DBに接続せずに読み飛ばした |
| `OFFSET SAVED BEFORE DB CONNECTION` | 読み飛ばした位置（41）を、DBに接続する前に保存した |
| `NORMAL LINE POSITION RESTORED ON DB FAILURE` | 次の正常な行は、DB接続に失敗したため先頭（41）に戻った |
| `PRODUCTION STATE FILE NOT MODIFIED BY TEST` | テストで本番の状態ファイルを変更していない |

> **重要：** `module.save_state` をモックに差し替えずに `run()` を動かすと、本物の `save_state()` が本番の状態ファイル（`/var/lib/wazuh-collector/state.json`）を書き換えてしまいます。`run()` を使うテストでは、必ず状態保存の関数を差し替えてください。

# 第5章　ローテーション時の読み残し対策

## 5.1　問題点

現在の `run()` には、ローテーションに関する問題が2つあります。

1. 巨大な行の読み飛ばし中にファイルの末尾（EOF）に達すると、inodeを確認せずに待ち続ける。
2. 改行がまだない行（`incomplete`）は毎回同じ位置に戻るため、EOFの処理にたどり着かない。

どちらも、Wazuhが日付の切り替わりで新しいファイルに移ると、Collectorが古いファイルで止まったままになります。対策は、**現在の `alerts.json` のinodeが変わっていたら、旧ファイルの未完了の行を警告付きで捨てて、新しいファイルを先頭から読む** ことです。inodeが変わっていない間は、書き込み途中の可能性があるので待ち続けます。

**実行先：security-core VM 220（root）**

```bash
sed -n '300,414p' \
  /tmp/wazuh-collector-hardening-test.py
```

```bash
sed -n '415,510p' \
  /tmp/wazuh-collector-hardening-test.py
```

修正の前にバックアップします。

```bash
cp -a \
  /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.backup-before-rotation-20261118

sha256sum \
  /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.backup-before-rotation-20261118
```

## 5.2　EOFでのローテーション検知

新しいファイルを開き、状態の保存に成功してから切り替えます。保存に失敗した場合は、新しいファイルを閉じて旧ファイルのまま待ちます。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")

old = '''            if status == "eof":
                if discarding:
                    time.sleep(POLL_INTERVAL)
                    continue

                try:
                    current_stat = ALERT_FILE.stat()
                except FileNotFoundError:
                    time.sleep(POLL_INTERVAL)
                    continue

                if current_stat.st_ino != active_inode:
                    handle.close()
                    handle = ALERT_FILE.open("rb")
                    active_inode = current_stat.st_ino

                    save_state(active_inode, 0)
                    logging.info("Switched to new alerts.json inode")

                time.sleep(POLL_INTERVAL)
                continue
'''

new = '''            if status == "eof":
                try:
                    current_stat = ALERT_FILE.stat()
                except FileNotFoundError:
                    time.sleep(POLL_INTERVAL)
                    continue

                if current_stat.st_ino != active_inode:
                    new_handle = ALERT_FILE.open("rb")
                    try:
                        save_state(current_stat.st_ino, 0)
                    except Exception as error:
                        new_handle.close()
                        logging.error(
                            "State save failed during rotation: %s",
                            type(error).__name__,
                        )
                        time.sleep(POLL_INTERVAL)
                        continue

                    if discarding:
                        logging.warning(
                            "Incomplete oversized line discarded at rotation"
                        )

                    handle.close()
                    handle = new_handle
                    active_inode = current_stat.st_ino
                    discarding = False
                    discard_start = None

                    logging.info("Switched to new alerts.json inode")

                time.sleep(POLL_INTERVAL)
                continue
'''

count = source.count(old)
if count != 1:
    raise SystemExit(f"Expected exactly one EOF block, found {count}")

path.write_text(source.replace(old, new), encoding="utf-8")
print("EOF rotation handling updated")
PY

python3 -m py_compile \
  /tmp/wazuh-collector-hardening-test.py
```

`py_compile` は成功しても何も表示しないため、改めて確認します。

```bash
python3 -m py_compile \
  /tmp/wazuh-collector-hardening-test.py \
&& echo "Python syntax: PASS"

sed -n '440,535p' \
  /tmp/wazuh-collector-hardening-test.py
```

## 5.3　未完了の行でのローテーション検知

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")

old = '''            if status == "incomplete":
                handle.seek(line_start)
                time.sleep(POLL_INTERVAL)
                continue
'''

new = '''            if status == "incomplete":
                try:
                    current_stat = ALERT_FILE.stat()
                except FileNotFoundError:
                    handle.seek(line_start)
                    time.sleep(POLL_INTERVAL)
                    continue

                if current_stat.st_ino != active_inode:
                    new_handle = ALERT_FILE.open("rb")
                    try:
                        save_state(current_stat.st_ino, 0)
                    except Exception as error:
                        new_handle.close()
                        handle.seek(line_start)
                        logging.error(
                            "State save failed during incomplete-line rotation: %s",
                            type(error).__name__,
                        )
                        time.sleep(POLL_INTERVAL)
                        continue

                    logging.warning(
                        "Incomplete alert line discarded at rotation"
                    )
                    handle.close()
                    handle = new_handle
                    active_inode = current_stat.st_ino
                    discarding = False
                    discard_start = None
                    logging.info("Switched to new alerts.json inode")
                else:
                    handle.seek(line_start)

                time.sleep(POLL_INTERVAL)
                continue
'''

if source.count(old) != 1:
    raise SystemExit("Expected exactly one incomplete block")

path.write_text(source.replace(old, new), encoding="utf-8")
print("Incomplete-line rotation handling updated")
PY
```

```bash
python3 -m py_compile \
  /tmp/wazuh-collector-hardening-test.py \
&& echo "Python syntax: PASS"

sed -n '455,555p' \
  /tmp/wazuh-collector-hardening-test.py
```

## 5.4　読み飛ばし中のEOFの通知

`read_alert_line()` は、読み飛ばし中にファイルの末尾に達すると `discarding` を返していました。これでは `run()` のEOFの処理（5.2）に届きません。`eof` を返すように直します。読み飛ばし中であることは `run()` 側の変数 `discarding` に残っているため、ローテーション時の警告は出せます。

**実行先：security-core VM 220（root）**

```bash
sed -n '335,415p' \
  /tmp/wazuh-collector-hardening-test.py
```

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")

old = '''        if not chunk:
            return "discarding", None, True
'''

new = '''        if not chunk:
            return "eof", None, False
'''

if source.count(old) != 1:
    raise SystemExit(
        f"Expected exactly one match, found {source.count(old)}"
    )

path.write_text(source.replace(old, new), encoding="utf-8")
print("EOF detection during discard updated")
PY
```

読み取り関数を確認します。`READ_CHUNK_BYTES = 8` のとき、`b"abcdefgh\n"`（9バイト）は1回目では改行に届かず `discarding`、2回目で `oversized` になります。

```bash
python3 - <<'PY'
import importlib.util
import io

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

module.MAX_ALERT_LINE_BYTES = 16
module.READ_CHUNK_BYTES = 8

# 破棄中のEOF
handle = io.BytesIO(b"")
assert module.read_alert_line(handle, True)[0] == "eof"

# 複数チャンクにまたがる超過行
handle = io.BytesIO(b"abcdefgh\n")
assert module.read_alert_line(handle, True)[0] == "discarding"
assert module.read_alert_line(handle, True)[0] == "oversized"

# 通常行
handle = io.BytesIO(b'{"ok":1}\n')
status, line, _ = module.read_alert_line(handle)
assert status == "line" and line == b'{"ok":1}\n'

# 未完了行
handle = io.BytesIO(b'{"ok":1}')
assert module.read_alert_line(handle)[0] == "incomplete"

print("DISCARD EOF TEST: PASS")
print("MULTI-CHUNK DISCARD TEST: PASS")
print("NORMAL LINE TEST: PASS")
print("INCOMPLETE LINE TEST: PASS")
print("ALL READER TESTS PASSED")
PY
```

## 5.5　ローテーションの統合テスト

一時ディレクトリに旧ファイルと新しいファイルを作り、実際の `run()` で切り替えを確認します。本番のログ・DB・状態ファイルには触れません。

**実行先：security-core VM 220（root）**

```bash
sed -n '415,550p' \
  /tmp/wazuh-collector-hardening-test.py
```

旧ファイルに未完了の行が残っている場合：

```bash
python3 - <<'PY'
import importlib.util
import tempfile
from pathlib import Path

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class StopTest(Exception):
    pass

with tempfile.TemporaryDirectory() as directory:
    root = Path(directory)
    old_path = root / "old-alerts.json"
    new_path = root / "alerts.json"

    old_path.write_bytes(b'{"unfinished":')
    new_path.write_bytes(b"")

    old_handle = old_path.open("rb")
    old_inode = old_path.stat().st_ino
    new_inode = new_path.stat().st_ino

    assert old_inode != new_inode

    saved_states = []
    warnings = []

    module.ALERT_FILE = new_path
    module.load_state = lambda: None
    module.open_initial_file = lambda state: (old_handle, old_inode)
    module.save_state = lambda inode, offset: saved_states.append(
        (inode, offset)
    )
    module.logging.warning = lambda message, *args: warnings.append(message)

    def stop_after_switch(seconds):
        raise StopTest()

    original_sleep = module.time.sleep
    module.time.sleep = stop_after_switch

    try:
        try:
            module.run()
        except StopTest:
            pass
    finally:
        module.time.sleep = original_sleep

    assert saved_states == [(new_inode, 0)], saved_states
    assert "Incomplete alert line discarded at rotation" in warnings
    assert old_handle.closed

    print("INCOMPLETE LINE ROTATION: PASS")
    print("NEW INODE STATE SAVED: PASS")
    print("NEW FILE OFFSET ZERO: PASS")
    print("OLD FILE HANDLE CLOSED: PASS")
    print("ALL ROTATION TESTS PASSED")
PY
```

巨大な行の読み飛ばし中にローテーションした場合（40バイトを8バイトずつ読み飛ばすため、状態が保存されるまでループを続けてから止めます）：

```bash
python3 - <<'PY'
import importlib.util
import tempfile
from pathlib import Path

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class StopTest(Exception):
    pass

with tempfile.TemporaryDirectory() as directory:
    root = Path(directory)
    old_path = root / "old-alerts.json"
    new_path = root / "alerts.json"

    old_path.write_bytes(b"X" * 40)
    new_path.write_bytes(b"")

    old_handle = old_path.open("rb")
    old_inode = old_path.stat().st_ino
    new_inode = new_path.stat().st_ino

    assert old_inode != new_inode

    module.MAX_ALERT_LINE_BYTES = 16
    module.READ_CHUNK_BYTES = 8
    module.ALERT_FILE = new_path
    module.load_state = lambda: None
    module.open_initial_file = lambda state: (old_handle, old_inode)

    saved_states = []
    warnings = []

    module.save_state = lambda inode, offset: saved_states.append(
        (inode, offset)
    )
    module.logging.warning = lambda message, *args: warnings.append(message)

    original_sleep = module.time.sleep

    def controlled_sleep(seconds):
        if saved_states:
            raise StopTest()

    module.time.sleep = controlled_sleep

    try:
        try:
            module.run()
        except StopTest:
            pass
    finally:
        module.time.sleep = original_sleep

    assert saved_states == [(new_inode, 0)], saved_states
    assert "Incomplete oversized line discarded at rotation" in warnings
    assert old_handle.closed

    print("OVERSIZED LINE ROTATION: PASS")
    print("NEW INODE STATE SAVED: PASS")
    print("NEW FILE OFFSET ZERO: PASS")
    print("OLD FILE HANDLE CLOSED: PASS")
    print("ALL OVERSIZED ROTATION TESTS PASSED")
PY
```

どちらも4項目が `PASS` になれば、未完了の行・巨大な行のどちらが残っていても、ローテーション後に新しいファイルへ移れます。

## 5.6　構造の確認

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import ast
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")

tree = ast.parse(source, filename=str(path))

functions = {
    node.name
    for node in ast.walk(tree)
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
}

required = {
    "safe_integer",
    "safe_text",
    "safe_string_list",
    "safe_mitre",
    "read_alert_line",
    "run",
    "process_line",
    "save_state",
}

missing = required - functions

assert not missing, f"Missing functions: {sorted(missing)}"

print("PYTHON SYNTAX: PASS")
print("REQUIRED FUNCTIONS: PASS")
print("FUNCTION COUNT:", len(functions))
print("TEST FILE SIZE:", len(source.encode("utf-8")))
PY
```

`PYTHON SYNTAX: PASS` と `REQUIRED FUNCTIONS: PASS` を確認します。構築時は関数が14個、テスト用コピーは15,201バイトでした。

# 第6章　機密情報と入力検証の総合テスト

## 6.1　ソースコードの静的な確認

`full_log` を参照していないか、INSERT文の対象、パスワードなどを含むログの文字列がないかを、構文木から調べます。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import ast
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
tree = ast.parse(path.read_text(encoding="utf-8"))

for node in ast.walk(tree):
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        value = node.value.lower()

        if "full_log" in value:
            print("FULL_LOG reference:", repr(node.value))

        if "insert into incident.alert_events" in value:
            print("\n=== INSERT SQL ===")
            print(node.value)

        if "logging." in value and any(
            word in value for word in (
                "password", "token", "secret", "credential"
            )
        ):
            print("REVIEW LOG STRING:", repr(node.value))

print("\n=== CHECK COMPLETE ===")
PY
```

`full_log` への参照はなく、INSERTの対象は許可した13列だけで、秘密情報を含むログの文字列もないことを確認します。

ソース全体も目で確認します。

```bash
sed -n '1,260p' /tmp/wazuh-collector-hardening-test.py
```

```bash
sed -n '260,460p' /tmp/wazuh-collector-hardening-test.py
```

## 6.2　機密情報が保存されないことのテスト

アラートのあらゆる場所に秘密の値を入れ、DBに登録するデータに1文字も残らないことを確認します。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import importlib.util
import json

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

secret = "DO_NOT_STORE_SECRET_7f3a"

alert = {
    "id": "1795000021.999999",
    "timestamp": "2026-11-18T12:00:00+00:00",
    "full_log": secret,
    "command": secret,
    "password": secret,
    "user": secret,
    "rule": {
        "id": "100106",
        "level": 12,
        "description": "Authentication failure",
        "groups": ["authentication_failed"],
        "mitre": {
            "id": ["T1110"],
            "tactic": ["Credential Access"],
            "technique": ["Brute Force"],
            "unexpected": secret,
        },
        "unexpected": secret,
    },
    "agent": {"id": "004", "name": "postgresql"},
    "manager": {"name": "security-core"},
    "decoder": {"name": "postgresql"},
    "data": {
        "srcip": "192.0.2.10",
        "srcport": "5432",
        "password": secret,
        "query": secret,
        "unexpected": secret,
    },
    "unexpected": secret,
}

event = module.extract_event(alert)

assert event is not None
assert secret not in json.dumps(
    event,
    default=str,
)

expected = {
    "event_id",
    "event_timestamp",
    "rule_id",
    "rule_level",
    "rule_description",
    "agent_id",
    "agent_name",
    "manager_name",
    "decoder_name",
    "rule_groups",
    "srcip",
    "srcport",
    "mitre",
}

assert set(event) == expected
assert event["srcip"] == "192.0.2.10"
assert event["srcport"] == 5432

print("SECRET VALUE EXCLUSION: PASS")
print("UNKNOWN FIELD EXCLUSION: PASS")
print("EXACT 13-FIELD WHITELIST: PASS")
print("VALIDATED IP/PORT EXTRACTION: PASS")
print("SENSITIVE DATA TEST: PASS")
PY
```

## 6.3　制御文字フィルターの修正

制御文字が取り除かれるかを確認します。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import importlib.util

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

value = "alpha\nbeta\r\ngamma\tdelta\x00epsilon\x7fomega"

result = module.safe_text(value)

print("INPUT REPR :", repr(value))
print("OUTPUT REPR:", repr(result))

assert result is not None
assert "\n" not in result
assert "\r" not in result
assert "\t" not in result
assert "\x00" not in result
assert "\x7f" not in result

print("CONTROL CHARACTER FILTER: PASS")
PY
```

構築時の結果は、改行・タブ・NULは除去されましたが、DEL（`0x7f`）が残りました（`AssertionError`）。

```text
OUTPUT REPR: 'alphabetagammadeltaepsilon\x7fomega'
```

原因は2.2で `'''` の中に `"\\\\x7f"` と書いたことで、ファイルにはDEL文字ではなく `\x7f` という4文字の文字列との比較が書き込まれていたためです（3.4の改行判定と同じ原因です）。該当の行を確認します。

```bash
grep -n -A 12 -B 3 'def safe_text' \
  /tmp/wazuh-collector-hardening-test.py
```

DELに加えて、C1制御文字（`0x80`〜`0x9f`）もまとめて除去する条件に置き換えます。修正の前にバックアップします。

```bash
cp -a /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.backup-before-control-fix-20261118

python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")

old = '        if char >= " " and char != "\\\\x7f"'
new = '        if char >= " " and not 0x7f <= ord(char) <= 0x9f'

count = source.count(old)

if count != 1:
    raise SystemExit(f"Expected exactly one target, found {count}")

path.write_text(
    source.replace(old, new, 1),
    encoding="utf-8",
)

print("TEST SCRIPT ONLY: UPDATED")
print("REPLACEMENTS:", count)
PY
```

対象の行が実際にどう書かれているかを、`repr` で確認します。

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")

for number, line in enumerate(
    path.read_text(encoding="utf-8").splitlines(),
    start=1,
):
    if 125 <= number <= 134:
        print(number, repr(line))
PY
```

次のように表示されれば、修正後の条件になっています。

```text
131 '        if char >= " " and not 0x7f <= ord(char) <= 0x9f'
```

> 構築時は、置換のコマンドが `Expected exactly one target, found 0` と表示しましたが、この確認で131行目はすでに修正後の内容になっていました。表示が「found 0」でも、必ずこの `repr` の確認で実際の内容を判断してください。

C0・DEL・C1の制御文字をまとめて再テストします。

```bash
python3 - <<'PY'
import importlib.util

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

value = (
    "alpha\nbeta\r\ngamma\tdelta"
    "\x00epsilon\x1f"
    "\x7f"
    "\x80"
    "\x9f"
    "omega"
)

result = module.safe_text(value)

print("OUTPUT REPR:", repr(result))

assert result == "alphabetagammadeltaepsilonomega", repr(result)

print("C0 CONTROL CHARACTERS: PASS")
print("DEL CHARACTER: PASS")
print("C1 CONTROL CHARACTERS: PASS")
print("CONTROL CHARACTER FILTER: PASS")
PY
```

## 6.4　各検証関数の境界値テスト

**実行先：security-core VM 220（root）**

文字列（`safe_text`）：

```bash
python3 - <<'PY'
import importlib.util

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

assert module.safe_text("A" * 5000, 4096) == "A" * 4096
assert module.safe_text("  valid text  ") == "valid text"
assert module.safe_text(" \t\n ") is None
assert module.safe_text(None) is None
assert module.safe_text(12345) is None

print("MAXIMUM LENGTH: PASS")
print("WHITESPACE TRIMMING: PASS")
print("EMPTY STRING REJECTION: PASS")
print("NON-STRING REJECTION: PASS")
print("SAFE TEXT VALIDATION: PASS")
PY
```

整数（`safe_integer`）：

```bash
python3 - <<'PY'
import importlib.util

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

safe = module.safe_integer

assert safe(0, 0, 16) == 0
assert safe(16, 0, 16) == 16
assert safe("12", 0, 16) == 12

assert safe(-1, 0, 16) is None
assert safe(17, 0, 16) is None
assert safe(True, 0, 16) is None
assert safe(False, 0, 16) is None

assert safe("1.5", 0, 16) is None
assert safe(" 12", 0, 16) is None
assert safe("+12", 0, 16) is None
assert safe("１２", 0, 16) is None
assert safe("9" * 21, 0, 16) is None
assert safe(None, 0, 16) is None

print("LOWER/UPPER BOUNDARY: PASS")
print("ASCII DECIMAL STRING: PASS")
print("NEGATIVE/OVERFLOW REJECTION: PASS")
print("BOOLEAN REJECTION: PASS")
print("INVALID STRING REJECTION: PASS")
print("SAFE INTEGER VALIDATION: PASS")
PY
```

IPアドレス（`safe_ip`）：

```bash
python3 - <<'PY'
import importlib.util

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

safe = module.safe_ip

assert safe("192.0.2.10") == "192.0.2.10"
assert safe("2001:0db8:0000:0000:0000:0000:0000:0001") == "2001:db8::1"
assert safe("::1") == "::1"

assert safe("999.999.999.999") is None
assert safe("192.0.2.10/24") is None
assert safe("example.com") is None
assert safe("") is None
assert safe(None) is None
assert safe(12345) is None

print("IPV4 VALIDATION: PASS")
print("IPV6 NORMALIZATION: PASS")
print("INVALID IP REJECTION: PASS")
print("NON-IP INPUT REJECTION: PASS")
print("SAFE IP VALIDATION: PASS")
PY
```

文字列のリスト（`safe_string_list`）：

```bash
python3 - <<'PY'
import importlib.util

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

safe = module.safe_string_list

assert safe(["alpha", "beta"]) == ["alpha", "beta"]

items = [f"item-{i}" for i in range(100)]
result = safe(items, max_items=64)

assert len(result) == 64
assert result[0] == "item-0"
assert result[-1] == "item-63"

long_result = safe(["A" * 500], item_limit=256)
assert long_result == ["A" * 256]

assert safe("not-a-list") == []
assert safe(None) == []
assert safe([None, 123, "", "valid"]) == ["valid"]

print("NORMAL LIST: PASS")
print("MAXIMUM ITEM COUNT: PASS")
print("MAXIMUM ITEM LENGTH: PASS")
print("INVALID LIST REJECTION: PASS")
print("INVALID ELEMENT FILTERING: PASS")
print("SAFE STRING LIST VALIDATION: PASS")
PY
```

MITRE情報（`safe_mitre`）：

```bash
python3 - <<'PY'
import importlib.util

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

safe = module.safe_mitre

result = safe({
    "id": ["T1110"],
    "tactic": ["Credential Access"],
    "technique": ["Brute Force"],
    "unexpected": "SECRET_VALUE",
})

assert set(result) == {"id", "tactic", "technique"}
assert result["id"] == ["T1110"]
assert result["tactic"] == ["Credential Access"]
assert result["technique"] == ["Brute Force"]

many = [f"T{i}" for i in range(100)]
limited = safe({"id": many})

assert len(limited["id"]) == 32

assert safe("invalid") == {}
assert safe(None) == {}

print("MITRE KEY WHITELIST: PASS")
print("MITRE VALUE PRESERVATION: PASS")
print("MITRE LIST LIMIT: PASS")
print("INVALID INPUT REJECTION: PASS")
print("SAFE MITRE VALIDATION: PASS")
PY
```

| 関数 | 確認した内容 |
|---|---|
| `safe_text` | 最大4,096文字、前後の空白の除去、空白だけの文字列と文字列以外の拒否 |
| `safe_integer` | 境界値、真偽値・小数・符号付き・全角数字・21桁以上の拒否 |
| `safe_ip` | IPv4、IPv6の正規化、CIDR表記・ホスト名・空値の拒否 |
| `safe_string_list` | 最大64個・各256文字、不正な要素の除外 |
| `safe_mitre` | 3つのキーだけを許可、`id` は最大32個 |

## 6.5　テスト版と本番の状態の確認

**実行先：security-core VM 220（root）**

```bash
python3 -m py_compile \
  /tmp/wazuh-collector-hardening-test.py \
  && echo "PYTHON COMPILE: PASS"

sha256sum /tmp/wazuh-collector-hardening-test.py

stat -c 'owner=%U:%G mode=%a size=%s modified=%y' \
  /tmp/wazuh-collector-hardening-test.py
```

```bash
echo "=== PRODUCTION COLLECTOR ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== TEST COLLECTOR ==="
sha256sum /tmp/wazuh-collector-hardening-test.py

echo
echo "=== PRODUCTION SERVICE ==="
systemctl is-active wazuh-collector.service

echo
echo "=== PRODUCTION STATE ==="
stat -c 'owner=%U:%G mode=%a size=%s modified=%y' \
  /var/lib/wazuh-collector/state.json
```

本番のCollector（`931ee3cb...`）は変わっておらず、テスト版（構築時15,215バイト）とは別の内容で、本番のサービスは `active` のままであることを確認します。

本番の読み取り位置が、現在の `alerts.json` と合っているかも確認します（状態ファイルの値そのものは表示しません）。

```bash
python3 - <<'PY'
import json
from pathlib import Path

state_path = Path("/var/lib/wazuh-collector/state.json")
alert_path = Path("/var/ossec/logs/alerts/alerts.json")

state = json.loads(state_path.read_text(encoding="utf-8"))
alert_stat = alert_path.stat()

inode_ok = state.get("inode") == alert_stat.st_ino
offset_ok = state.get("offset") == alert_stat.st_size

print("STATE JSON: PASS")
print("INODE MATCH:", "PASS" if inode_ok else "FAIL")
print("OFFSET MATCH:", "PASS" if offset_ok else "FAIL")

if not inode_ok or not offset_ok:
    raise SystemExit("STATE CONSISTENCY CHECK FAILED")
PY
```

# 第7章　状態ファイルとinodeの厳密化

## 7.1　問題点

**実行先：security-core VM 220（root）**

```bash
grep -n -A65 -B5 -E \
'^(def load_state|def open_initial_file|def run)' \
/tmp/wazuh-collector-hardening-test.py
```

```bash
sed -n '465,555p' \
  /tmp/wazuh-collector-hardening-test.py
```

```bash
sed -n '530,610p' \
  /tmp/wazuh-collector-hardening-test.py
```

確認の結果、次の3つの問題が見つかりました。

| 箇所 | 問題 | 対策 |
|---|---|---|
| `load_state()` | `int()` で変換するため、`true` も整数として受け入れる | `safe_integer()` で範囲と型を検証する |
| `open_initial_file()` | ファイルを開く前の `stat()` のinodeを保存している | 開いたファイルの `os.fstat()` のinodeを使う |
| `run()` のローテーション | `stat()` と `open()` の間に再びローテーションすると、保存するinodeと実際に開いたファイルが食い違う | 開いた直後の `os.fstat()` のinodeを保存する |

修正の前にバックアップします。

```bash
cp -a \
  /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.backup-before-inode-fix-20261118

sha256sum \
  /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.backup-before-inode-fix-20261118
```

## 7.2　状態ファイルの値の検証

inodeは1以上、読み取り位置は0以上で、どちらも64ビット符号付き整数の範囲に収まる整数だけを受け入れます。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")

old = '''        inode = int(state["inode"])
        offset = int(state["offset"])

        if inode <= 0 or offset < 0:
            raise ValueError("invalid state")
'''

new = '''        if not isinstance(state, dict):
            raise ValueError("invalid state")

        inode = safe_integer(
            state.get("inode"),
            1,
            9223372036854775807,
        )
        offset = safe_integer(
            state.get("offset"),
            0,
            9223372036854775807,
        )

        if inode is None or offset is None:
            raise ValueError("invalid state")
'''

count = source.count(old)
if count != 1:
    raise SystemExit(
        f"ERROR: Expected exactly one target block, found {count}"
    )

path.write_text(source.replace(old, new), encoding="utf-8")
print("LOAD_STATE VALIDATION PATCH: PASS")
PY
```

一時ディレクトリの状態ファイルでテストします（本番の状態ファイルには触れません）。

```bash
python3 - <<'PY'
import importlib.util
import tempfile
import json
from pathlib import Path

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

with tempfile.TemporaryDirectory() as directory:
    state_file = Path(directory) / "state.json"
    module.STATE_FILE = state_file

    state_file.write_text(
        json.dumps({"inode": 12345, "offset": 67890}),
        encoding="utf-8",
    )
    assert module.load_state() == (12345, 67890)

    print("VALID STATE: PASS")

    invalid_states = [
        {"inode": True, "offset": 10},
        {"inode": 12345, "offset": False},
        {"inode": -1, "offset": 10},
        {"inode": 12345, "offset": -1},
        {"inode": "invalid", "offset": 10},
        {"inode": 12345, "offset": 2**63},
        [],
        None,
    ]

    for invalid in invalid_states:
        state_file.write_text(json.dumps(invalid), encoding="utf-8")
        try:
            module.load_state()
        except RuntimeError:
            continue
        raise AssertionError(f"Invalid state accepted: {invalid!r}")

    print("INVALID STATE REJECTION: PASS")

    state_file.unlink()
    assert module.load_state() is None
    print("MISSING STATE HANDLING: PASS")

print("LOAD_STATE VALIDATION: PASS")
PY
```

## 7.3　初期ファイルを開く処理の修正

**実行先：security-core VM 220（root）**

```bash
sed -n '299,350p' \
  /tmp/wazuh-collector-hardening-test.py
```

`open_initial_file()` 全体を置き換えます。開いた直後に `os.fstat()` で実際のinodeとサイズを取り、状態にはそのinodeを保存します。途中で例外が起きた場合はファイルを閉じます。

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")

start = source.index("def open_initial_file(state):")
end = source.index("\n\ndef read_alert_line(", start)

new_function = '''def open_initial_file(state):
    if state is None:
        handle = ALERT_FILE.open("rb")
        try:
            actual_stat = os.fstat(handle.fileno())
            handle.seek(0, os.SEEK_END)
            offset = handle.tell()

            save_state(actual_stat.st_ino, offset)

            logging.info("Initial start at current end of alerts.json")
            return handle, actual_stat.st_ino
        except Exception:
            handle.close()
            raise

    old_inode, old_offset = state
    old_path = find_inode_file(old_inode)

    if old_path is not None:
        handle = old_path.open("rb")
        actual_stat = os.fstat(handle.fileno())

        if actual_stat.st_ino == old_inode:
            handle.seek(min(old_offset, actual_stat.st_size))
            logging.info("Resuming previous alert file")
            return handle, actual_stat.st_ino

        handle.close()
        logging.warning(
            "Previous alert file changed while opening; using current file"
        )

    handle = ALERT_FILE.open("rb")
    try:
        actual_stat = os.fstat(handle.fileno())

        if actual_stat.st_ino == old_inode:
            handle.seek(min(old_offset, actual_stat.st_size))
        else:
            handle.seek(0)
            logging.warning(
                "Previous rotated file not found; replaying current file"
            )

        return handle, actual_stat.st_ino
    except Exception:
        handle.close()
        raise
'''

source = source[:start] + new_function + source[end:]
path.write_text(source, encoding="utf-8")

print("OPEN_INITIAL_FILE INODE PATCH: PASS")
PY
```

```bash
python3 -m py_compile \
  /tmp/wazuh-collector-hardening-test.py \
  && echo "PYTHON COMPILE: PASS"

sed -n '311,375p' \
  /tmp/wazuh-collector-hardening-test.py
```

初回起動・ローテーション済みファイルからの再開・旧ファイルがない場合の3つを、一時ディレクトリでテストします。

```bash
python3 - <<'PY'
import importlib.util
import tempfile
import os
from pathlib import Path

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

with tempfile.TemporaryDirectory() as directory:
    root = Path(directory)
    alert_dir = root / "alerts"
    alert_dir.mkdir()
    alert_file = alert_dir / "alerts.json"

    module.ALERT_DIR = alert_dir
    module.ALERT_FILE = alert_file

    saved = []
    module.save_state = lambda inode, offset: saved.append((inode, offset))

    # 1. Initial start
    alert_file.write_bytes(b"first\nsecond\n")
    handle, inode = module.open_initial_file(None)

    actual_inode = os.fstat(handle.fileno()).st_ino
    assert inode == actual_inode
    assert handle.tell() == len(b"first\nsecond\n")
    assert saved == [(actual_inode, len(b"first\nsecond\n"))]
    handle.close()
    print("INITIAL START: PASS")

    # 2. Resume rotated file
    old_file = alert_dir / "alerts.json.1"
    alert_file.rename(old_file)
    alert_file.write_bytes(b"new-alert\n")

    old_inode = old_file.stat().st_ino
    handle, inode = module.open_initial_file((old_inode, 6))

    assert inode == os.fstat(handle.fileno()).st_ino
    assert inode == old_inode
    assert handle.tell() == 6
    handle.close()
    print("ROTATED FILE RESUME: PASS")

    # 3. Previous file missing
    missing_inode = old_inode + 1000000
    handle, inode = module.open_initial_file((missing_inode, 6))

    assert inode == os.fstat(handle.fileno()).st_ino
    assert inode == alert_file.stat().st_ino
    assert handle.tell() == 0
    handle.close()
    print("MISSING OLD FILE FALLBACK: PASS")

print("OPEN_INITIAL_FILE TESTS: PASS")
PY
```

## 7.4　ローテーション時のinodeの修正

未完了の行のとき（5.3）とEOFのとき（5.2）の両方で、新しいファイルを開いた直後に `os.fstat()` でinodeを取り直します。開いたファイルが旧ファイルと同じinodeだった場合は、切り替えずに待ちます。

**実行先：security-core VM 220（root）**

未完了の行のとき：

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")

old = '''                if current_stat.st_ino != active_inode:
                    new_handle = ALERT_FILE.open("rb")
                    try:
                        save_state(current_stat.st_ino, 0)
                    except Exception as error:
                        new_handle.close()
                        handle.seek(line_start)
                        logging.error(
                            "State save failed during incomplete-line rotation: %s",
                            type(error).__name__,
                        )
                        time.sleep(POLL_INTERVAL)
                        continue

                    logging.warning(
                        "Incomplete alert line discarded at rotation"
                    )
                    handle.close()
                    handle = new_handle
                    active_inode = current_stat.st_ino
                    discarding = False
                    discard_start = None
                    logging.info("Switched to new alerts.json inode")
'''

new = '''                if current_stat.st_ino != active_inode:
                    new_handle = ALERT_FILE.open("rb")
                    new_stat = os.fstat(new_handle.fileno())

                    if new_stat.st_ino == active_inode:
                        new_handle.close()
                        handle.seek(line_start)
                        time.sleep(POLL_INTERVAL)
                        continue

                    try:
                        save_state(new_stat.st_ino, 0)
                    except Exception as error:
                        new_handle.close()
                        handle.seek(line_start)
                        logging.error(
                            "State save failed during incomplete-line rotation: %s",
                            type(error).__name__,
                        )
                        time.sleep(POLL_INTERVAL)
                        continue

                    logging.warning(
                        "Incomplete alert line discarded at rotation"
                    )
                    handle.close()
                    handle = new_handle
                    active_inode = new_stat.st_ino
                    discarding = False
                    discard_start = None
                    logging.info("Switched to new alerts.json inode")
'''

count = source.count(old)
if count != 1:
    raise SystemExit(
        f"ERROR: Expected exactly one incomplete-rotation block, found {count}"
    )

path.write_text(source.replace(old, new), encoding="utf-8")
print("INCOMPLETE ROTATION INODE PATCH: PASS")
PY
```

```bash
python3 -m py_compile \
  /tmp/wazuh-collector-hardening-test.py \
  && echo "PYTHON COMPILE: PASS"

sed -n '465,515p' \
  /tmp/wazuh-collector-hardening-test.py
```

EOFのとき：

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")

old = '''                if current_stat.st_ino != active_inode:
                    new_handle = ALERT_FILE.open("rb")
                    try:
                        save_state(current_stat.st_ino, 0)
                    except Exception as error:
                        new_handle.close()
                        logging.error(
                            "State save failed during rotation: %s",
                            type(error).__name__,
                        )
                        time.sleep(POLL_INTERVAL)
                        continue

                    if discarding:
                        logging.warning(
                            "Incomplete oversized line discarded at rotation"
                        )

                    handle.close()
                    handle = new_handle
                    active_inode = current_stat.st_ino
                    discarding = False
                    discard_start = None

                    logging.info("Switched to new alerts.json inode")
'''

new = '''                if current_stat.st_ino != active_inode:
                    new_handle = ALERT_FILE.open("rb")
                    new_stat = os.fstat(new_handle.fileno())

                    if new_stat.st_ino == active_inode:
                        new_handle.close()
                        time.sleep(POLL_INTERVAL)
                        continue

                    try:
                        save_state(new_stat.st_ino, 0)
                    except Exception as error:
                        new_handle.close()
                        logging.error(
                            "State save failed during rotation: %s",
                            type(error).__name__,
                        )
                        time.sleep(POLL_INTERVAL)
                        continue

                    if discarding:
                        logging.warning(
                            "Incomplete oversized line discarded at rotation"
                        )

                    handle.close()
                    handle = new_handle
                    active_inode = new_stat.st_ino
                    discarding = False
                    discard_start = None

                    logging.info("Switched to new alerts.json inode")
'''

count = source.count(old)
if count != 1:
    raise SystemExit(
        f"ERROR: Expected exactly one EOF-rotation block, found {count}"
    )

path.write_text(source.replace(old, new), encoding="utf-8")
print("EOF ROTATION INODE PATCH: PASS")
PY
```

```bash
python3 -m py_compile \
  /tmp/wazuh-collector-hardening-test.py \
  && echo "PYTHON COMPILE: PASS"

sed -n '525,585p' \
  /tmp/wazuh-collector-hardening-test.py
```

```bash
sed -n '565,610p' \
  /tmp/wazuh-collector-hardening-test.py
```

## 7.5　inodeの修正の確認

構文木から `run()` のソースを取り出し、両方の箇所で実際のinodeを使っているかを確認します。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import ast
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")
tree = ast.parse(source)

run_func = next(
    node for node in tree.body
    if isinstance(node, ast.FunctionDef) and node.name == "run"
)

run_source = ast.get_source_segment(source, run_func)

checks = {
    "fstat after rotation open": "os.fstat(new_handle.fileno())",
    "incomplete state uses actual inode": "save_state(new_stat.st_ino, 0)",
    "EOF state uses actual inode": run_source.count(
        "save_state(new_stat.st_ino, 0)"
    ) == 2,
    "active inode uses actual inode": run_source.count(
        "active_inode = new_stat.st_ino"
    ) == 2,
}

for name, result in checks.items():
    passed = result if isinstance(result, bool) else result in run_source
    print(f"{name}: {'PASS' if passed else 'FAIL'}")
    if not passed:
        raise SystemExit(1)

print("ROTATION INODE STATIC CHECK: PASS")
PY
```

実際に `run()` を動かし、待機中にファイルをローテーションさせて、保存されたinodeが新しいファイルのものと一致するかを確認します。

```bash
python3 - <<'PY'
import importlib.util
import tempfile
from pathlib import Path


class StopTest(Exception):
    pass


path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def test_rotation(mode):
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        alert_dir = root / "alerts"
        alert_dir.mkdir()
        alert_file = alert_dir / "alerts.json"

        alert_file.write_bytes(
            b"partial" if mode == "incomplete" else b""
        )

        module.ALERT_DIR = alert_dir
        module.ALERT_FILE = alert_file

        initial_inode = alert_file.stat().st_ino
        module.load_state = lambda: (initial_inode, 0)

        saved_states = []
        module.save_state = lambda inode, offset: (
            saved_states.append((inode, offset))
        )

        sleep_count = 0

        def controlled_sleep(_seconds):
            nonlocal sleep_count
            sleep_count += 1

            if sleep_count == 1:
                alert_file.rename(alert_dir / "alerts.json.1")
                alert_file.write_bytes(b"new-alert\n")
                return

            raise StopTest()

        module.time.sleep = controlled_sleep

        try:
            module.run()
        except StopTest:
            pass
        else:
            raise AssertionError("Collector did not reach test stop")

        new_inode = alert_file.stat().st_ino

        assert saved_states, "No state was saved"
        assert saved_states[0] == (new_inode, 0), saved_states

        print(f"{mode.upper()} ROTATION: PASS")
        print(f"{mode.upper()} STATE INODE MATCH: PASS")


test_rotation("eof")
test_rotation("incomplete")

print("ROTATION INTEGRATION TESTS: PASS")
PY
```

`EOF ROTATION`・`INCOMPLETE ROTATION` の両方で `PASS` となれば、ローテーション後に保存されるinodeが、実際に開いた新しいファイルと一致しています。

# 第8章　テスト版の総合検証

第7章までで、主な改善がテスト版に入りました。この章では、テスト版を関数ごとに、もう一度まとめて検証します。DB・本番の状態ファイル・本番のCollectorには触れません。

## 8.1　読み込みの安全性と本番の状態

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import ast
import importlib.util
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")

source = path.read_text(encoding="utf-8")
ast.parse(source)
print("AST SYNTAX: PASS")

spec = importlib.util.spec_from_file_location(
    "collector_import_safety_test",
    str(path),
)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

print("IMPORT WITHOUT RUN: PASS")
print("TEST MODULE:", module.__name__)
PY
```

モジュールとして読み込んでも `run()` が動かないことを確認します。

```bash
echo "=== PRODUCTION SCRIPT ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== TEST SCRIPT ==="
sha256sum /tmp/wazuh-collector-hardening-test.py

echo
echo "=== PRODUCTION SERVICE ==="
systemctl is-active wazuh-collector.service

echo
echo "=== PRODUCTION FILE PERMISSIONS ==="
stat -c '%U:%G %a %s %n' \
  /usr/local/lib/wazuh-collector/collector.py
```

本番は `root:root 755 9626` のまま、サービスは `active` です。

## 8.2　関数の一覧とrun()の確認

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import ast
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
tree = ast.parse(path.read_text(encoding="utf-8"))

for node in tree.body:
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        print(
            f"{node.name}: "
            f"lines {node.lineno}-{node.end_lineno}"
        )
PY
```

構築時は14個の関数があり、末尾は `open_initial_file`（322〜370行目）、`read_alert_line`（373〜416行目）、`process_line`（419〜438行目）、`run`（441〜618行目）でした。行番号は環境で異なることがあるため、以降の `sed` の範囲は、この出力に合わせてください。

```bash
sed -n '441,618p' \
  /tmp/wazuh-collector-hardening-test.py
```

```bash
sed -n '373,440p' \
  /tmp/wazuh-collector-hardening-test.py
```

## 8.3　行サイズの境界値テスト

本来の上限（1 MiB）のまま、ちょうど上限・上限超え・改行なし・非常に大きい行の4つを確かめます。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import importlib.util
import tempfile
from pathlib import Path

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

limit = module.MAX_ALERT_LINE_BYTES

cases = [
    ("exact_limit", b"A" * (limit - 1) + b"\n", "line"),
    ("over_limit", b"A" * limit + b"\n", "oversized"),
    ("incomplete", b"A" * (limit - 1), "incomplete"),
    ("huge_line", b"A" * (limit + 200000) + b"\n", "discarding"),
]

for name, content, expected in cases:
    with tempfile.TemporaryFile() as handle:
        handle.write(content)
        handle.seek(0)

        status, line, discarding = module.read_alert_line(handle)

        assert status == expected, (
            name, status, expected
        )

        if name == "exact_limit":
            assert len(line) == limit
        else:
            assert line is None

        if name == "huge_line":
            assert discarding is True

        print(f"{name}: PASS ({status})")

print("LINE SIZE BOUNDARY TESTS: PASS")
PY
```

| ケース | 結果 |
|---|---|
| 1 MiBちょうど（改行込み） | `line` |
| 1 MiB超え | `oversized` |
| 改行なし | `incomplete` |
| 1 MiB＋約200 KB | `discarding` |

巨大な行を64 KiBずつ捨てたあと、次の正常な行を読めることを確認します。

```bash
python3 - <<'PY'
import importlib.util
import tempfile

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

with tempfile.TemporaryFile() as handle:
    huge = b"A" * (module.MAX_ALERT_LINE_BYTES + 300000)
    valid = b'{"rule":{"id":"100001"}}\n'

    handle.write(huge + b"\n" + valid)
    handle.seek(0)

    status, line, discarding = module.read_alert_line(handle)

    assert status == "discarding"
    assert discarding is True
    print("OVERSIZED DETECTION: PASS")

    chunks = 0
    while True:
        status, line, discarding = module.read_alert_line(
            handle,
            discarding=True,
        )
        chunks += 1

        if status == "oversized":
            break

        assert status == "discarding"
        assert line is None

    print(f"CHUNKED DISCARD: PASS ({chunks} chunks)")

    status, line, discarding = module.read_alert_line(handle)

    assert status == "line"
    assert line == valid
    assert discarding is False

    print("NEXT VALID LINE: PASS")

print("CHUNKED OVERSIZED LINE TEST: PASS")
PY
```

構築時は4回に分けて捨て、直後の正常な行を読めました。

## 8.4　状態ファイルの管理

**実行先：security-core VM 220（root）**

```bash
sed -n '244,370p' \
  /tmp/wazuh-collector-hardening-test.py
```

保存と読み込み、権限 `0600`、置き換え、不正な値の拒否を、一時ディレクトリで確認します。

```bash
python3 - <<'PY'
import importlib.util
import json
import os
import tempfile
from pathlib import Path

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

with tempfile.TemporaryDirectory() as directory:
    state_file = Path(directory) / "state.json"
    module.STATE_FILE = state_file

    module.save_state(12345, 67890)

    assert state_file.exists()
    assert module.load_state() == (12345, 67890)
    print("STATE SAVE/LOAD: PASS")

    mode = os.stat(state_file).st_mode & 0o777
    assert mode == 0o600, oct(mode)
    print("STATE PERMISSION 0600: PASS")

    before = json.loads(state_file.read_text())
    module.save_state(12346, 67891)
    after = json.loads(state_file.read_text())

    assert before != after
    assert after == {"inode": 12346, "offset": 67891}
    print("ATOMIC STATE REPLACEMENT: PASS")

    invalid_states = [
        [],
        {"inode": True, "offset": 0},
        {"inode": 123, "offset": -1},
        {"inode": "invalid", "offset": 0},
    ]

    for invalid in invalid_states:
        state_file.write_text(json.dumps(invalid))
        try:
            module.load_state()
        except RuntimeError:
            pass
        else:
            raise AssertionError(f"Invalid state accepted: {invalid}")

    print("INVALID STATE REJECTION: PASS")

print("STATE MANAGEMENT TESTS: PASS")
PY
```

## 8.5　DB登録と重複処理

INSERT文とDBの設定、`event_id` の作り方を確認します。

**実行先：security-core VM 220（root）**

```bash
sed -n '1,80p' \
  /tmp/wazuh-collector-hardening-test.py
```

> このコマンドはファイルを表示するだけです。`.pgpass` やDBのパスワードは表示されません。もし出力に秘密情報が含まれていた場合は、どこにも貼り付けないでください。

```bash
sed -n '186,243p' \
  /tmp/wazuh-collector-hardening-test.py
```

```bash
sed -n '419,440p' \
  /tmp/wazuh-collector-hardening-test.py
```

| 項目 | 確認結果 |
|---|---|
| 接続 | TLS `verify-full`、専用ユーザー `wazuh_collector` |
| SQL | INSERTだけ。`ON CONFLICT` は使わない |
| 対象の列 | 13項目のホワイトリスト |
| `event_id` | Wazuhのアラートの `id`（最大128文字）。再処理しても同じIDになる |
| 重複処理 | `connection.transaction()` の外側で `UniqueViolation` を捕まえるため、トランザクションは確実にロールバックされる |

DBの接続をモック（偽物）にして、登録成功・重複・その他のDBエラーの3つを確かめます。

```bash
python3 - <<'PY'
import importlib.util
import json

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class FakeTransaction:
    def __init__(self, connection):
        self.connection = connection

    def __enter__(self):
        self.connection.entered += 1
        return self

    def __exit__(self, exc_type, exc, tb):
        if exc_type is not None:
            self.connection.rolled_back += 1
        else:
            self.connection.committed += 1
        return False

class FakeConnection:
    def __init__(self, error=None):
        self.error = error
        self.entered = 0
        self.committed = 0
        self.rolled_back = 0
        self.executed = 0

    def transaction(self):
        return FakeTransaction(self)

    def execute(self, sql, event):
        self.executed += 1
        if self.error:
            raise self.error

alert = {
    "id": "test-event-001",
    "timestamp": "2026-11-18T12:00:00.000+0900",
    "rule": {"id": "100001", "level": 5},
    "agent": {"id": "001", "name": "test-agent"},
    "manager": {"name": "test-manager"},
    "decoder": {"name": "json"},
}

line = json.dumps(alert).encode()

# 1. INSERT成功
conn = FakeConnection()
module.process_line(conn, line)

assert conn.executed == 1
assert conn.committed == 1
assert conn.rolled_back == 0
print("INSERT SUCCESS: PASS")

# 2. 一意制約違反
duplicate = module.psycopg.errors.UniqueViolation(
    "duplicate key"
)
conn = FakeConnection(duplicate)
module.process_line(conn, line)

assert conn.executed == 1
assert conn.rolled_back == 1
assert conn.committed == 0
print("DUPLICATE HANDLING: PASS")

# 3. その他のDBエラー
other_error = module.psycopg.errors.OperationalError(
    "simulated database failure"
)
conn = FakeConnection(other_error)

try:
    module.process_line(conn, line)
except module.psycopg.errors.OperationalError:
    pass
else:
    raise AssertionError("OperationalError was swallowed")

assert conn.rolled_back == 1
print("OTHER DB ERROR PROPAGATION: PASS")

print("MOCK DB TRANSACTION TESTS: PASS")
PY
```

## 8.6　状態の保存失敗後の再処理

DBへの登録は成功したのに、状態ファイルの保存に失敗した場合を考えます。Collectorは行の先頭に戻って同じアラートをもう一度処理しますが、2回目は重複として捨てられ、DBには1件だけ残る、という流れを確かめます。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import importlib.util
import json
import tempfile

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class FakeTransaction:
    def __init__(self, connection):
        self.connection = connection

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

class FakeConnection:
    def __init__(self):
        self.ids = set()
        self.inserts = 0
        self.duplicates = 0

    def transaction(self):
        return FakeTransaction(self)

    def execute(self, sql, event):
        self.inserts += 1
        event_id = event["event_id"]

        if event_id in self.ids:
            self.duplicates += 1
            raise module.psycopg.errors.UniqueViolation(
                "duplicate key"
            )

        self.ids.add(event_id)

alert = {
    "id": "retry-event-001",
    "timestamp": "2026-11-18T12:00:00.000+0900",
    "rule": {"id": "100001", "level": 5},
    "agent": {"id": "001", "name": "test-agent"},
    "manager": {"name": "test-manager"},
    "decoder": {"name": "json"},
}
line = json.dumps(alert).encode()

connection = FakeConnection()
save_attempts = 0

with tempfile.TemporaryFile() as handle:
    handle.write(line + b"\n")
    handle.seek(0)

    start = handle.tell()
    status, data, _ = module.read_alert_line(handle)
    assert status == "line"

    module.process_line(connection, data)

    save_attempts += 1
    try:
        raise OSError("simulated state failure")
    except OSError:
        handle.seek(start)

    status, retry_data, _ = module.read_alert_line(handle)
    assert status == "line"
    assert retry_data == data

    module.process_line(connection, retry_data)

    save_attempts += 1
    assert handle.tell() == len(line) + 1

assert connection.inserts == 2
assert connection.duplicates == 1
assert len(connection.ids) == 1
assert save_attempts == 2

print("FIRST INSERT: PASS")
print("STATE FAILURE AND REWIND: PASS")
print("RETRY DUPLICATE DETECTION: PASS")
print("SINGLE STORED EVENT: PASS")
print("STATE RETRY SEQUENCE: PASS")
PY
```

| 確認項目 | 結果 |
|---|---|
| 1回目の登録 | 成功 |
| 状態の保存失敗と巻き戻し | 行の先頭に戻る |
| 2回目の処理 | 重複として検出され、捨てられる |
| DBに残る件数 | 1件 |

> 第3部で `ON CONFLICT` をやめ、`UniqueViolation` で重複を処理するように直したことが、ここで「再処理しても二重に登録されない」安全性につながっています。

## 8.7　本番との差分

最後に、本番のコードとテスト版の差分を確認します。表示するだけで、何も変更しません。

**実行先：security-core VM 220（root）**

```bash
diff -u \
  /usr/local/lib/wazuh-collector/collector.py \
  /tmp/wazuh-collector-hardening-test.py
```

差分は、次の5つの領域に分かれます。

1. アラートの入力値の厳格化とホワイトリスト化（第2章・第6章）
2. 状態ファイルの値の検証（第7章）
3. 実際に開いたファイルのinodeによるローテーション処理（第5章・第7章）
4. 1行1 MiBの上限と、巨大な行の段階的な読み飛ばし（第3章・第4章）
5. DB接続の失敗時の読み取り位置の巻き戻し（第4章）

```bash
nl -ba /tmp/wazuh-collector-hardening-test.py | sed -n '435,625p'
```

# 第9章　ファイル操作の例外処理と最終確認

## 9.1　ファイル操作の洗い出し

`stat`・`open`・`fstat`・`close`・`seek`・`tell`・`readline` を呼んでいる行を、構文木からすべて書き出します。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import ast
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
tree = ast.parse(path.read_text(encoding="utf-8"))

targets = {
    "stat", "open", "fstat", "close",
    "seek", "tell", "readline"
}

for node in ast.walk(tree):
    if isinstance(node, ast.Call):
        func = node.func
        name = None

        if isinstance(func, ast.Attribute):
            name = func.attr
        elif isinstance(func, ast.Name):
            name = func.id

        if name in targets:
            print(
                f"line={node.lineno} "
                f"operation={name}"
            )
PY
```

```bash
nl -ba /tmp/wazuh-collector-hardening-test.py | sed -n '315,375p;485,620p'
```

| 箇所 | 問題 | 方針 |
|---|---|---|
| `open_initial_file()` のローテーション済みファイル | 開いた後に `fstat()`・`seek()` が失敗すると、ファイルが開いたまま残る | 失敗したらファイルを閉じて、例外を呼び出し元に伝える |
| `run()` のローテーション時の `stat()`・`open()` | `FileNotFoundError` 以外の `OSError` で処理が止まる | 読めないファイルを黙って飛ばすとアラートが欠落するため、例外で終了させ、systemdに再起動させる（9.3） |

> すべての `OSError` を一律に握りつぶすことはしません。ファイルが読めない状態で処理を続けると、アラートの欠落につながるためです。

## 9.2　ローテーション済みファイルを開く処理の修正

修正の前にバックアップします。

**実行先：security-core VM 220（root）**

```bash
cp -a \
  /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.backup-before-file-open-fix-20261118
```

```bash
sha256sum \
  /tmp/wazuh-collector-hardening-test.py \
  /tmp/wazuh-collector-hardening-test.py.backup-before-file-open-fix-20261118
```

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-hardening-test.py")
source = path.read_text(encoding="utf-8")

old = '''    if old_path is not None:
        handle = old_path.open("rb")
        actual_stat = os.fstat(handle.fileno())

        if actual_stat.st_ino == old_inode:
            handle.seek(min(old_offset, actual_stat.st_size))
            logging.info("Resuming previous alert file")
            return handle, actual_stat.st_ino

        handle.close()
        logging.warning(
            "Previous alert file changed while opening; using current file"
        )
'''

new = '''    if old_path is not None:
        handle = None
        try:
            handle = old_path.open("rb")
            actual_stat = os.fstat(handle.fileno())

            if actual_stat.st_ino == old_inode:
                handle.seek(min(old_offset, actual_stat.st_size))
                logging.info("Resuming previous alert file")
                return handle, actual_stat.st_ino

            handle.close()
            handle = None
            logging.warning(
                "Previous alert file changed while opening; using current file"
            )
        except Exception:
            if handle is not None:
                try:
                    handle.close()
                except OSError:
                    pass
            raise
'''

count = source.count(old)
if count != 1:
    raise SystemExit(
        f"ERROR: Expected exactly one target block, found {count}"
    )

path.write_text(source.replace(old, new), encoding="utf-8")
print("TEST COPY UPDATED: PASS")
print("TARGET BLOCK COUNT:", count)
PY
```

```bash
python3 -m py_compile \
  /tmp/wazuh-collector-hardening-test.py \
&& sed -n '335,375p' \
  /tmp/wazuh-collector-hardening-test.py
```

`fstat()` が失敗する偽のファイルで、例外が伝わり、ファイルが閉じられることを確認します。実際のファイルは使いません。

```bash
python3 - <<'PY'
import importlib.util
from pathlib import Path

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class FakeHandle:
    def __init__(self):
        self.closed = False

    def fileno(self):
        return 123

    def close(self):
        self.closed = True

handle = FakeHandle()
old_path = Path("/tmp/fake-rotated-alerts.json")

original_find = module.find_inode_file
original_open = Path.open
original_fstat = module.os.fstat

try:
    module.find_inode_file = lambda inode: old_path

    def fake_open(self, *args, **kwargs):
        if self == old_path:
            return handle
        raise AssertionError("Unexpected file open")

    def fake_fstat(fd):
        raise OSError("simulated fstat failure")

    Path.open = fake_open
    module.os.fstat = fake_fstat

    try:
        module.open_initial_file((12345, 100))
        raise AssertionError("Expected OSError was not raised")
    except OSError as error:
        assert str(error) == "simulated fstat failure"

    assert handle.closed

    print("FSTAT FAILURE PROPAGATION: PASS")
    print("FILE HANDLE CLOSED: PASS")

finally:
    module.find_inode_file = original_find
    Path.open = original_open
    module.os.fstat = original_fstat
PY
```

## 9.3　予期しない例外とsystemdの自動再起動

想定外の `OSError` でCollectorが終了しても、systemdが再起動すれば、保存済みの読み取り位置から再開できます。本番サービスの再起動の設定を確認します（設定は変更しません）。

**実行先：security-core VM 220（root）**

```bash
systemctl show wazuh-collector.service \
  -p Restart \
  -p RestartUSec \
  -p NRestarts \
  -p ActiveState \
  -p SubState
```

```text
Restart=always
RestartUSec=5s
NRestarts=0
ActiveState=active
SubState=running
```

## 9.4　一意制約の確認

再起動後の再処理で二重登録が起きないのは、`event_id` に一意制約があるからです。テーブルのインデックスを確認します。Collector用の `.pgpass` は専用の場所にあるため、`PGPASSFILE` で指定します。

**実行先：security-core VM 220（root）**

```bash
sudo -u wazuh-collector env \
  PGPASSFILE=/etc/wazuh-collector/.pgpass \
  psql "host=postgresql.neomedia.mydns.jp hostaddr=192.168.0.151 dbname=security_workbench user=wazuh_collector sslmode=verify-full sslrootcert=/etc/ssl/certs/postgresql-server-ca.pem" \
  -c "SELECT indexname, indexdef FROM pg_indexes WHERE schemaname='incident' AND tablename='alert_events';"
```

> `PGPASSFILE` を指定しないと、psqlは標準の `~/.pgpass` を探すため、`fe_sendauth: no password supplied` で失敗します。また、結果がページャー（`less`）で表示された場合は、`q` キーで終了します。

```text
 alert_events_pkey          | CREATE UNIQUE INDEX alert_events_pkey ON incident.alert_events USING btree (event_id)
 idx_alert_events_timestamp | CREATE INDEX idx_alert_events_timestamp ON incident.alert_events USING btree (event_timestamp DESC)
 idx_alert_events_level     | CREATE INDEX idx_alert_events_level ON incident.alert_events USING btree (rule_level DESC)
 idx_alert_events_rule      | CREATE INDEX idx_alert_events_rule ON incident.alert_events USING btree (rule_id)
 idx_alert_events_srcip     | CREATE INDEX idx_alert_events_srcip ON incident.alert_events USING btree (srcip)
```

`alert_events_pkey` が `event_id` の一意インデックスです。これで、次の流れで二重登録が防がれることを確認できました。

1. DBへの登録が成功する。
2. 状態を保存する前に障害が起き、Collectorが終了する。
3. systemdが5秒後にCollectorを再起動する。
4. 保存済みの読み取り位置から、同じアラートをもう一度処理する。
5. `event_id` の一意制約で拒否され、`Duplicate alert skipped` として読み飛ばされる。

## 9.5　本番の状態の確認

**実行先：security-core VM 220（root）**

```bash
echo "=== SERVICE ==="
systemctl is-active wazuh-collector.service

echo
echo "=== RESTART COUNT ==="
systemctl show wazuh-collector.service -p NRestarts

echo
echo "=== PRODUCTION SCRIPT HASH ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py
```

本番のCollectorは `active`、再起動0回、SHA-256は第4部の開始時と同じ `931ee3cb...` のままです。第4部の作業は、すべてテスト用コピーだけで行いました。

# 第4部のまとめ

第4部では、稼働中のCollectorを止めずに監査し、テスト用コピー `/tmp/wazuh-collector-hardening-test.py` で次の強化を行いました。

| 領域 | 強化の内容 | 章 |
|---|---|---|
| 入力検証 | 真偽値の拒否、制御文字（C0・DEL・C1）の除去、リストとMITRE情報の上限 | 第2・6章 |
| 行サイズ | 1行1 MiBの上限、64 KiB単位の読み飛ばし | 第3・4章 |
| DB障害 | 巨大な行はDBなしで処理、正常な行は接続失敗時に巻き戻す | 第4章 |
| ローテーション | 未完了の行・読み飛ばし中でも新しいファイルへ切り替える | 第5章 |
| 状態ファイル | 値の型と範囲の検証、実際に開いたファイルのinodeを保存 | 第7章 |
| 例外処理 | 開いたファイルを確実に閉じる、想定外のエラーはsystemdの再起動に任せる | 第9章 |

| バックアップ | 内容 |
|---|---|
| `/usr/local/lib/wazuh-collector/collector.py.backup-pre-hardening-20261118` | 改善前の本番コード（1.5） |
| `/tmp/wazuh-collector-hardening-test.py.backup-before-*-20261118` | テスト版の各修正の直前の状態 |

> `/tmp` のテスト版とバックアップは、VMを再起動すると消えることがあります。第5部で本番に反映するまでは、security-coreを再起動しないでください。

第5部では、終了処理の改善を加えたうえで、テスト版を本番のCollectorに反映し、再起動・実際のローテーション・DB登録の一致を確認します。
