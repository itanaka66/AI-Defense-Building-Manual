---
title: "AI自律型サイバー防御システム 構築マニュアル 前編"
subtitle: "第8部　統合監視基盤の構築"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」前編の第8部です。第7部までで、Wazuhのアラートを PostgreSQL に保存する仕組みが完成しました。第8部では、防御システムを構成するサーバーそのものの状態（CPU・メモリ・ディスク・ネットワーク）を集め、Grafanaの統合ダッシュボードで見られるようにします。

## 本書の表記

- コマンドやファイル内容は、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 各手順の冒頭に「実行先」を示します。
- 「実行結果（例）」は構築時の実際の出力です。系列数・時刻などは、お使いの環境では異なります。

## 監視の対象と方針

統合ダッシュボードで監視するのは、次の5台です。

| 対象 | IPアドレス | 役割 |
|---|---|---|
| Proxmoxホスト `pve` | 192.168.0.240 | ハイパーバイザー |
| VM 220 `security-core` | 192.168.0.220 | Wazuh・Collector |
| LXC 109 `postgresql` | 192.168.0.151 | PostgreSQL（Wazuhイベントの保存先） |
| LXC 103 `lxc-prometheus` | 192.168.0.197 | Prometheus |
| LXC 105 `lxc-grafana` | 192.168.0.199 | Grafana |

- 各サーバーに Node Exporter を入れ、Prometheus（LXC 103）が集めます。
- Prometheus は、集めたデータを既存の VictoriaMetrics に転送（Remote Write）して保存します。Grafana は VictoriaMetrics を見ます。
- Grafana と VictoriaMetrics は外部に公開しません。内部専用の監視基盤とします。
- LXC 400番台は対象外です。VictoriaMetrics は既存の LXC 406 で動いていますが、本書では `vmbr0` 側のアドレス `192.168.0.171:8428` に接続して使うだけで、LXC 406 自体の設定は変更しません。
- `192.168.1.25`（別システムの PostgreSQL と PostgreSQL Exporter）も対象外です。

# 第1章　GrafanaとVictoriaMetricsの接続

## 1.1　Grafanaの状態の確認

**実行先：LXC 105 lxc-grafana（root）**

```bash
echo "=== HOST ==="
hostname
ip -br addr

echo
echo "=== GRAFANA SERVICE ==="
systemctl is-active grafana-server
systemctl status grafana-server --no-pager -l | head -25

echo
echo "=== GRAFANA HTTP ==="
curl -sS --max-time 5 http://127.0.0.1:3000/api/health

echo
echo
echo "=== LISTEN PORT ==="
ss -lntp | grep ':3000' || true

echo
echo "=== GRAFANA PROVISIONING FILES ==="
find /etc/grafana/provisioning -maxdepth 3 -type f \
  -printf '%p\n' 2>/dev/null | sort
```

構築時は Grafana 13.0.2 が `active (running)` で、`/api/health` も正常でした。

## 1.2　VictoriaMetricsへの到達の確認

Grafana（`vmbr0`、192.168.0.0/24）からは、VictoriaMetrics の `vmbr1` 側のアドレス（192.168.1.23）には届きません。ネットワークを変更せず、`vmbr0` 側のアドレス `192.168.0.171` に接続できるかを確かめます。

**実行先：LXC 105 lxc-grafana（root）**

```bash
echo "=== VICTORIAMETRICS VMbr0 HEALTH ==="
curl -sS --max-time 5 \
  -w '\nHTTP_STATUS=%{http_code}\n' \
  http://192.168.0.171:8428/health

echo
echo "=== VICTORIAMETRICS VMbr0 METRICS QUERY ==="
curl -sS --max-time 5 \
  -G 'http://192.168.0.171:8428/api/v1/query' \
  --data-urlencode 'query=up' \
  -w '\nHTTP_STATUS=%{http_code}\n' \
  | head -c 1000
```

`/health` が HTTP 200（`OK`）、`/api/v1/query` が `status: success` であれば接続できています。

## 1.3　データソースの登録

GrafanaのWeb画面（`http://192.168.0.199:3000`）にログインし、次の設定を行います。

1. 左メニュー **Connections → Data sources**
2. **Add data source**
3. **Prometheus** を選択
4. 以下を設定

| 項目 | 設定値 |
|---|---|
| Name | VictoriaMetrics |
| Prometheus server URL | `http://192.168.0.171:8428` |
| Access | Server（既定値） |

5. **Save & test** をクリック

`Successfully queried the Prometheus API.` と表示されれば完了です。

# 第2章　監視対象の現状の確認

## 2.1　VictoriaMetricsに届いているデータ

**実行先：LXC 105 lxc-grafana（root）**

```bash
echo "=== UP TARGETS ==="
curl -sS --max-time 10 \
  'http://192.168.0.171:8428/api/v1/query?query=up' \
  | python3 -c '
import json,sys
d=json.load(sys.stdin)
for r in d.get("data",{}).get("result",[]):
    m=r["metric"]
    job=m.get("job","-")
    instance=m.get("instance","-")
    value=r["value"][1]
    print("{:<20} {:<30} UP={}".format(job,instance,value))
'
```

構築時は11件の系列がありましたが、5台のどれのデータでもありませんでした（対象外のサーバーのものです）。5台のCPU・メモリ・ディスクのデータは、まだ集められていません。

## 2.2　ポートの確認

**実行先：LXC 105 lxc-grafana（root）**

```bash
python3 - <<'PY'
import socket

targets = {
    "pve": "192.168.0.240",
    "security-core": "192.168.0.220",
    "postgresql": "192.168.0.151",
    "prometheus": "192.168.0.197",
    "grafana": "192.168.0.199",
}

ports = {
    "node_exporter": 9100,
    "postgres_exporter": 9187,
    "prometheus": 9090,
    "grafana": 3000,
}

for name, ip in targets.items():
    print(f"\n=== {name} ({ip}) ===")
    for service, port in ports.items():
        try:
            with socket.create_connection((ip, port), timeout=2):
                result = "OPEN"
        except OSError:
            result = "CLOSED/UNREACHABLE"
        print(f"{service:20} {ip}:{port:<5} {result}")
PY
```

構築時は、5台とも Node Exporter（9100）が `CLOSED` でした。各サーバーで確かめたところ、どれにも Node Exporter は入っていませんでした。次章から、1台ずつ導入して動作を確認してから次のサーバーへ進みます。

# 第3章　ProxmoxホストへのNode Exporterの導入

## 3.1　パッケージの確認

**実行先：Proxmoxホスト pve（root）**

```bash
echo "=== OS VERSION ==="
cat /etc/os-release | grep -E '^(PRETTY_NAME|VERSION_CODENAME)='

echo
echo "=== NODE EXPORTER PACKAGE CANDIDATE ==="
apt-cache policy prometheus-node-exporter
```

構築時は Debian 12（bookworm）で、公式リポジトリの `prometheus-node-exporter 1.5.0-1+b6` を導入できました。

## 3.2　インストール

パッケージを入れると、すぐにすべてのアドレスで待ち受けを始めます。先に一時的にマスクして、起動しないようにしてから入れます。

**実行先：Proxmoxホスト pve（root）**

```bash
systemctl mask --runtime prometheus-node-exporter.service
```

```bash
apt-get install -y prometheus-node-exporter
```

設定を確認します（まだ起動しません）。

```bash
echo "=== SERVICE UNIT ==="
systemctl cat prometheus-node-exporter.service

echo
echo "=== DEFAULT CONFIG ==="
if [ -f /etc/default/prometheus-node-exporter ]; then
  cat /etc/default/prometheus-node-exporter
else
  echo "No default config"
fi

echo
echo "=== MASK STATUS ==="
systemctl is-enabled prometheus-node-exporter.service
```

Debianのパッケージは、`/etc/default/prometheus-node-exporter` の `ARGS` で起動オプションを指定します。`MASK STATUS` が `masked-runtime` であることを確認します。

## 3.3　待ち受けのアドレスの限定と起動

待ち受けを `192.168.0.240:9100` だけに限定します。

**実行先：Proxmoxホスト pve（root）**

```bash
cp -a /etc/default/prometheus-node-exporter \
  /etc/default/prometheus-node-exporter.bak

sed -i \
  's/^ARGS=.*/ARGS="--web.listen-address=192.168.0.240:9100"/' \
  /etc/default/prometheus-node-exporter

echo "=== UPDATED CONFIG ==="
cat /etc/default/prometheus-node-exporter
```

```bash
systemctl unmask --runtime prometheus-node-exporter.service
systemctl daemon-reload
systemctl enable --now prometheus-node-exporter.service
```

```bash
echo "=== SERVICE STATUS ==="
systemctl status prometheus-node-exporter.service --no-pager -l

echo
echo "=== LISTEN SOCKET ==="
ss -lntp | grep ':9100'

echo
echo "=== METRICS TEST ==="
curl -fsS http://192.168.0.240:9100/metrics | head -n 15
```

最後に `curl: (23) Failure writing output to destination` と表示されますが、`head` が15行で読み取りを終えたためで、異常ではありません。

## 3.4　Prometheusからの到達の確認

**実行先：LXC 103 lxc-prometheus（root）**

```bash
echo "=== PVE NODE EXPORTER CONNECTIVITY ==="
curl -fsS --max-time 5 \
  http://192.168.0.240:9100/metrics \
  -o /tmp/pve-node-metrics.prom \
  && grep -E '^(node_uname_info|node_cpu_seconds_total|node_memory_MemTotal_bytes)' \
     /tmp/pve-node-metrics.prom | head -n 10

echo
echo "=== HTTP RESULT ==="
test -s /tmp/pve-node-metrics.prom && echo "SUCCESS: metrics received"
```

`SUCCESS: metrics received` と表示されれば届いています。

# 第4章　Prometheusへの収集ジョブの追加

## 4.1　ジョブの追加

既存のジョブ（`prometheus`・`ollama-gpu`）はそのままにして、PVE用のジョブを追加します。

**実行先：LXC 103 lxc-prometheus（root）**

```bash
cp -a /etc/prometheus/prometheus.yml \
  /etc/prometheus/prometheus.yml.bak.$(date +%Y%m%d-%H%M%S)

cat >> /etc/prometheus/prometheus.yml <<'EOF'

  - job_name: "pve-node"
    static_configs:
      - targets:
          - 192.168.0.240:9100
        labels:
          host: "pve"
          role: "hypervisor"
EOF

echo "=== VALIDATE CONFIG ==="
promtool check config /etc/prometheus/prometheus.yml
```

`SUCCESS` と表示されることを確認します（構築時は Prometheus 3.12.0）。

## 4.2　設定の再読み込み

このPrometheusは、Web API（Lifecycle API）での再読み込みが無効です（HTTP 403になります）。systemd のユニットに次の設定があるため、`systemctl reload` で SIGHUP を送って再読み込みします。

```text
ExecReload=/bin/kill -HUP $MAINPID
```

**実行先：LXC 103 lxc-prometheus（root）**

```bash
systemctl reload prometheus

echo "=== SERVICE STATUS ==="
systemctl is-active prometheus

echo
echo "=== PVE TARGET STATUS ==="
curl -fsS 'http://127.0.0.1:9090/api/v1/targets?state=active' \
  | python3 -c '
import json, sys
data = json.load(sys.stdin)
for target in data["data"]["activeTargets"]:
    if target["labels"].get("job") == "pve-node":
        print("health:", target["health"])
        print("scrapeUrl:", target["scrapeUrl"])
        print("lastError:", target["lastError"])
'
```

再読み込みの直後は表示されないことがあります。そのときは、次のコマンドですべてのジョブを確認します。

```bash
echo "=== PROMETHEUS JOBS ==="
curl -fsS 'http://127.0.0.1:9090/api/v1/targets?state=any' \
  | python3 -c '
import json, sys
data = json.load(sys.stdin)
print("API status:", data.get("status"))
for target in data.get("data", {}).get("activeTargets", []):
    print(
        "job:", target.get("labels", {}).get("job"),
        "health:", target.get("health"),
        "url:", target.get("scrapeUrl"),
        "error:", target.get("lastError")
    )
'

echo
echo "=== RECENT PROMETHEUS LOGS ==="
journalctl -u prometheus -n 30 --no-pager
```

構築時は、3つのジョブすべてが `health: up` でした。

# 第5章　VictoriaMetricsへの転送（Remote Write）

## 5.1　現状の確認とバックアップ

**実行先：LXC 103 lxc-prometheus（root）**

```bash
echo "=== REMOTE WRITE CONFIG ==="
grep -n -A 8 -B 2 'remote_write' /etc/prometheus/prometheus.yml \
  || echo "remote_write is not configured"

echo
echo "=== VICTORIAMETRICS CONNECTIVITY ==="
curl -sS --max-time 5 \
  -o /dev/null \
  -w 'HTTP_STATUS=%{http_code}\n' \
  http://192.168.0.171:8428/health
```

```bash
echo "=== CONFIG BACKUP ==="
cp -a /etc/prometheus/prometheus.yml \
  /etc/prometheus/prometheus.yml.pre-remote-write.$(date +%Y%m%d-%H%M%S)

echo "=== CONFIG TAIL ==="
tail -n 35 /etc/prometheus/prometheus.yml
```

## 5.2　転送の設定の追加

転送先と、転送元を見分けるラベル（`prometheus_source`）を追加します。

**実行先：LXC 103 lxc-prometheus（root）**

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/etc/prometheus/prometheus.yml")
text = path.read_text()

if "\nremote_write:" in text or text.startswith("remote_write:"):
    raise SystemExit("ERROR: remote_write already exists; no change made")

addition = '''
external_labels:
  prometheus_source: "lxc-prometheus"

remote_write:
  - url: "http://192.168.0.171:8428/api/v1/write"
'''

path.write_text(text.rstrip() + "\n\n" + addition)
print("remote_write configuration added")
PY

echo
echo "=== VALIDATE CONFIG ==="
promtool check config /etc/prometheus/prometheus.yml
```

構築時は、ここで `promtool` がエラーになりました。`external_labels` は最上位の項目ではなく、`global` の中に置く必要があります。次のコマンドで `global` の中に移します。

```bash
python3 - <<'PY'
from pathlib import Path
import re

path = Path("/etc/prometheus/prometheus.yml")
text = path.read_text()

text = re.sub(
    r'\nexternal_labels:\n  prometheus_source: "lxc-prometheus"\n',
    '\n',
    text,
    count=1
)

pattern = r'(?m)^global:\n'
if not re.search(pattern, text):
    raise SystemExit("ERROR: global section not found")

text = re.sub(
    pattern,
    'global:\n  external_labels:\n    prometheus_source: "lxc-prometheus"\n',
    text,
    count=1
)

path.write_text(text)
print("external_labels moved under global")
PY

echo
echo "=== VALIDATE CONFIG ==="
promtool check config /etc/prometheus/prometheus.yml
```

```bash
echo "=== GLOBAL CONFIG ==="
sed -n '1,12p' /etc/prometheus/prometheus.yml

echo
echo "=== REMOTE WRITE CONFIG ==="
tail -n 12 /etc/prometheus/prometheus.yml

echo
echo "=== FINAL VALIDATION ==="
promtool check config /etc/prometheus/prometheus.yml
```

## 5.3　反映と転送の確認

**実行先：LXC 103 lxc-prometheus（root）**

```bash
systemctl reload prometheus

echo "=== SERVICE STATUS ==="
systemctl is-active prometheus

echo
echo "=== RECENT REMOTE WRITE LOGS ==="
journalctl -u prometheus --since "2 minutes ago" --no-pager \
  | grep -Ei 'remote|write|error|failed' \
  | tail -n 20
```

```bash
echo "=== REMOTE WRITE DATA ARRIVAL ==="
curl -fsSG 'http://192.168.0.171:8428/api/v1/query' \
  --data-urlencode 'query=count by (job) ({prometheus_source="lxc-prometheus"})' \
  | python3 -m json.tool

echo
echo "=== REMOTE WRITE ERRORS ==="
journalctl -u prometheus --since "10 minutes ago" --no-pager \
  | grep -Ei 'remote|write|retry|failed|error|dropped' \
  | tail -n 30
```

| ジョブ | VictoriaMetricsの系列数（構築時） |
|---|---:|
| `pve-node` | 8,909 |
| `ollama-gpu` | 865 |
| `prometheus` | 791 |

> VictoriaMetrics で検索するときは、`host="pve"` ではなく `job="pve-node"` を条件にします。構築時は `host="pve"` で検索して0件になりました。

## 5.4　保存されたデータの確認

**実行先：LXC 103 lxc-prometheus（root）**

```bash
echo "=== PVE FILESYSTEM METRICS ==="
curl -fsSG 'http://192.168.0.171:8428/api/v1/query' \
  --data-urlencode 'query=count(node_filesystem_size_bytes{job="pve-node"})' \
  | python3 -m json.tool

echo
echo "=== PVE NETWORK METRICS ==="
curl -fsSG 'http://192.168.0.171:8428/api/v1/query' \
  --data-urlencode 'query=count(node_network_receive_bytes_total{job="pve-node"})' \
  | python3 -m json.tool

echo
echo "=== PVE DISK I/O METRICS ==="
curl -fsSG 'http://192.168.0.171:8428/api/v1/query' \
  --data-urlencode 'query=count(node_disk_read_bytes_total{job="pve-node"})' \
  | python3 -m json.tool
```

ファイルシステム・ネットワーク・ディスクI/Oの各系列が1件以上あれば、ダッシュボードに必要なデータがそろっています。

# 第6章　PVEのダッシュボードの作成

ダッシュボードは、Grafanaの画面で作るのではなく、ファイル（プロビジョニング）で作ります。設定をファイルとして残せるためです。

## 6.1　データソースのUIDの確認

ダッシュボードのJSONには、データソースのUIDを書きます。Grafanaのデータベースを読み取り専用で開いて確認します。

**実行先：LXC 105 lxc-grafana（root）**

```bash
python3 - <<'PY'
import sqlite3

con = sqlite3.connect(
    "file:/var/lib/grafana/grafana.db?mode=ro", uri=True
)

try:
    columns = {
        row[1] for row in
        con.execute("PRAGMA table_info(data_source)").fetchall()
    }

    fields = [
        name for name in
        ("id", "uid", "name", "type", "url", "is_default")
        if name in columns
    ]

    sql = (
        "SELECT " + ", ".join(fields) +
        " FROM data_source WHERE name = ?"
    )

    row = con.execute(sql, ("VictoriaMetrics",)).fetchone()

    print("=== VICTORIAMETRICS DATASOURCE ===")
    if row:
        print(dict(zip(fields, row)))
    else:
        print("Datasource not found")
finally:
    con.close()
PY
```

構築時のUIDは `dfsldbphmj9c0e` でした。次の手順の `"uid": "dfsldbphmj9c0e"` は、自分の環境のUIDに置き換えます。

## 6.2　ダッシュボードとプロビジョニングの設定の作成

`PVE Host Overview` ダッシュボード（CPU・メモリ・ファイルシステム・ネットワーク・ディスクI/O・稼働時間の6パネル）と、それを読み込む設定を作ります。同じ名前のファイルがあるときは、上書きせずに止まります。

**実行先：LXC 105 lxc-grafana（root）**

```bash
python3 - <<'PY'
import json
import os
from pathlib import Path

provider = Path("/etc/grafana/provisioning/dashboards/pve.yaml")
directory = Path("/var/lib/grafana/dashboards")
dashboard_file = directory / "pve-overview.json"

if provider.exists() or dashboard_file.exists():
    raise SystemExit("ABORT: 同名ファイルが存在します。上書きしません。")

directory.mkdir(parents=True, exist_ok=True)

ds = {"type": "prometheus", "uid": "dfsldbphmj9c0e"}

def panel(pid, title, expr, unit, x, y, w=12, h=8, kind="timeseries"):
    return {
        "id": pid,
        "title": title,
        "type": kind,
        "datasource": ds,
        "gridPos": {"x": x, "y": y, "w": w, "h": h},
        "targets": [{
            "refId": "A",
            "expr": expr,
            "legendFormat": "{{instance}} {{device}} {{mountpoint}}",
            "range": True
        }],
        "fieldConfig": {
            "defaults": {"unit": unit},
            "overrides": []
        },
        "options": {
            "legend": {"showLegend": True},
            "tooltip": {"mode": "multi"}
        }
    }

panels = [
    panel(1, "CPU Usage", 
          '100 * (1 - avg by(instance) (rate(node_cpu_seconds_total{job="pve-node",mode="idle"}[5m])))',
          "percent", 0, 0),
    panel(2, "Memory Usage",
          '100 * (1 - node_memory_MemAvailable_bytes{job="pve-node"} / node_memory_MemTotal_bytes{job="pve-node"})',
          "percent", 12, 0),
    panel(3, "Filesystem Usage",
          '100 * (1 - node_filesystem_avail_bytes{job="pve-node",fstype!~"tmpfs|overlay|squashfs"} / node_filesystem_size_bytes{job="pve-node",fstype!~"tmpfs|overlay|squashfs"})',
          "percent", 0, 8),
    panel(4, "Network Traffic",
          'rate(node_network_receive_bytes_total{job="pve-node",device!~"lo"}[5m])',
          "Bps", 12, 8),
    panel(5, "Disk I/O",
          'rate(node_disk_read_bytes_total{job="pve-node"}[5m])',
          "Bps", 0, 16),
    panel(6, "Host Uptime",
          'time() - node_boot_time_seconds{job="pve-node"}',
          "s", 12, 16, kind="stat")
]

dashboard = {
    "id": None,
    "uid": "pve-host-overview",
    "title": "PVE Host Overview",
    "tags": ["proxmox", "pve", "infrastructure"],
    "timezone": "browser",
    "schemaVersion": 41,
    "version": 1,
    "refresh": "30s",
    "time": {"from": "now-6h", "to": "now"},
    "panels": panels
}

provider_text = """apiVersion: 1
providers:
  - name: 'pve'
    orgId: 1
    folder: 'Infrastructure'
    type: file
    disableDeletion: true
    editable: true
    updateIntervalSeconds: 30
    options:
      path: /var/lib/grafana/dashboards
"""

dashboard_file.write_text(
    json.dumps(dashboard, ensure_ascii=False, indent=2) + "\n"
)
provider.write_text(provider_text)

os.chown(directory, 472, 472)
os.chmod(directory, 0o750)
os.chown(dashboard_file, 472, 472)
os.chmod(dashboard_file, 0o640)
os.chown(provider, 0,  gid := __import__("grp").getgrnam("grafana").gr_gid)
os.chmod(provider, 0o640)

# JSON再読込検証
json.loads(dashboard_file.read_text())

print("SUCCESS: Dashboard JSON created and validated")
print("Dashboard:", dashboard_file)
print("Provider:", provider)
print("Panels:", len(panels))
print("Grafana service was not restarted.")
PY

echo
echo "=== CREATED FILES ==="
ls -l /etc/grafana/provisioning/dashboards/pve.yaml \
      /var/lib/grafana/dashboards/pve-overview.json
```

## 6.3　ファイルの所有者の修正

6.2では所有者をUID 472にしていますが、このLXCのGrafanaの実行ユーザー `grafana` はUID 102です。このままではGrafanaがJSONを読めないため、所有者を `grafana` に直します。

**実行先：LXC 105 lxc-grafana（root）**

```bash
echo "=== CORRECT DASHBOARD FILE OWNERSHIP ==="
chown grafana:grafana \
  /var/lib/grafana/dashboards \
  /var/lib/grafana/dashboards/pve-overview.json

echo
echo "=== VERIFY OWNERSHIP ==="
stat -c '%U:%G %a %n' \
  /var/lib/grafana/dashboards \
  /var/lib/grafana/dashboards/pve-overview.json

echo
echo "=== VERIFY GRAFANA READ ACCESS ==="
runuser -u grafana -- test -r \
  /var/lib/grafana/dashboards/pve-overview.json \
  && echo "SUCCESS: grafana can read dashboard JSON" \
  || echo "ERROR: grafana cannot read dashboard JSON"
```

## 6.4　Grafanaの再起動と確認

**実行先：LXC 105 lxc-grafana（root）**

```bash
echo "=== RESTART GRAFANA ==="
systemctl restart grafana-server

echo
echo "=== SERVICE STATUS ==="
systemctl is-active grafana-server

echo
echo "=== GRAFANA HEALTH ==="
curl -fsS http://127.0.0.1:3000/api/health \
  | python3 -m json.tool

echo
echo "=== DASHBOARD PROVISIONING LOGS ==="
journalctl -u grafana-server --since "3 minutes ago" --no-pager \
  | grep -Ei 'provision|dashboard|error|failed' \
  | tail -n 30
```

再起動の直後は、まだ3000番ポートで待ち受けておらず、`/api/health` に接続できないことがあります。少し待ってから確認します。

```bash
echo "=== GRAFANA HEALTH ==="
curl -fsS http://127.0.0.1:3000/api/health \
  | python3 -m json.tool

echo
echo "=== DASHBOARD PROVISIONING RESULT ==="
journalctl -u grafana-server --since "5 minutes ago" --no-pager \
  | grep -Ei 'pve|provisioning.dashboard|finished to provision|error' \
  | tail -n 30

echo
echo "=== DASHBOARD FILE ACCESS ==="
runuser -u grafana -- test -r \
  /var/lib/grafana/dashboards/pve-overview.json \
  && echo "SUCCESS"
```

ログに `finished to provision dashboards` があれば読み込みは完了しています。

## 6.5　画面での確認

Grafanaの画面で **Dashboards → Infrastructure → PVE Host Overview** を開き、6つのパネルすべてにデータが表示されることを確認します。構築時は、すべてのパネルが表示されました。

# 第7章　security-coreの監視の追加

Wazuhの本体や設定には触れず、Node Exporterだけを追加します。

## 7.1　確認とインストール

**実行先：security-core VM 220（root）**

```bash
echo "=== OS VERSION ==="
cat /etc/os-release | grep -E '^(PRETTY_NAME|VERSION_CODENAME)='

echo
echo "=== NODE EXPORTER PACKAGE ==="
dpkg-query -W -f='${Status} ${Version}\n' prometheus-node-exporter 2>/dev/null \
  || echo "NOT INSTALLED"

echo
echo "=== PORT 9100 ==="
ss -lntp | grep ':9100' || echo "NOT LISTENING"
```

```bash
apt-get update
apt-cache policy prometheus-node-exporter
```

構築時は Ubuntu 24.04.5 LTS で、候補は `1.7.0-1ubuntu0.3` でした。PVEと同じく、一時的にマスクしてから入れます。

```bash
systemctl mask --runtime prometheus-node-exporter.service

apt-get install -y prometheus-node-exporter
```

## 7.2　待ち受けのアドレスの限定と起動

**実行先：security-core VM 220（root）**

```bash
echo "=== CURRENT NODE EXPORTER CONFIG ==="
cat /etc/default/prometheus-node-exporter

echo
echo "=== SET LISTEN ADDRESS ==="
cat > /etc/default/prometheus-node-exporter <<'EOF'
ARGS="--web.listen-address=192.168.0.220:9100"
EOF

echo
echo "=== VERIFY CONFIG ==="
cat /etc/default/prometheus-node-exporter
```

一時的なマスクは `/run/systemd/system/` にあるため、解除するときも `--runtime` を付けます（付けないと解除されず、起動が拒否されます）。

```bash
echo "=== REMOVE RUNTIME MASK ==="
systemctl unmask --runtime prometheus-node-exporter.service

echo
echo "=== VERIFY UNMASK ==="
systemctl is-enabled prometheus-node-exporter.service

echo
echo "=== ENABLE AND START ==="
systemctl enable --now prometheus-node-exporter.service

echo
echo "=== SERVICE STATUS ==="
systemctl is-active prometheus-node-exporter.service

echo
echo "=== LISTEN ADDRESS ==="
ss -lntp | grep ':9100'
```

## 7.3　Prometheusからの到達の確認

**実行先：LXC 103 lxc-prometheus（root）**

```bash
echo "=== SECURITY CORE NODE EXPORTER CONNECTIVITY ==="
curl -fsS --max-time 5 \
  http://192.168.0.220:9100/metrics \
  -o /tmp/security-core-node-metrics.prom \
  && echo "SUCCESS: metrics received"

echo
echo "=== METRIC SAMPLE ==="
grep -m 5 '^node_cpu_seconds_total' \
  /tmp/security-core-node-metrics.prom

echo
echo "=== METRIC COUNTS ==="
wc -l /tmp/security-core-node-metrics.prom
```

## 7.4　ジョブの追加

`pve-node` のジョブのすぐ後に、次のジョブを追加します。

```yaml
  - job_name: "security-core"
    static_configs:
      - targets:
          - 192.168.0.220:9100
        labels:
          host: "security-core"
          role: "security"
```

**実行先：LXC 103 lxc-prometheus（root）**

```bash
set -e

CONFIG=/etc/prometheus/prometheus.yml
BACKUP="${CONFIG}.pre-security-core.$(date +%Y%m%d-%H%M%S)"

cp -a "$CONFIG" "$BACKUP"
echo "BACKUP: $BACKUP"

python3 - <<'PY'
from pathlib import Path

path = Path("/etc/prometheus/prometheus.yml")
text = path.read_text()

if 'job_name: "security-core"' in text:
    raise SystemExit("ABORT: security-core job already exists")

anchor = '''  - job_name: "pve-node"
    static_configs:
      - targets:
          - 192.168.0.240:9100
        labels:
          host: "pve"
          role: "hypervisor"
'''

if text.count(anchor) != 1:
    raise SystemExit("ABORT: expected pve-node block not found exactly once")

addition = anchor + '''
  - job_name: "security-core"
    static_configs:
      - targets:
          - 192.168.0.220:9100
        labels:
          host: "security-core"
          role: "security"
'''

path.write_text(text.replace(anchor, addition, 1))
print("SUCCESS: security-core job added")
PY

echo
echo "=== VALIDATE PROMETHEUS CONFIG ==="
/usr/local/bin/promtool check config "$CONFIG"
```

> 先頭に `set -e` があるため、このコマンドは対話中のシェルに直接貼り付けず、`bash` を起動してから実行するか、スクリプトにして実行してください。途中で失敗すると、ログインしているシェルごと終了します。

## 7.5　反映と確認

**実行先：LXC 103 lxc-prometheus（root）**

```bash
echo "=== RELOAD PROMETHEUS ==="
systemctl reload prometheus

echo
echo "=== SERVICE STATUS ==="
systemctl is-active prometheus

echo
echo "=== SECURITY CORE TARGET ==="
sleep 3
curl -fsSG 'http://127.0.0.1:9090/api/v1/targets' \
  --data-urlencode 'state=any' \
  | python3 -c '
import json,sys
data=json.load(sys.stdin)
for group in data["data"]["activeTargets"]:
    if group["labels"].get("job") == "security-core":
        print(json.dumps({
            "job": group["labels"].get("job"),
            "instance": group["labels"].get("instance"),
            "health": group["health"],
            "lastError": group["lastError"]
        }, indent=2))
'
```

直後は `health: unknown` です。1回目の収集が終わるまで待ってから確認します。

```bash
sleep 20

echo "=== SECURITY CORE TARGET STATUS ==="
curl -fsSG 'http://127.0.0.1:9090/api/v1/targets' \
  --data-urlencode 'state=any' \
  | python3 -c '
import json,sys
data=json.load(sys.stdin)
for target in data["data"]["activeTargets"]:
    if target["labels"].get("job") == "security-core":
        print(json.dumps({
            "job": target["labels"].get("job"),
            "instance": target["labels"].get("instance"),
            "health": target["health"],
            "lastScrape": target["lastScrape"],
            "lastError": target["lastError"]
        }, indent=2))
'

echo
echo "=== SECURITY CORE UP METRIC ==="
curl -fsSG 'http://127.0.0.1:9090/api/v1/query' \
  --data-urlencode 'query=up{job="security-core"}' \
  | python3 -m json.tool
```

```bash
echo "=== SECURITY CORE REMOTE WRITE ARRIVAL ==="
curl -fsSG 'http://192.168.0.171:8428/api/v1/query' \
  --data-urlencode 'query=up{job="security-core",prometheus_source="lxc-prometheus"}' \
  | python3 -m json.tool

echo
echo "=== SECURITY CORE CPU SERIES ==="
curl -fsSG 'http://192.168.0.171:8428/api/v1/query' \
  --data-urlencode 'query=count(node_cpu_seconds_total{job="security-core"})' \
  | python3 -m json.tool

echo
echo "=== REMOTE WRITE ERRORS ==="
journalctl -u prometheus --since "10 minutes ago" --no-pager \
  | grep -Ei 'remote.*error|write.*failed|retrying' \
  | tail -n 20 || true
```

構築時は、`up` が `1`、CPUの系列が64件で、転送のエラーはありませんでした。

# 第8章　PostgreSQL（LXC 109）の監視の追加

PostgreSQLの本体には触れず、Node Exporterだけを追加します。

## 8.1　インストール

**実行先：LXC 109 postgresql（root）**

```bash
apt-get update
apt-cache policy prometheus-node-exporter
```

構築時は Debian 13（trixie）で、候補は `1.9.0-1+b4` でした。

```bash
systemctl mask --runtime prometheus-node-exporter.service

apt-get install -y prometheus-node-exporter
```

```bash
echo "=== CURRENT CONFIG ==="
cat /etc/default/prometheus-node-exporter

echo
echo "=== SERVICE MASK ==="
systemctl is-enabled prometheus-node-exporter.service || true
```

`ARGS=""` と `masked-runtime` を確認します。

## 8.2　待ち受けのアドレスの限定と起動

**実行先：LXC 109 postgresql（root）**

```bash
cat > /etc/default/prometheus-node-exporter <<'EOF'
ARGS="--web.listen-address=192.168.0.151:9100"
EOF

echo "=== CONFIGURATION ==="
cat /etc/default/prometheus-node-exporter

echo
echo "=== REMOVE RUNTIME MASK ==="
systemctl unmask --runtime prometheus-node-exporter.service

echo
echo "=== ENABLE AND START ==="
systemctl enable --now prometheus-node-exporter.service
```

```bash
echo "=== SERVICE STATUS ==="
systemctl show prometheus-node-exporter \
  -p ActiveState -p SubState -p MainPID

echo
echo "=== LISTEN ADDRESS ==="
ss -lntp | grep ':9100' || echo "NOT LISTENING"

echo
echo "=== METRICS TEST ==="
curl -fsS --max-time 5 http://192.168.0.151:9100/metrics \
  | grep -m 3 '^node_cpu_seconds_total'
```

## 8.3　Prometheusからの到達の確認

**実行先：LXC 103 lxc-prometheus（root）**

```bash
echo "=== POSTGRESQL NODE EXPORTER CONNECTIVITY ==="
curl -fsS --max-time 5 http://192.168.0.151:9100/metrics \
  -o /tmp/postgresql-node-exporter.metrics

echo "HTTP metrics: OK"
echo "Metric lines:"
wc -l /tmp/postgresql-node-exporter.metrics

echo
echo "=== CPU METRIC SAMPLE ==="
grep -m 3 '^node_cpu_seconds_total' \
  /tmp/postgresql-node-exporter.metrics
```

## 8.4　ジョブの追加と反映

`security-core` のジョブの後に `postgresql-node` を追加します。

**実行先：LXC 103 lxc-prometheus（root）**

```bash
set -e

BACKUP="/etc/prometheus/prometheus.yml.pre-postgresql-node.$(date +%Y%m%d-%H%M%S)"
cp -a /etc/prometheus/prometheus.yml "$BACKUP"

python3 - <<'PY'
from pathlib import Path

p = Path("/etc/prometheus/prometheus.yml")
s = p.read_text()

marker = '''  - job_name: "security-core"
    static_configs:
      - targets:
          - 192.168.0.220:9100
        labels:
          host: "security-core"
          role: "security"
'''

addition = marker + '''
  - job_name: "postgresql-node"
    static_configs:
      - targets:
          - 192.168.0.151:9100
        labels:
          host: "postgresql"
          role: "database"
'''

if s.count(marker) != 1:
    raise SystemExit("ERROR: security-core block is not unique; no change made")
if 'job_name: "postgresql-node"' in s:
    raise SystemExit("ERROR: postgresql-node already exists; no change made")

p.write_text(s.replace(marker, addition, 1))
print("Added postgresql-node scrape job.")
PY

echo
echo "=== PROMETHEUS CONFIG VALIDATION ==="
promtool check config /etc/prometheus/prometheus.yml

echo
echo "=== BACKUP ==="
echo "$BACKUP"
```

```bash
systemctl reload prometheus

echo "=== SERVICE STATUS ==="
systemctl show prometheus -p ActiveState -p SubState -p MainPID

echo
echo "=== RELOAD LOG ==="
journalctl -u prometheus --since "2 minutes ago" --no-pager \
  | tail -30
```

## 8.5　確認

**実行先：LXC 103 lxc-prometheus（root）**

```bash
echo "=== POSTGRESQL TARGET STATUS ==="
curl -fsSG 'http://127.0.0.1:9090/api/v1/targets' \
  --data-urlencode 'state=active' \
  | python3 -c '
import json,sys
data=json.load(sys.stdin)
for t in data["data"]["activeTargets"]:
    if t["labels"].get("job") == "postgresql-node":
        print(json.dumps({
            "health": t["health"],
            "scrapeUrl": t["scrapeUrl"],
            "lastError": t["lastError"],
            "labels": t["labels"]
        }, indent=2))
'

echo
echo "=== PROMETHEUS UP QUERY ==="
curl -fsSG 'http://127.0.0.1:9090/api/v1/query' \
  --data-urlencode 'query=up{job="postgresql-node"}' \
  | python3 -m json.tool
```

```bash
echo "=== VICTORIAMETRICS POSTGRESQL TARGET ==="
curl -fsSG 'http://192.168.0.171:8428/api/v1/query' \
  --data-urlencode 'query=up{job="postgresql-node",prometheus_source="lxc-prometheus"}' \
  | python3 -m json.tool

echo
echo "=== POSTGRESQL CPU METRIC COUNT ==="
curl -fsSG 'http://192.168.0.171:8428/api/v1/query' \
  --data-urlencode 'query=count(node_cpu_seconds_total{job="postgresql-node"})' \
  | python3 -m json.tool

echo
echo "=== REMOTE WRITE ERRORS ==="
journalctl -u prometheus --since "10 minutes ago" --no-pager \
  | grep -Ei 'remote.?write.*(error|fail)|non-recoverable' \
  || echo "NO REMOTE WRITE ERRORS FOUND"
```

`health: up`、`up` が `1`、`NO REMOTE WRITE ERRORS FOUND` であれば完了です。

# 第9章　Prometheus（LXC 103）自身の監視の追加

Prometheus（9090番）とポートが重ならないよう、Node Exporterは `192.168.0.197:9100` で待ち受けます。

## 9.1　インストールと起動

**実行先：LXC 103 lxc-prometheus（root）**

```bash
apt-get update
apt-cache policy prometheus-node-exporter
```

```bash
systemctl mask --runtime prometheus-node-exporter.service

apt-get install -y prometheus-node-exporter
```

```bash
cat > /etc/default/prometheus-node-exporter <<'EOF'
ARGS="--web.listen-address=192.168.0.197:9100"
EOF

echo "=== CONFIGURATION ==="
cat /etc/default/prometheus-node-exporter

echo
echo "=== REMOVE RUNTIME MASK ==="
systemctl unmask --runtime prometheus-node-exporter.service

echo
echo "=== ENABLE AND START ==="
systemctl enable --now prometheus-node-exporter.service
```

```bash
echo "=== SERVICE STATUS ==="
systemctl show prometheus-node-exporter \
  -p ActiveState -p SubState -p MainPID

echo
echo "=== LISTEN ADDRESS ==="
ss -lntp | grep ':9100' || echo "NOT LISTENING"

echo
echo "=== METRICS TEST ==="
curl -fsS --max-time 5 http://192.168.0.197:9100/metrics \
  -o /tmp/prometheus-node-exporter.metrics

echo "Metric lines:"
wc -l /tmp/prometheus-node-exporter.metrics

echo
echo "=== CPU METRIC SAMPLE ==="
grep -m 3 '^node_cpu_seconds_total' \
  /tmp/prometheus-node-exporter.metrics
```

## 9.2　ジョブの追加と反映

**実行先：LXC 103 lxc-prometheus（root）**

```bash
echo "=== CURRENT SCRAPE JOBS ==="
grep -nE 'job_name:|targets:|remote_write:|192\.168\.0\.197' \
  /etc/prometheus/prometheus.yml
```

```bash
set -e

BACKUP="/etc/prometheus/prometheus.yml.pre-prometheus-node.$(date +%Y%m%d-%H%M%S)"
cp -a /etc/prometheus/prometheus.yml "$BACKUP"

python3 - <<'PY'
from pathlib import Path

p = Path("/etc/prometheus/prometheus.yml")
s = p.read_text()

marker = '''  - job_name: "postgresql-node"
    static_configs:
      - targets:
          - 192.168.0.151:9100
        labels:
          host: "postgresql"
          role: "database"
'''

addition = marker + '''
  - job_name: "prometheus-node"
    static_configs:
      - targets:
          - 192.168.0.197:9100
        labels:
          host: "prometheus"
          role: "monitoring"
'''

if s.count(marker) != 1:
    raise SystemExit("ERROR: postgresql-node block is not unique; no change made")
if 'job_name: "prometheus-node"' in s:
    raise SystemExit("ERROR: prometheus-node already exists; no change made")

p.write_text(s.replace(marker, addition, 1))
print("Added prometheus-node scrape job.")
PY

echo
echo "=== CONFIG VALIDATION ==="
promtool check config /etc/prometheus/prometheus.yml

echo
echo "=== BACKUP ==="
echo "$BACKUP"
```

```bash
systemctl reload prometheus

echo "=== SERVICE STATUS ==="
systemctl show prometheus -p ActiveState -p SubState -p MainPID

echo
echo "=== RELOAD LOG ==="
journalctl -u prometheus --since "2 minutes ago" --no-pager \
  | tail -20
```

## 9.3　確認

**実行先：LXC 103 lxc-prometheus（root）**

```bash
echo "=== PROMETHEUS NODE TARGET STATUS ==="
curl -fsSG 'http://127.0.0.1:9090/api/v1/targets' \
  --data-urlencode 'state=active' \
  | python3 -c '
import json,sys
data=json.load(sys.stdin)
for t in data["data"]["activeTargets"]:
    if t["labels"].get("job") == "prometheus-node":
        print(json.dumps({
            "health": t["health"],
            "scrapeUrl": t["scrapeUrl"],
            "lastError": t["lastError"],
            "labels": t["labels"]
        }, indent=2))
'

echo
echo "=== PROMETHEUS UP QUERY ==="
curl -fsSG 'http://127.0.0.1:9090/api/v1/query' \
  --data-urlencode 'query=up{job="prometheus-node"}' \
  | python3 -m json.tool
```

```bash
echo "=== VICTORIAMETRICS PROMETHEUS TARGET ==="
curl -fsSG 'http://192.168.0.171:8428/api/v1/query' \
  --data-urlencode 'query=up{job="prometheus-node",prometheus_source="lxc-prometheus"}' \
  | python3 -m json.tool

echo
echo "=== CPU METRIC COUNT ==="
curl -fsSG 'http://192.168.0.171:8428/api/v1/query' \
  --data-urlencode 'query=count(node_cpu_seconds_total{job="prometheus-node"})' \
  | python3 -m json.tool

echo
echo "=== REMOTE WRITE ERRORS ==="
journalctl -u prometheus --since "10 minutes ago" --no-pager \
  | grep -Ei 'remote.?write.*(error|fail)|non-recoverable' \
  || echo "NO REMOTE WRITE ERRORS FOUND"
```

# 第10章　Grafana（LXC 105）自身の監視の追加

Grafana本体（3000番）は変更せず、Node Exporterを `192.168.0.199:9100` で待ち受けます。

## 10.1　インストールと起動

**実行先：LXC 105 lxc-grafana（root）**

```bash
apt-get update
apt-cache policy prometheus-node-exporter
```

```bash
systemctl mask --runtime prometheus-node-exporter.service

apt-get install -y prometheus-node-exporter
```

```bash
cat > /etc/default/prometheus-node-exporter <<'EOF'
ARGS="--web.listen-address=192.168.0.199:9100"
EOF

echo "=== CONFIGURATION ==="
cat /etc/default/prometheus-node-exporter

echo
echo "=== REMOVE RUNTIME MASK ==="
systemctl unmask --runtime prometheus-node-exporter.service

echo
echo "=== ENABLE AND START ==="
systemctl enable --now prometheus-node-exporter.service
```

```bash
echo "=== SERVICE STATUS ==="
systemctl show prometheus-node-exporter \
  -p ActiveState -p SubState -p MainPID

echo
echo "=== LISTEN ADDRESS ==="
ss -lntp | grep ':9100' || echo "NOT LISTENING"

echo
echo "=== METRICS TEST ==="
curl -fsS --max-time 5 http://192.168.0.199:9100/metrics \
  -o /tmp/grafana-node-exporter.metrics

echo "Metric lines:"
wc -l /tmp/grafana-node-exporter.metrics

echo
echo "=== CPU METRIC SAMPLE ==="
grep -m 3 '^node_cpu_seconds_total' \
  /tmp/grafana-node-exporter.metrics
```

## 10.2　Prometheusからの到達の確認

**実行先：LXC 103 lxc-prometheus（root）**

```bash
echo "=== GRAFANA NODE EXPORTER CONNECTIVITY ==="
curl -fsS --max-time 5 http://192.168.0.199:9100/metrics \
  -o /tmp/grafana-node-exporter.metrics

echo "Metric lines:"
wc -l /tmp/grafana-node-exporter.metrics

echo
echo "=== CPU METRIC SAMPLE ==="
grep -m 3 '^node_cpu_seconds_total' \
  /tmp/grafana-node-exporter.metrics
```

## 10.3　ジョブの追加と反映

このジョブは、`remote_write:` の直前（ジョブの並びの最後）に追加します。

```yaml
  - job_name: "grafana-node"
    static_configs:
      - targets:
          - 192.168.0.199:9100
        labels:
          host: "grafana"
          role: "visualization"
```

**実行先：LXC 103 lxc-prometheus（root）**

```bash
set -e

CONFIG=/etc/prometheus/prometheus.yml
BACKUP="${CONFIG}.pre-grafana-node.$(date +%Y%m%d-%H%M%S)"

cp -a "$CONFIG" "$BACKUP"
echo "Backup: $BACKUP"

python3 - <<'PY'
from pathlib import Path

p = Path("/etc/prometheus/prometheus.yml")
s = p.read_text()

marker = '\n\n\nremote_write:\n'
job = '''
  - job_name: "grafana-node"
    static_configs:
      - targets:
          - 192.168.0.199:9100
        labels:
          host: "grafana"
          role: "visualization"
'''

if 'job_name: "grafana-node"' in s:
    raise SystemExit("ERROR: grafana-node already exists; no changes made.")

if s.count(marker) != 1:
    raise SystemExit("ERROR: expected insertion point not found uniquely; no changes made.")

p.write_text(s.replace(marker, '\n' + job + marker, 1))
print("grafana-node job added.")
PY

echo
echo "=== UPDATED JOB CONFIGURATION ==="
grep -nA9 'job_name: "grafana-node"' "$CONFIG"
```

`marker` は、構築時の設定ファイルで `remote_write:` の前に空行が2行あったことに合わせています。自分の環境のファイルの形に合わせてください（形が違うときは、変更せずに止まります）。

```bash
echo "=== PROMETHEUS CONFIG VALIDATION ==="
promtool check config /etc/prometheus/prometheus.yml
```

```bash
echo "=== RELOAD PROMETHEUS CONFIGURATION ==="
systemctl reload prometheus

echo
echo "=== SERVICE STATUS ==="
systemctl show prometheus \
  -p ActiveState -p SubState -p MainPID

echo
echo "=== RECENT CONFIGURATION LOGS ==="
journalctl -u prometheus --since "2 minutes ago" --no-pager \
  | tail -30
```

## 10.4　確認

**実行先：LXC 103 lxc-prometheus（root）**

```bash
echo "=== GRAFANA TARGET STATUS ==="
curl -fsSG 'http://127.0.0.1:9090/api/v1/targets' \
  --data-urlencode 'state=active' \
  | python3 -c '
import json, sys
data = json.load(sys.stdin)
for target in data["data"]["activeTargets"]:
    if target["labels"].get("job") == "grafana-node":
        print("health:", target["health"])
        print("scrapeUrl:", target["scrapeUrl"])
        print("lastError:", target["lastError"])
        print("lastScrape:", target["lastScrape"])
'

echo
echo "=== PROMETHEUS UP QUERY ==="
curl -fsSG 'http://127.0.0.1:9090/api/v1/query' \
  --data-urlencode 'query=up{job="grafana-node"}' \
  | python3 -m json.tool
```

```bash
echo "=== VICTORIAMETRICS: GRAFANA TARGET ==="
curl -fsSG 'http://192.168.0.171:8428/api/v1/query' \
  --data-urlencode 'query=up{job="grafana-node",prometheus_source="lxc-prometheus"}' \
  | python3 -m json.tool

echo
echo "=== GRAFANA CPU METRIC COUNT ==="
curl -fsSG 'http://192.168.0.171:8428/api/v1/query' \
  --data-urlencode 'query=count(node_cpu_seconds_total{job="grafana-node"})' \
  | python3 -m json.tool

echo
echo "=== REMOTE WRITE ERRORS ==="
journalctl -u prometheus --since "10 minutes ago" --no-pager \
  | grep -Ei 'remote.?write.*(error|fail)|non-recoverable' \
  || echo "No remote_write errors found"
```

これで5台すべてが監視の対象になりました。

# 第11章　統合インフラ監視ダッシュボードの作成

PVEのダッシュボードはそのまま残し、5台をまとめて比べる「Integrated Infrastructure Overview」を新しく作ります。各ホストに付けた `host` ラベルで、ホストごとに表示します。

## 11.1　既存の設定の確認

**実行先：LXC 105 lxc-grafana（root）**

```bash
echo "=== DASHBOARD PROVISIONING ==="
cat /etc/grafana/provisioning/dashboards/pve.yaml

echo
echo "=== EXISTING DASHBOARD FILES ==="
find /var/lib/grafana/dashboards -maxdepth 1 -type f \
  -printf '%f (%s bytes)\n'

echo
echo "=== EXISTING PVE DASHBOARD SUMMARY ==="
python3 - <<'PY'
import json
from pathlib import Path

p = Path("/var/lib/grafana/dashboards/pve-overview.json")
d = json.loads(p.read_text())

print("title:", d.get("title"))
print("uid:", d.get("uid"))
print("schemaVersion:", d.get("schemaVersion"))
print("panels:", len(d.get("panels", [])))
for panel in d.get("panels", []):
    print("-", panel.get("title"), "| type:", panel.get("type"))
PY
```

6.2のプロビジョニングの設定は、`/var/lib/grafana/dashboards` の中のJSONをすべて自動で読み込みます（フォルダーは `Infrastructure`）。そのため、設定の変更は不要で、JSONファイルを置くだけで追加できます。

## 11.2　ダッシュボードの作成

7つのパネル（ホストの稼働状態・CPU・メモリ・ファイルシステム・ネットワーク・ディスクI/O・稼働時間）を作ります。同じ名前のファイルがあるときは、上書きせずに止まります。`"uid": "dfsldbphmj9c0e"` は、6.1で確認した自分の環境のUIDに置き換えます。

**実行先：LXC 105 lxc-grafana（root）**

```bash
set -e

python3 - <<'PY'
import json
from pathlib import Path

path = Path("/var/lib/grafana/dashboards/infrastructure-overview.json")

if path.exists():
    raise SystemExit(f"ERROR: {path} already exists. No overwrite performed.")

ds = {"type": "prometheus", "uid": "dfsldbphmj9c0e"}
jobs = '(pve-node|security-core|postgresql-node|prometheus-node|grafana-node)'

def panel(pid, title, ptype, x, y, w, h, exprs, unit, instant=False):
    targets = []
    for i, (expr, legend) in enumerate(exprs):
        targets.append({
            "refId": chr(65+i),
            "expr": expr,
            "legendFormat": legend,
            "instant": instant,
            "range": not instant
        })

    defaults = {
        "unit": unit,
        "color": {"mode": "palette-classic"},
        "custom": {
            "drawStyle": "line",
            "lineInterpolation": "smooth",
            "lineWidth": 2,
            "fillOpacity": 12,
            "showPoints": "never",
            "spanNulls": False
        }
    }

    if title == "Host Availability":
        defaults["color"] = {"mode": "thresholds"}
        defaults["thresholds"] = {
            "mode": "absolute",
            "steps": [
                {"color": "red", "value": None},
                {"color": "green", "value": 1}
            ]
        }
    elif unit == "percent":
        defaults["min"] = 0
        defaults["max"] = 100

    options = (
        {
            "reduceOptions": {
                "values": False,
                "calcs": ["lastNotNull"],
                "fields": ""
            },
            "orientation": "auto",
            "textMode": "auto",
            "colorMode": "background" if title == "Host Availability" else "value",
            "graphMode": "area",
            "justifyMode": "auto",
            "showPercentChange": False,
            "percentChangeColorMode": "standard"
        }
        if ptype == "stat"
        else {
            "legend": {
                "showLegend": True,
                "displayMode": "list",
                "placement": "bottom",
                "calcs": []
            },
            "tooltip": {"mode": "multi", "sort": "desc"}
        }
    )

    return {
        "id": pid,
        "title": title,
        "type": ptype,
        "datasource": ds,
        "gridPos": {"h": h, "w": w, "x": x, "y": y},
        "fieldConfig": {"defaults": defaults, "overrides": []},
        "targets": targets,
        "options": options
    }

panels = [
    panel(1, "Host Availability", "stat", 0, 0, 24, 5, [
        (f'up{{job=~"{jobs}"}}', "{{host}}")
    ], "short", True),

    panel(2, "CPU Usage by Host", "timeseries", 0, 5, 12, 8, [
        (f'100 * (1 - avg by (host) (rate(node_cpu_seconds_total{{job=~"{jobs}",mode="idle"}}[5m])))',
         "{{host}}")
    ], "percent"),

    panel(3, "Memory Usage by Host", "timeseries", 12, 5, 12, 8, [
        (f'100 * (1 - max by (host) (node_memory_MemAvailable_bytes{{job=~"{jobs}"}}) / max by (host) (node_memory_MemTotal_bytes{{job=~"{jobs}"}}))',
         "{{host}}")
    ], "percent"),

    panel(4, "Maximum Filesystem Usage by Host", "timeseries", 0, 13, 12, 8, [
        (f'max by (host) (100 * (1 - node_filesystem_avail_bytes{{job=~"{jobs}",fstype!~"tmpfs|overlay|squashfs"}} / node_filesystem_size_bytes{{job=~"{jobs}",fstype!~"tmpfs|overlay|squashfs"}}))',
         "{{host}}")
    ], "percent"),

    panel(5, "Network Traffic by Host", "timeseries", 12, 13, 12, 8, [
        (f'sum by (host) (rate(node_network_receive_bytes_total{{job=~"{jobs}",device!~"lo"}}[5m]))',
         "{{host}} RX"),
        (f'sum by (host) (rate(node_network_transmit_bytes_total{{job=~"{jobs}",device!~"lo"}}[5m]))',
         "{{host}} TX")
    ], "Bps"),

    panel(6, "Disk I/O by Host", "timeseries", 0, 21, 12, 8, [
        (f'sum by (host) (rate(node_disk_read_bytes_total{{job=~"{jobs}"}}[5m]))',
         "{{host}} Read"),
        (f'sum by (host) (rate(node_disk_written_bytes_total{{job=~"{jobs}"}}[5m]))',
         "{{host}} Write")
    ], "Bps"),

    panel(7, "Host Uptime", "stat", 12, 21, 12, 8, [
        (f'time() - node_boot_time_seconds{{job=~"{jobs}"}}',
         "{{host}}")
    ], "s", True)
]

dashboard = {
    "uid": "infra-unified-overview",
    "title": "Integrated Infrastructure Overview",
    "description": "Unified monitoring for PVE, Security Core, PostgreSQL, Prometheus and Grafana.",
    "tags": ["infrastructure", "node-exporter", "victoriametrics"],
    "timezone": "browser",
    "schemaVersion": 41,
    "version": 1,
    "refresh": "30s",
    "time": {"from": "now-1h", "to": "now"},
    "panels": panels,
    "annotations": {
        "list": [{
            "builtIn": 1,
            "datasource": {"type": "grafana", "uid": "-- Grafana --"},
            "enable": True,
            "hide": True,
            "iconColor": "rgba(0, 211, 255, 1)",
            "name": "Annotations & Alerts",
            "type": "dashboard"
        }]
    }
}

path.write_text(json.dumps(dashboard, indent=2) + "\n")
print("Created:", path)
print("UID:", dashboard["uid"])
print("Panels:", len(panels))
for p in panels:
    print("-", p["title"])
PY

chown grafana:grafana /var/lib/grafana/dashboards/infrastructure-overview.json
chmod 640 /var/lib/grafana/dashboards/infrastructure-overview.json

echo
echo "=== JSON VALIDATION ==="
python3 -m json.tool \
  /var/lib/grafana/dashboards/infrastructure-overview.json \
  >/dev/null && echo "JSON: VALID"

echo
echo "=== FILE PERMISSIONS ==="
ls -l /var/lib/grafana/dashboards/infrastructure-overview.json

echo
echo "=== GRAFANA READ ACCESS ==="
runuser -u grafana -- test -r \
  /var/lib/grafana/dashboards/infrastructure-overview.json \
  && echo "READABLE: YES"
```

> 先頭に `set -e` があるため、`bash` を起動してから実行してください（7.4の注記と同じです）。

## 11.3　読み込みの確認

プロビジョニングは30秒ごとにファイルを確認するため、Grafanaの再起動は不要です。

**実行先：LXC 105 lxc-grafana（root）**

```bash
echo "=== WAIT FOR DASHBOARD PROVISIONING ==="
sleep 35

echo
echo "=== PROVISIONING LOGS ==="
journalctl -u grafana-server --since "3 minutes ago" --no-pager \
  | grep -Ei 'provisioning.dashboard|finished to provision|error|infrastructure-overview'

echo
echo "=== GRAFANA HEALTH ==="
curl -fsS http://127.0.0.1:3000/api/health \
  | python3 -m json.tool
```

時間を置いて確認したいときは、ログの範囲を広げます（`--since` は作業した時刻に合わせます）。

```bash
echo "=== DASHBOARD PROVISIONING HISTORY ==="
journalctl -u grafana-server \
  --since "2026-11-20 10:20:00" --no-pager \
  | grep -Ei 'provision|dashboard|infrastructure-overview' \
  | tail -60

echo
echo "=== NEW DASHBOARD FILE ==="
stat /var/lib/grafana/dashboards/infrastructure-overview.json
```

構築時は、ダッシュボードの検索インデックスが `size=3` に増えたことがログで確認できました。

## 11.4　画面での確認

Grafanaの画面で **Dashboards → Infrastructure → Integrated Infrastructure Overview** を開き、7つのパネルすべてに5台分のデータが表示されることを確認します。構築時は、すべてのパネルが表示されました。

# 第8部のまとめ

## 完成した監視の構成

| 監視対象 | アドレス | Prometheusのジョブ | `host` / `role` |
|---|---|---|---|
| Proxmoxホスト | 192.168.0.240:9100 | `pve-node` | `pve` / `hypervisor` |
| security-core | 192.168.0.220:9100 | `security-core` | `security-core` / `security` |
| PostgreSQL | 192.168.0.151:9100 | `postgresql-node` | `postgresql` / `database` |
| Prometheus | 192.168.0.197:9100 | `prometheus-node` | `prometheus` / `monitoring` |
| Grafana | 192.168.0.199:9100 | `grafana-node` | `grafana` / `visualization` |

データの流れ：Node Exporter → Prometheus（LXC 103）→ Remote Write → VictoriaMetrics（`192.168.0.171:8428`）→ Grafana（LXC 105）

## 作成したダッシュボード

| ダッシュボード | UID | パネル |
|---|---|---|
| PVE Host Overview | `pve-host-overview` | 6 |
| Integrated Infrastructure Overview | `infra-unified-overview` | 7 |

## 守った方針

- 各 Node Exporter は、`vmbr0` 側の自分のアドレスだけで待ち受ける。
- 既存のジョブ（`prometheus`・`ollama-gpu`）、既存のサービス、PVEのダッシュボードは変更しない。
- Prometheus は再起動せず、SIGHUP（`systemctl reload`）で設定を読み込み直す。
- Grafana と VictoriaMetrics は外部に公開しない。LXC 400番台と `192.168.1.25` には触れない。

## 変更したファイル

| サーバー | ファイル |
|---|---|
| 5台すべて | `/etc/default/prometheus-node-exporter` |
| LXC 103 | `/etc/prometheus/prometheus.yml`（変更ごとにバックアップを作成） |
| LXC 105 | `/etc/grafana/provisioning/dashboards/pve.yaml`、`/var/lib/grafana/dashboards/pve-overview.json`、`/var/lib/grafana/dashboards/infrastructure-overview.json` |
