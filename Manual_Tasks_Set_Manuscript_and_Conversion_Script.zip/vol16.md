---
title: "AI自律型サイバー防御システム 構築マニュアル 前編"
subtitle: "第16部　WazuhアラートをAI分析につなぐ"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」前編の第16部です。第15部で VM 230 に置いた Relay の接続情報を使い、AI Defense Manager（FastAPI）に次の機能を足します。

```text
VM220 security-core
  Wazuh Indexer
       ↓
  Read-only Relay API
       ↓ HTTPS + Token
VM230 ai-defense-manager
  Wazuh Connector
       ↓
  SecurityEvent変換・検証
       ↓
  AIAnalysisRequest
       ↓
  既存AI Analysis Service
       ↓
  JSON形式の防御提案
```

追加するAPIは次の2つです。既存の `/health` と `/api/v1/analysis` はそのまま残します。

- `GET /api/v1/wazuh/events`：Relay からアラートを取り、`SecurityEvent` にして返す
- `POST /api/v1/wazuh/analyze`：取ったアラートを既存の AI 分析（`analyze_events()`）に渡し、防御の提案を返す

AI に渡すのは検証済みのイベントだけです。Relay のトークンや接続先は渡しません。また、AI に防御の操作（IPの遮断など）を実行する権限は与えません。

## 本書の表記

- コマンドやプログラムは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 実行先は、特に断りがない場合 **ai-defense-manager VM 230（root）** です。

# 第1章　今のアプリを確かめる

## 1.1　ファイルの構成

```bash
find /opt/ai-defense-manager -maxdepth 3 -type f ! -path '*/venv/*' ! -path '*/__pycache__/*' ! -name '*.pyc' -printf '%P\n' | sort | head -n 100
```

設定・イベントのスキーマ・アプリ本体・分析API・分析サービス・分析のスキーマを読みます（変更はしません）。

```bash
sed -n '1,240p' /opt/ai-defense-manager/app/core/config.py
```

```bash
sed -n '1,260p' /opt/ai-defense-manager/app/schemas/security_event.py
```

```bash
sed -n '1,260p' /opt/ai-defense-manager/app/main.py
```

```bash
sed -n '1,300p' /opt/ai-defense-manager/app/api/analysis.py
```

```bash
sed -n '1,320p' /opt/ai-defense-manager/app/services/ai_analysis.py
```

```bash
sed -n '1,260p' /opt/ai-defense-manager/app/schemas/analysis.py
```

`AIAnalysisRequest` は1〜100件の `SecurityEvent` を受け取る作りです。Relay も最大100件なので、そのままつなげられます。

## 1.2　依存パッケージ

```bash
cat /opt/ai-defense-manager/requirements.lock
```

`httpx`（HTTPS の通信）、`pydantic`（検証と変換）、`fastapi`（API）はすでに入っています。追加のインストールはしません。

## 1.3　動いているか

```bash
systemctl list-units --type=service --all | grep -iE 'ai-defense|uvicorn'
```

```bash
ss -lntp '( sport = :8000 )'
```

```bash
ps -eo pid,ppid,user,args --sort=pid | grep -E '[u]vicorn|[g]unicorn|[a]pp.main|[a]i-defense-manager'
```

構築時は、systemd のサービスはなく、ポート 8000 で待ち受けているプロセスもありませんでした（アプリは止まっている状態です）。

```bash
ls -la /opt/ai-defense-manager && ls -ld /opt/ai-defense-manager/venv /etc/ai-defense-manager /etc/ai-defense-manager/credentials
```

```bash
find /opt/ai-defense-manager/tests /opt/ai-defense-manager/config -maxdepth 3 -type f -printf '%p\n' | sort
```

`tests` と `config` は空でした。

## 1.4　防御の提案のスキーマ

```bash
sed -n '1,280p' /opt/ai-defense-manager/app/schemas/analysis_proposal.py
```

```bash
sed -n '1,280p' /opt/ai-defense-manager/app/schemas/action.py
```

すでに次の安全のための制約が入っています。これは変えません。

- AI の提案は JSON で返す
- `temporary_block_ip`（一時的なIPの遮断）はグローバルIPだけが対象で、別々の証拠イベントIDが2件以上必要
- TTL は1〜900秒
- 遮断の提案は、必ず人の承認が必要（`ActionProposal` の初めの状態は `PENDING`）
- 実際に遮断する処理は含まれていない

## 1.5　ユーザーと権限

```bash
id ai-defense && stat -c '%A %U:%G %n' /opt/ai-defense-manager /opt/ai-defense-manager/app /opt/ai-defense-manager/venv /opt/ai-defense-manager/data /opt/ai-defense-manager/logs /etc/ai-defense-manager/credentials
```

| 対象 | 持ち主 | 意味 |
|---|---|---|
| アプリ本体 | `root:ai-defense` | 実行ユーザーはコードを書き換えられない |
| 仮想環境 | `root:root` | 実行ユーザーはパッケージを書き換えられない |
| `data`・`logs` | `ai-defense:ai-defense` | アプリの書き込み先 |
| Relay の接続情報 | `root:ai-defense` | 実行ユーザーは読める。ほかのユーザーは読めない |

```bash
/opt/ai-defense-manager/venv/bin/python -c 'import fastapi,httpx,pydantic,pydantic_settings; print("FastAPI",fastapi.__version__); print("httpx",httpx.__version__); print("Pydantic",pydantic.__version__); print("DEPENDENCIES_OK")'
```

```bash
stat -c '%A %U:%G %s bytes %n' /etc/ai-defense-manager/credentials/relay-ca.crt /etc/ai-defense-manager/credentials/relay-api.token && runuser -u ai-defense -- test -r /etc/ai-defense-manager/credentials/relay-ca.crt && runuser -u ai-defense -- test -r /etc/ai-defense-manager/credentials/relay-api.token && echo CREDENTIAL_ACCESS_OK
```

# 第2章　Relayから取ってSecurityEventにする

## 2.1　実際のデータの形

Relay が返す値の形を、1件だけ取って確かめます。

```bash
python3 - <<'PY'
import json
import ssl
import urllib.request
from pathlib import Path

base = "https://192.168.0.220:8765"
credentials = Path("/etc/ai-defense-manager/credentials")
token = (credentials / "relay-api.token").read_text().strip()
context = ssl.create_default_context(cafile=str(credentials / "relay-ca.crt"))
request = urllib.request.Request(
    base + "/v1/alerts?limit=1&since_minutes=60",
    headers={"Authorization": f"Bearer {token}"},
)
with urllib.request.urlopen(request, context=context, timeout=10) as response:
    data = json.load(response)

print("STATUS: OK")
print("COUNT:", data.get("count"))
if data.get("alerts"):
    alert = data["alerts"][0]
    print("FIELDS:", sorted(alert.keys()))
    for key in ("timestamp", "rule.level", "rule.id", "rule.description",
                "agent.id", "agent.name", "manager.name", "location", "decoder.name"):
        value = alert.get(key)
        print(f"{key}: {value!r} ({type(value).__name__})")
PY
```

構築時の結果（抜粋）は次のとおりです。

| 項目 | 値 |
|---|---|
| `timestamp` | `'2026-11-20T23:54:26.205+0000'`（タイムゾーン付きの文字列） |
| `rule.level` | `3`（整数） |
| `rule.id` | `'87203'` |
| `rule.description` | `'Proxmox VE authentication succeeded.'` |
| `agent.name` | `'pve'` |
| `decoder.name` | `'pvedaemon'` |

`agent.ip` はエージェント自身のIPアドレスなので、攻撃元のIPとしては扱いません。

## 2.2　変換のきまり

Wazuh のレベルを、`SecurityEvent` の重大度に次のように置き換えます。

| Wazuhのレベル | 重大度 |
|---:|---|
| 0〜3 | `info` |
| 4〜7 | `low` |
| 8〜11 | `medium` |
| 12〜14 | `high` |
| 15〜16 | `critical` |

## 2.3　wazuh_relay.py

```bash
cat > /opt/ai-defense-manager/app/services/wazuh_relay.py <<'PY'
from datetime import datetime
from pathlib import Path

import httpx

from app.core.config import settings
from app.schemas.security_event import SecurityEvent


class WazuhRelayError(Exception):
    pass


def _severity(level: int) -> str:
    if not 0 <= level <= 16:
        raise ValueError("Wazuh rule level is outside the accepted range")

    if level <= 3:
        return "info"
    if level <= 7:
        return "low"
    if level <= 11:
        return "medium"
    if level <= 14:
        return "high"
    return "critical"


def _convert_alert(alert: dict) -> SecurityEvent:
    if not isinstance(alert, dict):
        raise ValueError("Alert must be an object")

    timestamp = alert.get("timestamp")
    level = alert.get("rule.level")
    rule_id = alert.get("rule.id")
    description = alert.get("rule.description")
    agent_id = alert.get("agent.id")
    agent_name = alert.get("agent.name")
    location = alert.get("location")
    decoder = alert.get("decoder.name")

    if not isinstance(timestamp, str):
        raise ValueError("Invalid alert timestamp")
    if isinstance(level, bool) or not isinstance(level, int):
        raise ValueError("Invalid Wazuh rule level")

    observed_at = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
    if observed_at.tzinfo is None or observed_at.utcoffset() is None:
        raise ValueError("Alert timestamp must include a timezone")

    if rule_id is not None and not isinstance(rule_id, str):
        raise ValueError("Invalid rule ID")
    if description is not None and not isinstance(description, str):
        raise ValueError("Invalid rule description")
    if agent_id is not None and not isinstance(agent_id, str):
        raise ValueError("Invalid agent ID")
    if agent_name is not None and not isinstance(agent_name, str):
        raise ValueError("Invalid agent name")
    if location is not None and not isinstance(location, str):
        raise ValueError("Invalid alert location")
    if decoder is not None and not isinstance(decoder, str):
        raise ValueError("Invalid decoder name")

    category = (decoder or location or "wazuh")[:64]
    summary = (description or "Wazuh security alert")[:512]

    return SecurityEvent(
        source="wazuh",
        observed_at=observed_at,
        severity=_severity(level),
        rule_id=rule_id,
        rule_description=description[:512] if description else None,
        agent_id=agent_id,
        agent_name=agent_name,
        event_category=category,
        event_summary=summary,
    )


async def fetch_wazuh_events(
    limit: int = 50,
    since_minutes: int = 60,
) -> list[SecurityEvent]:
    if not 1 <= limit <= 100:
        raise ValueError("limit must be between 1 and 100")
    if not 1 <= since_minutes <= 1440:
        raise ValueError("since_minutes must be between 1 and 1440")

    ca_file = Path(settings.wazuh_relay_ca_file)
    token_file = Path(settings.wazuh_relay_token_file)

    if not ca_file.is_file() or not token_file.is_file():
        raise WazuhRelayError("Relay credentials are unavailable")

    try:
        token = token_file.read_text(encoding="utf-8").strip()
    except OSError as exc:
        raise WazuhRelayError("Unable to read Relay credentials") from exc

    if not token or len(token) > 512:
        raise WazuhRelayError("Relay token is invalid")

    url = (
        f"{str(settings.wazuh_relay_base_url).rstrip('/')}"
        "/v1/alerts"
    )

    try:
        async with httpx.AsyncClient(
            verify=str(ca_file),
            timeout=settings.wazuh_relay_timeout_seconds,
            follow_redirects=False,
        ) as client:
            response = await client.get(
                url,
                params={
                    "limit": limit,
                    "since_minutes": since_minutes,
                },
                headers={"Authorization": f"Bearer {token}"},
            )
            response.raise_for_status()
            payload = response.json()

        alerts = payload.get("alerts")
        if not isinstance(alerts, list):
            raise WazuhRelayError("Relay returned an invalid response")

        if len(alerts) > limit:
            raise WazuhRelayError("Relay returned more alerts than requested")

        return [_convert_alert(alert) for alert in alerts]

    except WazuhRelayError:
        raise
    except (httpx.HTTPError, ValueError, TypeError, KeyError) as exc:
        raise WazuhRelayError("Wazuh Relay retrieval or validation failed") from exc
PY
```

貼り付けたときに端末の表示が乱れることがあります。ファイルが最後まで書けたかを行数と末尾で確かめます（構築時は137行でした）。

```bash
wc -l /opt/ai-defense-manager/app/services/wazuh_relay.py && tail -n 20 /opt/ai-defense-manager/app/services/wazuh_relay.py
```

```bash
 /opt/ai-defense-manager/venv/bin/python -m py_compile /opt/ai-defense-manager/app/services/wazuh_relay.py && echo WAZUH_RELAY_SYNTAX_OK
```

## 2.4　設定の追加

接続先と、接続情報のファイルの場所を設定に足します。トークンそのものは設定に書きません。

```bash
python3 - <<'PY'
from pathlib import Path

p = Path("/opt/ai-defense-manager/app/core/config.py")
s = p.read_text()

marker = '    analysis_timeout_seconds: int = Field(default=60, ge=1, le=600)\n'
addition = '''    analysis_timeout_seconds: int = Field(default=60, ge=1, le=600)

    wazuh_relay_base_url: HttpUrl = "https://192.168.0.220:8765/"
    wazuh_relay_ca_file: str = "/etc/ai-defense-manager/credentials/relay-ca.crt"
    wazuh_relay_token_file: str = "/etc/ai-defense-manager/credentials/relay-api.token"
    wazuh_relay_timeout_seconds: int = Field(default=15, ge=1, le=60)
'''

if "wazuh_relay_base_url" in s:
    raise SystemExit("Relay settings already exist; no changes made")
if marker not in s:
    raise SystemExit("Expected insertion point not found; no changes made")

p.write_text(s.replace(marker, addition, 1))
print("WAZUH_RELAY_SETTINGS_ADDED")
PY
```

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
from app.core.config import settings

assert str(settings.wazuh_relay_base_url) == "https://192.168.0.220:8765/"
assert settings.wazuh_relay_ca_file == "/etc/ai-defense-manager/credentials/relay-ca.crt"
assert settings.wazuh_relay_token_file == "/etc/ai-defense-manager/credentials/relay-api.token"
assert settings.wazuh_relay_timeout_seconds == 15

print("RELAY_URL:", settings.wazuh_relay_base_url)
print("CA_FILE:", settings.wazuh_relay_ca_file)
print("TOKEN_FILE_CONFIGURED:", bool(settings.wazuh_relay_token_file))
print("TIMEOUT:", settings.wazuh_relay_timeout_seconds)
print("CONFIG_VALID")
PY
```

# 第3章　取得のAPI

## 3.1　wazuh.py（取得だけ）

`limit` は1〜100件（既定50件）、`since_minutes` は1〜1440分（既定60分）です。Relay との通信に失敗したら `502` を返し、接続情報や Relay の生のデータは返しません。

```bash
cat > /opt/ai-defense-manager/app/api/wazuh.py <<'PY'
from fastapi import APIRouter, HTTPException, Query

from app.schemas.security_event import SecurityEvent
from app.services.wazuh_relay import WazuhRelayError, fetch_wazuh_events

router = APIRouter(prefix="/api/v1/wazuh", tags=["Wazuh"])


@router.get("/events", response_model=list[SecurityEvent])
async def get_wazuh_events(
    limit: int = Query(default=50, ge=1, le=100),
    since_minutes: int = Query(default=60, ge=1, le=1440),
) -> list[SecurityEvent]:
    try:
        return await fetch_wazuh_events(
            limit=limit,
            since_minutes=since_minutes,
        )
    except WazuhRelayError as exc:
        raise HTTPException(
            status_code=502,
            detail="Wazuh alert retrieval or validation failed",
        ) from exc
PY
```

```bash
cd /opt/ai-defense-manager && ./venv/bin/python -m py_compile app/core/config.py app/services/wazuh_relay.py app/api/wazuh.py && ./venv/bin/python -c 'from app.api.wazuh import router; print("ROUTES:", [(r.path, sorted(r.methods)) for r in router.routes]); print("WAZUH_API_IMPORT_OK")'
```

## 3.2　アプリへの登録

```bash
python3 - <<'PY'
from pathlib import Path

p = Path("/opt/ai-defense-manager/app/main.py")
s = p.read_text()

if "from app.api.wazuh import router as wazuh_router" in s:
    raise SystemExit("Wazuh router import already exists; no changes made")

s = s.replace(
    "from app.api.analysis import router as analysis_router\n",
    "from app.api.analysis import router as analysis_router\n"
    "from app.api.wazuh import router as wazuh_router\n",
    1,
)

s = s.replace(
    "app.include_router(analysis_router)\n",
    "app.include_router(analysis_router)\n"
    "app.include_router(wazuh_router)\n",
    1,
)

if "app.include_router(wazuh_router)" not in s:
    raise SystemExit("Router registration failed; no file written")

p.write_text(s)
print("WAZUH_ROUTER_REGISTERED")
PY
```

## 3.3　登録の確認

構築時の FastAPI 0.165.0 では、`include_router()` で登録したルーターは遅れて組み込まれるため、`app.routes` を見ても `/api/v1/...` が出てきません。そこで、FastAPI が作る OpenAPI の仕様で確かめます。

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
from app.main import app

schema = app.openapi()
paths = schema.get("paths", {})

for path in sorted(paths):
    print(path, sorted(paths[path].keys()))

required = {
    ("/health", "get"),
    ("/api/v1/analysis", "post"),
    ("/api/v1/wazuh/events", "get"),
}
actual = {
    (path, method.lower())
    for path, operations in paths.items()
    for method in operations
}
missing = required - actual

if missing:
    raise SystemExit(f"MISSING_OPENAPI_OPERATIONS: {missing}")

print("OPENAPI_ROUTE_REGISTRATION_OK")
PY
```

## 3.4　実行ユーザーで取ってみる

`ai-defense` ユーザーで Relay から5件を取り、`SecurityEvent` に変換します。

```bash
cd /opt/ai-defense-manager && runuser -u ai-defense -- ./venv/bin/python - <<'PY'
import asyncio
from app.services.wazuh_relay import fetch_wazuh_events

async def main():
    events = await fetch_wazuh_events(limit=5, since_minutes=60)
    print("EVENT_COUNT:", len(events))
    for event in events:
        print({
            "source": event.source,
            "severity": event.severity,
            "rule_id": event.rule_id,
            "agent_id": event.agent_id,
            "agent_name": event.agent_name,
            "event_category": event.event_category,
            "event_summary": event.event_summary,
            "observed_at": event.observed_at.isoformat(),
            "source_ip": event.source_ip,
        })
    print("SECURITY_EVENT_CONVERSION_OK")

asyncio.run(main())
PY
```

構築時は5件すべてが変換でき、`rule.level=3` は `info` になりました。Relay は攻撃元のIPを返さないため、`source_ip` は `None` のままです。

# 第4章　分析のAPI

## 4.1　リクエストのスキーマ

```bash
cat > /opt/ai-defense-manager/app/schemas/wazuh.py <<'PY'
from pydantic import BaseModel, ConfigDict, Field


class WazuhAnalysisRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    limit: int = Field(default=50, ge=1, le=100)
    since_minutes: int = Field(default=60, ge=1, le=1440)
    analysis_context: str | None = Field(default=None, max_length=2000)
    requested_language: str = Field(default="ja", pattern=r"^(ja|en)$")
PY
```

```bash
cd /opt/ai-defense-manager && ./venv/bin/python -m py_compile app/schemas/wazuh.py && ./venv/bin/python -c 'from app.schemas.wazuh import WazuhAnalysisRequest; r=WazuhAnalysisRequest(); print(r.model_dump()); print("WAZUH_ANALYSIS_SCHEMA_OK")'
```

## 4.2　wazuh.py（分析を追加）

`POST /api/v1/wazuh/analyze` は次の順に処理します。

1. Relay から Wazuh のアラートを取る
2. `SecurityEvent` に変換して検証する
3. 0件なら AI を呼ばずに `404` で終わる
4. 既存の `analyze_events()` に渡す
5. `AIAnalysisProposal`（防御の提案）を返す

```bash
cat > /opt/ai-defense-manager/app/api/wazuh.py <<'PY'
from fastapi import APIRouter, HTTPException, Query

from app.schemas.analysis import AIAnalysisRequest
from app.schemas.analysis_proposal import AIAnalysisProposal
from app.schemas.security_event import SecurityEvent
from app.schemas.wazuh import WazuhAnalysisRequest
from app.services.ai_analysis import AIAnalysisError, analyze_events
from app.services.wazuh_relay import WazuhRelayError, fetch_wazuh_events

router = APIRouter(prefix="/api/v1/wazuh", tags=["Wazuh"])


@router.get("/events", response_model=list[SecurityEvent])
async def get_wazuh_events(
    limit: int = Query(default=50, ge=1, le=100),
    since_minutes: int = Query(default=60, ge=1, le=1440),
) -> list[SecurityEvent]:
    try:
        return await fetch_wazuh_events(
            limit=limit,
            since_minutes=since_minutes,
        )
    except WazuhRelayError as exc:
        raise HTTPException(
            status_code=502,
            detail="Wazuh alert retrieval or validation failed",
        ) from exc


@router.post("/analyze", response_model=AIAnalysisProposal)
async def analyze_wazuh_events(
    request: WazuhAnalysisRequest,
) -> AIAnalysisProposal:
    try:
        events = await fetch_wazuh_events(
            limit=request.limit,
            since_minutes=request.since_minutes,
        )

        if not events:
            raise HTTPException(
                status_code=404,
                detail="No Wazuh alerts found in the requested time range",
            )

        analysis_request = AIAnalysisRequest(
            events=events,
            analysis_context=request.analysis_context,
            requested_language=request.requested_language,
        )

        return await analyze_events(analysis_request)

    except WazuhRelayError as exc:
        raise HTTPException(
            status_code=502,
            detail="Wazuh alert retrieval or validation failed",
        ) from exc
    except AIAnalysisError as exc:
        raise HTTPException(
            status_code=502,
            detail="AI analysis failed or returned an invalid response",
        ) from exc
PY
```

```bash
wc -l /opt/ai-defense-manager/app/api/wazuh.py && tail -n 35 /opt/ai-defense-manager/app/api/wazuh.py
```

構築時は63行で、末尾まで書けていました。

```bash
cd /opt/ai-defense-manager && ./venv/bin/python -m py_compile app/api/wazuh.py app/schemas/wazuh.py app/services/wazuh_relay.py app/core/config.py && ./venv/bin/python - <<'PY'
from app.main import app

paths = app.openapi()["paths"]

for path in sorted(paths):
    print(path, sorted(paths[path].keys()))

required = {
    ("/health", "get"),
    ("/api/v1/analysis", "post"),
    ("/api/v1/wazuh/events", "get"),
    ("/api/v1/wazuh/analyze", "post"),
}
actual = {
    (path, method.lower())
    for path, operations in paths.items()
    for method in operations
}
missing = required - actual

if missing:
    raise SystemExit(f"MISSING_OPERATIONS: {missing}")

print("WAZUH_INTEGRATION_OPENAPI_OK")
PY
```

# 第5章　Wazuh → Ollama → AI分析の確認

## 5.1　モデルがあるか

分析に使う `qwen3:8b` が Ollama（VM 101）にあるかを確かめます。まだ分析のリクエストは送りません。

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
import json
import urllib.request
from app.core.config import settings

url = str(settings.ollama_base_url).rstrip("/") + "/api/tags"
try:
    with urllib.request.urlopen(url, timeout=10) as response:
        data = json.load(response)
    models = [m.get("name") for m in data.get("models", [])]
    print("OLLAMA_STATUS: OK")
    print("AVAILABLE_MODELS:")
    for model in models:
        print(" -", model)
    print("QWEN3_8B_AVAILABLE:", any(
        name == "qwen3:8b" or name.startswith("qwen3:8b-")
        for name in models
    ))
except Exception as exc:
    print("OLLAMA_CHECK_FAILED:", type(exc).__name__, str(exc))
    raise SystemExit(1)
PY
```

## 5.2　つないで分析する

実行ユーザーで5件のアラートを取り、既存の分析に渡します。アラートの内容は LLM に送られますが、防御の操作・IPの遮断・設定の変更はいっさい行いません。

```bash
cd /opt/ai-defense-manager && runuser -u ai-defense -- ./venv/bin/python - <<'PY'
import asyncio
from app.schemas.analysis import AIAnalysisRequest
from app.services.wazuh_relay import fetch_wazuh_events
from app.services.ai_analysis import analyze_events

async def main():
    events = await fetch_wazuh_events(limit=5, since_minutes=60)
    if not events:
        raise RuntimeError("No Wazuh events available for analysis")

    request = AIAnalysisRequest(
        events=events,
        analysis_context="Wazuhから取得した直近のセキュリティイベントを分析してください。実行済みの操作として扱わず、防御操作は提案だけにしてください。",
        requested_language="ja",
    )

    print("INPUT_EVENT_COUNT:", len(events))
    proposal = await analyze_events(request)

    print("ANALYSIS_RESULT:")
    print("severity:", proposal.severity)
    print("confidence:", proposal.confidence)
    print("recommended_action:", proposal.recommended_action.value)
    print("requires_human_approval:", proposal.requires_human_approval)
    print("evidence_event_count:", len(proposal.evidence_event_ids))
    print("target_ip:", proposal.target_ip)
    print("ttl_seconds:", proposal.ttl_seconds)
    print("summary:", proposal.summary)
    print("reasoning:", proposal.reasoning)
    print("WAZUH_TO_AI_ANALYSIS_OK")

asyncio.run(main())
PY
```

構築時の結果は次のとおりです。認証の成功やログインのセッションの記録が中心だったため、遮断の提案が出ないのは妥当です。

| 項目 | 結果 |
|---|---|
| `severity` | `info` |
| `confidence` | `0.8` |
| `recommended_action` | `no_action` |
| `evidence_event_count` | `5` |
| `target_ip`・`ttl_seconds` | `None` |

## 5.3　追加したファイルの権限

```bash
stat -c '%A %U:%G %n' \
  /opt/ai-defense-manager/app/main.py \
  /opt/ai-defense-manager/app/core/config.py \
  /opt/ai-defense-manager/app/api/wazuh.py \
  /opt/ai-defense-manager/app/schemas/wazuh.py \
  /opt/ai-defense-manager/app/services/wazuh_relay.py \
  /etc/ai-defense-manager/credentials/relay-ca.crt \
  /etc/ai-defense-manager/credentials/relay-api.token
```

構築時は、新しく作った API 関係の3ファイルが `root:root` の `644` になっていました。既存のファイルと持ち主をそろえる作業は、次の部で行います。

# おわりに

第16部で、AI Defense Manager に次のAPIを足しました。

| API | 内容 |
|---|---|
| `GET /api/v1/wazuh/events` | Relay からアラートを取り、`SecurityEvent` で返す |
| `POST /api/v1/wazuh/analyze` | 取ったアラートを AI で分析し、防御の提案を返す |

次の部では、ファイルの権限をそろえ、AI Defense Manager を systemd のサービスとして動かします。
