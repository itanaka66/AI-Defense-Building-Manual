import re,sys
def build(a,b,hen,intro,out):
    parts=[]
    for n in range(a,b+1):
        s=open(f'vol{n}.md',encoding='utf-8').read()
        fm,body=re.match(r'^---\n(.*?)\n---\n(.*)$',s,re.S).groups()
        sub=re.search(r'^subtitle:\s*"(.*)"',fm,re.M).group(1)
        o=[];incode=False
        for l in body.split('\n'):
            if l.startswith('```'): incode=not incode
            if not incode:
                m=re.match(r'^(#{1,6}) (.*)$',l)
                if m: l='#'*min(len(m.group(1))+1,3)+' '+m.group(2)
            o.append(l)
        parts.append(f'# {sub}\n'+'\n'.join(o).strip('\n')+'\n')
    sec=open('hen_section.md',encoding='utf-8').read().replace('## 編と部の構成\n','## 編と部の構成\n',1)
    head=f'---\ntitle: "AI自律型サイバー防御システム 構築マニュアル {hen}"\nsubtitle: "合本　第{a}部〜第{b}部"\nauthor: "田中勇"\nlang: ja-JP\n---\n\n# {hen}について\n\n{intro}\n\n{sec}\n'
    open(out,'w',encoding='utf-8').write(head+'\n'.join(parts))
build(1,23,'前編','''本書は「AI自律型サイバー防御システム 構築マニュアル」の前編（第1部〜第23部）を1冊にまとめた合本です。Proxmox の上に Wazuh を中心とした防御基盤を作り、アラートを PostgreSQL に保存する Collector、統合監視、AI Defense Manager、Wazuh Indexer の読み取り専用ユーザー、中継API（Relay）、AI の分析とその保護、運用の点検までを、構築の記録から成功した手順だけを時系列に並べています。

前編の最後（第23部）で、Wazuh Indexer の監査ログがどこにも保存されていないらしいことがわかりました。その続きは中編（第24部〜）で扱います。''','omnibus.md')
build(24,30,'中編','''本書は「AI自律型サイバー防御システム 構築マニュアル」の中編（第24部〜第30部）を1冊にまとめた合本です。前編で作った環境の上で、Wazuh Indexer の監査ログが保存されない原因をコードで突き止めて保存できるようにし、その点検の途中で見つかった Collector の停止を、読み残しを出さずに復旧して、同じ理由で止まらないように直します。

前編と同じ環境（Proxmox・VM 220 security-core・LXC 109 PostgreSQL など）を前提にしています。前提となる構成や手順は前編を見てください。''','omnibus_chu.md')
