---
title: "AI自律型サイバー防御システム 運用マニュアル"
subtitle: "構築マニュアル 前編・中編（第1部〜第30部）対応版"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」（以下「本編」）で構築したシステムを、日々運用するための手順をまとめたものです。

- コマンドは、本編に載っている、構築時に実際に使ったものだけを使っています。改変していません。
- 各手順に、元になった本編の部と節を「（本編 第N部 X.Y）」の形で示します。本編は前編（第1部〜第23部）と中編（第24部〜第30部）に分かれていますが、部の番号は通し番号です。背景や結果の詳しい例は本編を見てください。
- 構築の会話の中に手順がないものは、新しく作っていません。「手順なし（未対応）」と書いています。
- 時刻・inode・件数・プロセス番号などは構築時のものです。自分の環境の値に置き換えてください。

## 一般的なPCで構築した場合

本書（と構築マニュアル）は、1台の大きなサーバーに Proxmox VE を入れ、その上の仮想マシン（VM）とコンテナ（LXC）に各機能を置く構成で書いています。同じシステムは、**一般的なPC（ミニPCやデスクトップPC）を複数台組み合わせて構築することも容易です**。1つのVM・LXCを、1台のPCと考えてください。

### VM・LXCとPCの読み替え

| 本書での名前 | 本書での置き場所 | 役割 | 読み替え（例） |
|---|---|---|---|
| security-core | VM 220（192.168.0.220） | Wazuh（Manager・Indexer・Dashboard）、Collector | PC1 |
| postgresql | LXC 109（192.168.0.151） | PostgreSQL（アラートの保存） | PC2 |
| lxc-prometheus | LXC 103（192.168.0.197） | Prometheus | PC2 |
| lxc-grafana | LXC 105（192.168.0.199） | Grafana | PC2 |
| VictoriaMetrics | 既存の LXC（192.168.0.171） | メトリクスの保存 | PC2 |
| ai-defense-manager | VM 230（192.168.0.33） | AI Defense Manager | PC3 |
| ollama-gpu | VM 101（192.168.0.180） | Ollama（ローカルLLM） | PC4 |
| pve | Proxmoxホスト（192.168.0.240） | 仮想化の基盤（監視の対象の1台） | 不要（各PCがそれぞれ監視の対象になる） |

上の表は、監視と保存の役割（PostgreSQL・Prometheus・Grafana・VictoriaMetrics）を1台（PC2）にまとめた4台構成の例です。台数に余裕があれば、本書と同じように1役割を1台に分けても構いません。1台にまとめる場合も、使うポート（PostgreSQL 5432、Prometheus 9090、Grafana 3000、VictoriaMetrics 8428）は重なりません。ただし Node Exporter（9100）は1台に1つだけにし、Prometheus のジョブも1台分にまとめます。

本文の「実行先：LXC 103 lxc-prometheus」などは、その役割を置いたPC（上の例では PC2）と読み替えてください。

### 参考になるPCの構成

次の表は目安です。本書の構築環境で各VMに割り当てた量と、本編 第1部で示したWazuhの公式の目安（25〜100エージェントで 8 vCPU・8 GiB RAM・100〜200GB）をもとにしています。この台数・構成で動かしたことを確かめたものではありません。監視するサーバーの数・ログの量・保存する期間に合わせて増やしてください。

| PC | 役割 | CPU | メモリ | ディスク | 備考 |
|---|---|---|---|---|---|
| PC1 | Wazuh・Collector | 8コア以上 | 16GB以上 | SSD 250GB以上 | 本書の VM 220 と同じ量。Indexer がログを保存するため、ディスクは多めに |
| PC2 | PostgreSQL・Prometheus・Grafana・VictoriaMetrics | 4コア以上 | 16GB以上 | SSD 500GB以上 | 保存する期間に応じてディスクを増やす |
| PC3 | AI Defense Manager | 4コア以上 | 8GB以上 | SSD 100GB以上 | 本書の VM 230 と同じ量 |
| PC4 | Ollama | 8コア以上 | 32GB以上 | SSD 500GB以上 | NVIDIA のGPU（VRAM 12GB以上を目安）。本書では RTX 3090（24GB）で `qwen3:8b` を使用 |

OSは、本書と同じく Ubuntu Server 24.04 LTS を使うのが簡単です（本書では、LXCの一部が Debian 13 でした。パッケージの名前や版は同じ手順で確かめられます）。

### 読み替えるときの注意

- **Proxmox だけのコマンド**：`qm`・`pct`・`pvesm` は Proxmox のコマンドです。VMやLXCを作る手順（本編 第1部 第2〜4章、第10部 第6章など）は、各PCにOSを入れる作業に置き換えます。Proxmoxホスト自体を監視する手順（本編 第1部 第11章、第8部 第3章）は、不要です。
- **IPアドレス**：本書のIPアドレスは構築した環境の値です。各PCに固定のIPアドレスを割り当て、本文のアドレスを読み替えてください。本書では2つのネットワーク（192.168.0.0/24 と 192.168.1.0/24）を使っていますが、すべてのPCを同じネットワーク（例：192.168.0.0/24）に置いても構いません。
- **待ち受けのアドレス**：Node Exporter や中継APIなどは、そのPC自身のアドレスだけで待ち受けるように設定しています（例：`--web.listen-address=192.168.0.240:9100`）。そのPCのアドレスに置き換えてください。
- **ディスクの監視**：本編 第10部のディスク障害の検知と対処は、PCでも同じ考え方で行えます。デバイス名（`/dev/sdg` など）は自分の環境で確かめてください。
- **GPU**：PC4 では、NVIDIA のドライバーを入れて `nvidia-smi` でGPUが見えることを確かめてから Ollama を入れます（Ollama の導入は、構築マニュアルの範囲より前に済んでいたため、手順は載せていません）。

## 実行先の表記

| 表記 | サーバー |
|---|---|
| pve | Proxmoxホスト（192.168.0.240） |
| security-core | VM 220（192.168.0.220 / 192.168.1.220）。Wazuh・Collector・Indexer・Relay |
| postgresql | LXC 109（192.168.0.151）。PostgreSQL |
| lxc-prometheus | LXC 103（192.168.0.197）。Prometheus |
| lxc-grafana | LXC 105（192.168.0.199）。Grafana |
| ai-defense-manager | VM 230（192.168.0.33）。AI Defense Manager |
| ollama-gpu | VM 101（192.168.0.180）。Ollama |

# 第1章　システムの構成

## 1.1　データの流れ

| 流れ | 内容 | 本編 |
|---|---|---|
| アラートの保存 | Wazuh の `alerts.json` → Collector（security-core）→ PostgreSQL `security_workbench` の `incident.alert_events` | 第3部〜第7部 |
| アラートの検索 | Wazuh → Indexer（security-core、127.0.0.1:9200）。AI用の読み取り専用ユーザー `ai-defense-reader` | 第12部・第13部 |
| サーバーの監視 | 各サーバーの Node Exporter（9100）→ Prometheus（lxc-prometheus）→ VictoriaMetrics（192.168.0.171:8428）→ Grafana（lxc-grafana:3000） | 第8部 |
| アラートの中継 | Indexer → Relay（security-core、`https://192.168.0.220:8765`、Bearer トークン、接続元は 192.168.0.33 だけ）→ AI Defense Manager | 第14部〜第16部 |
| AIの分析 | AI Defense Manager（127.0.0.1:8000、systemd）→ Ollama（192.168.0.180:11434、`qwen3:8b`）。LLM には6項目だけを伏せ字にして送る | 第11部・第12部・第16部〜第20部 |
| 分析の履歴 | AI Defense Manager → SQLite（`/opt/ai-defense-manager/data/ai-defense.db`） | 第18部・第20部 |
| 監査ログ | Wazuh Indexer の Security プラグイン → `security-auditlog-YYYY.MM.dd`（Indexer の中）。リクエストの本文は記録しない | 第24部〜第27部 |

## 1.2　主なサービスとファイル

| サーバー | サービス・ファイル | 内容 |
|---|---|---|
| security-core | `wazuh-collector`（systemd） | Collector。実行ユーザー `wazuh-collector` |
| security-core | `/usr/local/lib/wazuh-collector/collector.py` | Collector本体 |
| security-core | `/var/lib/wazuh-collector/state.json` | 読み取り位置（inode・offset）。中身は表示しない |
| security-core | `/var/ossec/logs/alerts/alerts.json` | Wazuhのアラート。毎日ローテーションし、古い日は `alerts/年/月/ossec-alerts-DD.json(.gz)` |
| security-core | `/root/ai-defense-reader.password` | Indexerの読み取り専用ユーザーのパスワード（root だけ） |
| 5台 | `prometheus-node-exporter` | Node Exporter（9100） |
| lxc-prometheus | `/etc/prometheus/prometheus.yml` | 収集のジョブと Remote Write |
| lxc-grafana | `/var/lib/grafana/dashboards/*.json` | ダッシュボード（PVE Host Overview、Integrated Infrastructure Overview） |
| security-core | `ai-defense-relay`（systemd） | Relay。実行ユーザー `ai-defense-relay`。`/opt/ai-defense-relay/relay.py` |
| security-core | `/etc/credstore/ai-defense-*` | Relay に `LoadCredential` で渡す秘密の情報（root だけ、600）。中身は表示しない |
| ai-defense-manager | `ai-defense-manager`（systemd） | AI Defense Manager の API（127.0.0.1:8000）。実行ユーザー `ai-defense` |
| ai-defense-manager | `/opt/ai-defense-manager/` | AI Defense Manager の本体 |
| ai-defense-manager | `/etc/ai-defense-manager/credentials/` | Relay の CA 証明書とトークン（`root:ai-defense`、640）。中身は表示しない |
| ai-defense-manager | `/opt/ai-defense-manager/data/ai-defense.db` | 分析の履歴（SQLite、`ai-defense` の 600） |
| pve | VM 220・230 の起動順 | VM 220 → 120秒待つ → VM 230（`onboot`・`startup`） |

# 第2章　毎日の確認

## 2.1　Collectorの状態と読み取り位置

**実行先：security-core（root）**

```bash
echo "=== SERVICE STATUS ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts

echo
echo "=== PRODUCTION CODE HASH ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== STATE AND ALERT FILE ==="
python3 - <<'PY'
import json
import os
from pathlib import Path

state_path = Path("/var/lib/wazuh-collector/state.json")
alert_path = Path("/var/ossec/logs/alerts/alerts.json")

state = json.loads(state_path.read_text())
state_stat = state_path.stat()
alert_stat = alert_path.stat()

print("state_owner_uid:", state_stat.st_uid)
print("state_owner_gid:", state_stat.st_gid)
print("state_mode:", oct(state_stat.st_mode & 0o777))
print("state_inode:", state["inode"])
print("state_offset:", state["offset"])
print("alert_inode:", alert_stat.st_ino)
print("alert_size:", alert_stat.st_size)
print("inode_match:", state["inode"] == alert_stat.st_ino)
print("offset_within_file:", 0 <= state["offset"] <= alert_stat.st_size)
print("state_at_eof:", state["offset"] == alert_stat.st_size)
PY
```

`ActiveState=active`、`SubState=running`、`inode_match: True`、`offset_within_file: True` であれば正常です。`NRestarts` が前の日より増えていたら、2.2のログを確認します（本編 第7部 13.1）。

## 2.2　Collectorのログ

**実行先：security-core（root）**

```bash
echo "=== COLLECTOR SERVICE ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts -p ExecMainStatus

echo
echo "=== ALERT FILE ==="
stat -c 'inode=%i size=%s mode=%a owner=%U:%G' \
  /var/ossec/logs/alerts/alerts.json

echo
echo "=== COLLECTOR STATE METADATA ==="
stat -c 'mode=%a owner=%U:%G size=%s' \
  /var/lib/wazuh-collector/state.json

echo
echo "=== COLLECTOR CODE HASH ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== RECENT COLLECTOR STATUS LOGS ==="
journalctl -u wazuh-collector --since "30 minutes ago" --no-pager \
  | grep -Ei 'connection established|inserted|duplicate|error|warning' \
  | sed -E 's/(password|token|secret)=([^ ]+)/\1=[REDACTED]/Ig' \
  | tail -30
```

`PermissionError` がくり返し出ている、または `NRestarts` が増え続けているときは、第4章 4.1 へ進みます（本編 第9部 1.1）。

## 2.3　DBの件数と取り込みの遅れ

**実行先：postgresql（root）**

```bash
sudo -u postgres psql -X -d security_workbench -c "
SELECT
    COUNT(*) AS total_events,
    MAX(ingested_at) AS latest_ingested_at,
    MAX(event_timestamp) AS latest_event_timestamp
FROM incident.alert_events;
"
```

`latest_ingested_at` が新しくなっていることを確かめます（本編 第7部 2.1）。

取り込みの遅れは、集計用のロール `dbadmin` で測ります（パスワードは `-W` で入力します）。

```bash
psql -X -h 127.0.0.1 -U dbadmin \
  -d security_workbench -W -c "
WITH recent AS (
    SELECT
        EXTRACT(EPOCH FROM (ingested_at - event_timestamp))
            AS delay_seconds
    FROM incident.alert_events
    WHERE ingested_at >= NOW() - INTERVAL '15 minutes'
)
SELECT
    COUNT(*) AS total_events,
    COUNT(*) FILTER (
        WHERE delay_seconds < 0
    ) AS negative_delay_events,
    ROUND(AVG(delay_seconds)::numeric, 2) AS avg_delay_seconds,
    ROUND(
        percentile_cont(0.50)
        WITHIN GROUP (ORDER BY delay_seconds)::numeric, 2
    ) AS p50_delay_seconds,
    ROUND(
        percentile_cont(0.95)
        WITHIN GROUP (ORDER BY delay_seconds)::numeric, 2
    ) AS p95_delay_seconds,
    ROUND(MAX(delay_seconds)::numeric, 2) AS max_delay_seconds
FROM recent;
"
```

通常の運転では1〜2秒程度です。遅れが大きいときは、まず2.1で読み残しがないかを確かめます（本編 第9部 第6章・第8章）。

## 2.4　サーバーの監視

**実行先：security-core（root）**

```bash
echo "=== VICTORIAMETRICS HEALTH ==="
curl -sS --max-time 5 -w '\nHTTP_STATUS=%{http_code}\n' \
  http://192.168.0.171:8428/health

echo
echo "=== PROMETHEUS METRICS QUERY ==="
curl -sS --max-time 10 -G \
  'http://192.168.0.171:8428/api/v1/query' \
  --data-urlencode 'query=up' \
  -w '\nHTTP_STATUS=%{http_code}\n'
```

```bash
VM='http://192.168.0.171:8428'

for QUERY in \
  'node_load1{job=~"pve-node|security-core|postgresql-node|prometheus-node|grafana-node"}' \
  'node_memory_MemAvailable_bytes{job=~"pve-node|security-core|postgresql-node|prometheus-node|grafana-node"}' \
  'node_filesystem_avail_bytes{job=~"pve-node|security-core|postgresql-node|prometheus-node|grafana-node",mountpoint="/"}'
do
  echo
  echo "=== $QUERY ==="
  curl -sS --max-time 10 -G "$VM/api/v1/query" \
    --data-urlencode "query=$QUERY"
  echo
done
```

5台分のデータが返ることを確かめます（本編 第9部 5.1）。画面では、Grafana（`http://192.168.0.199:3000`）の **Dashboards → Infrastructure → Integrated Infrastructure Overview** で、5台すべてが表示されていることを確認します（本編 第8部 第11章）。

Prometheus の収集の状態は、次で確かめます。

**実行先：lxc-prometheus（root）**

```bash
echo "=== PROMETHEUS JOBS ==="
curl -fsS 'http://127.0.0.1:9090/api/v1/targets?state=any' \
  | python3 -c '
import json, sys
data = json.load(sys.stdin)
print("API status:", data.get("status"))
for target in data.get("data", {}).get("activeTargets", []):
    print(
        "job:", target.get("labels", {}).get("job"),
        "health:", target.get("health"),
        "url:", target.get("scrapeUrl"),
        "error:", target.get("lastError")
    )
'

echo
echo "=== RECENT PROMETHEUS LOGS ==="
journalctl -u prometheus -n 30 --no-pager
```

すべてのジョブが `health: up` であることを確認します（本編 第8部 4.2）。

## 2.5　Wazuh

**実行先：security-core（root）**

```bash
echo "=== WAZUH SERVICES ==="
systemctl --no-pager --type=service --state=running \
  | grep -i wazuh || true

echo
echo "=== WAZUH RELATED LISTENING PORTS ==="
ss -lntp \
  | grep -E ':(55000|55001|1514|1515|514|9200|9100)\b' \
  || true

echo
echo "=== WAZUH MANAGER STATUS ==="
systemctl show wazuh-manager \
  -p ActiveState -p SubState -p MainPID -p ExecMainStatus

echo
echo "=== COLLECTOR STATUS ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts
```

```bash
echo "=== WAZUH MANAGER RECENT ERRORS ==="
journalctl -u wazuh-manager --since "30 minutes ago" \
  --no-pager -p err

echo
echo "=== WAZUH MANAGER RECENT WARNINGS ==="
journalctl -u wazuh-manager --since "30 minutes ago" \
  --no-pager -p warning | tail -30
```

直近のエラー・警告がないことを確かめます（本編 第9部 5.2・5.4）。

## 2.6　RelayとAI Defense Manager

**実行先：security-core（root）**

```bash
systemctl is-enabled ai-defense-relay.service; systemctl is-active ai-defense-relay.service; systemctl show ai-defense-relay.service -p After -p Wants -p Restart -p RestartSec -p User -p Group
```

**実行先：ai-defense-manager（root）**

```bash
systemctl is-enabled ai-defense-manager.service; systemctl is-active ai-defense-manager.service; systemctl show ai-defense-manager.service -p After -p Wants -p Restart -p RestartSec -p User -p Group
```

```bash
ss -lntp '( sport = :8000 )' && curl --fail --silent --show-error --max-time 5 http://127.0.0.1:8000/health
```

どちらも `enabled` で `active`、`/health` が `{"status":"ok",...}` を返せば正常です（本編 第17部）。Wazuh のアラートが取れるかは、次で確かめます（AI の分析はしません）。

**実行先：ai-defense-manager（root）**（`/opt/ai-defense-manager` で実行）

```bash
curl --fail --silent --show-error --max-time 20 \
  'http://127.0.0.1:8000/api/v1/wazuh/events?limit=5&since_minutes=60' \
  | ./venv/bin/python -c 'import json,sys; data=json.load(sys.stdin); print("EVENT_COUNT:",len(data)); [print({"severity":e["severity"],"rule_id":e["rule_id"],"agent_name":e["agent_name"],"event_category":e["event_category"],"event_summary":e["event_summary"]}) for e in data]; print("WAZUH_HTTP_API_OK")'
```

## 2.7　Indexerの監査ログ

**実行先：security-core（root）**

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/_plugins/_security/api/audit' | python3 -c 'import json,sys; d=json.load(sys.stdin); a=d["config"]["audit"]; print("AUDIT_ENABLED:",d["config"].get("enabled")); print("LOG_REQUEST_BODY:",a.get("log_request_body")); print("EXCLUDE_SENSITIVE_HEADERS:",a.get("exclude_sensitive_headers")); print("ENABLE_REST:",a.get("enable_rest")); print("ENABLE_TRANSPORT:",a.get("enable_transport")); print("DISABLED_REST_CATEGORIES:",a.get("disabled_rest_categories")); print("DISABLED_TRANSPORT_CATEGORIES:",a.get("disabled_transport_categories"))'
```

`AUDIT_ENABLED: True`、`LOG_REQUEST_BODY: False` であることを確かめます（本編 第26部）。監査ログのインデックスができているかは、次で確かめます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/_cat/indices?format=json&h=index,health,status,docs.count,store.size' | python3 -c 'import json,sys; d=json.load(sys.stdin); rows=[x for x in d if "audit" in x.get("index","").lower()]; print("AUDIT_INDEX_COUNT:",len(rows)); [print(x) for x in rows]'
```

ノードが1つのため、インデックスの状態は `yellow` になります（本編 第27部 1.3）。

# 第3章　サービスの起動と停止

## 3.1　Collectorの再起動

**実行先：security-core（root）**

```bash
systemctl restart wazuh-collector

echo "=== SERVICE STATUS ==="
systemctl show wazuh-collector \
  -p ActiveState \
  -p SubState \
  -p MainPID \
  -p NRestarts \
  -p ExecMainStatus

echo
echo "=== RECENT JOURNAL ==="
journalctl -u wazuh-collector -n 30 --no-pager
```

再起動の後は、2.1で、保存した位置から再開していることを確かめます。DBへの接続は、新しいアラートを読んだときに行われます（本編 第6部・第7部 1.4）。

> Collector を長く止めたままにしないでください。止まっている間に日付が変わり、読みかけの古いファイルが圧縮されると、起動を拒否するようになります（第4章 4.2）。

## 3.2　Prometheusの設定の再読み込み

`prometheus.yml` を変えたときは、再起動ではなく、SIGHUP で読み込み直します。

**実行先：lxc-prometheus（root）**

```bash
systemctl reload prometheus

echo "=== SERVICE STATUS ==="
systemctl is-active prometheus

echo
echo "=== PVE TARGET STATUS ==="
curl -fsS 'http://127.0.0.1:9090/api/v1/targets?state=active' \
  | python3 -c '
import json, sys
data = json.load(sys.stdin)
for target in data["data"]["activeTargets"]:
    if target["labels"].get("job") == "pve-node":
        print("health:", target["health"])
        print("scrapeUrl:", target["scrapeUrl"])
        print("lastError:", target["lastError"])
'
```

本編 第8部 4.2。

## 3.3　Grafanaの再起動

**実行先：lxc-grafana（root）**

```bash
echo "=== RESTART GRAFANA ==="
systemctl restart grafana-server

echo
echo "=== SERVICE STATUS ==="
systemctl is-active grafana-server

echo
echo "=== GRAFANA HEALTH ==="
curl -fsS http://127.0.0.1:3000/api/health \
  | python3 -m json.tool

echo
echo "=== DASHBOARD PROVISIONING LOGS ==="
journalctl -u grafana-server --since "3 minutes ago" --no-pager \
  | grep -Ei 'provision|dashboard|error|failed' \
  | tail -n 30
```

再起動の直後は3000番で待ち受けていないことがあります。少し待ってから、次で確かめます（本編 第8部 6.4）。

```bash
echo "=== GRAFANA HEALTH ==="
curl -fsS http://127.0.0.1:3000/api/health \
  | python3 -m json.tool

echo
echo "=== DASHBOARD PROVISIONING RESULT ==="
journalctl -u grafana-server --since "5 minutes ago" --no-pager \
  | grep -Ei 'pve|provisioning.dashboard|finished to provision|error' \
  | tail -n 30

echo
echo "=== DASHBOARD FILE ACCESS ==="
runuser -u grafana -- test -r \
  /var/lib/grafana/dashboards/pve-overview.json \
  && echo "SUCCESS"
```

## 3.4　AI Defense Manager（APIサーバー）

APIサーバーは systemd のサービス `ai-defense-manager` で、自動起動します（本編 第17部）。待ち受けは `127.0.0.1:8000` だけです。

**実行先：ai-defense-manager（root）**

コードを変えたときは、再起動して読み込み直します（API が少し止まります）。

```bash
systemctl restart ai-defense-manager.service && systemctl is-active ai-defense-manager.service
```

```bash
curl -sS -i http://127.0.0.1:8000/health
```

`active` と `{"status":"ok",...}` が返れば正常です。書き込めるのは `data` ディレクトリだけです（`ReadWritePaths`、本編 第18部 第4章）。

## 3.5　Relay

Relay は systemd のサービス `ai-defense-relay` で、自動起動します（本編 第14部・第17部）。

**実行先：security-core（root）**

```bash
ss -lntp '( sport = :8765 )' && echo && journalctl -u ai-defense-relay.service -n 20 --no-pager
```

`192.168.0.220:8765` で待ち受けていることを確かめます。TLS の確認は次のとおりです。

```bash
timeout 5 openssl s_client -connect 192.168.0.220:8765 -CAfile /etc/ai-defense-relay/ca.crt -verify_ip 192.168.0.220 -verify_return_error -brief </dev/null
```

## 3.6　VMの起動順

Proxmox を起動すると、VM 220（Wazuh・Relay）が先に起動し、120秒待ってから VM 230 が起動します。

**実行先：pve（root）**

```bash
for id in 220 230; do
  echo "===== VM $id ====="
  qm status "$id"
  qm config "$id" | grep -E '^(onboot|startup):'
done
```

本編 第17部 第5章。

# 第4章　障害のときの対応

## 4.1　Collectorが PermissionError で止まる

**原因**：日付が変わって Wazuh が新しい `alerts.json` を作ったとき、Collector の読み取りACLが付いていない（本編 第9部 第1章）。

**実行先：security-core（root）**

```bash
setfacl -m u:wazuh-collector:r-- \
  /var/ossec/logs/alerts/alerts.json

echo "=== UPDATED FILE ACL ==="
getfacl -p /var/ossec/logs/alerts/alerts.json

echo
echo "=== READ TEST ==="
runuser -u wazuh-collector -- \
  test -r /var/ossec/logs/alerts/alerts.json
echo "read_test_exit_code=$?"
```

`read_test_exit_code=0` になれば読めます。自動の再起動で戻るかを確かめます。

```bash
echo "=== WAIT FOR AUTO RECOVERY ==="
sleep 15

echo
echo "=== COLLECTOR SERVICE ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts -p ExecMainStatus

echo
echo "=== RECENT COLLECTOR LOGS ==="
journalctl -u wazuh-collector --since "2 minutes ago" --no-pager \
  | grep -Ei 'started|connection|inserted|duplicate|error|warning' \
  | tail -25
```

戻らないときは、4.2 を確認します。同じことは中編でも起きています（本編 第28部 2.2〜2.3）。

## 4.2　Collectorが起動を拒否する（古いファイルが圧縮された）

**原因**：Collectorが止まっている間に、読みかけの古いファイルが圧縮（`.json.gz`）され、保存したinodeのファイルがなくなった。Collector自体は圧縮ファイルを探しません（本編 第9部 第2章〜第4章）。

この場合は、取り込んでいない日の圧縮ファイルを、Collectorの既存の処理でDBに取り込み、読み取り位置を今の `alerts.json` に進めます。手順の全体と注意は本編 第9部 第2章〜第4章にあります。ここでは主なコマンドを示します（`target_offset`・日付・件数は自分の環境の値に置き換えます）。

**1. 保存した位置が、どの日のファイルの末尾に当たるかを調べる**（実行先：security-core（root））

```bash
python3 - <<'PY'
import gzip
import json
from pathlib import Path

base = Path("/var/ossec/logs/alerts/2026/Nov")
target_offset = 2774739

for day in ("17", "18", "19"):
    path = base / f"ossec-alerts-{day}.json.gz"
    if not path.exists():
        continue

    total = 0
    lines = 0
    first = None
    last = None
    before = None
    after = None
    boundary = None

    with gzip.open(path, "rb") as f:
        while True:
            start = total
            line = f.readline()
            if not line:
                break

            total += len(line)
            lines += 1

            try:
                obj = json.loads(line)
                ts = obj.get("timestamp")
            except Exception:
                ts = None

            if first is None:
                first = ts
            last = ts

            if start <= target_offset < total:
                boundary = (start, total)
                before = ts
            elif total <= target_offset:
                before = ts
            elif after is None and start >= target_offset:
                after = ts

    print(f"FILE={path.name}")
    print(f"  uncompressed_bytes={total}")
    print(f"  lines={lines}")
    print(f"  first_timestamp={first}")
    print(f"  last_timestamp={last}")
    print(f"  saved_offset={target_offset}")
    print(f"  offset_within_file={target_offset <= total}")
    print(f"  boundary_line_byte_range={boundary}")
    print(f"  timestamp_at_or_before_offset={before}")
    print(f"  timestamp_after_offset={after}")
PY
```

**2. 取り込んでいない日のファイルを Collector が読めるようにする**

```bash
echo "=== ARCHIVE READ ACCESS ==="
if runuser -u wazuh-collector -- test -r \
  /var/ossec/logs/alerts/2026/Nov/ossec-alerts-19.json.gz; then
  echo "archive_readable=YES"
else
  echo "archive_readable=NO"
fi

echo
echo "=== ARCHIVE METADATA ==="
stat -c 'owner=%U group=%G mode=%a size=%s inode=%i' \
  /var/ossec/logs/alerts/2026/Nov/ossec-alerts-19.json.gz
```

```bash
setfacl -m u:wazuh-collector:r-- \
  /var/ossec/logs/alerts/2026/Nov/ossec-alerts-19.json.gz

echo "=== VERIFY ACL ==="
getfacl -p \
  /var/ossec/logs/alerts/2026/Nov/ossec-alerts-19.json.gz

echo
echo "=== VERIFY COLLECTOR ACCESS ==="
if runuser -u wazuh-collector -- test -r \
  /var/ossec/logs/alerts/2026/Nov/ossec-alerts-19.json.gz; then
  echo "archive_readable=YES"
else
  echo "archive_readable=NO"
fi
```

**3. DBに書き込まずに検証する**

```bash
runuser -u wazuh-collector -- python3 - <<'PY'
import gzip
import json
import sys

sys.path.insert(0, "/usr/local/lib/wazuh-collector")
import collector

path = "/var/ossec/logs/alerts/2026/Nov/ossec-alerts-19.json.gz"

total = 0
json_errors = 0
extract_errors = 0
missing_event_id = 0
missing_timestamp = 0
valid_events = 0

with gzip.open(path, "rt", encoding="utf-8") as f:
    for line in f:
        total += 1
        try:
            raw = json.loads(line)
        except (json.JSONDecodeError, UnicodeDecodeError):
            json_errors += 1
            continue

        try:
            event = collector.extract_event(raw)
        except Exception:
            extract_errors += 1
            continue

        if not event:
            extract_errors += 1
            continue

        if not event.get("event_id"):
            missing_event_id += 1
        if not event.get("event_timestamp"):
            missing_timestamp += 1

        if event.get("event_id") and event.get("event_timestamp"):
            valid_events += 1

print(f"total_lines={total}")
print(f"json_errors={json_errors}")
print(f"extract_errors={extract_errors}")
print(f"missing_event_id={missing_event_id}")
print(f"missing_timestamp={missing_timestamp}")
print(f"valid_events={valid_events}")
print("archive_validation=" +
      ("OK" if total == 9039 and json_errors == 0
       and extract_errors == 0 and missing_event_id == 0
       and missing_timestamp == 0 and valid_events == total
       else "FAILED"))
PY
```

**4. 取り込んで、読み取り位置を進める**（日付が変わる直前には実行しない）

```bash
runuser -u wazuh-collector -- python3 - <<'PY'
import gzip
import logging
import os
import sys

sys.path.insert(0, "/usr/local/lib/wazuh-collector")
import collector

archive = "/var/ossec/logs/alerts/2026/Nov/ossec-alerts-19.json.gz"
expected_lines = 9039

# 処理前のファイル識別情報を保存
archive_inode_before = os.stat(archive).st_ino
current_inode_before = os.stat(collector.ALERT_FILE).st_ino

logging.disable(logging.CRITICAL)

processed = 0

try:
    with collector.psycopg.connect(**collector.DB_CONFIG) as conn:
        with gzip.open(archive, "rt", encoding="utf-8") as f:
            for line in f:
                collector.process_line(conn, line)
                processed += 1

    print(f"archive_lines_processed={processed}")

    if processed != expected_lines:
        raise RuntimeError("Unexpected archive line count; state not advanced")

    # 処理中にファイルがローテーションされていないことを確認
    archive_inode_after = os.stat(archive).st_ino
    current_inode_after = os.stat(collector.ALERT_FILE).st_ino

    if archive_inode_after != archive_inode_before:
        raise RuntimeError("Archive inode changed; state not advanced")

    if current_inode_after != current_inode_before:
        raise RuntimeError("Current alert inode changed; state not advanced")

    # 全件処理完了後に限り、現在のログの先頭から通常収集を開始
    collector.save_state(current_inode_after, 0)

    print("database_replay=COMPLETED")
    print("state_update=COMPLETED")
    print(f"current_alert_inode={current_inode_after}")
    print("recovery_result=SUCCESS")

except Exception as exc:
    print("recovery_result=FAILED")
    print("error_type=" + type(exc).__name__)
    print("state_update=NOT_CONFIRMED")
    raise
PY
```

**5. 復帰の確認**

```bash
sleep 15

python3 - <<'PY'
import json
import os

state_path = "/var/lib/wazuh-collector/state.json"
alert_path = "/var/ossec/logs/alerts/alerts.json"

with open(state_path) as f:
    state = json.load(f)

st = os.stat(alert_path)

print(f"state_inode={state['inode']}")
print(f"alert_inode={st.st_ino}")
print(f"state_offset={state['offset']}")
print(f"alert_size={st.st_size}")
print(f"inode_match={state['inode'] == st.st_ino}")
print(f"at_or_near_eof={state['offset'] <= st.st_size}")
print(f"remaining_bytes={max(0, st.st_size - state['offset'])}")
PY

echo
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts
```

本編 第9部 第2章〜第4章。

## 4.3　Wazuhのルール40704（サービスの異常終了）が多発する

**原因の例**：LXCで、Node Exporter と一緒に入る IPMI の収集のタイマーが、デバイスがないため1分ごとに失敗している（本編 第9部 第9章）。

**実行先：対象のLXC（root）**

```bash
systemctl disable --now prometheus-node-exporter-ipmitool-sensor.timer
```

```bash
echo "=== IPMI TIMER ==="
systemctl show prometheus-node-exporter-ipmitool-sensor.timer \
  -p LoadState -p ActiveState -p UnitFileState

echo
echo "=== NODE EXPORTER ==="
systemctl show prometheus-node-exporter.service \
  -p LoadState -p ActiveState -p SubState -p MainPID
```

本編 第9部 9.3〜9.5 で、失敗しているサービスを特定する手順を確認してから止めてください。

## 4.4　Wazuhのルール5138（SATAディスクの障害）が出る

**原因の例**：Proxmoxホストのディスクの故障（本編 第10部）。診断の手順は本編 第10部 第1章・第2章・第4章を見てください。故障と判断したバックアップ用の領域は、次のように書き込みを止めて切り離しました。

**実行先：pve（root）**

```bash
mount -o remount,ro /mnt/pve/backup && \
findmnt -T /mnt/pve/backup -o SOURCE,TARGET,FSTYPE,OPTIONS
```

```bash
umount /mnt/pve/backup
```

HDDを取り外した後、Proxmoxのストレージの定義を削除します。

```bash
pvesm remove backup
```

```bash
pvesm status
```

本編 第10部 第3章〜第5章。HDDの交換・新しいバックアップ先の用意の手順は、構築の会話にはありません（手順なし）。

## 4.5　AIの分析が時間切れになる

**確認**：Ollama を直接呼び、応答があるかを確かめます（本編 第12部 2.2）。

**実行先：ai-defense-manager（root）**

```bash
curl -sS --max-time 10 http://192.168.0.180:11434/api/tags
```

```bash
curl -sS --max-time 60 http://192.168.0.180:11434/api/chat -H 'Content-Type: application/json' -d '{"model":"qwen3:8b","stream":false,"think":false,"format":"json","messages":[{"role":"user","content":"Return exactly this JSON object: {\"status\":\"ok\"}"}],"options":{"num_predict":128},"keep_alive":"5m"}'
```

`{"status":"ok"}` が返らないときは、Ollama の側（VM 101）でモデルの読み込みの状態とログを確認します（本編 第12部 2.1）。Ollama を別の用途と共有している場合、モデルの読み込みが重なって遅くなることがあります。

## 4.6　AIの分析が 502 を返す

**原因の例**：AI が JSON の形は守っても、値がスキーマに合わない（構築時は `confidence` が 0〜1 ではなく `100` だった。本編 第20部 第1章）。

**実行先：ai-defense-manager（root）**

```bash
curl -sS --connect-timeout 5 --max-time 10 http://192.168.0.180:11434/api/tags
```

```bash
cd /opt/ai-defense-manager && ./venv/bin/python - <<'PY'
import httpx, json
from app.schemas.analysis_proposal import AIAnalysisProposal

payload = {
    "model": "qwen3:8b",
    "stream": False,
    "think": False,
    "format": AIAnalysisProposal.model_json_schema(),
    "messages": [{"role": "user", "content": "Return a valid JSON proposal. Use event ID 11111111-1111-4111-8111-111111111111. Choose no_action and provide all required fields."}]
}

try:
    r = httpx.post("http://192.168.0.180:11434/api/chat", json=payload, timeout=180)
    print("HTTP_STATUS:", r.status_code)
    print("RESPONSE:", r.text[:4000])
except Exception as e:
    print("ERROR:", type(e).__name__, str(e))
PY
```

Ollama に直接たずね、返った JSON の値がスキーマ（本編 第20部 1.3 の表）に合っているかを確かめます。AI への指示（`SYSTEM_PROMPT`）を直すときは、本編 第20部 第2章の手順で、バックアップと差分の確認をしてから行います。

## 4.7　Relayから取得できない（502）

**実行先：ai-defense-manager（root）**

```bash
openssl s_client -connect 192.168.0.220:8765 -CAfile /etc/ai-defense-manager/credentials/relay-ca.crt -verify_return_error -brief </dev/null
```

**実行先：security-core（root）**

```bash
ss -lntp '( sport = :8765 )' && echo && journalctl -u ai-defense-relay.service -n 20 --no-pager
```

TLS の検証が通り、Relay が待ち受けていれば、Relay の側から Indexer に届くかを確かめます（本編 第22部 3.2）。

```bash
python3 - <<'PY'
import base64, json, ssl, urllib.request, urllib.error

password = open(
    "/etc/credstore/ai-defense-indexer-password", "r"
).read().strip()

token = base64.b64encode(
    ("ai-defense-reader:" + password).encode()
).decode()

request = urllib.request.Request(
    "https://127.0.0.1:9200/_plugins/_security/authinfo",
    headers={"Authorization": "Basic " + token},
)

context = ssl.create_default_context(
    cafile="/etc/credstore/ai-defense-indexer-ca"
)

try:
    with urllib.request.urlopen(request, context=context, timeout=10) as response:
        data = json.loads(response.read())
        print("HTTP_STATUS:", response.status)
        for key in ("user_name", "backend_roles", "roles", "is_admin"):
            if key in data:
                print(f"{key}: {data[key]}")
except urllib.error.HTTPError as exc:
    print("HTTP_STATUS:", exc.code)
    print("AUTHENTICATION_OR_AUTHORIZATION_FAILED")
except Exception as exc:
    print("CHECK_ERROR:", type(exc).__name__)
PY
```

## 4.8　Collectorが前のファイルを探せずに止まる

**原因の例**：保存した inode のファイルを探す途中で、入れないディレクトリに当たった。または、前のファイルが圧縮されて見つからない（本編 第28部・第29部）。

**実行先：security-core（root）**

```bash
systemctl show wazuh-collector.service \
  -p User -p Group -p DynamicUser -p MainPID \
  -p ExecMainCode -p ExecMainStatus \
  -p NRestarts -p Result
```

```bash
journalctl -u wazuh-collector.service -n 35 --no-pager -o short-iso
```

`PermissionError` が隠しディレクトリ（名前が `.` で始まる）で出ているときは、第30部で直した Collector（隠しディレクトリを探さない）になっているかを確かめます。

```bash
runuser -u wazuh-collector -- python3 - <<'PY'
import ast
import os
from pathlib import Path

source_path = "/usr/local/lib/wazuh-collector/collector.py"
source = Path(source_path).read_text()
tree = ast.parse(source)

function = next(
    node for node in tree.body
    if isinstance(node, ast.FunctionDef)
    and node.name == "find_inode_file"
)

namespace = {
    "os": os,
    "Path": Path,
    "ALERT_DIR": Path("/var/ossec/logs/alerts"),
}

exec(compile(ast.Module(body=[function], type_ignores=[]), source_path, "exec"), namespace)

result = namespace["find_inode_file"](9223372036854775807)

print("RESULT:", result)
print("TEST: PASS" if result is None else "TEST: UNEXPECTED MATCH")
PY
```

`TEST: PASS` なら直っています。前のファイルが見つからないときは、保存した読み取り位置が前のファイルの最後と一致するかを、大きさ・行・チェックサムで確かめてから、読み取り位置を書き換えます。手順は本編 第29部 第1章〜第2章にあります（4.2 の方法とは別の方法です）。

# 第5章　設定を変えるときの注意

| 対象 | 注意 | 本編 |
|---|---|---|
| Collector の本体 | 反映の前にハッシュとバックアップを取り、テスト用のコピーで確かめてから、一度に置き換える。ファイルを置き換えても、再起動するまで動いているプロセスは古いコードのまま | 第5部・第7部 |
| Prometheus のジョブ | バックアップを取ってから追加し、`promtool check config` で確かめて、`systemctl reload prometheus` で読み込み直す | 第8部 |
| Node Exporter | 入れるときは一時的にマスクし、待ち受けを自分の `vmbr0` 側のアドレスに限ってから起動する。マスクの解除は `--runtime` を付ける | 第8部 |
| Grafana のダッシュボード | `/var/lib/grafana/dashboards` にJSONを置けば自動で読み込まれる。所有者を `grafana` にする | 第8部 |
| Indexer のロール・ユーザー | `securityadmin.sh -f` はその種類の設定を丸ごと置き換える。必ず今の設定（バックアップ）に追加分を足したファイルを反映し、反映後にバックアップと比べて欠けがないかを確かめる | 第13部 |
| AI Defense Manager | アプリのファイルは `root:ai-defense`・`640`。実行ユーザーは書き込めないため、構文の確認は `__pycache__` を作らない方法で行う。変える前にバックアップを取り、`diff -u` で差分を確かめてから再起動する | 第11部・第12部・第19部・第20部 |
| LLM に送る内容 | 送る項目は6つだけ（`event_id`・`observed_at`・`severity`・`rule_id`・`event_category`・`event_summary`）。要約は `event_sanitizer.py` で伏せ字にする。項目を足すときは、モックのテストで送信の内容を確かめる | 第19部・第20部 |
| Indexer の YAML | 動いている Indexer の設定と、ディスクの上の `internal_users.yml`・`roles.yml` は一致していない。ディスクの YAML をそのまま `securityadmin.sh` で適用し直すと `ai-defense-reader` が消え、Relay が止まる | 第22部 |
| Indexer の監査の設定 | 動いている設定は `.opendistro_security` の文書 `audit` にある。`opensearch.yml` を書き換えても反映されない。監査の API の PATCH で、変える項目だけを変える（`PUT` は全体を置き換えるので使わない） | 第26部 |
| Collector の探索 | `find_inode_file()` は隠しディレクトリを探さない（第30部で変更）。本物のアラートの置き場を隠しディレクトリにしない | 第30部 |
| VM 230 の SSH | パスワードの認証と root のログインは禁止（`/etc/ssh/sshd_config.d/00-local-hardening.conf`）。SSH の設定を変えるときは、root のコンソールを開いたまま、`sshd -t`・`sshd -T` で確かめてから reload する | 第21部 |

# 第6章　残っている課題とリスク

| 区分 | 内容 | 本編 |
|---|---|---|
| リスク・未対応 | 新しい `alerts.json` に Collector の読み取りACLを付ける恒久的な対策がない（毎日の停止の可能性） | 第9部 |
| 一部対応 | `alerts` の中に root 専用の隠しディレクトリ `.acl-inheritance-test.bkv8vd` が残っている。Collector は探さないように直した（ディレクトリは残したまま） | 第9部・第30部 |
| リスク・未対応 | Collector は圧縮ファイル（`.json.gz`）を探さない。止まっている間に圧縮されると、4.2 の手順が必要 | 第7部・第9部 |
| リスク・未対応 | security-core にOSのファイアウォールがない（ufw・nftables・firewalld すべて無効） | 第13部 |
| 未対応 | `app/api/analysis.py` の所有者・権限をほかのファイルにそろえていない | 第12部 |
| 未対応 | Proxmox のバックアップの保存先は本書の範囲外で別に用意する | 第10部 |
| 未対応 | TrueNAS（VM 100）の扱いは別途検討（RAID_A は切り離したまま） | 第10部 |
| 未対応 | security-core の `/root` に、Indexer 用のハッシュ・記録・定義のファイルが残っている | 第13部 |
| 未対応 | Relay の relay.py には、手順の記録がない変更（ログの形・同時処理の上限8）が入っている | 第14部・第22部 |
| 未対応 | 保存済みの分析の履歴（第20部より前の分）は伏せ字にしていない（点検では該当なし） | 第20部 |
| 対応済み | Indexer の監査ログを `internal_opensearch` に保存し、リクエストの本文を記録しないようにした | 第25部〜第27部 |
| 未対応 | Collector の `safe_text()` は形を整えるだけで、`rule.description` などに入った秘密の情報を除く処理ではない | 第28部 |
| 未対応 | Wazuh のログの切り替えの方式（`copytruncate` かどうか）の確認は途中 | 第30部 |
| 未対応 | `ai-defense-reader` に標準のロール `own_index` が付いている（同じ名前のインデックスはない） | 第23部 |
| 対応済み | VM 230 の SSH を公開鍵の認証に切り替え、パスワードの認証と root のログインを禁止した | 第21部 |
| 対応済み | AI Defense Manager の API を systemd のサービスにした | 第17部 |
