---
title: "AI自律型サイバー防御システム 構築マニュアル 中編"
subtitle: "第26部　監査ログでリクエストの本文を記録しない"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」中編の第26部です。第25部で `opensearch.yml` に `plugins.security.audit.config.log_request_body: false` を書いて Indexer を再起動しましたが、監査の API は `log_request_body: true` を返したままでした。ここでは、その理由をコードで突き止め、**監査の API（PATCH）で `log_request_body` だけを `false` にします**。

わかった理由は次のとおりです。

- 監査の設定は、Indexer の内部のインデックス `.opendistro_security` の中の文書 `audit` にも保存されている（動的な設定）
- 起動のとき、この文書が**あれば**それを使い、**なければ**`opensearch.yml` から設定を作る
- この環境では文書 `audit` があるため、`opensearch.yml` の `log_request_body: false` は使われない

## 本書の表記

- コマンドやプログラムは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 実行先は **security-core VM 220（root）** です。
- 管理者の証明書（`admin.pem`・`admin-key.pem`）で Indexer に接続します。`admin` ユーザーのパスワードは使いません。
- `javap` の出力は長いので、結果の要点だけを書きます。

# 第1章　設定はどこから読まれるか

## 1.1　ノードの設定とファイル

```bash
python3 - <<'PY'
import json
import ssl
import urllib.request

ctx = ssl.create_default_context(cafile="/etc/wazuh-indexer/certs/root-ca.pem")
ctx.load_cert_chain(
    certfile="/etc/wazuh-indexer/certs/admin.pem",
    keyfile="/etc/wazuh-indexer/certs/admin-key.pem"
)

url = "https://127.0.0.1:9200/_nodes/settings?flat_settings=true"
req = urllib.request.Request(url)

with urllib.request.urlopen(req, context=ctx, timeout=15) as res:
    data = json.load(res)

for node_id, node in data.get("nodes", {}).items():
    settings = node.get("settings", {})
    print("NODE:", node.get("name", node_id))
    for key in sorted(settings):
        if "audit" in key.lower():
            value = settings[key]
            if any(x in key.lower() for x in ("password", "token", "secret", "credential")):
                value = "[REDACTED]"
            print(f"{key} = {value}")
PY
```

ノードの設定の API には、監査の設定は1つも出てきませんでした（出てこないことだけでは、読み込まれていないとは言えません）。

```bash
grep -nE '^[[:space:]]*plugins\.security\.audit\.(type|config\.log_request_body):' /etc/wazuh-indexer/opensearch.yml && stat -c '%U:%G %a %s' /etc/wazuh-indexer/opensearch.yml
```

ファイルには2行があり、持ち主と権限も変わっていません。

## 1.2　AuditConfigの作られ方

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p 'org.opensearch.security.auditlog.config.AuditConfig'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c 'org.opensearch.security.auditlog.config.AuditConfig' | sed -n '/public static org.opensearch.security.auditlog.config.AuditConfig from(/,/public static java.util.Set/p'
```

`AuditConfig.from(Settings)` は、ノードの設定（`opensearch.yml`）から監査の設定を作ります。

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c 'org.opensearch.security.auditlog.impl.AuditLogImpl' | sed -n '/setConfig(/,/enableRoutes(/p'
```

`setConfig()` は受け取った設定をそのまま使います。`AuditLogImpl` が値を `true` に戻しているわけではありません。

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/lib/*:/usr/share/wazuh-indexer/plugins/opensearch-security/*' -p -c org.opensearch.security.OpenSearchSecurityPlugin | grep -n -B 8 -A 12 'AuditLogImpl.setConfig\|setConfig:(Lorg/opensearch/security/auditlog/config/AuditConfig'
```

`OpenSearchSecurityPlugin` から直接は呼ばれていません。設定を扱うクラスを探します。

```bash
/usr/share/wazuh-indexer/jdk/bin/jar tf /usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar | grep -Ei 'Audit|ConfigurationRepository|DynamicConfig|ConfigUpdate'
```

動的な設定を読み込むのは `ConfigurationRepository`、監査の API は `AuditApiAction` です。

## 1.3　ConfigurationRepository

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c org.opensearch.security.configuration.ConfigurationRepository | grep -n -B 8 -A 12 -Ei 'AuditConfig|auditLog|auditLogImpl|setConfig|onChange'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c org.opensearch.security.configuration.ConfigurationRepository | sed -n '/private void setupAuditConfigurationIfAny/,/private boolean createSecurityIndexIfAbsent/p'
```

`setupAuditConfigurationIfAny()` は、`.opendistro_security` に監査の設定の文書があるかで分かれます。

| 文書 | 動き |
|---|---|
| ある | `AuditConfig.from(settings)` を呼ばない（文書の設定を使う） |
| ない | `opensearch.yml` から設定を作って使う |

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c org.opensearch.security.configuration.ConfigurationLoaderSecurity7 | sed -n '/isAuditConfigDocPresentInIndex/,/^[[:space:]]*public/p'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c 'org.opensearch.security.configuration.ConfigurationLoaderSecurity7$2' | grep -n -B 10 -A 18 -Ei 'audit|isAuditConfigDocPresentInIndex|set\(|toConfig|AUDIT'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c 'org.opensearch.security.configuration.ConfigurationLoaderSecurity7$1' | grep -n -B 8 -A 16 -Ei 'audit|isAuditConfigDocPresentInIndex|success|CType|set\('
```

文書 `audit` が読めれば `isAuditConfigDocPresentInIndex = true`、なければ `false` にして、`opensearch.yml` から初期の設定を作ります。

```bash
journalctl -u wazuh-indexer --since "2026-11-21 08:20:00" --no-pager | grep -Ei 'Hot-reloading of audit configuration|Audit configuration settings found|Using configuration with defaults from opensearch settings'
```

ログには、どちらの経路を通ったかの記録はありませんでした。

# 第2章　文書があるかを確かめる

## 2.1　管理者の証明書

`admin` ユーザーのパスワードは使わず（わからなくてもリセットはしません）、管理者の証明書で接続します。

```bash
find /etc/wazuh-indexer -maxdepth 3 -type f \( -iname '*admin*.pem' -o -iname '*root-ca*.pem' -o -iname '*admin*.crt' -o -iname '*admin*.key' \) -printf '%p\n'
```

```bash
openssl x509 -in /etc/wazuh-indexer/certs/admin.pem -noout -subject -issuer -dates -ext extendedKeyUsage
```

構築時は CN が `admin`、有効期間は 2026年11月17日〜2036年11月14日でした。

## 2.2　文書 audit

文書の中身は取らず、あるかどうかだけを確かめます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/.opendistro_security/_doc/audit?filter_path=_index,_id,found'
```

構築時の結果は次のとおりで、文書はありました。

```text
_index: .opendistro_security
_id: audit
found: true
```

これで、`opensearch.yml` の変更が反映されなかった理由がわかりました。なお、この文書の `audit` は JSON ではなく、内部の形式の文字列（940文字）で保存されていたため、ここからは値を取り出していません。値は監査の API で確かめます。

## 2.3　監査のAPIでの値

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/_plugins/_security/api/audit' | python3 -c 'import json,sys; d=json.load(sys.stdin); print("log_request_body =",d["config"]["audit"].get("log_request_body","<not found>"))'
```

`log_request_body = True` でした。API の応答では、設定は `config` の下の `audit` の直下にあります。

```text
config
 ├─ compliance
 ├─ enabled
 └─ audit
```

# 第3章　監査のAPIで変える

## 3.1　変え方を確かめる

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c org.opensearch.security.dlic.rest.api.AuditApiAction
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c 'org.opensearch.security.dlic.rest.api.AuditApiAction$2'
```

- 監査の API は `PUT /_plugins/_security/api/audit/config` と `PATCH /_plugins/_security/api/audit` を受け付ける
- 変更は、監査の設定の再読み込み（ホットリロード）が有効なときだけできる（文書があるので有効）

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c org.opensearch.security.dlic.rest.api.AuditApiAction | grep -A100 -B10 'processPatchRequest\|lambda\$auditApiRequestHandlers\$2'
```

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c org.opensearch.security.dlic.rest.api.AbstractApiAction | grep -A100 -B10 -E 'processPatchRequest|processPutRequest|processChangeRequest'
```

| 方法 | 動き |
|---|---|
| `PUT` | 設定の全体を置き換える（今回は使わない） |
| `PATCH` | 今の設定を読み、JSON Patch（`add`・`replace`・`remove`）を当てる。変わった項目だけを検証する |

```bash
/usr/share/wazuh-indexer/jdk/bin/javap -classpath '/usr/share/wazuh-indexer/plugins/opensearch-security/opensearch-security-2.19.6.0.jar:/usr/share/wazuh-indexer/lib/*' -p -c 'org.opensearch.security.dlic.rest.api.AuditApiAction$AuditRequestContentValidator'
```

変更した後の設定の全体も検証されます。REST と Transport の記録しないカテゴリーなど、ほかの設定は今のまま残す必要があります。

## 3.2　今の設定

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/_plugins/_security/api/audit' | python3 -c 'import json,sys; d=json.load(sys.stdin); a=d["config"]["audit"]; print("log_request_body:",a.get("log_request_body")); print("exclude_sensitive_headers:",a.get("exclude_sensitive_headers")); print("enable_rest:",a.get("enable_rest")); print("enable_transport:",a.get("enable_transport")); print("disabled_rest_categories:",a.get("disabled_rest_categories")); print("disabled_transport_categories:",a.get("disabled_transport_categories")); print("ignore_users_count:",len(a.get("ignore_users",[]))); print("ignore_requests_count:",len(a.get("ignore_requests",[]))); print("ignore_headers_count:",len(a.get("ignore_headers",[]))); print("ignore_url_params_count:",len(a.get("ignore_url_params",[])))'
```

| 項目 | 今の値 |
|---|---|
| `log_request_body` | `true` |
| `exclude_sensitive_headers` | `true` |
| `enable_rest`・`enable_transport` | `true` |
| 記録しないカテゴリー（REST・Transport） | `AUTHENTICATED`・`GRANTED_PRIVILEGES` |
| `ignore_users` | 1件 |

JSON Patch の場所（JSON Pointer）と、読み取り専用の項目を確かめます。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/_plugins/_security/api/audit' | python3 -c 'import json,sys; d=json.load(sys.stdin); c=d.get("config",{}); print("config_keys:",list(c)); print("audit_is_object:",isinstance(c.get("audit"),dict)); print("audit_pointer_value:",c.get("audit",{}).get("log_request_body")); print("readonly_paths:",d.get("_readonly"))'
```

`readonly_paths: []`（読み取り専用の項目はない）でした。変える場所は `/config/audit/log_request_body` です。

## 3.3　PATCH

`log_request_body` だけを `false` にします。ほかの監査の設定には触れません。Indexer の再起動は要りません。

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem -X PATCH 'https://127.0.0.1:9200/_plugins/_security/api/audit' -H 'Content-Type: application/json' -d '[{"op":"replace","path":"/config/audit/log_request_body","value":false}]' -w '\nHTTP_STATUS:%{http_code}\n'
```

構築時は `Resource updated.` と `HTTP_STATUS:200` が返りました。

## 3.4　反映の確認

```bash
curl -sS --cacert /etc/wazuh-indexer/certs/root-ca.pem --cert /etc/wazuh-indexer/certs/admin.pem --key /etc/wazuh-indexer/certs/admin-key.pem 'https://127.0.0.1:9200/_plugins/_security/api/audit' | python3 -c 'import json,sys; d=json.load(sys.stdin); a=d["config"]["audit"]; print("AUDIT_ENABLED:",d["config"].get("enabled")); print("LOG_REQUEST_BODY:",a.get("log_request_body")); print("EXCLUDE_SENSITIVE_HEADERS:",a.get("exclude_sensitive_headers")); print("ENABLE_REST:",a.get("enable_rest")); print("ENABLE_TRANSPORT:",a.get("enable_transport")); print("DISABLED_REST_CATEGORIES:",a.get("disabled_rest_categories")); print("DISABLED_TRANSPORT_CATEGORIES:",a.get("disabled_transport_categories"))'
```

| 項目 | 結果 |
|---|---|
| 監査の全体 | 有効 |
| `LOG_REQUEST_BODY` | `False` |
| `EXCLUDE_SENSITIVE_HEADERS` | `True` |
| REST・Transport の監査 | 有効 |
| 記録しないカテゴリー | 変わらず |

これは監査ログに本文を記録しない設定です。ほかのアプリのログなどに本文が出ないことまでは保証しません。

# おわりに

第26部で、監査の設定がどこから読まれるかを突き止め、監査の API の PATCH で `log_request_body` を `false` にしました（再起動なし）。

| 設定の場所 | 役割 |
|---|---|
| `opensearch.yml` | 出力先（`plugins.security.audit.type`）。監査の文書がないときの初期の値 |
| `.opendistro_security` の文書 `audit` | 動いている監査の設定。監査の API（PATCH）で変える |

次の部では、監査ログが実際に保存されているか、本文が記録されていないかを確かめます。
