---
title: "AI自律型サイバー防御システム 構築マニュアル 前編"
subtitle: "第6部　データ整合性の検証と運用監査"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」前編の第6部です。第5部で本番に反映した強化版のCollectorについて、重複が起きないこと、Wazuhのアラートが1件も欠けずにDBに入っていることを、件数だけでなくイベントIDの単位まで確かめます。さらに、実際の日付の切り替わり（ローテーション）をまたいだ運用を監査します。

## 本書の表記

- コマンドやファイル内容は、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 各手順の冒頭に「実行先」を示します。DBの確認は、LXC 109の中でDB管理者（`postgres`）で行います（プロンプトは `root@postgresql`）。
- 「実行結果（例）」は構築時の実際の出力です。イベントID・件数・時刻・inodeなどは、お使いの環境では異なります。
- 認証情報や状態ファイルの中身は表示しません。

## 第5部終了時点の状態

| 項目 | 状態 |
|---|---|
| Collector | 強化版（`/usr/local/lib/wazuh-collector/collector.py`、18,898バイト） |
| サービス | `wazuh-collector.service`（active、自動起動） |
| 照合 | 同じ期間のWazuhのアラートとDBの件数が一致（230件） |

# 第1章　重複防止の保証

## 1.1　イベントIDの実装

**実行先：security-core VM 220（root）**

```bash
echo "=== EVENT ID IMPLEMENTATION ==="

grep -n -B 8 -A 18 \
  -E 'event_id|UniqueViolation|23505|ON CONFLICT' \
  /usr/local/lib/wazuh-collector/collector.py
```

| 項目 | 実装 |
|---|---|
| `event_id` | Wazuhのアラートの `id`（最大128文字） |
| 重複の検出 | DBの一意制約違反（SQLSTATE `23505`） |
| 重複の扱い | 読み飛ばしてログに記録 |
| `ON CONFLICT` | 使わない（INSERTだけの権限を保つため） |

## 1.2　DB側の制約

**実行先：LXC 109 postgresql（root）**

```bash
sudo -u postgres psql -X -d security_workbench -c "
SELECT
    c.conname AS constraint_name,
    c.contype AS constraint_type,
    pg_get_constraintdef(c.oid) AS definition
FROM pg_constraint c
WHERE c.conrelid = 'incident.alert_events'::regclass

UNION ALL

SELECT
    i.indexname,
    'INDEX',
    i.indexdef
FROM pg_indexes i
WHERE i.schemaname = 'incident'
  AND i.tablename = 'alert_events'
ORDER BY 1;
"
```

| 制約・インデックス | 目的 |
|---|---|
| `PRIMARY KEY (event_id)` | 重複の防止 |
| `mitre` のCHECK | JSONのオブジェクトであることを保証 |
| `rule_level` のCHECK | 0〜16に制限 |
| `srcport` のCHECK | ポート番号の範囲に制限 |
| 時刻・レベル・ルール・送信元IPのインデックス | 検索の高速化 |

現在のデータに重複がないことを確認します。

```bash
sudo -u postgres psql -X -d security_workbench -c "
SELECT
    COUNT(*) AS total_rows,
    COUNT(DISTINCT event_id) AS unique_event_ids,
    COUNT(*) - COUNT(DISTINCT event_id) AS duplicate_count
FROM incident.alert_events;
"
```

```text
 total_rows | unique_event_ids | duplicate_count 
------------+------------------+-----------------
        547 |              547 |               0
(1 row)
```

## 1.3　Collectorのロールの権限

**実行先：LXC 109 postgresql（root）**

```bash
sudo -u postgres psql -X -d security_workbench -c "
SELECT
    rolname,
    rolsuper,
    rolcreatedb,
    rolcreaterole
FROM pg_roles
WHERE rolname = 'wazuh_collector';
"
```

`wazuh_collector` がスーパーユーザー・DB作成・ロール作成の権限を持たないことを確認します。次の試験に使う、一時テーブルの作成権限も確認します。

```bash
sudo -u postgres psql -X -d security_workbench -c "
SELECT
    has_database_privilege(
        'wazuh_collector',
        current_database(),
        'TEMP'
    ) AS can_create_temp_table,
    has_database_privilege(
        'wazuh_collector',
        current_database(),
        'CONNECT'
    ) AS can_connect;
"
```

## 1.4　一時テーブルでの重複登録の試験

本番のテーブルには触れず、一時テーブルに `wazuh_collector` の権限で同じIDを2回登録し、2回目が拒否されることを確認します。最後にトランザクション全体をロールバックします。

一時テーブルのスキーマ名は接続ごとに変わるため、`pg_my_temp_schema()` から名前を取り出して `\gexec` で権限を与えます（`pg_temp` という別名には `GRANT` できません）。

**実行先：LXC 109 postgresql（root）**

```bash
sudo -u postgres psql -X -v ON_ERROR_STOP=1 -P pager=off -d security_workbench <<'SQL'
BEGIN;

CREATE TEMP TABLE collector_duplicate_test (
    event_id text PRIMARY KEY
);

SELECT format(
    'GRANT USAGE ON SCHEMA %I TO wazuh_collector',
    nspname
)
FROM pg_namespace
WHERE oid = pg_my_temp_schema()
\gexec

GRANT INSERT ON collector_duplicate_test TO wazuh_collector;

SET ROLE wazuh_collector;

DO $$
BEGIN
    INSERT INTO collector_duplicate_test (event_id)
    VALUES ('duplicate-test-325');

    BEGIN
        INSERT INTO collector_duplicate_test (event_id)
        VALUES ('duplicate-test-325');

        RAISE EXCEPTION 'FAIL: duplicate was accepted';

    EXCEPTION
        WHEN unique_violation THEN
            RAISE NOTICE 'PASS: duplicate rejected with unique_violation';
    END;
END;
$$;

RESET ROLE;

SELECT
    COUNT(*) AS inserted_rows,
    COUNT(DISTINCT event_id) AS unique_event_ids
FROM collector_duplicate_test;

ROLLBACK;
SQL
```

`PASS: duplicate rejected with unique_violation` に続いて、`inserted_rows` と `unique_event_ids` がどちらも `1` になれば成功です。

## 1.5　Collector側の重複処理の試験

同じアラートを `process_line()` で2回処理し、2回目の `UniqueViolation` が外に漏れずに処理されることを、モックの接続で確認します。テスト用ファイルはrootしか読めないため、rootで実行します。

**実行先：security-core VM 220（root）**

```bash
grep -n -A100 -B20 'def process_line' \
  /tmp/wazuh-collector-hardening-test.py
```

```bash
python3 - <<'PY'
import importlib.util
from unittest.mock import patch
import psycopg
import json

path = "/tmp/wazuh-collector-hardening-test.py"
spec = importlib.util.spec_from_file_location("collector_test", path)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

class FakeTransaction:
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        return False

class FakeConnection:
    def __init__(self):
        self.calls = 0
        self.transactions = 0

    def transaction(self):
        self.transactions += 1
        return FakeTransaction()

    def execute(self, sql, event):
        self.calls += 1
        assert sql == m.INSERT_SQL

        if self.calls == 1:
            return

        raise psycopg.errors.UniqueViolation(
            "duplicate key value violates unique constraint"
        )

connection = FakeConnection()
line = json.dumps({"id": "duplicate-test-325"}).encode()

with patch.object(
    m,
    "extract_event",
    return_value={"event_id": "duplicate-test-325"},
):
    m.process_line(connection, line)
    m.process_line(connection, line)

assert connection.calls == 2
assert connection.transactions == 2

print("PASS: first INSERT accepted by mock")
print("PASS: second INSERT raised UniqueViolation")
print("PASS: duplicate handled without propagation")
print("PASS: transactions =", connection.transactions)
print("PASS: execute calls =", connection.calls)
print("PASS: no production DB connection")
PY
```

> `/tmp/wazuh-collector-hardening-test.py` はrootだけが読めるファイル（権限600）です。一般ユーザーで実行すると `PermissionError` になります。

# 第2章　WazuhとDBのイベント単位の照合

件数が合っていても、別のイベントが入れ替わっている可能性はゼロではありません。ここでは、読み取りだけで、イベントIDの集合まで照合します。サービスの再起動や設定の変更はしません。

## 2.1　Collectorの稼働状態と読み取り位置

**実行先：security-core VM 220（root）**

```bash
echo "=== SERVICE STATUS ==="
systemctl show wazuh-collector \
  -p ActiveState \
  -p SubState \
  -p MainPID \
  -p NRestarts \
  -p ExecMainStatus

echo
echo "=== RECENT JOURNAL ==="
journalctl -u wazuh-collector -n 30 --no-pager

echo
echo "=== STATE FILE METADATA ==="
stat -c '%n | %U:%G | %a | %s bytes | modified=%y' \
  /var/lib/wazuh-collector/state.json
```

> `NRestarts` は、第5部で起動に失敗していたときの再起動の回数を含む累計の値です。

```bash
python3 - <<'PY'
import json
import os

state_path = "/var/lib/wazuh-collector/state.json"
alert_path = "/var/ossec/logs/alerts/alerts.json"

with open(state_path, "r") as f:
    state = json.load(f)

st = os.stat(alert_path)

saved_inode = state.get("inode")
saved_offset = state.get("offset")

print("=== COLLECTOR STATE ===")
print("saved_inode:", saved_inode)
print("saved_offset:", saved_offset)

print("\n=== CURRENT ALERT FILE ===")
print("current_inode:", st.st_ino)
print("current_size:", st.st_size)

print("\n=== COMPARISON ===")
if saved_inode == st.st_ino:
    unread = st.st_size - saved_offset
    print("inode_match: PASS")
    print("unread_bytes:", unread)
    print("offset_within_file:", 0 <= saved_offset <= st.st_size)
else:
    print("inode_match: FAIL")
    print("Rotation or file replacement requires investigation.")
PY
```

## 2.2　DB側の基本の整合性

**実行先：LXC 109 postgresql（root）**

```bash
sudo -u postgres psql -X -P pager=off -d security_workbench -c "
SELECT
    COUNT(*) AS total_rows,
    COUNT(DISTINCT event_id) AS unique_event_ids,
    COUNT(*) - COUNT(DISTINCT event_id) AS duplicate_count,
    MAX(event_timestamp) AS latest_event_timestamp,
    MAX(ingested_at) AS latest_ingested_at,
    COUNT(*) FILTER (
        WHERE ingested_at >= NOW() - INTERVAL '5 minutes'
    ) AS ingested_last_5m,
    NOW() AS database_time
FROM incident.alert_events;
"
```

## 2.3　最新のアラートの取り込みの確認

`alerts.json` の末尾のアラートを5件表示し、そのIDがDBにあるかを個別に確かめます。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import json
from collections import deque

path = "/var/ossec/logs/alerts/alerts.json"
last = deque(maxlen=5)

with open(path, "rb") as f:
    for line in f:
        try:
            obj = json.loads(line)
            last.append({
                "id": obj.get("id"),
                "timestamp": obj.get("timestamp"),
                "rule_id": obj.get("rule", {}).get("id"),
                "rule_level": obj.get("rule", {}).get("level"),
                "agent_id": obj.get("agent", {}).get("id"),
            })
        except (json.JSONDecodeError, UnicodeDecodeError):
            continue

print("=== LAST 5 ALERT METADATA ===")
for item in last:
    print(json.dumps(item, ensure_ascii=False))
PY

echo
echo "=== COLLECTOR LOG SINCE SUCCESSFUL START ==="
journalctl -u wazuh-collector \
  --since "2026-11-18 15:31:53 UTC" \
  --no-pager \
  | tail -n 40
```

**実行先：LXC 109 postgresql（root）**

```bash
sudo -u postgres psql -X -P pager=off -d security_workbench -c "
SELECT
    event_id,
    event_timestamp,
    ingested_at,
    rule_id,
    agent_id
FROM incident.alert_events
WHERE event_id IN (
    '1795033806.3121490',
    '1795033806.3122882',
    '1795033806.3123268'
)
ORDER BY event_timestamp, event_id;
"
```

`IN` の中のIDは、前のコマンドで表示された自分の環境のIDに置き換えます。構築時は3件とも登録されていて、アラートの発生からDBへの取り込みまでの遅れは約1秒以内でした。

## 2.4　照合する範囲の確定

第5部で修正版を起動したときの読み取り位置（構築時は `2178712`）から後を、照合の範囲にします。範囲の件数・時刻・最初と最後のIDを出します。

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import json

path = "/var/ossec/logs/alerts/alerts.json"
start_offset = 2178712

timestamps = []
event_ids = []

with open(path, "rb") as f:
    f.seek(start_offset)

    for line in f:
        try:
            alert = json.loads(line)
        except (json.JSONDecodeError, UnicodeDecodeError):
            continue

        ts = alert.get("timestamp")
        event_id = alert.get("id")

        if isinstance(ts, str):
            timestamps.append(ts)
        if isinstance(event_id, str):
            event_ids.append(event_id)

print("scope_count:", len(event_ids))
print("earliest_timestamp:", min(timestamps) if timestamps else None)
print("latest_timestamp:", max(timestamps) if timestamps else None)
print("first_event_id:", event_ids[0] if event_ids else None)
print("last_event_id:", event_ids[-1] if event_ids else None)
PY
```

`start_offset` は、自分の環境の値に置き換えます。構築時は413件で、最古が `2026-11-18T15:15:10.963+0000`、最新が `2026-11-18T20:31:14.188+0000` でした。同じ時刻の範囲でDBを数えます。

**実行先：LXC 109 postgresql（root）**

```bash
sudo -u postgres psql -X -P pager=off -d security_workbench -c "
SELECT
    COUNT(*) AS db_rows,
    COUNT(DISTINCT event_id) AS unique_event_ids,
    MIN(event_timestamp) AS earliest_event,
    MAX(event_timestamp) AS latest_event,
    MIN(ingested_at) AS first_ingested,
    MAX(ingested_at) AS last_ingested
FROM incident.alert_events
WHERE event_timestamp >= TIMESTAMPTZ '2026-11-18 15:15:10.963+00'
  AND event_timestamp <= TIMESTAMPTZ '2026-11-18 20:31:14.188+00';
"
```

| 照合項目 | alerts.json | PostgreSQL |
|---|---:|---:|
| 件数 | 413 | 413 |
| 一意なevent_id | 413 | 413 |
| 最古のイベント | 15:15:10.963 | 15:15:10.963 |
| 最新のイベント | 20:31:14.188 | 20:31:14.188 |

# 第3章　イベントIDの集合の完全一致

## 3.1　照合の考え方

件数が同じでも、IDの中身が同じとは限りません。範囲の中のイベントIDを並べ替えて改行でつなぎ、SHA-256を計算して、両側で一致するかを確かめます。一致すれば、413件のIDが1件ずつ同じであることが分かります。

> ハッシュを計算している間にも新しいアラートが増えます。DBと同じ **時刻の範囲** に絞って計算しないと、件数がずれて比較できません。

## 3.2　alerts.json側のハッシュ

**実行先：security-core VM 220（root）**

```bash
python3 - <<'PY'
import json
import hashlib

path = "/var/ossec/logs/alerts/alerts.json"
start_offset = 2178712

start = "2026-11-18T15:15:10.963+0000"
end   = "2026-11-18T20:31:14.188+0000"

ids = []

with open(path, "rb") as f:
    f.seek(start_offset)

    for line in f:
        try:
            alert = json.loads(line)
        except (json.JSONDecodeError, UnicodeDecodeError):
            continue

        ts = alert.get("timestamp")
        event_id = alert.get("id")

        if (
            isinstance(ts, str)
            and start <= ts <= end
            and isinstance(event_id, str)
            and event_id
        ):
            ids.append(event_id)

payload = "\n".join(sorted(ids)).encode("utf-8")

print("source_count:", len(ids))
print("source_unique_ids:", len(set(ids)))
print("source_sha256:", hashlib.sha256(payload).hexdigest())
PY
```

`start_offset`・`start`・`end` は、第2章2.4で確定した自分の環境の値に置き換えます。

## 3.3　DB側のハッシュ

同じ範囲のIDを、同じ並べ方・同じつなぎ方でハッシュにします。

**実行先：LXC 109 postgresql（root）**

```bash
sudo -u postgres psql -X -qAt -d security_workbench -c "
SELECT event_id
FROM incident.alert_events
WHERE event_timestamp >= TIMESTAMPTZ '2026-11-18 15:15:10.963+00'
  AND event_timestamp <= TIMESTAMPTZ '2026-11-18 20:31:14.188+00'
ORDER BY event_id;
" | python3 -c '
import sys, hashlib
ids = sys.stdin.read().splitlines()
payload = "\n".join(ids).encode("utf-8")
print("db_count:", len(ids))
print("db_unique_ids:", len(set(ids)))
print("db_sha256:", hashlib.sha256(payload).hexdigest())
'
```

構築時の結果：

| 項目 | alerts.json | PostgreSQL |
|---|---:|---:|
| 件数 | 413 | 413 |
| 一意なID | 413 | 413 |
| SHA-256 | `a819b04e...34137d6` | `a819b04e...34137d6` |

```text
a819b04e5a912e29592a164da3a12e24aa3ca4d27e57a3aa124d0830b34137d6
```

ハッシュが一致したので、対象の413件はIDの単位で欠落も重複もなく、すべてDBに入っています。

# 第4章　実際のローテーションの構造

第5部では一時ディレクトリの疑似ログでローテーションを試験しました。ここでは、実際のWazuhのファイル構造を確かめて、Collectorの前提と合っているかを調べます。本番のCollectorは止めず、ログの削除・移動・変更もしません。

## 4.1　現在の状態

**実行先：security-core VM 220（root）**

```bash
echo "=== COLLECTOR STATE ==="
python3 - <<'PY'
import json
p = "/var/lib/wazuh-collector/state.json"
with open(p) as f:
    s = json.load(f)
print("saved_inode:", s.get("inode"))
print("saved_offset:", s.get("offset"))
PY

echo
echo "=== ALERT LOG FILES ==="
find /var/ossec/logs/alerts -maxdepth 1 -type f \
  -printf '%f | inode=%i | size=%s | mtime=%TY-%Tm-%Td %TH:%TM:%TS\n' \
  | sort

echo
echo "=== CURRENT ALERTS.JSON ==="
stat -c 'inode=%i size=%s bytes mtime=%y' \
  /var/ossec/logs/alerts/alerts.json
```

保存されているinodeと読み取り位置が、現在の `alerts.json` のinodeとサイズに一致していれば、末尾まで処理できています。

## 4.2　アラートのディレクトリの構造

**実行先：security-core VM 220（root）**

```bash
echo "=== ALERT DIRECTORY TREE ==="
find /var/ossec/logs/alerts -maxdepth 5 \
  -printf '%y | inode=%i | size=%s | %p\n' \
  | sort

echo
echo "=== WAZUH ROTATION MESSAGES ==="
grep -iE 'rotat|alerts\.json|alerts\.log' \
  /var/ossec/logs/ossec.log 2>/dev/null \
  | tail -50
```

構築時の結果：

```text
=== ALERT DIRECTORY TREE ===
d | inode=5398349 | size=4096 | /var/ossec/logs/alerts
d | inode=5398502 | size=4096 | /var/ossec/logs/alerts/2026
d | inode=5398503 | size=4096 | /var/ossec/logs/alerts/2026/Nov
f | inode=5398501 | size=3132720 | /var/ossec/logs/alerts/2026/Nov/ossec-alerts-18.log
f | inode=5398501 | size=3132720 | /var/ossec/logs/alerts/alerts.log
f | inode=5398822 | size=499 | /var/ossec/logs/alerts/2026/Nov/ossec-alerts-17.json.sum
f | inode=5399257 | size=496 | /var/ossec/logs/alerts/2026/Nov/ossec-alerts-17.log.sum
f | inode=5408976 | size=196775 | /var/ossec/logs/alerts/2026/Nov/ossec-alerts-17.log.gz
f | inode=5408977 | size=158174 | /var/ossec/logs/alerts/2026/Nov/ossec-alerts-17.json.gz
f | inode=5409146 | size=2603330 | /var/ossec/logs/alerts/2026/Nov/ossec-alerts-18.json
f | inode=5409146 | size=2603330 | /var/ossec/logs/alerts/alerts.json

=== WAZUH ROTATION MESSAGES ===
2026/11/18 00:00:10 wazuh-monitord: INFO: Starting new log after rotation.
root@security-core:~#
```

| 組 | 関係 |
|---|---|
| `alerts.json` と `2026/Nov/ossec-alerts-18.json` | 同じinode（当日のJSON） |
| `alerts.log` と `2026/Nov/ossec-alerts-18.log` | 同じinode（当日のテキスト形式。Collectorは使わない） |
| `ossec-alerts-17.json.gz` | 前日のJSONを圧縮したもの（`.sum` は署名） |

日付が変わると、`alerts.json` は新しいファイルになり、前日分は `年/月` の下に残ったあと、圧縮されます。

## 4.3　Collectorから見えるか

現在の `find_inode_file()` と、日付ごとのディレクトリの権限を確認します。

**実行先：security-core VM 220（root）**

```bash
echo "=== COLLECTOR INODE SEARCH FUNCTION ==="
grep -n -A45 -B5 'def find_inode_file' \
  /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== CURRENT JSON FILE LINK COUNT ==="
stat -c '%n | inode=%i | links=%h | owner=%U:%G | mode=%a' \
  /var/ossec/logs/alerts/alerts.json \
  /var/ossec/logs/alerts/2026/Nov/ossec-alerts-18.json

echo
echo "=== ARCHIVE DIRECTORY PERMISSIONS ==="
namei -l /var/ossec/logs/alerts/2026/Nov/ossec-alerts-18.json

echo
echo "=== ARCHIVE ACL ==="
getfacl -p \
  /var/ossec/logs/alerts/2026 \
  /var/ossec/logs/alerts/2026/Nov \
  /var/ossec/logs/alerts/2026/Nov/ossec-alerts-18.json
```

```bash
echo "=== COLLECTOR DIRECTORY ACCESS ==="
for path in \
  /var/ossec/logs/alerts \
  /var/ossec/logs/alerts/2026 \
  /var/ossec/logs/alerts/2026/Nov
do
    if sudo -u wazuh-collector test -x "$path"; then
        echo "SEARCH OK: $path"
    else
        echo "SEARCH DENIED: $path"
    fi
done

echo
echo "=== COLLECTOR FILE READ ACCESS ==="
for path in \
  /var/ossec/logs/alerts/alerts.json \
  /var/ossec/logs/alerts/2026/Nov/ossec-alerts-18.json
do
    if sudo -u wazuh-collector test -r "$path"; then
        echo "READ OK: $path"
    else
        echo "READ DENIED: $path"
    fi
done
```

| 対象 | Collectorから |
|---|---|
| `alerts/` | 通過できる |
| `alerts/2026/`・`alerts/2026/Nov/` | 通過できない |
| `alerts.json` | 読める |
| `2026/Nov/ossec-alerts-18.json` | 読めない（同じファイルでも、途中のディレクトリを通過できないため） |

**問題点：**

1. `find_inode_file()` は `alerts` の直下しか探さない。旧ファイルは `年/月` の下にある。
2. Collectorには `年/月` のディレクトリを通過する権限がない。
3. `alerts` のデフォルトACL（第3部7.3）は、すでにあった `2026`・`Nov` には反映されていない。

このままでは、Collectorを止めている間に日付が変わると、第5部9.3の fail-closed により起動できません。

## 4.4　圧縮されたアーカイブと読み取り位置

**実行先：security-core VM 220（root）**

```bash
echo "=== ROTATED JSON ARCHIVES ==="
find /var/ossec/logs/alerts -type f \
  -name 'ossec-alerts-*.json*' \
  -printf '%i | %s bytes | %u:%g | %m | %p\n' \
  | sort

echo
echo "=== GZIP ARCHIVE VALIDATION ==="
for f in /var/ossec/logs/alerts/*/*/*.json.gz; do
    [ -f "$f" ] || continue
    if gzip -t "$f"; then
        echo "GZIP OK: $f"
    else
        echo "GZIP ERROR: $f"
    fi
done

echo
echo "=== COLLECTOR STATE METADATA ==="
stat -c '%n | owner=%U:%G | mode=%a | size=%s | modify=%y' \
  /var/lib/wazuh-collector/state.json
```

```bash
echo "=== COLLECTOR STATE (SAFE FIELDS ONLY) ==="
sudo -u wazuh-collector python3 - <<'PY'
import json

path = "/var/lib/wazuh-collector/state.json"

with open(path, "r", encoding="utf-8") as f:
    state = json.load(f)

print("saved_inode =", state.get("inode"))
print("saved_offset =", state.get("offset"))
PY

echo
echo "=== CURRENT AND ARCHIVED INODES ==="
stat -c 'inode=%i | size=%s | %n' \
  /var/ossec/logs/alerts/alerts.json \
  /var/ossec/logs/alerts/2026/Nov/ossec-alerts-18.json \
  /var/ossec/logs/alerts/2026/Nov/ossec-alerts-17.json.gz
```

圧縮されたファイルは、圧縮の時点で新しいinodeになります。そのため、圧縮の後では旧inodeから元のファイルを探すことはできません。圧縮されていないJSONだけを探索の対象とし、見つからない場合は fail-closed で止まる、という設計を保ちます。

# 第5章　日付ごとのディレクトリの再帰探索

## 5.1　テスト用コピーの作成

本番のコードからテスト用のコピーを作ります。本番のCollectorは止めません。

**実行先：security-core VM 220（root）**

```bash
set -e

PROD=/usr/local/lib/wazuh-collector/collector.py
TEST=/tmp/wazuh-collector-rotation-test.py

echo "=== VERIFY PRODUCTION HASH ==="
sha256sum "$PROD"

echo
echo "=== CREATE ISOLATED TEST COPY ==="
install -o root -g root -m 755 "$PROD" "$TEST"

cmp "$PROD" "$TEST"

echo
echo "=== VERIFY TEST COPY ==="
sha256sum "$PROD" "$TEST"
stat -c '%n | %U:%G | %a | %s bytes' "$TEST"

echo
echo "=== IMPORTS AND PATH CONSTANTS ==="
sed -n '1,100p' "$TEST"

echo
echo "=== INODE SEARCH FUNCTION ==="
sed -n '300,395p' "$TEST"
```

## 5.2　再帰的に探す関数

`find_inode_file()` を、サブディレクトリまで探すように置き換えます。

- 対象は、圧縮されていない `.json` の通常のファイルだけ（`.json.gz` は除外）。
- 探索中に権限エラーなどが起きた場合は、「見つからなかった」として扱わず、例外を呼び出し元に伝える（第5部9.3の fail-closed と合わせて、読み残しを黙って捨てないため）。

**実行先：security-core VM 220（root）**

```bash
set -e

TEST=/tmp/wazuh-collector-rotation-test.py

python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-rotation-test.py")
source = path.read_text()

start = source.index("def find_inode_file(inode):")
end = source.index("\n\ndef open_initial_file(state):", start)

replacement = '''def find_inode_file(inode):
    """
    Recursively locate a previous uncompressed JSON alert file.

    Directory traversal errors are propagated. Returning None is allowed
    only after the entire accessible alert tree has been searched.
    Compressed archives are deliberately excluded.
    """
    pending = [ALERT_DIR]

    while pending:
        directory = pending.pop()

        with os.scandir(directory) as entries:
            for entry in entries:
                if entry.is_dir(follow_symlinks=False):
                    pending.append(Path(entry.path))
                    continue

                if not entry.is_file(follow_symlinks=False):
                    continue

                if not entry.name.endswith(".json"):
                    continue

                if entry.inode() == inode:
                    return Path(entry.path)

    return None
'''

updated = source[:start] + replacement + source[end:]
path.write_text(updated)
PY

echo "=== SYNTAX VALIDATION ==="
/usr/bin/python3 -m py_compile "$TEST"

echo
echo "=== CANDIDATE FUNCTION ==="
sed -n '310,375p' "$TEST"

echo
echo "=== PRODUCTION HASH (MUST REMAIN UNCHANGED) ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== TEST COPY HASH ==="
sha256sum "$TEST"
```

## 5.3　単体テスト

一時ディレクトリに `2026/Nov` の構造を作り、3つの動作を確かめます。

**実行先：security-core VM 220（root）**

```bash
/usr/bin/python3 - <<'PY'
import importlib.util
import tempfile
import gzip
import os
from pathlib import Path

candidate = "/tmp/wazuh-collector-rotation-test.py"

spec = importlib.util.spec_from_file_location(
    "collector_rotation_test", candidate
)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

with tempfile.TemporaryDirectory() as tmp:
    root = Path(tmp)
    nested = root / "2026" / "Nov"
    nested.mkdir(parents=True)

    old_json = nested / "ossec-alerts-18.json"
    old_json.write_text('{"id":"test-001"}\n')

    archive = nested / "ossec-alerts-17.json.gz"
    with gzip.open(archive, "wt") as f:
        f.write('{"id":"test-archive"}\n')

    module.ALERT_DIR = root

    # TEST 1: recursive discovery
    found = module.find_inode_file(old_json.stat().st_ino)
    assert found == old_json, f"Unexpected path: {found}"
    print("PASS: recursive JSON inode discovery")

    # TEST 2: compressed archive exclusion
    found_archive = module.find_inode_file(archive.stat().st_ino)
    assert found_archive is None, f"Archive unexpectedly found: {found_archive}"
    print("PASS: compressed archive excluded")

    # TEST 3: permission/traversal errors fail closed
    original_scandir = module.os.scandir

    def blocked_scandir(path):
        if Path(path) == root / "2026":
            raise PermissionError("simulated permission denial")
        return original_scandir(path)

    module.os.scandir = blocked_scandir
    try:
        try:
            module.find_inode_file(old_json.stat().st_ino)
        except PermissionError:
            print("PASS: traversal error propagated (fail closed)")
        else:
            raise AssertionError("Traversal error was silently ignored")
    finally:
        module.os.scandir = original_scandir

print("PASS: all recursive inode search tests")
PY
```

## 5.4　権限がない実際の環境での確認

ACLを変える前の実際のディレクトリに対して、Collectorのユーザーで探索させると、エラーが安全に伝わる（黙って `None` を返さない）ことを確認します。

**実行先：security-core VM 220（root）**

```bash
sudo -u wazuh-collector /usr/bin/python3 - <<'PY'
import importlib.util

path = "/tmp/wazuh-collector-rotation-test.py"

spec = importlib.util.spec_from_file_location(
    "collector_rotation_test",
    path,
)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

try:
    result = module.find_inode_file(-1)
except PermissionError:
    print("PASS: real directory traversal denied safely")
except OSError as error:
    print("PASS: filesystem error propagated:", type(error).__name__)
else:
    raise AssertionError(
        f"Expected traversal denial, got result={result!r}"
    )
PY

echo
echo "=== PRODUCTION SERVICE STATUS ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts
```

構築時は `PASS: real directory traversal denied safely` と表示され、本番のCollectorは同じPIDのまま、再起動回数も増えていませんでした。

# 第6章　日付ごとのディレクトリへの最小限のACL

## 6.1　現在のACL

再帰探索には、ディレクトリの中身を一覧する読み取り（`r`）と通過（`x`）の両方が必要です。ファイル自体の読み取り権限は、第3部7.3のデフォルトACLですでに付いています。変更の前に確認します。

**実行先：security-core VM 220（root）**

```bash
echo "=== ALERT DIRECTORY ACL ==="
getfacl -p \
  /var/ossec/logs/alerts \
  /var/ossec/logs/alerts/2026 \
  /var/ossec/logs/alerts/2026/Nov

echo
echo "=== CURRENT JSON FILE ACL ==="
getfacl -p \
  /var/ossec/logs/alerts/alerts.json \
  /var/ossec/logs/alerts/2026/Nov/ossec-alerts-18.json

echo
echo "=== PRODUCTION HASH ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py
```

## 6.2　ACLの追加

`wazuh-collector` に、既存の年・月のディレクトリへ `r-x` を追加します。ほかのユーザーやグループの権限は変えません。ACLを変えるコマンドは、rootで実行します（一般ユーザーでは失敗します）。

**実行先：security-core VM 220（root）**

```bash
setfacl -m u:wazuh-collector:r-x \
  /var/ossec/logs/alerts/2026

setfacl -m u:wazuh-collector:r-x \
  /var/ossec/logs/alerts/2026/Nov

echo "=== UPDATED ACL ==="
getfacl -p \
  /var/ossec/logs/alerts/2026 \
  /var/ossec/logs/alerts/2026/Nov

echo
echo "=== COLLECTOR ACCESS TEST ==="
sudo -u wazuh-collector test -r \
  /var/ossec/logs/alerts/2026 &&
  echo "PASS: year directory readable"

sudo -u wazuh-collector test -x \
  /var/ossec/logs/alerts/2026 &&
  echo "PASS: year directory searchable"

sudo -u wazuh-collector test -r \
  /var/ossec/logs/alerts/2026/Nov &&
  echo "PASS: month directory readable"

sudo -u wazuh-collector test -r \
  /var/ossec/logs/alerts/2026/Nov/ossec-alerts-18.json &&
  echo "PASS: archived JSON readable"
```

最上位の `alerts` も、これまでの `--x`（通過だけ）では `os.scandir()` で一覧できないため、`r-x` にします。

```bash
setfacl -m u:wazuh-collector:r-x \
  /var/ossec/logs/alerts

echo "=== UPDATED ACL ==="
getfacl -p /var/ossec/logs/alerts

echo
echo "=== ACCESS TEST ==="
sudo -u wazuh-collector test -r /var/ossec/logs/alerts &&
  echo "PASS: alerts directory readable"

sudo -u wazuh-collector test -x /var/ossec/logs/alerts &&
  echo "PASS: alerts directory searchable"
```

| 対象 | Collectorの権限（変更後） |
|---|---|
| `alerts` | `r-x` |
| `alerts/2026` | `r-x` |
| `alerts/2026/Nov` | `r-x` |
| JSONファイル | `r--`（変更なし） |

> 第5部では、一覧の権限がないことを前提に、起動時に現在のファイルを優先して開くよう直しました。その処理はそのまま残るので、今回の権限は、ローテーション後に旧ファイルを探すときにだけ使われます。

## 6.3　Collectorのユーザーでの再帰探索

**実行先：security-core VM 220（root）**

```bash
sudo -u wazuh-collector /usr/bin/python3 - <<'PY'
import importlib.util
from pathlib import Path

spec = importlib.util.spec_from_file_location(
    "collector_rotation_test",
    "/tmp/wazuh-collector-rotation-test.py",
)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

current = Path("/var/ossec/logs/alerts/alerts.json")
dated = Path("/var/ossec/logs/alerts/2026/Nov/ossec-alerts-18.json")
archive = Path("/var/ossec/logs/alerts/2026/Nov/ossec-alerts-17.json.gz")

for target in (current, dated):
    found = module.find_inode_file(target.stat().st_ino)
    assert found is not None, f"Not found: {target}"
    assert found.stat().st_ino == target.stat().st_ino
    print(f"PASS: discovered inode {target.stat().st_ino}")

if archive.exists():
    found = module.find_inode_file(archive.stat().st_ino)
    assert found is None, f"Compressed archive unexpectedly found: {found}"
    print("PASS: compressed archive excluded")

print("PASS: production-user recursive discovery")
PY
```

## 6.4　将来の年・月のディレクトリへの継承

これから作られる `2027/Jan` のようなディレクトリにも、デフォルトACLで同じ権限が付くかを、`alerts` の中の一時ディレクトリで確かめます。一時ディレクトリは `mktemp -d` で権限700で作られるため、テストの最上位にもCollectorの `r-x` を付けてから試します。終了時に一時ディレクトリは自動で削除されます。

**実行先：security-core VM 220（root）**

```bash
set -e

TEST_DIR=$(mktemp -d /var/ossec/logs/alerts/.acl-inheritance-test.XXXXXX)
trap 'rm -rf "$TEST_DIR"' EXIT

setfacl -m u:wazuh-collector:r-x "$TEST_DIR"

mkdir -p "$TEST_DIR/2027/Jan"
touch "$TEST_DIR/2027/Jan/test.json"

echo "=== COLLECTOR ACCESS TEST ==="

sudo -u wazuh-collector test -r "$TEST_DIR" &&
  echo "PASS: test root readable"

sudo -u wazuh-collector test -x "$TEST_DIR" &&
  echo "PASS: test root searchable"

sudo -u wazuh-collector test -r "$TEST_DIR/2027" &&
  echo "PASS: future year directory readable"

sudo -u wazuh-collector test -r "$TEST_DIR/2027/Jan" &&
  echo "PASS: future month directory readable"

sudo -u wazuh-collector test -r "$TEST_DIR/2027/Jan/test.json" &&
  echo "PASS: future JSON file readable"

sudo -u wazuh-collector test -x "$TEST_DIR/2027/Jan" &&
  echo "PASS: future month directory searchable"

echo "PASS: all ACL inheritance access tests"
```

> このコマンドは `set -e` と `trap` を使うため、対話シェルで実行すると、終了時にシェルも閉じることがあります。その場合はログインし直してください。

# 第7章　再帰探索版の本番反映

## 7.1　差分と呼び出し元の確認

**実行先：security-core VM 220（root）**

```bash
echo "=== PRODUCTION SHA256 ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== TEST CANDIDATE SHA256 ==="
sha256sum /tmp/wazuh-collector-rotation-test.py

echo
echo "=== CODE DIFF ==="
diff -u \
  /usr/local/lib/wazuh-collector/collector.py \
  /tmp/wazuh-collector-rotation-test.py

echo
echo "=== PRODUCTION SERVICE ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts
```

差分は `find_inode_file()` の1関数だけです。

| 項目 | 本番 | 候補 |
|---|---|---|
| 探索の範囲 | `alerts` の直下だけ | サブディレクトリまで再帰的に |
| 対象 | 通常のファイル | `.json` の通常のファイル（`.json.gz` は除外） |
| 探索のエラー | 警告を出して `None` | 例外を呼び出し元に伝える |

```bash
echo "=== open_initial_file ==="
grep -n -A55 -B5 '^def open_initial_file' \
  /tmp/wazuh-collector-rotation-test.py

echo
echo "=== find_inode_file CALL SITES ==="
grep -n -B8 -A12 'find_inode_file(' \
  /tmp/wazuh-collector-rotation-test.py

echo
echo "=== ROTATION SWITCH LOGIC ==="
grep -n -B12 -A35 'ALERT_FILE.stat' \
  /tmp/wazuh-collector-rotation-test.py

echo
echo "=== SERVICE STATUS ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts
```

呼び出し元の `open_initial_file()` は、旧ファイルを見つけたら `fstat()` でinodeを確かめ直してから読み、見つからなければ `RuntimeError` で止まります。通常のローテーションの切り替え（第5部）には影響しません。

> **残る制約：** 旧ファイルがすでに圧縮されている（`.json.gz` になっている）と、元のinodeは見つかりません。その場合は fail-closed で起動を拒否します。

## 7.2　本番のコードの置き換え

候補のハッシュ・構文・サービスの稼働を確かめ、現在の本番（`7a816056...`）を保全してから、一度に置き換えます。サービスはまだ再起動しないので、動いているプロセスは古いコードのままです。

**実行先：security-core VM 220（root）**

```bash
set -euo pipefail

PROD="/usr/local/lib/wazuh-collector/collector.py"
CANDIDATE="/tmp/wazuh-collector-rotation-test.py"
BACKUP="/usr/local/lib/wazuh-collector/collector.py.backup-before-recursive-rotation-20261119"
EXPECTED="ac2974775d46b902ee69b3e7219bf9cb550c7d8a65c38cbdf8ac89ecc67a5e96"

echo "=== PRECHECK ==="

test -f "$PROD"
test -f "$CANDIDATE"
test ! -e "$BACKUP"

ACTUAL=$(sha256sum "$CANDIDATE" | awk '{print $1}')
test "$ACTUAL" = "$EXPECTED"

systemctl is-active --quiet wazuh-collector

/usr/bin/python3 -m py_compile "$CANDIDATE"

echo "PASS: candidate hash and syntax verified"
echo "PASS: production service is active"

echo
echo "=== BACKUP CURRENT PRODUCTION ==="

cp -a "$PROD" "$BACKUP"

cmp -s "$PROD" "$BACKUP"
echo "PASS: production backup verified"

echo
echo "=== PREPARE ATOMIC REPLACEMENT ==="

TEMP="${PROD}.new.$$"

install -o root -g root -m 755 "$CANDIDATE" "$TEMP"

test "$(sha256sum "$TEMP" | awk '{print $1}')" = "$EXPECTED"

echo
echo "=== ATOMIC REPLACEMENT ==="

mv -f "$TEMP" "$PROD"

echo
echo "=== VERIFY DEPLOYMENT ==="

sha256sum "$PROD" "$BACKUP"

stat -c '%n | %U:%G | %a | %s bytes' "$PROD" "$BACKUP"

test "$(sha256sum "$PROD" | awk '{print $1}')" = "$EXPECTED"
test "$(sha256sum "$BACKUP" | awk '{print $1}')" = \
  "7a81605628ccefa5284d6a32559d8431108e61fe3213fb74ae0479ec051d4244"

echo "PASS: atomic deployment completed"

echo
echo "=== SERVICE STILL RUNNING ==="

systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts
```

`EXPECTED` は、5.2で表示された自分の環境の候補のハッシュに置き換えます。最後の `test` の `7a816056...` も、置き換える前の自分の本番のハッシュに置き換えます。

## 7.3　再起動と確認

**実行先：security-core VM 220（root）**

```bash
systemctl restart wazuh-collector

echo "=== SERVICE STATUS ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts -p ExecMainStatus

echo
echo "=== RECENT SERVICE LOG ==="
journalctl -u wazuh-collector -n 20 --no-pager
```

```bash
echo "=== LOGS SINCE NEW START ==="
journalctl -u wazuh-collector \
  --since "2026-11-18 20:54:31" \
  --no-pager

echo
echo "=== PROCESS STATUS ==="
ps -p 90884 -o pid,ppid,stat,etime,%cpu,%mem,cmd

echo
echo "=== COLLECTOR STATE ==="
/usr/bin/python3 - <<'PY'
import json
from pathlib import Path

p = Path("/var/lib/wazuh-collector/state.json")
s = json.loads(p.read_text())
print("saved_inode =", s.get("inode"))
print("saved_offset =", s.get("offset"))
PY

echo
echo "=== CURRENT ALERT FILE ==="
stat -c 'inode=%i size=%s' /var/ossec/logs/alerts/alerts.json

echo
echo "=== PRODUCTION HASH ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py
```

`--since` の時刻と `ps -p` のPIDは、自分の環境の値に置き換えます。構築時は新しいPID `90884`、再起動回数0で動き、保存されたinodeと位置が現在の `alerts.json` と一致していました。

```bash
echo "=== RECENT COLLECTOR LOG ==="
journalctl -u wazuh-collector -n 40 --no-pager

echo
echo "=== SERVICE STATUS ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts -p ExecMainStatus

echo
echo "=== STATE FILE METADATA ==="
stat -c '%U:%G %a %s bytes %y' \
  /var/lib/wazuh-collector/state.json
```

> 起動の直後は、ログに `PostgreSQL connection established` が出ないことがあります。第4部第4章の読み取りループでは、DBへの接続は「新しい正常なアラートの行を読んだとき」に初めて行うためです（次の章で確認します）。

```bash
echo "=== COLLECTOR RUN / DB CONNECTION FLOW ==="
nl -ba /usr/local/lib/wazuh-collector/collector.py \
  | sed -n '450,545p;640,700p'
```

# 第8章　再起動後の取り込みの監査

## 8.1　DBへの接続のタイミング

`run()` では、DBへの接続は次の条件のときに初めて行われます。

```python
if status == "line":
    if connection is None or connection.closed:
        connection = psycopg.connect(**DB_CONFIG)
```

つまり、起動して読み取り位置から再開したあと、新しいアラートの行を読んだときに接続します。新しいアラートが来るまでは、接続のログは出ません。しばらく待ってから確認します。この確認は、状態ファイルを読むためrootで行います（一般ユーザーでは `PermissionError` になります。これは意図した制限です）。

**実行先：security-core VM 220（root）**

```bash
echo "=== COLLECTOR STATUS ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts -p ExecMainStatus

echo
echo "=== STATE ==="
python3 - <<'PY'
import json
from pathlib import Path

s = json.loads(
    Path("/var/lib/wazuh-collector/state.json").read_text()
)
print("inode =", s.get("inode"))
print("offset =", s.get("offset"))
PY

echo
echo "=== ALERT FILE ==="
stat -c 'inode=%i size=%s' /var/ossec/logs/alerts/alerts.json

echo
echo "=== RECENT APPLICATION LOGS ==="
journalctl -u wazuh-collector -n 12 --no-pager
```

構築時は、再起動から約2分後に次のログが出ていました。

```text
Nov 18 20:56:25 security-core python3[90884]: 2026-11-18 20:56:25,729 INFO PostgreSQL connection established
```

## 8.2　取り込みの継続

**実行先：LXC 109 postgresql（root）**

> `postgres` ユーザーはLXC 109にしかありません。security-coreで実行すると `unknown user postgres` になります。

```bash
sudo -u postgres psql -X -d security_workbench -c "
SELECT
    COUNT(*) AS total_events,
    COUNT(*) FILTER (
        WHERE ingested_at >= NOW() - INTERVAL '1 hour'
    ) AS ingested_last_1h,
    COUNT(*) FILTER (
        WHERE ingested_at >= NOW() - INTERVAL '24 hours'
    ) AS ingested_last_24h,
    MAX(event_timestamp) AS latest_event_timestamp,
    MAX(ingested_at) AS latest_ingested_at,
    NOW() AS database_time
FROM incident.alert_events;
"
```

## 8.3　重複と必須項目

```bash
sudo -u postgres psql -X -d security_workbench -c "
SELECT
    COUNT(*) AS total_events,
    COUNT(event_id) AS nonnull_event_ids,
    COUNT(DISTINCT event_id) AS unique_event_ids,
    COUNT(*) - COUNT(DISTINCT event_id) AS duplicate_excess,
    COUNT(*) FILTER (WHERE event_id IS NULL) AS null_event_ids,
    COUNT(*) FILTER (WHERE ingested_at IS NULL) AS null_ingested_at,
    COUNT(*) FILTER (WHERE rule_id IS NULL) AS null_rule_ids,
    COUNT(*) FILTER (WHERE agent_id IS NULL) AS null_agent_ids,
    COUNT(*) FILTER (WHERE rule_level IS NULL) AS null_rule_levels
FROM incident.alert_events;
"
```

構築時は687件で、重複も、イベントID・取り込み時刻・ルールID・エージェントID・レベルの欠落も0件でした。

## 8.4　5分ごとの取り込み件数

```bash
sudo -u postgres psql -X -d security_workbench -c "
SELECT
    date_bin(
        INTERVAL '5 minutes',
        ingested_at,
        TIMESTAMPTZ '2000-01-01 00:00:00+00'
    ) AS interval_start,
    COUNT(*) AS event_count,
    MIN(ingested_at) AS first_ingested,
    MAX(ingested_at) AS last_ingested
FROM incident.alert_events
WHERE ingested_at >= NOW() - INTERVAL '1 hour'
GROUP BY 1
ORDER BY 1;
"
```

取り込みが途切れた時間帯がないかを確認します。

## 8.5　読み取りの追従と再起動後の件数

**実行先：security-core VM 220（root）**

```bash
echo "=== WAZUH ALERT FILE ==="
stat -c 'inode=%i size=%s modified=%y' \
  /var/ossec/logs/alerts/alerts.json

echo
echo "=== COLLECTOR STATE ==="
python3 - <<'PY'
import json
from pathlib import Path

p = Path("/var/lib/wazuh-collector/state.json")
s = json.loads(p.read_text())
print("inode =", s.get("inode"))
print("offset =", s.get("offset"))
PY

echo
echo "=== COLLECTOR STATUS ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts
```

**実行先：LXC 109 postgresql（root）**

```bash
sudo -u postgres psql -X -d security_workbench -c "
SELECT
    COUNT(*) AS inserted_after_restart,
    COUNT(DISTINCT event_id) AS unique_events,
    COUNT(*) - COUNT(DISTINCT event_id) AS duplicate_excess,
    MIN(ingested_at) AS first_ingested,
    MAX(ingested_at) AS latest_ingested
FROM incident.alert_events
WHERE ingested_at >= TIMESTAMPTZ '2026-11-18 20:54:31+00';
"
```

時刻は、7.3で再起動した時刻に置き換えます。構築時は再起動後に14件が登録され、すべて一意でした。

# 第9章　ローテーションの仕組みと再起動の履歴

まだローテーションは起こさず、読み取りだけで、Wazuhがどのようにローテーションしているかと、これまでのCollectorの停止の原因を整理します。

## 9.1　ローテーションを行っているもの

**実行先：security-core VM 220（root）**

```bash
echo "=== LOGROTATE CONFIGURATION ==="
grep -RniE 'wazuh|alerts|ossec' \
  /etc/logrotate.conf /etc/logrotate.d 2>/dev/null || true

echo
echo "=== RELATED TIMERS ==="
systemctl list-timers --all --no-pager \
  | grep -Ei 'wazuh|logrotate|ossec' || true

echo
echo "=== RELATED CRON JOBS ==="
grep -RniE 'wazuh|alerts|ossec|logrotate' \
  /etc/cron.d /etc/cron.daily /etc/cron.hourly \
  /var/spool/cron/crontabs 2>/dev/null || true

echo
echo "=== ALERT DIRECTORY STRUCTURE ==="
find /var/ossec/logs/alerts \
  -maxdepth 4 -type f \
  -printf '%TY-%Tm-%Td %TH:%TM:%TS | inode=%i | size=%s | %p\n' \
  2>/dev/null | sort | tail -60
```

logrotateやcronには、Wazuhのアラート用の設定はありません。

```bash
echo "=== ALERT FILE LINK RELATIONSHIP ==="
stat -c '%n | inode=%i | links=%h | size=%s | owner=%U:%G | mode=%a' \
  /var/ossec/logs/alerts/alerts.json \
  /var/ossec/logs/alerts/2026/Nov/ossec-alerts-18.json

echo
echo "=== ALERT DIRECTORY ENTRIES ==="
ls -lai /var/ossec/logs/alerts
ls -lai /var/ossec/logs/alerts/2026/Nov

echo
echo "=== WAZUH MANAGER PROCESSES ==="
ps -eo pid,ppid,user,stat,etime,args \
  | grep -E '[w]azuh-(analysisd|monitord|managerd|logcollector)'

echo
echo "=== WAZUH MANAGER SERVICE ==="
systemctl show wazuh-manager \
  -p ActiveState -p SubState -p MainPID -p NRestarts
```

```text
/var/ossec/logs/alerts/
├── alerts.json
├── alerts.log
└── 2026/
    └── Nov/
        ├── ossec-alerts-17.json.gz
        ├── ossec-alerts-17.json.sum
        ├── ossec-alerts-17.log.gz
        ├── ossec-alerts-17.log.sum
        ├── ossec-alerts-18.json
        └── ossec-alerts-18.log
```

## 9.2　Wazuhのローテーションの設定

**実行先：security-core VM 220（root）**

```bash
echo "=== WAZUH MONITORING CONFIGURATION ==="
grep -n -A8 -B5 -E 'rotate|compress|alerts|log_alert' \
  /var/ossec/etc/ossec.conf

echo
echo "=== WAZUH MONITORD REFERENCES ==="
grep -RniE 'alerts\.json|ossec-alerts|rotate|compress' \
  /var/ossec/etc \
  /var/ossec/queue \
  2>/dev/null | head -100

echo
echo "=== WAZUH VERSION ==="
/var/ossec/bin/wazuh-control info 2>/dev/null | head -30
```

```bash
echo "=== MONITORD ROTATION SETTINGS ==="
grep -n -B3 -A3 -E \
  '^monitord\.(day_wait|compress|rotate_log|size_rotate)=' \
  /var/ossec/etc/internal_options.conf

echo
echo "=== ANALYSISD ROTATION SETTINGS ==="
grep -n -B3 -A3 -E \
  '^analysisd\.min_rotate_interval=' \
  /var/ossec/etc/internal_options.conf

echo
echo "=== WAZUH MONITORD OPEN FILES ==="
MONITORD_PID=$(pgrep -xo wazuh-monitord)
echo "PID=$MONITORD_PID"
lsof -nP -p "$MONITORD_PID" 2>/dev/null \
  | grep -E 'alerts|ossec-alerts' || true

echo
echo "=== ALERT FILE OPEN HANDLES ==="
lsof -nP /var/ossec/logs/alerts/alerts.json 2>/dev/null || true
```

```bash
echo "=== WAZUH INTERNAL LOG ROTATION RECORDS ==="
grep -iE 'rotat|compress|sign|alerts\.json|ossec-alerts' \
  /var/ossec/logs/ossec.log 2>/dev/null | tail -80

echo
echo "=== MONITORD JOURNAL ==="
journalctl --no-pager -u wazuh-manager \
  --since "2026-11-18 00:00:00" \
  --until "2026-11-19 00:00:00" 2>/dev/null \
  | grep -iE 'monitord|rotat|compress|alerts' | tail -60

echo
echo "=== ROTATED JSON FILES ==="
find /var/ossec/logs/alerts -type f \
  -name 'ossec-alerts-*.json*' \
  -printf '%TY-%Tm-%Td %TH:%TM:%TS | %i | %s | %p\n' \
  | sort
```

| 項目 | 内容 |
|---|---|
| ローテーションを行うもの | Wazuh Managerの `wazuh-monitord`（logrotateではない） |
| 周期 | 日次（`monitord.rotate_log=1`）。構築時の記録は `00:00:10` の `Starting new log after rotation.` |
| 圧縮 | 有効（`monitord.compress=1`）。前日のJSONは `.json.gz` になる |
| 署名 | 有効（`monitord.sign=1`）。`.sum` が作られる |
| 当日のファイル | `alerts.json` と `年/月/ossec-alerts-日.json` が同じinode（ハードリンク） |

## 9.3　Collectorの停止の履歴

**実行先：security-core VM 220（root）**

```bash
echo "=== COLLECTOR JOURNAL ==="
journalctl -u wazuh-collector \
  --since "2026-11-18 00:00:00" \
  --no-pager \
  | grep -E 'starting|Resuming|rotation|PostgreSQL|ERROR|WARNING|Stopping|Started'

echo
echo "=== COLLECTOR CURRENT STATE ==="
python3 - <<'PY'
import json
from pathlib import Path

p = Path("/var/lib/wazuh-collector/state.json")
s = json.loads(p.read_text())
print("inode:", s.get("inode"))
print("offset:", s.get("offset"))
PY

echo
echo "=== CURRENT ALERT FILE ==="
stat -c 'inode=%i size=%s modified=%y' \
  /var/ossec/logs/alerts/alerts.json

echo
echo "=== COLLECTOR PROCESS ==="
systemctl show wazuh-collector \
  -p MainPID -p NRestarts -p ActiveState -p SubState
```

```bash
echo "=== COLLECTOR FAILURE WINDOW ==="
journalctl -u wazuh-collector \
  --since "2026-11-18 15:14:50" \
  --until "2026-11-18 15:17:10" \
  --no-pager -o short-iso

echo
echo "=== SYSTEMD FAILURE DETAILS ==="
journalctl \
  --since "2026-11-18 15:14:50" \
  --until "2026-11-18 15:17:10" \
  --no-pager \
  | grep -Ei 'wazuh-collector|failed|failure|traceback|permission|denied|killed|oom|error'
```

時刻は、第5部8.5で起動に失敗した時間帯に置き換えます。19回の再起動の失敗は、すべて同じ原因でした。

```text
collector.py
  run()
    └─ open_initial_file()
         └─ find_inode_file()
              └─ os.scandir('/var/ossec/logs/alerts')
```

`/var/ossec/logs/alerts` を一覧する権限がなく、`PermissionError` で終了していました（第5部8.5）。この問題は、第5部9.1のコードの修正と、第6章のACLで解消しています。

## 9.4　ACLの最終確認

**実行先：security-core VM 220（root）**

```bash
echo "=== ALERT DIRECTORY ACL ==="
getfacl -p /var/ossec/logs/alerts

echo
echo "=== YEAR DIRECTORY ACL ==="
getfacl -p /var/ossec/logs/alerts/2026

echo
echo "=== MONTH DIRECTORY ACL ==="
getfacl -p /var/ossec/logs/alerts/2026/Nov

echo
echo "=== COLLECTOR USER ACCESS ==="
sudo -u wazuh-collector test -r /var/ossec/logs/alerts \
  && echo "PASS: directory readable" \
  || echo "FAIL: directory unreadable"

sudo -u wazuh-collector test -x /var/ossec/logs/alerts \
  && echo "PASS: directory searchable" \
  || echo "FAIL: directory not searchable"
```

```bash
echo "=== DEFAULT ACL ON ALERT ROOT ==="
getfacl -cp /var/ossec/logs/alerts \
  | grep '^default:'

echo
echo "=== EXISTING JSON FILE ACL ==="
getfacl -cp /var/ossec/logs/alerts/2026/Nov/ossec-alerts-18.json

echo
echo "=== COLLECTOR READ ACCESS TO CURRENT JSON ==="
sudo -u wazuh-collector test -r \
  /var/ossec/logs/alerts/2026/Nov/ossec-alerts-18.json \
  && echo "PASS: JSON readable" \
  || echo "FAIL: JSON unreadable"
```

| 項目 | 結果 |
|---|---|
| ディレクトリ | Collectorに `r-x`（一覧と通過） |
| JSONファイル | Collectorに `r--`（読み取りだけ） |
| 書き込み | なし（Wazuhのログを変更・削除できない） |
| 将来のディレクトリ | デフォルトACLで同じ権限を継承 |

# 第10章　再起動ループの原因の整理

## 10.1　systemdの再起動の設定

**実行先：security-core VM 220（root）**

```bash
echo "=== COLLECTOR RESTART POLICY ==="
systemctl show wazuh-collector \
  -p Restart \
  -p RestartSec \
  -p StartLimitIntervalUSec \
  -p StartLimitBurst \
  -p NRestarts

echo
echo "=== SERVICE UNIT ==="
systemctl cat wazuh-collector
```

| 設定 | 値 | 意味 |
|---|---:|---|
| `Restart` | `always` | 終了すると再起動する |
| `RestartSec` | 5秒 | 再起動までの待ち時間 |
| `StartLimitIntervalUSec` | 10秒 | 起動回数を数える期間 |
| `StartLimitBurst` | 5回 | この回数を超えると起動をやめる |

起動の制限は「10秒間に5回を超えて起動した場合」に働きます。再起動の間隔が5秒なので、10秒間には2回しか起動せず、制限に届きません。そのため、第5部8.5では19回も再起動を繰り返しました。

```bash
echo "=== MAIN LOOP AND EXCEPTION HANDLING ==="
nl -ba /usr/local/lib/wazuh-collector/collector.py \
  | sed -n '450,510p;650,710p'

echo
echo "=== EXCEPTION HANDLERS ==="
grep -n -E 'except |finally:|raise |sys\.exit|SystemExit|KeyboardInterrupt' \
  /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== SYSTEMD START LIMIT HISTORY ==="
journalctl -u wazuh-collector \
  --since "2026-11-18 15:14:50" \
  --until "2026-11-18 15:17:10" \
  --no-pager \
  | grep -Ei 'start request repeated|start-limit|scheduled restart|failed'
```

## 10.2　起動時の処理の構造

**実行先：security-core VM 220（root）**

```bash
echo "=== RUN FUNCTION: INITIALIZATION AND MAIN LOOP ==="
nl -ba /usr/local/lib/wazuh-collector/collector.py \
  | sed -n '450,570p'

echo
echo "=== RUN FUNCTION: ROTATION AND SHUTDOWN ==="
nl -ba /usr/local/lib/wazuh-collector/collector.py \
  | sed -n '570,710p'

echo
echo "=== MODULE ENTRY POINT ==="
nl -ba /usr/local/lib/wazuh-collector/collector.py \
  | sed -n '700,730p'
```

```bash
echo "=== LOAD STATE ==="
nl -ba /usr/local/lib/wazuh-collector/collector.py \
  | sed -n '240,330p'

echo
echo "=== FIND INODE AND OPEN INITIAL FILE ==="
nl -ba /usr/local/lib/wazuh-collector/collector.py \
  | sed -n '310,430p'

echo
echo "=== CURRENT PRODUCTION CODE HASH ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py
```

`run()` の初期化の部分は、`try/finally` の外にあります。

```python
state = load_state()
handle, active_inode = open_initial_file(state)

try:
    while True:
```

| 項目 | 現状 | 評価 |
|---|---|---|
| 初期化中の例外 | 捕まえずにプロセスが終了する（systemdが再起動） | 読み残しを黙って捨てないための意図した動作。ただし再起動が延々と続く |
| DB接続のエラー | 5秒待って再試行する（プロセスは終了しない） | 問題なし |
| 保存位置がファイルより大きい場合 | 次の行で、黙ってファイルの末尾に合わせる | **要修正**（読み残しを捨てる可能性） |

```python
handle.seek(min(old_offset, actual_stat.st_size))
```

保存されている読み取り位置がファイルのサイズより大きいのは、ファイルが短くなった（切り詰められた）など、通常は起きない状態です。末尾に合わせて続けると、その間のアラートを取りこぼしたことに気づけません。fail-closedの方針に合わせて、起動を拒否するように直します。

## 10.3　実行環境の確認

**実行先：security-core VM 220（root）**

```bash
echo "=== PYTHON VERSION ==="
python3 --version

echo
echo "=== COLLECTOR IMPORTS AND CONFIGURATION ==="
nl -ba /usr/local/lib/wazuh-collector/collector.py \
  | sed -n '1,120p'

echo
echo "=== SYSTEMD VERSION ==="
systemd --version | head -n 2

echo
echo "=== PRODUCTION SERVICE STATUS ==="
systemctl show wazuh-collector \
  -p ActiveState \
  -p SubState \
  -p MainPID \
  -p NRestarts
```

構築時は Python 3.12.3、systemd 255.4 で、本番のCollectorはPID `90884`、再起動回数0で動いていました。

# 第11章　起動時の読み取り位置の検証

ここからの修正も、本番を止めずにテスト用のコピーで行います。

## 11.1　テスト用コピーの作成

**実行先：security-core VM 220（root）**

```bash
TEST_FILE=/tmp/wazuh-collector-step330-test.py

cp --preserve=mode,ownership \
  /usr/local/lib/wazuh-collector/collector.py \
  "$TEST_FILE"

chmod 600 "$TEST_FILE"

echo "=== TEST COPY ==="
stat -c '%n | owner=%U:%G | mode=%a | size=%s' "$TEST_FILE"

echo
echo "=== HASH COMPARISON ==="
sha256sum \
  /usr/local/lib/wazuh-collector/collector.py \
  "$TEST_FILE"

echo
echo "=== PYTHON SYNTAX CHECK ==="
python3 -m py_compile "$TEST_FILE" \
  && echo "PASS: syntax valid"
```

```bash
echo "=== FUNCTION DEFINITIONS ==="
grep -n '^def ' /tmp/wazuh-collector-step330-test.py

echo
echo "=== FILE AND STATE CONSTANTS ==="
grep -nE '^(ALERT_FILE|ALERT_DIR|STATE_FILE|POLL_INTERVAL|MAX_ALERT_LINE_BYTES|READ_CHUNK_BYTES)' \
  /tmp/wazuh-collector-step330-test.py

echo
echo "=== FILE OPEN AND SEEK OPERATIONS ==="
grep -nE 'open\(|\.seek\(|\.tell\(|fstat\(|\.stat\(' \
  /tmp/wazuh-collector-step330-test.py
```

## 11.2　修正前の動作の再現

一時ディレクトリで、修正前の動作を確かめます。保存位置がファイルより大きい場合に、黙って末尾に合わせてしまうことを再現します。

**実行先：security-core VM 220（root）**

```bash
cat > /tmp/test_step330_baseline.py <<'PY'
import importlib.util
import tempfile
from pathlib import Path
from unittest.mock import patch

source = "/tmp/wazuh-collector-step330-test.py"

spec = importlib.util.spec_from_file_location("collector_test", source)
collector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(collector)

with tempfile.TemporaryDirectory(prefix="step330-") as tmp:
    root = Path(tmp)
    alert_dir = root / "alerts"
    alert_dir.mkdir()

    alert_file = alert_dir / "alerts.json"
    alert_file.write_bytes(b'{"test":"event"}\n')

    collector.ALERT_FILE = alert_file
    collector.ALERT_DIR = alert_dir
    collector.STATE_FILE = root / "state" / "state.json"

    actual_inode = alert_file.stat().st_ino
    actual_size = alert_file.stat().st_size

    # Test 1: normal resume
    handle, inode = collector.open_initial_file((actual_inode, 0))
    assert inode == actual_inode
    assert handle.tell() == 0
    handle.close()
    print("PASS: normal resume")

    # Test 2: offset larger than file size
    handle, inode = collector.open_initial_file(
        (actual_inode, actual_size + 100)
    )
    observed_offset = handle.tell()
    handle.close()

    print(
        "BASELINE:",
        f"saved_offset={actual_size + 100}",
        f"actual_size={actual_size}",
        f"resumed_offset={observed_offset}",
    )

    if observed_offset == actual_size:
        print("CONFIRMED: current code silently clamps oversized offset")
    else:
        raise AssertionError("Unexpected offset behavior")

    # Test 3: missing previous inode must fail closed
    try:
        collector.open_initial_file((9223372036854775807, 0))
    except RuntimeError as error:
        print("PASS: missing inode fails closed:", str(error))
    else:
        raise AssertionError("Missing inode was not rejected")

    # Test 4: traversal error must propagate
    with patch.object(
        collector.os,
        "scandir",
        side_effect=PermissionError("test permission failure"),
    ):
        try:
            collector.find_inode_file(9223372036854775807)
        except PermissionError:
            print("PASS: traversal PermissionError propagates")
        else:
            raise AssertionError("Traversal error was swallowed")

print("PASS: baseline tests completed")
PY

python3 /tmp/test_step330_baseline.py
```

構築時は、保存位置117・ファイルのサイズ17に対して、再開位置が17になり、問題が再現しました。

```text
saved_offset=117
actual_size=17
resumed_offset=17
```

## 11.3　修正

現在のファイル・ローテーション済みファイルの2か所で、`seek()` の前に位置を確かめ、ファイルより大きければ `RuntimeError` で止めます。

**実行先：security-core VM 220（root）**

```bash
echo "=== OPEN INITIAL FILE ==="
sed -n '340,410p' /tmp/wazuh-collector-step330-test.py

echo
echo "=== STATE SAVE AND LOAD ==="
sed -n '249,313p' /tmp/wazuh-collector-step330-test.py
```

```bash
python3 - <<'PY'
from pathlib import Path

path = Path("/tmp/wazuh-collector-step330-test.py")
source = path.read_text(encoding="utf-8")

old_current = '''        if actual_stat.st_ino == old_inode:
            handle.seek(min(old_offset, actual_stat.st_size))
            logging.info("Resuming current alert file")
            return handle, actual_stat.st_ino
'''

new_current = '''        if actual_stat.st_ino == old_inode:
            if old_offset > actual_stat.st_size:
                raise RuntimeError(
                    "Saved offset exceeds current alert file size; "
                    "refusing unsafe resume"
                )

            handle.seek(old_offset)
            logging.info("Resuming current alert file")
            return handle, actual_stat.st_ino
'''

old_rotated = '''        handle.seek(min(old_offset, actual_stat.st_size))
        logging.info("Resuming previous rotated alert file")
'''

new_rotated = '''        if old_offset > actual_stat.st_size:
            raise RuntimeError(
                "Saved offset exceeds previous alert file size; "
                "refusing unsafe resume"
            )

        handle.seek(old_offset)
        logging.info("Resuming previous rotated alert file")
'''

if source.count(old_current) != 1:
    raise SystemExit("ABORT: current-file target is not unique")

if source.count(old_rotated) != 1:
    raise SystemExit("ABORT: rotated-file target is not unique")

updated = source.replace(old_current, new_current, 1)
updated = updated.replace(old_rotated, new_rotated, 1)

path.write_text(updated, encoding="utf-8")
print("PASS: test copy updated")
PY

echo
echo "=== MODIFIED RESUME CHECKS ==="
sed -n '355,410p' /tmp/wazuh-collector-step330-test.py

echo
echo "=== SYNTAX CHECK ==="
python3 -m py_compile /tmp/wazuh-collector-step330-test.py
```

> 現在のファイルの場合、例外は `open_initial_file()` の `except Exception:` でファイルを閉じてから呼び出し元に伝わります。

## 11.4　読み取り位置の検証

**実行先：security-core VM 220（root）**

```bash
cat > /tmp/test_step330_offset.py <<'PY'
import importlib.util
import tempfile
from pathlib import Path

spec = importlib.util.spec_from_file_location(
    "collector_test",
    "/tmp/wazuh-collector-step330-test.py",
)
collector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(collector)

def expect_rejection(label, state):
    try:
        handle, inode = collector.open_initial_file(state)
    except RuntimeError as error:
        print(f"PASS: {label}: {error}")
    else:
        handle.close()
        raise AssertionError(f"FAIL: {label}: unsafe resume accepted")

with tempfile.TemporaryDirectory(prefix="step330-offset-") as tmp:
    root = Path(tmp)
    alert_dir = root / "alerts"
    rotated_dir = alert_dir / "2026" / "Nov"
    rotated_dir.mkdir(parents=True)

    current = alert_dir / "alerts.json"
    current.write_bytes(b'{"current":true}\n')

    collector.ALERT_FILE = current
    collector.ALERT_DIR = alert_dir
    collector.STATE_FILE = root / "state" / "state.json"

    current_inode = current.stat().st_ino
    current_size = current.stat().st_size

    # 1. Current file: valid offset
    handle, inode = collector.open_initial_file(
        (current_inode, 3)
    )
    assert inode == current_inode
    assert handle.tell() == 3
    handle.close()
    print("PASS: current file valid offset")

    # 2. Current file: oversized offset
    expect_rejection(
        "current file oversized offset",
        (current_inode, current_size + 100),
    )

    # 3. Rotated file: valid offset
    rotated = rotated_dir / "ossec-alerts-old.json"
    rotated.write_bytes(b'{"previous":true}\n')
    rotated_inode = rotated.stat().st_ino

    handle, inode = collector.open_initial_file(
        (rotated_inode, 5)
    )
    assert inode == rotated_inode
    assert handle.tell() == 5
    handle.close()
    print("PASS: rotated file valid offset")

    # 4. Rotated file: oversized offset
    rotated_size = rotated.stat().st_size
    expect_rejection(
        "rotated file oversized offset",
        (rotated_inode, rotated_size + 100),
    )

    # 5. Missing inode
    expect_rejection(
        "missing inode",
        (9223372036854775807, 0),
    )

print("PASS: all offset safety tests completed")
PY

python3 /tmp/test_step330_offset.py
```

| 検証 | 結果 |
|---|---|
| 現在のファイル：正しい位置 | 再開する |
| 現在のファイル：位置がファイルより大きい | 起動を拒否 |
| ローテーション済みファイル：正しい位置 | 再開する |
| ローテーション済みファイル：位置がファイルより大きい | 起動を拒否 |
| 旧inodeが見つからない | 起動を拒否 |

## 11.5　差分と本番の確認

**実行先：security-core VM 220（root）**

```bash
echo "=== TEST COPY DIFF ==="
diff -u \
  /usr/local/lib/wazuh-collector/collector.py \
  /tmp/wazuh-collector-step330-test.py

echo
echo "=== PRODUCTION SHA256 ==="
sha256sum /usr/local/lib/wazuh-collector/collector.py

echo
echo "=== TEST COPY SHA256 ==="
sha256sum /tmp/wazuh-collector-step330-test.py

echo
echo "=== PRODUCTION SERVICE STATUS ==="
systemctl show wazuh-collector \
  -p ActiveState -p SubState -p MainPID -p NRestarts
```

差分が表示されなかった場合は、終了コードも確認します。`diff` は、差分があると終了コード1を返します（エラーではありません）。

```bash
diff -u \
  /usr/local/lib/wazuh-collector/collector.py \
  /tmp/wazuh-collector-step330-test.py

echo "DIFF_EXIT_CODE=$?"
```

変更は `open_initial_file()` の2か所だけで、本番（`ac297477...`）は変わっていないことを確認します。

## 11.6　inodeの取り違えの検証

旧ファイルを探した結果、保存したinodeと違うファイルが返ってきた場合に、そのファイルを読まずに止まることを確認します。

**実行先：security-core VM 220（root）**

```bash
cat > /tmp/test_step330_inode.py <<'PY'
import importlib.util
import tempfile
from pathlib import Path
from unittest.mock import patch

spec = importlib.util.spec_from_file_location(
    "collector_test",
    "/tmp/wazuh-collector-step330-test.py",
)
collector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(collector)

with tempfile.TemporaryDirectory(prefix="step330-inode-") as tmp:
    root = Path(tmp)
    alert_dir = root / "alerts"
    alert_dir.mkdir()

    current = alert_dir / "alerts.json"
    impostor = alert_dir / "impostor.json"

    current.write_bytes(b'{"current":true}\n')
    impostor.write_bytes(b'{"impostor":true}\n')

    collector.ALERT_FILE = current
    collector.ALERT_DIR = alert_dir
    collector.STATE_FILE = root / "state" / "state.json"

    wrong_inode = impostor.stat().st_ino

    # Return a path whose actual inode differs from the saved inode.
    with patch.object(
        collector,
        "find_inode_file",
        return_value=impostor,
    ):
        try:
            collector.open_initial_file((wrong_inode + 1, 0))
        except RuntimeError as error:
            print("PASS: inode mismatch rejected:", str(error))
        else:
            raise AssertionError("Mismatched inode was accepted")

    # Verify the real inode can still be located normally.
    found = collector.find_inode_file(wrong_inode)
    assert found == impostor
    print("PASS: recursive inode lookup returns matching file")

print("PASS: inode identity tests completed")
PY

python3 /tmp/test_step330_inode.py
```

# 第6部のまとめ

第6部では、強化版のCollectorが「欠けず・重ならず」にアラートをDBへ入れていることを、イベントIDの単位まで確かめ、実際のローテーションの構造に合わせて仕上げました。

| 確認・変更 | 結果 |
|---|---|
| 重複の防止 | DBの主キーで保証。一時テーブルとモックで、2回目の登録が拒否されることを確認 |
| 完全性 | 対象413件のイベントIDの集合のSHA-256が、alerts.jsonとDBで一致 |
| ローテーションの構造 | `wazuh-monitord` が日次で `年/月` に移し、前日分を圧縮する |
| 旧ファイルの探索 | 再帰探索に変更（`.json.gz` は除外、探索のエラーは fail-closed）し、本番に反映 |
| ACL | `alerts`・`年`・`月` のディレクトリにCollectorの `r-x`。将来のディレクトリにも継承 |
| 再起動後 | DBへの接続は新しいアラートを読んだときに確立。取り込みは継続し、重複0件 |
| 読み取り位置の検証 | テスト版で、保存位置がファイルより大きい場合に起動を拒否する修正を確認（本番への反映は第7部） |

| 本番のファイル | SHA-256（構築時） |
|---|---|
| `collector.py`（再帰探索版） | `ac297477...` |
| `collector.py.backup-before-recursive-rotation-20261119` | `7a816056...`（第5部の版） |

> **残る制約：** 旧ファイルがすでに圧縮されていると、元のinodeは見つからず、起動を拒否します（第7章7.1）。日付をまたいでCollectorを止めるときは注意してください。

第7部では、テスト版 `/tmp/wazuh-collector-step330-test.py` の検証を続け（STEP 330-16以降）、異常終了時のファイルの解放、巨大な行やJSONの深さへの耐性などを確かめてから、本番に反映します。
