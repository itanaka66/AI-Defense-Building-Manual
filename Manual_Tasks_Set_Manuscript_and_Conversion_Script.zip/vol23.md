---
title: "AI自律型サイバー防御システム 構築マニュアル 前編"
subtitle: "第23部　Indexerの権限と監査ログの調査"
author: "田中勇"
lang: ja-JP
---

# はじめに

## 本書について

本書は「AI自律型サイバー防御システム 構築マニュアル」前編の第23部です。第22部で、動いている Indexer には `ai-defense-reader` と `ai_defense_alerts_read` があるのに、ディスクの上の YAML には定義がないことがわかりました。ここでは、設定は変えずに**読み取りだけで**次のことを調べます。

1. 設定の変更の記録（OpenSearch Security の監査ログ）がどう設定され、どこに残るか
2. 管理者の証明書を使って、ロールとユーザーの実際の定義を確かめる
3. Indexer のログに残っている `ai-defense-reader` に関する記録

監査ログの保存先は、この部の時点では突き止められていません。調べた手順と、わかったことまでを記します。

## 本書の表記

- コマンドやプログラムは、構築時に実際に使用したものをそのまま掲載しています。改変していません。
- 実行先は **security-core VM 220（root）** です。
- ログの本文、パスワード、秘密鍵の中身は表示しません。

# 第1章　監査ログの設定

## 1.1　監査ログのファイル

```bash
find /var/log/wazuh-indexer -maxdepth 2 -type f \( -iname '*audit*' -o -iname '*security*' \) -printf '%p  %TY-%Tm-%Td %TH:%TM  %s bytes\n' 2>/dev/null | sort
```

構築時は、監査ログらしいファイルは見つかりませんでした。

## 1.2　audit.yml

```bash
grep -nEi -A 3 -B 2 'audit|compliance|external_config|enabled|log4j' /etc/wazuh-indexer/opensearch-security/audit.yml
```

```bash
sed -n '25,130p' /etc/wazuh-indexer/opensearch-security/audit.yml
```

| 設定 | 値 |
|---|---|
| REST API の監査 | 有効 |
| Transport API の監査 | 有効 |
| 内部のセキュリティ設定の変更の記録（`internal_config`） | 有効 |
| 外部の設定ファイルの変更の記録（`external_config`） | 無効 |
| リクエストの本文の記録（`log_request_body`） | 有効 |
| 認証の成功・権限の付与のイベント | 記録しない |

`log_request_body: true` は、REST API のリクエストの本文も記録する設定です。記録の扱いには注意が必要です（不足情報メモ 23-A）。

```bash
grep -nEi 'audit|appender|fileName|filePattern' /etc/wazuh-indexer/log4j2.properties
```

`log4j2.properties` には、監査ログ専用のファイルの出力先は見当たりません。

```bash
sed -n '1,28p' /etc/wazuh-indexer/opensearch-security/audit.yml
```

YAML として読み、出力の方式に関係する項目を表示します。

```bash
python3 - <<'PY'
import yaml

path = "/etc/wazuh-indexer/opensearch-security/audit.yml"

with open(path, encoding="utf-8") as f:
    data = yaml.safe_load(f) or {}

config = data.get("config", {})
audit = config.get("audit", {})
compliance = config.get("compliance", {})

print("AUDIT_ENABLED:", config.get("enabled"))
print("AUDIT_CONFIG_KEYS:", sorted(audit.keys()))
print("AUDIT_OUTPUT_TYPE:", audit.get("type", "NOT_EXPLICITLY_CONFIGURED"))
print("COMPLIANCE_ENABLED:", compliance.get("enabled"))
print("INTERNAL_CONFIG_AUDIT:", compliance.get("internal_config"))
PY
```

監査は有効ですが、出力の方式は `audit.yml` には書かれていません。

## 1.3　Indexerの稼働のログ

秘密の情報らしい文字列は伏せて表示します。

```bash
journalctl -u wazuh-indexer --since "2026-11-17" --no-pager | grep -Ei 'audit|compliance|securityanalytics|internalusers|rolesmapping|roles' | tail -80 | sed -E 's/(password|token|authorization)([=: ]+)[^ ,"]+/\1\2[REDACTED]/Ig'
```

構築時は、監査やロールの変更に関する記録は見つかりませんでした。

# 第2章　管理者の証明書でロールとユーザーを確かめる

## 2.1　ai-defense-readerでは一覧を見られないこと

```bash
python3 - <<'PY'
import base64, json, ssl, urllib.request, urllib.error

password = open("/etc/credstore/ai-defense-indexer-password").read().strip()
auth = base64.b64encode(("ai-defense-reader:" + password).encode()).decode()

request = urllib.request.Request(
    "https://127.0.0.1:9200/_cat/indices?format=json&h=index",
    headers={"Authorization": "Basic " + auth},
)

context = ssl.create_default_context(
    cafile="/etc/credstore/ai-defense-indexer-ca"
)

try:
    with urllib.request.urlopen(request, context=context, timeout=10) as response:
        indices = json.loads(response.read())
        names = sorted(
            item.get("index", "")
            for item in indices
            if any(word in item.get("index", "").lower()
                   for word in ("audit", "security", "compliance"))
        )
        print("HTTP_STATUS:", response.status)
        print("MATCHING_INDEX_COUNT:", len(names))
        for name in names:
            print(name)
except urllib.error.HTTPError as exc:
    print("HTTP_STATUS:", exc.code)
    print("INDEX_LIST_ACCESS_DENIED")
except Exception as exc:
    print("CHECK_ERROR:", type(exc).__name__)
PY
```

`HTTP_STATUS: 403` でした。アラートを読むだけのユーザーに、インデックスの一覧を見る権限は要りません。権限は足さず、管理者の側から確かめます。

## 2.2　管理者の証明書

ファイルの名前と権限だけを表示します。

```bash
find /etc/wazuh-indexer -maxdepth 3 -type f \( -iname '*admin*.pem' -o -iname '*admin*.crt' -o -iname '*admin*.key' \) -printf '%p  %m  %u:%g\n' | sort
```

```bash
find /etc/wazuh-indexer/certs -maxdepth 1 -type f -printf '%f  %m  %u:%g\n' | sort
```

`admin.pem` と `admin-key.pem` は `wazuh-indexer` の持ち物で、権限は `400` でした。以下のプログラムは、この証明書で Indexer に読み取りだけの問い合わせをします。

## 2.3　ai_defense_alerts_readの定義

```bash
python3 - <<'PY'
import json
import ssl
import urllib.request
import urllib.error

context = ssl.create_default_context(
    cafile="/etc/wazuh-indexer/certs/root-ca.pem"
)
context.load_cert_chain(
    certfile="/etc/wazuh-indexer/certs/admin.pem",
    keyfile="/etc/wazuh-indexer/certs/admin-key.pem"
)

url = "https://127.0.0.1:9200/_plugins/_security/api/roles/ai_defense_alerts_read"
request = urllib.request.Request(url)

try:
    with urllib.request.urlopen(request, context=context, timeout=10) as response:
        data = json.loads(response.read())
        print("HTTP_STATUS:", response.status)
        print(json.dumps(data, indent=2))
except urllib.error.HTTPError as exc:
    print("HTTP_STATUS:", exc.code)
    print("ADMIN_ROLE_READ_FAILED")
except Exception as exc:
    print("CHECK_ERROR:", type(exc).__name__)
PY
```

| 項目 | 値 |
|---|---|
| `cluster_permissions` | 空 |
| `index_patterns` | `wazuh-alerts-4.x-*` だけ |
| `allowed_actions` | `read` だけ |
| `tenant_permissions` | 空 |
| `reserved`・`static` | `false` |

Wazuh のアラート以外は対象にせず、書き込み・削除・クラスターの管理の権限はありません。

## 2.4　own_indexの定義

`ai-defense-reader` には、標準のロール `own_index` も付いています。

```bash
python3 - <<'PY'
import json
import ssl
import urllib.request

context = ssl.create_default_context(
    cafile="/etc/wazuh-indexer/certs/root-ca.pem"
)
context.load_cert_chain(
    certfile="/etc/wazuh-indexer/certs/admin.pem",
    keyfile="/etc/wazuh-indexer/certs/admin-key.pem"
)

url = "https://127.0.0.1:9200/_plugins/_security/api/roles/own_index"
request = urllib.request.Request(url)

with urllib.request.urlopen(request, context=context, timeout=10) as response:
    data = json.loads(response.read())
    print("HTTP_STATUS:", response.status)
    print(json.dumps(data, indent=2))
PY
```

`own_index` は、ユーザーの名前と同じ名前のインデックス（`${user_name}`）に `indices_all` を許し、`cluster_composite_ops` も許す標準のロールです（`reserved: true`）。そこで、`ai-defense-reader` という名前のインデックスがあるかを確かめます。

```bash
python3 - <<'PY'
import ssl
import urllib.request
import urllib.error

context = ssl.create_default_context(
    cafile="/etc/wazuh-indexer/certs/root-ca.pem"
)
context.load_cert_chain(
    certfile="/etc/wazuh-indexer/certs/admin.pem",
    keyfile="/etc/wazuh-indexer/certs/admin-key.pem"
)

url = "https://127.0.0.1:9200/ai-defense-reader"
request = urllib.request.Request(url, method="HEAD")

try:
    with urllib.request.urlopen(request, context=context, timeout=10) as response:
        print("INDEX_EXISTS: yes")
        print("HTTP_STATUS:", response.status)
except urllib.error.HTTPError as exc:
    if exc.code == 404:
        print("INDEX_EXISTS: no")
        print("HTTP_STATUS:", exc.code)
    else:
        print("HTTP_STATUS:", exc.code)
except Exception as exc:
    print("CHECK_ERROR:", type(exc).__name__)
PY
```

`INDEX_EXISTS: no`（`404`）でした。今は `own_index` で触れられるインデックスはありません。ただし、将来この名前のインデックスができれば、`ai-defense-reader` がすべての操作をできるようになります（不足情報メモ 23-B）。

## 2.5　ユーザーの定義

パスワードのハッシュは表示しません。

```bash
python3 - <<'PY'
import json
import ssl
import urllib.request

context = ssl.create_default_context(
    cafile="/etc/wazuh-indexer/certs/root-ca.pem"
)
context.load_cert_chain(
    certfile="/etc/wazuh-indexer/certs/admin.pem",
    keyfile="/etc/wazuh-indexer/certs/admin-key.pem"
)

url = "https://127.0.0.1:9200/_plugins/_security/api/internalusers/ai-defense-reader"
request = urllib.request.Request(url)

with urllib.request.urlopen(request, context=context, timeout=10) as response:
    data = json.loads(response.read())
    user = data.get("ai-defense-reader", {})
    print("HTTP_STATUS:", response.status)
    print(json.dumps({
        "reserved": user.get("reserved"),
        "backend_roles": user.get("backend_roles", []),
        "attributes": user.get("attributes", {}),
        "description": user.get("description")
    }, indent=2))
PY
```

構築時は `reserved: false`、`backend_roles` と `attributes` は空、`description` は `Read-only access to Wazuh alert indices for AI Defense Manager` でした。

# 第3章　監査ログの保存先を探す

## 3.1　インデックス

```bash
python3 - <<'PY'
import json
import ssl
import urllib.request

context = ssl.create_default_context(
    cafile="/etc/wazuh-indexer/certs/root-ca.pem"
)
context.load_cert_chain(
    certfile="/etc/wazuh-indexer/certs/admin.pem",
    keyfile="/etc/wazuh-indexer/certs/admin-key.pem"
)

url = "https://127.0.0.1:9200/_cat/indices?format=json&h=index"
request = urllib.request.Request(url)

with urllib.request.urlopen(request, context=context, timeout=10) as response:
    indices = json.loads(response.read())
    print("HTTP_STATUS:", response.status)
    for item in indices:
        name = item.get("index", "")
        if "audit" in name.lower() or "security" in name.lower():
            print(name)
PY
```

出てきたのは `.opendistro_security`（セキュリティの設定を入れる内部のインデックス）と、`wazuh-states-*`（Wazuh の状態や資産の情報）だけでした。名前に `audit` を含むインデックスはありません。

## 3.2　動いている監査の設定

```bash
python3 - <<'PY'
import json
import ssl
import urllib.request
import urllib.error

context = ssl.create_default_context(
    cafile="/etc/wazuh-indexer/certs/root-ca.pem"
)
context.load_cert_chain(
    certfile="/etc/wazuh-indexer/certs/admin.pem",
    keyfile="/etc/wazuh-indexer/certs/admin-key.pem"
)

url = "https://127.0.0.1:9200/_plugins/_security/api/audit"
request = urllib.request.Request(url)

try:
    with urllib.request.urlopen(request, context=context, timeout=10) as response:
        data = json.loads(response.read())
        print("HTTP_STATUS:", response.status)
        if isinstance(data, dict):
            for key, value in data.items():
                if key.lower() in ("audit", "config"):
                    print(key + ":")
                    print(json.dumps(value, indent=2))
                elif isinstance(value, (str, int, bool, type(None))):
                    print(f"{key}: {value}")
                else:
                    print(f"{key}: [structured configuration]")
        else:
            print("RESPONSE_TYPE:", type(data).__name__)
except urllib.error.HTTPError as exc:
    print("HTTP_STATUS:", exc.code)
    print("AUDIT_API_READ_FAILED")
except Exception as exc:
    print("CHECK_ERROR:", type(exc).__name__)
PY
```

動いている監査の設定は、ディスクの上の `audit.yml` と一致していました（監査は有効、内部の設定の変更の記録も有効、リクエストの本文の記録も有効、機密のヘッダーは記録から除く）。

## 3.3　ログのファイル

```bash
grep -nEi 'audit|compliance|logger|appender|fileName|filePattern' /etc/wazuh-indexer/log4j2.properties
```

```bash
find /var/log/wazuh-indexer -maxdepth 2 -type f -printf '%f  %m  %u:%g\n' 2>/dev/null | sort
```

通常のログ（`wazuh-cluster.log`）と JSON 形式のログ（`wazuh-cluster_server.json`）があり、どちらも `640 wazuh-indexer:wazuh-indexer` でした。監査専用のファイルはありません。

JSON のログで、関係する語を含む行の数だけを数えます（本文は表示しません）。

```bash
python3 - <<'PY'
from pathlib import Path

p = Path("/var/log/wazuh-indexer/wazuh-cluster_server.json")
terms = ("audit", "compliance", "ai-defense-reader", "ai_defense_alerts_read")

counts = {term: 0 for term in terms}

with p.open(errors="replace") as f:
    for line in f:
        lower = line.lower()
        for term in terms:
            if term in lower:
                counts[term] += 1

print("FILE:", p.name)
for term, count in counts.items():
    print(f"{term}: {count}")
PY
```

| 語 | 行の数 |
|---|---:|
| `audit` | 0 |
| `compliance` | 0 |
| `ai-defense-reader` | 3 |
| `ai_defense_alerts_read` | 3 |

## 3.4　その3行は何か

時刻・レベルなどのメタデータだけを取り出します。

```bash
python3 - <<'PY'
import json
from pathlib import Path

p = Path("/var/log/wazuh-indexer/wazuh-cluster_server.json")
terms = ("ai-defense-reader", "ai_defense_alerts_read")

with p.open(errors="replace") as f:
    for line in f:
        if not any(term in line.lower() for term in terms):
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue

        print({
            "timestamp": obj.get("@timestamp") or obj.get("timestamp"),
            "level": obj.get("log.level") or obj.get("level"),
            "logger": obj.get("log.logger") or obj.get("logger"),
            "event_dataset": obj.get("event.dataset"),
        })
PY
```

```bash
python3 - <<'PY'
import json
from pathlib import Path

p = Path("/var/log/wazuh-indexer/wazuh-cluster_server.json")
terms = ("ai-defense-reader", "ai_defense_alerts_read")

with p.open(errors="replace") as f:
    for line in f:
        if not any(term in line.lower() for term in terms):
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue

        print("TOP_LEVEL_KEYS:", sorted(obj.keys()))

        for key in ("log", "event", "error", "opensearch"):
            value = obj.get(key)
            if isinstance(value, dict):
                print(f"{key.upper()}_KEYS:", sorted(value.keys()))
        print("---")
PY
```

```bash
python3 - <<'PY'
import json
from pathlib import Path
from collections import Counter

p = Path("/var/log/wazuh-indexer/wazuh-cluster_server.json")
terms = ("ai-defense-reader", "ai_defense_alerts_read")
counts = Counter()

with p.open(errors="replace") as f:
    for line in f:
        if not any(term in line.lower() for term in terms):
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue

        counts[(
            obj.get("component", "<missing>"),
            obj.get("type", "<missing>"),
            obj.get("level", "<missing>")
        )] += 1

print("MATCHED_LOG_CATEGORIES:")
for (component, log_type, level), count in sorted(counts.items()):
    print({
        "component": component,
        "type": log_type,
        "level": level,
        "count": count
    })
PY
```

3行とも、OpenSearch Security の権限の判定に関係するログでした。

| コンポーネント | レベル | 件数 |
|---|---|---:|
| `RestApiPrivilegesEvaluator` | INFO | 1 |
| `PrivilegesEvaluatorImpl` | INFO | 1 |
| `AbstractApiAction` | ERROR | 1 |

## 3.5　ERRORの行を分類する

本文は表示せず、例外のクラスの名前、権限の拒否・認証の失敗などを示す語、HTTP のステータスがあるかだけを調べます。

```bash
python3 - <<'PY'
import json
import re
from pathlib import Path

p = Path("/var/log/wazuh-indexer/wazuh-cluster_server.json")
terms = ("ai-defense-reader", "ai_defense_alerts_read")

with p.open(errors="replace") as f:
    for line in f:
        if not any(term in line.lower() for term in terms):
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue

        if obj.get("level") != "ERROR":
            continue

        message = obj.get("message", "")
        match = re.search(
            r'([A-Za-z_$][A-Za-z0-9_.$]*(?:Exception|Error))',
            message
        )

        print({
            "timestamp": obj.get("timestamp"),
            "component": obj.get("component"),
            "exception_class": match.group(1) if match else "not_identified"
        })
PY
```

```bash
python3 - <<'PY'
import json
import re
from pathlib import Path

p = Path("/var/log/wazuh-indexer/wazuh-cluster_server.json")
terms = ("ai-defense-reader", "ai_defense_alerts_read")

with p.open(errors="replace") as f:
    for line in f:
        if not any(term in line.lower() for term in terms):
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue

        if obj.get("level") != "ERROR":
            continue

        message = str(obj.get("message", "")).lower()

        flags = {
            "permission_denied": any(x in message for x in (
                "no permissions", "permission denied", "forbidden"
            )),
            "authentication_failure": any(x in message for x in (
                "authentication failed", "unauthorized", "invalid credentials"
            )),
            "resource_not_found": any(x in message for x in (
                "not found", "does not exist"
            )),
            "internal_error": any(x in message for x in (
                "internal server error", "unexpected exception"
            )),
        }

        action = re.search(r'\[(indices:[a-z_/*-]+)\]', message)
        status = re.search(r'\b(401|403|404|500|502|503)\b', message)

        print({
            "timestamp": obj.get("timestamp"),
            "component": obj.get("component"),
            "message_length": len(message),
            "classification_flags": flags,
            "index_action": action.group(1) if action else None,
            "http_status_if_logged": status.group(1) if status else None
        })
PY
```

```bash
python3 - <<'PY'
import json
import re
from pathlib import Path

p = Path("/var/log/wazuh-indexer/wazuh-cluster_server.json")
terms = ("ai-defense-reader", "ai_defense_alerts_read")

with p.open(errors="replace") as f:
    for line in f:
        if not any(term in line.lower() for term in terms):
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        if obj.get("level") != "ERROR":
            continue

        message = str(obj.get("message", ""))
        patterns = [
            r'(?i)\b(?:exception|error)\s*:\s*([A-Za-z0-9_.$]+)',
            r'(?i)\bstatus(?:_code)?\s*[=:]\s*(\d{3})',
            r'(?i)\bHTTP\s+(\d{3})\b',
            r'(?i)\b(?:denied|forbidden|unauthorized|bad request)\b',
            r'(?i)\b(?:GET|POST|PUT|DELETE)\s+(/[A-Za-z0-9_./?*-]*)',
        ]

        print("TIMESTAMP:", obj.get("timestamp"))
        for pattern in patterns:
            matches = re.findall(pattern, message)
            print("PATTERN_MATCH:", matches if matches else "none")
PY
```

構築時は、どの方法でも ERROR の原因は特定できませんでした（例外のクラスの名前・権限の拒否・認証の失敗・HTTP のステータスのどれも見つからない）。第22部 3.3 で `ai-defense-reader` がロールの定義を読もうとして `403` になった記録の可能性がありますが、確かめられていません（不足情報メモ 23-C）。

## 3.6　監査の出力の方式

```bash
grep -nEi 'audit|opensearch\.logs|path\.logs|plugins\.security' /etc/wazuh-indexer/opensearch.yml
```

`opensearch.yml` には、監査の出力の方式（`plugins.security.audit.type`）の設定がありません。

```bash
grep -RniE 'plugins\.security\.audit\.type|internal_opensearch|external_opensearch|audit.*type' /etc/wazuh-indexer /usr/share/wazuh-indexer 2>/dev/null | head -80
```

```bash
sed -n '78,105p' /etc/wazuh-indexer/opensearch-security/opensearch.yml.example
```

設定例のファイルには、Indexer の中に保存する `plugins.security.audit.type: internal_opensearch` が書かれています。ただし、これは例であり、実際の設定とは限りません。

動いているノードの設定を確かめます。

```bash
python3 - <<'PY'
import json
import ssl
import urllib.request

context = ssl.create_default_context(
    cafile="/etc/wazuh-indexer/certs/root-ca.pem"
)
context.load_cert_chain(
    certfile="/etc/wazuh-indexer/certs/admin.pem",
    keyfile="/etc/wazuh-indexer/certs/admin-key.pem"
)

url = "https://127.0.0.1:9200/_nodes/settings?flat_settings=true&filter_path=nodes.*.settings.plugins.security.audit*"
request = urllib.request.Request(url)

with urllib.request.urlopen(request, context=context, timeout=10) as response:
    data = json.loads(response.read())
    print("HTTP_STATUS:", response.status)
    print(json.dumps(data, indent=2))
PY
```

`HTTP_STATUS: 200` で、中身は `{}`（明示的な設定はない）でした。

Indexer のプロセスの起動の引数に、監査に関係するものがあるかを確かめます（引数のすべては表示しません）。

```bash
python3 - <<'PY'
from pathlib import Path

for p in Path("/proc").glob("[0-9]*/cmdline"):
    try:
        raw = p.read_bytes().replace(b"\0", b" ").decode(errors="replace")
    except (PermissionError, FileNotFoundError, ProcessLookupError):
        continue

    if "org.opensearch.bootstrap.OpenSearch" in raw:
        print("PID:", p.parent.name)
        for arg in raw.split():
            if "audit" in arg.lower():
                print("AUDIT_ARGUMENT:", arg)
        print("PROCESS_FOUND")
        break
else:
    print("OPENSEARCH_PROCESS_NOT_FOUND")
PY
```

プロセスは見つかりましたが、監査に関係する引数はありませんでした。

## 3.7　プラグイン

```bash
/usr/share/wazuh-indexer/bin/opensearch-plugin list
```

`wazuh-indexer` ユーザーで実行すると `/etc/default/wazuh-indexer` を読めずにエラーになるため、root で実行します。`opensearch-security`（監査の機能を持つプラグイン）が入っていることを確かめました。

# おわりに

第23部で調べた結果は次のとおりです。

| 項目 | 結果 |
|---|---|
| `ai_defense_alerts_read` | `wazuh-alerts-4.x-*` の `read` だけ（適切） |
| `own_index` | 同じ名前のインデックスはないので、今は影響なし |
| `ai-defense-reader` の定義 | 予約なし・バックエンドのロールなし |
| 監査の設定 | 有効（内部の設定の変更・リクエストの本文も記録） |
| 監査の出力の方式・保存先 | 明示の設定なし。保存先は**未確定** |
| JSON のログの ERROR 1件 | 原因は**未特定** |

監査ログの保存先は、中編の第24部で突き止め、第25部〜第27部で保存できるようにします。ERROR の原因は未特定のままです（不足情報メモ 23-C）。
